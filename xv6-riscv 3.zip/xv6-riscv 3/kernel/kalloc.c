// Physical memory allocator for user processes,
// kernel stacks, page-table pages,
// and pipe buffers. Allocates whole 4096-byte pages.

#include "types.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "riscv.h"
#include "defs.h"

// number of physical pages that fit below PHYSTOP
#define NPAGES (PHYSTOP / PGSIZE)

void freerange(void *pa_start, void *pa_end);

extern char end[]; // first address after kernel (defined by kernel.ld)

struct run {
  struct run *next;
};

struct {
  struct spinlock lock;
  struct run *freelist;
  int ref[NPAGES]; // reference count per physical page
} kmem;

void
kinit()
{
  initlock(&kmem.lock, "kmem");
  freerange(end, (void*)PHYSTOP);
}

// initialize free list and refcounts
void
freerange(void *pa_start, void *pa_end)
{
  char *p = (char*)PGROUNDUP((uint64)pa_start);
  for (; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
    uint64 idx = (uint64)p / PGSIZE;
    if (idx >= NPAGES)
      panic("freerange: idx out of range");
    kmem.ref[idx] = 1;    // temporary ref to allow kfree()
    kfree(p);
  }
}

// increment reference count of a physical page
void
inc(uint64 pa)
{
  if ((pa % PGSIZE) != 0 || pa < (uint64)end || pa >= PHYSTOP)
    panic("inc: bad pa");

  acquire(&kmem.lock);
  uint64 idx = pa / PGSIZE;
  if (idx >= NPAGES)
    panic("inc: idx out of range");

  kmem.ref[idx]++;
  release(&kmem.lock);
}

// decrement reference count; return new count
uint64
dec(uint64 pa)
{
  if ((pa % PGSIZE) != 0 || pa < (uint64)end || pa >= PHYSTOP)
    panic("dec: bad pa");

  acquire(&kmem.lock);
  uint64 idx = pa / PGSIZE;
  if (idx >= NPAGES)
    panic("dec: idx out of range");
  if (kmem.ref[idx] <= 0)
    panic("dec: ref underflow");

  kmem.ref[idx]--;
  int c = kmem.ref[idx];
  release(&kmem.lock);
  return c;
}

// get current refcount
uint64
get(uint64 pa)
{
  if ((pa % PGSIZE) != 0 || pa < (uint64)end || pa >= PHYSTOP)
    panic("get: bad pa");

  acquire(&kmem.lock);
  uint64 idx = pa / PGSIZE;
  if (idx >= NPAGES)
    panic("get: idx out of range");

  int c = kmem.ref[idx];
  release(&kmem.lock);
  return c;
}

// free one 4096-byte physical page
void
kfree(void *pa)
{
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (uint64)pa < (uint64)end || (uint64)pa >= PHYSTOP)
    panic("kfree: bad pa");

  // only actually free when refcount reaches 0
  if (dec((uint64)pa) > 0)
    return;

  // fill with junk to detect dangling refs
  memset(pa, 1, PGSIZE);

  r = (struct run*)pa;

  acquire(&kmem.lock);
  r->next = kmem.freelist;
  kmem.freelist = r;
  release(&kmem.lock);
}

// allocate one 4096-byte physical page
void *
kalloc(void)
{
  struct run *r;

  acquire(&kmem.lock);
  r = kmem.freelist;
  if (r)
    kmem.freelist = r->next;
  release(&kmem.lock);

  if (r) {
    memset((char*)r, 5, PGSIZE); // fill with junk
    uint64 pa = (uint64)r;
    uint64 idx = pa / PGSIZE;
    if (idx >= NPAGES)
      panic("kalloc: idx out of range");
    kmem.ref[idx] = 1;
  }

  return (void*)r;
}
