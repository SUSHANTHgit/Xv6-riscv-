
kernel/kernel:     file format elf64-littleriscv


Disassembly of section .text:

0000000080000000 <_entry>:
_entry:
        # set up a stack for C.
        # stack0 is declared in start.c,
        # with a 4096-byte stack per CPU.
        # sp = stack0 + ((hartid + 1) * 4096)
        la sp, stack0
    80000000:	00009117          	auipc	sp,0x9
    80000004:	9a010113          	addi	sp,sp,-1632 # 800089a0 <stack0>
        li a0, 1024*4
    80000008:	6505                	lui	a0,0x1
        csrr a1, mhartid
    8000000a:	f14025f3          	csrr	a1,mhartid
        addi a1, a1, 1
    8000000e:	0585                	addi	a1,a1,1
        mul a0, a0, a1
    80000010:	02b50533          	mul	a0,a0,a1
        add sp, sp, a0
    80000014:	912a                	add	sp,sp,a0
        # jump to start() in start.c
        call start
    80000016:	04e000ef          	jal	80000064 <start>

000000008000001a <spin>:
spin:
        j spin
    8000001a:	a001                	j	8000001a <spin>

000000008000001c <timerinit>:
}

// ask each hart to generate timer interrupts.
void
timerinit()
{
    8000001c:	1141                	addi	sp,sp,-16
    8000001e:	e406                	sd	ra,8(sp)
    80000020:	e022                	sd	s0,0(sp)
    80000022:	0800                	addi	s0,sp,16
#define MIE_STIE (1L << 5)  // supervisor timer
static inline uint64
r_mie()
{
  uint64 x;
  asm volatile("csrr %0, mie" : "=r" (x) );
    80000024:	304027f3          	csrr	a5,mie
  // enable supervisor-mode timer interrupts.
  w_mie(r_mie() | MIE_STIE);
    80000028:	0207e793          	ori	a5,a5,32
}

static inline void 
w_mie(uint64 x)
{
  asm volatile("csrw mie, %0" : : "r" (x));
    8000002c:	30479073          	csrw	mie,a5
static inline uint64
r_menvcfg()
{
  uint64 x;
  // asm volatile("csrr %0, menvcfg" : "=r" (x) );
  asm volatile("csrr %0, 0x30a" : "=r" (x) );
    80000030:	30a027f3          	csrr	a5,0x30a
  
  // enable the sstc extension (i.e. stimecmp).
  w_menvcfg(r_menvcfg() | (1L << 63)); 
    80000034:	577d                	li	a4,-1
    80000036:	177e                	slli	a4,a4,0x3f
    80000038:	8fd9                	or	a5,a5,a4

static inline void 
w_menvcfg(uint64 x)
{
  // asm volatile("csrw menvcfg, %0" : : "r" (x));
  asm volatile("csrw 0x30a, %0" : : "r" (x));
    8000003a:	30a79073          	csrw	0x30a,a5

static inline uint64
r_mcounteren()
{
  uint64 x;
  asm volatile("csrr %0, mcounteren" : "=r" (x) );
    8000003e:	306027f3          	csrr	a5,mcounteren
  
  // allow supervisor to use stimecmp and time.
  w_mcounteren(r_mcounteren() | 2);
    80000042:	0027e793          	ori	a5,a5,2
  asm volatile("csrw mcounteren, %0" : : "r" (x));
    80000046:	30679073          	csrw	mcounteren,a5
// machine-mode cycle counter
static inline uint64
r_time()
{
  uint64 x;
  asm volatile("csrr %0, time" : "=r" (x) );
    8000004a:	c01027f3          	rdtime	a5
  
  // ask for the very first timer interrupt.
  w_stimecmp(r_time() + 1000000);
    8000004e:	000f4737          	lui	a4,0xf4
    80000052:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    80000056:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    80000058:	14d79073          	csrw	stimecmp,a5
}
    8000005c:	60a2                	ld	ra,8(sp)
    8000005e:	6402                	ld	s0,0(sp)
    80000060:	0141                	addi	sp,sp,16
    80000062:	8082                	ret

0000000080000064 <start>:
{
    80000064:	1141                	addi	sp,sp,-16
    80000066:	e406                	sd	ra,8(sp)
    80000068:	e022                	sd	s0,0(sp)
    8000006a:	0800                	addi	s0,sp,16
  asm volatile("csrr %0, mstatus" : "=r" (x) );
    8000006c:	300027f3          	csrr	a5,mstatus
  x &= ~MSTATUS_MPP_MASK;
    80000070:	7779                	lui	a4,0xffffe
    80000072:	7ff70713          	addi	a4,a4,2047 # ffffffffffffe7ff <end+0xffffffff7fd9f697>
    80000076:	8ff9                	and	a5,a5,a4
  x |= MSTATUS_MPP_S;
    80000078:	6705                	lui	a4,0x1
    8000007a:	80070713          	addi	a4,a4,-2048 # 800 <_entry-0x7ffff800>
    8000007e:	8fd9                	or	a5,a5,a4
  asm volatile("csrw mstatus, %0" : : "r" (x));
    80000080:	30079073          	csrw	mstatus,a5
  asm volatile("csrw mepc, %0" : : "r" (x));
    80000084:	00001797          	auipc	a5,0x1
    80000088:	01e78793          	addi	a5,a5,30 # 800010a2 <main>
    8000008c:	34179073          	csrw	mepc,a5
  asm volatile("csrw satp, %0" : : "r" (x));
    80000090:	4781                	li	a5,0
    80000092:	18079073          	csrw	satp,a5
  asm volatile("csrw medeleg, %0" : : "r" (x));
    80000096:	67c1                	lui	a5,0x10
    80000098:	17fd                	addi	a5,a5,-1 # ffff <_entry-0x7fff0001>
    8000009a:	30279073          	csrw	medeleg,a5
  asm volatile("csrw mideleg, %0" : : "r" (x));
    8000009e:	30379073          	csrw	mideleg,a5
  asm volatile("csrr %0, sie" : "=r" (x) );
    800000a2:	104027f3          	csrr	a5,sie
  w_sie(r_sie() | SIE_SEIE | SIE_STIE);
    800000a6:	2207e793          	ori	a5,a5,544
  asm volatile("csrw sie, %0" : : "r" (x));
    800000aa:	10479073          	csrw	sie,a5
  asm volatile("csrw pmpaddr0, %0" : : "r" (x));
    800000ae:	57fd                	li	a5,-1
    800000b0:	83a9                	srli	a5,a5,0xa
    800000b2:	3b079073          	csrw	pmpaddr0,a5
  asm volatile("csrw pmpcfg0, %0" : : "r" (x));
    800000b6:	47bd                	li	a5,15
    800000b8:	3a079073          	csrw	pmpcfg0,a5
  timerinit();
    800000bc:	f61ff0ef          	jal	8000001c <timerinit>
  asm volatile("csrr %0, mhartid" : "=r" (x) );
    800000c0:	f14027f3          	csrr	a5,mhartid
  w_tp(id);
    800000c4:	2781                	sext.w	a5,a5
}

static inline void 
w_tp(uint64 x)
{
  asm volatile("mv tp, %0" : : "r" (x));
    800000c6:	823e                	mv	tp,a5
  asm volatile("mret");
    800000c8:	30200073          	mret
}
    800000cc:	60a2                	ld	ra,8(sp)
    800000ce:	6402                	ld	s0,0(sp)
    800000d0:	0141                	addi	sp,sp,16
    800000d2:	8082                	ret

00000000800000d4 <consolewrite>:
//
// user write()s to the console go here.
//
int
consolewrite(int user_src, uint64 src, int n)
{
    800000d4:	7119                	addi	sp,sp,-128
    800000d6:	fc86                	sd	ra,120(sp)
    800000d8:	f8a2                	sd	s0,112(sp)
    800000da:	f4a6                	sd	s1,104(sp)
    800000dc:	0100                	addi	s0,sp,128
  char buf[32];
  int i = 0;

  while(i < n){
    800000de:	06c05b63          	blez	a2,80000154 <consolewrite+0x80>
    800000e2:	f0ca                	sd	s2,96(sp)
    800000e4:	ecce                	sd	s3,88(sp)
    800000e6:	e8d2                	sd	s4,80(sp)
    800000e8:	e4d6                	sd	s5,72(sp)
    800000ea:	e0da                	sd	s6,64(sp)
    800000ec:	fc5e                	sd	s7,56(sp)
    800000ee:	f862                	sd	s8,48(sp)
    800000f0:	f466                	sd	s9,40(sp)
    800000f2:	f06a                	sd	s10,32(sp)
    800000f4:	8b2a                	mv	s6,a0
    800000f6:	8bae                	mv	s7,a1
    800000f8:	8a32                	mv	s4,a2
  int i = 0;
    800000fa:	4481                	li	s1,0
    int nn = sizeof(buf);
    if(nn > n - i)
    800000fc:	02000c93          	li	s9,32
    80000100:	02000d13          	li	s10,32
      nn = n - i;
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000104:	f8040a93          	addi	s5,s0,-128
    80000108:	5c7d                	li	s8,-1
    8000010a:	a025                	j	80000132 <consolewrite+0x5e>
    if(nn > n - i)
    8000010c:	0009099b          	sext.w	s3,s2
    if(either_copyin(buf, user_src, src+i, nn) == -1)
    80000110:	86ce                	mv	a3,s3
    80000112:	01748633          	add	a2,s1,s7
    80000116:	85da                	mv	a1,s6
    80000118:	8556                	mv	a0,s5
    8000011a:	3b8020ef          	jal	800024d2 <either_copyin>
    8000011e:	03850d63          	beq	a0,s8,80000158 <consolewrite+0x84>
      break;
    uartwrite(buf, nn);
    80000122:	85ce                	mv	a1,s3
    80000124:	8556                	mv	a0,s5
    80000126:	7b4000ef          	jal	800008da <uartwrite>
    i += nn;
    8000012a:	009904bb          	addw	s1,s2,s1
  while(i < n){
    8000012e:	0144d963          	bge	s1,s4,80000140 <consolewrite+0x6c>
    if(nn > n - i)
    80000132:	409a07bb          	subw	a5,s4,s1
    80000136:	893e                	mv	s2,a5
    80000138:	fcfcdae3          	bge	s9,a5,8000010c <consolewrite+0x38>
    8000013c:	896a                	mv	s2,s10
    8000013e:	b7f9                	j	8000010c <consolewrite+0x38>
    80000140:	7906                	ld	s2,96(sp)
    80000142:	69e6                	ld	s3,88(sp)
    80000144:	6a46                	ld	s4,80(sp)
    80000146:	6aa6                	ld	s5,72(sp)
    80000148:	6b06                	ld	s6,64(sp)
    8000014a:	7be2                	ld	s7,56(sp)
    8000014c:	7c42                	ld	s8,48(sp)
    8000014e:	7ca2                	ld	s9,40(sp)
    80000150:	7d02                	ld	s10,32(sp)
    80000152:	a821                	j	8000016a <consolewrite+0x96>
  int i = 0;
    80000154:	4481                	li	s1,0
    80000156:	a811                	j	8000016a <consolewrite+0x96>
    80000158:	7906                	ld	s2,96(sp)
    8000015a:	69e6                	ld	s3,88(sp)
    8000015c:	6a46                	ld	s4,80(sp)
    8000015e:	6aa6                	ld	s5,72(sp)
    80000160:	6b06                	ld	s6,64(sp)
    80000162:	7be2                	ld	s7,56(sp)
    80000164:	7c42                	ld	s8,48(sp)
    80000166:	7ca2                	ld	s9,40(sp)
    80000168:	7d02                	ld	s10,32(sp)
  }

  return i;
}
    8000016a:	8526                	mv	a0,s1
    8000016c:	70e6                	ld	ra,120(sp)
    8000016e:	7446                	ld	s0,112(sp)
    80000170:	74a6                	ld	s1,104(sp)
    80000172:	6109                	addi	sp,sp,128
    80000174:	8082                	ret

0000000080000176 <consoleread>:
// user_dist indicates whether dst is a user
// or kernel address.
//
int
consoleread(int user_dst, uint64 dst, int n)
{
    80000176:	711d                	addi	sp,sp,-96
    80000178:	ec86                	sd	ra,88(sp)
    8000017a:	e8a2                	sd	s0,80(sp)
    8000017c:	e4a6                	sd	s1,72(sp)
    8000017e:	e0ca                	sd	s2,64(sp)
    80000180:	fc4e                	sd	s3,56(sp)
    80000182:	f852                	sd	s4,48(sp)
    80000184:	f05a                	sd	s6,32(sp)
    80000186:	ec5e                	sd	s7,24(sp)
    80000188:	1080                	addi	s0,sp,96
    8000018a:	8b2a                	mv	s6,a0
    8000018c:	8a2e                	mv	s4,a1
    8000018e:	89b2                	mv	s3,a2
  uint target;
  int c;
  char cbuf;

  target = n;
    80000190:	8bb2                	mv	s7,a2
  acquire(&cons.lock);
    80000192:	00011517          	auipc	a0,0x11
    80000196:	80e50513          	addi	a0,a0,-2034 # 800109a0 <cons>
    8000019a:	483000ef          	jal	80000e1c <acquire>
  while(n > 0){
    // wait until interrupt handler has put some
    // input into cons.buffer.
    while(cons.r == cons.w){
    8000019e:	00011497          	auipc	s1,0x11
    800001a2:	80248493          	addi	s1,s1,-2046 # 800109a0 <cons>
      if(killed(myproc())){
        release(&cons.lock);
        return -1;
      }
      sleep(&cons.r, &cons.lock);
    800001a6:	00011917          	auipc	s2,0x11
    800001aa:	89290913          	addi	s2,s2,-1902 # 80010a38 <cons+0x98>
  while(n > 0){
    800001ae:	0b305b63          	blez	s3,80000264 <consoleread+0xee>
    while(cons.r == cons.w){
    800001b2:	0984a783          	lw	a5,152(s1)
    800001b6:	09c4a703          	lw	a4,156(s1)
    800001ba:	0af71063          	bne	a4,a5,8000025a <consoleread+0xe4>
      if(killed(myproc())){
    800001be:	173010ef          	jal	80001b30 <myproc>
    800001c2:	1a8020ef          	jal	8000236a <killed>
    800001c6:	e12d                	bnez	a0,80000228 <consoleread+0xb2>
      sleep(&cons.r, &cons.lock);
    800001c8:	85a6                	mv	a1,s1
    800001ca:	854a                	mv	a0,s2
    800001cc:	763010ef          	jal	8000212e <sleep>
    while(cons.r == cons.w){
    800001d0:	0984a783          	lw	a5,152(s1)
    800001d4:	09c4a703          	lw	a4,156(s1)
    800001d8:	fef703e3          	beq	a4,a5,800001be <consoleread+0x48>
    800001dc:	f456                	sd	s5,40(sp)
    }

    c = cons.buf[cons.r++ % INPUT_BUF_SIZE];
    800001de:	00010717          	auipc	a4,0x10
    800001e2:	7c270713          	addi	a4,a4,1986 # 800109a0 <cons>
    800001e6:	0017869b          	addiw	a3,a5,1
    800001ea:	08d72c23          	sw	a3,152(a4)
    800001ee:	07f7f693          	andi	a3,a5,127
    800001f2:	9736                	add	a4,a4,a3
    800001f4:	01874703          	lbu	a4,24(a4)
    800001f8:	00070a9b          	sext.w	s5,a4

    if(c == C('D')){  // end-of-file
    800001fc:	4691                	li	a3,4
    800001fe:	04da8663          	beq	s5,a3,8000024a <consoleread+0xd4>
      }
      break;
    }

    // copy the input byte to the user-space buffer.
    cbuf = c;
    80000202:	fae407a3          	sb	a4,-81(s0)
    if(either_copyout(user_dst, dst, &cbuf, 1) == -1)
    80000206:	4685                	li	a3,1
    80000208:	faf40613          	addi	a2,s0,-81
    8000020c:	85d2                	mv	a1,s4
    8000020e:	855a                	mv	a0,s6
    80000210:	278020ef          	jal	80002488 <either_copyout>
    80000214:	57fd                	li	a5,-1
    80000216:	04f50663          	beq	a0,a5,80000262 <consoleread+0xec>
      break;

    dst++;
    8000021a:	0a05                	addi	s4,s4,1
    --n;
    8000021c:	39fd                	addiw	s3,s3,-1

    if(c == '\n'){
    8000021e:	47a9                	li	a5,10
    80000220:	04fa8b63          	beq	s5,a5,80000276 <consoleread+0x100>
    80000224:	7aa2                	ld	s5,40(sp)
    80000226:	b761                	j	800001ae <consoleread+0x38>
        release(&cons.lock);
    80000228:	00010517          	auipc	a0,0x10
    8000022c:	77850513          	addi	a0,a0,1912 # 800109a0 <cons>
    80000230:	481000ef          	jal	80000eb0 <release>
        return -1;
    80000234:	557d                	li	a0,-1
    }
  }
  release(&cons.lock);

  return target - n;
}
    80000236:	60e6                	ld	ra,88(sp)
    80000238:	6446                	ld	s0,80(sp)
    8000023a:	64a6                	ld	s1,72(sp)
    8000023c:	6906                	ld	s2,64(sp)
    8000023e:	79e2                	ld	s3,56(sp)
    80000240:	7a42                	ld	s4,48(sp)
    80000242:	7b02                	ld	s6,32(sp)
    80000244:	6be2                	ld	s7,24(sp)
    80000246:	6125                	addi	sp,sp,96
    80000248:	8082                	ret
      if(n < target){
    8000024a:	0179fa63          	bgeu	s3,s7,8000025e <consoleread+0xe8>
        cons.r--;
    8000024e:	00010717          	auipc	a4,0x10
    80000252:	7ef72523          	sw	a5,2026(a4) # 80010a38 <cons+0x98>
    80000256:	7aa2                	ld	s5,40(sp)
    80000258:	a031                	j	80000264 <consoleread+0xee>
    8000025a:	f456                	sd	s5,40(sp)
    8000025c:	b749                	j	800001de <consoleread+0x68>
    8000025e:	7aa2                	ld	s5,40(sp)
    80000260:	a011                	j	80000264 <consoleread+0xee>
    80000262:	7aa2                	ld	s5,40(sp)
  release(&cons.lock);
    80000264:	00010517          	auipc	a0,0x10
    80000268:	73c50513          	addi	a0,a0,1852 # 800109a0 <cons>
    8000026c:	445000ef          	jal	80000eb0 <release>
  return target - n;
    80000270:	413b853b          	subw	a0,s7,s3
    80000274:	b7c9                	j	80000236 <consoleread+0xc0>
    80000276:	7aa2                	ld	s5,40(sp)
    80000278:	b7f5                	j	80000264 <consoleread+0xee>

000000008000027a <consputc>:
{
    8000027a:	1141                	addi	sp,sp,-16
    8000027c:	e406                	sd	ra,8(sp)
    8000027e:	e022                	sd	s0,0(sp)
    80000280:	0800                	addi	s0,sp,16
  if(c == BACKSPACE){
    80000282:	10000793          	li	a5,256
    80000286:	00f50863          	beq	a0,a5,80000296 <consputc+0x1c>
    uartputc_sync(c);
    8000028a:	6e4000ef          	jal	8000096e <uartputc_sync>
}
    8000028e:	60a2                	ld	ra,8(sp)
    80000290:	6402                	ld	s0,0(sp)
    80000292:	0141                	addi	sp,sp,16
    80000294:	8082                	ret
    uartputc_sync('\b'); uartputc_sync(' '); uartputc_sync('\b');
    80000296:	4521                	li	a0,8
    80000298:	6d6000ef          	jal	8000096e <uartputc_sync>
    8000029c:	02000513          	li	a0,32
    800002a0:	6ce000ef          	jal	8000096e <uartputc_sync>
    800002a4:	4521                	li	a0,8
    800002a6:	6c8000ef          	jal	8000096e <uartputc_sync>
    800002aa:	b7d5                	j	8000028e <consputc+0x14>

00000000800002ac <consoleintr>:
// do erase/kill processing, append to cons.buf,
// wake up consoleread() if a whole line has arrived.
//
void
consoleintr(int c)
{
    800002ac:	1101                	addi	sp,sp,-32
    800002ae:	ec06                	sd	ra,24(sp)
    800002b0:	e822                	sd	s0,16(sp)
    800002b2:	e426                	sd	s1,8(sp)
    800002b4:	1000                	addi	s0,sp,32
    800002b6:	84aa                	mv	s1,a0
  acquire(&cons.lock);
    800002b8:	00010517          	auipc	a0,0x10
    800002bc:	6e850513          	addi	a0,a0,1768 # 800109a0 <cons>
    800002c0:	35d000ef          	jal	80000e1c <acquire>

  switch(c){
    800002c4:	47d5                	li	a5,21
    800002c6:	08f48d63          	beq	s1,a5,80000360 <consoleintr+0xb4>
    800002ca:	0297c563          	blt	a5,s1,800002f4 <consoleintr+0x48>
    800002ce:	47a1                	li	a5,8
    800002d0:	0ef48263          	beq	s1,a5,800003b4 <consoleintr+0x108>
    800002d4:	47c1                	li	a5,16
    800002d6:	10f49363          	bne	s1,a5,800003dc <consoleintr+0x130>
  case C('P'):  // Print process list.
    procdump();
    800002da:	242020ef          	jal	8000251c <procdump>
      }
    }
    break;
  }
  
  release(&cons.lock);
    800002de:	00010517          	auipc	a0,0x10
    800002e2:	6c250513          	addi	a0,a0,1730 # 800109a0 <cons>
    800002e6:	3cb000ef          	jal	80000eb0 <release>
}
    800002ea:	60e2                	ld	ra,24(sp)
    800002ec:	6442                	ld	s0,16(sp)
    800002ee:	64a2                	ld	s1,8(sp)
    800002f0:	6105                	addi	sp,sp,32
    800002f2:	8082                	ret
  switch(c){
    800002f4:	07f00793          	li	a5,127
    800002f8:	0af48e63          	beq	s1,a5,800003b4 <consoleintr+0x108>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800002fc:	00010717          	auipc	a4,0x10
    80000300:	6a470713          	addi	a4,a4,1700 # 800109a0 <cons>
    80000304:	0a072783          	lw	a5,160(a4)
    80000308:	09872703          	lw	a4,152(a4)
    8000030c:	9f99                	subw	a5,a5,a4
    8000030e:	07f00713          	li	a4,127
    80000312:	fcf766e3          	bltu	a4,a5,800002de <consoleintr+0x32>
      c = (c == '\r') ? '\n' : c;
    80000316:	47b5                	li	a5,13
    80000318:	0cf48563          	beq	s1,a5,800003e2 <consoleintr+0x136>
      consputc(c);
    8000031c:	8526                	mv	a0,s1
    8000031e:	f5dff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    80000322:	00010717          	auipc	a4,0x10
    80000326:	67e70713          	addi	a4,a4,1662 # 800109a0 <cons>
    8000032a:	0a072683          	lw	a3,160(a4)
    8000032e:	0016879b          	addiw	a5,a3,1
    80000332:	863e                	mv	a2,a5
    80000334:	0af72023          	sw	a5,160(a4)
    80000338:	07f6f693          	andi	a3,a3,127
    8000033c:	9736                	add	a4,a4,a3
    8000033e:	00970c23          	sb	s1,24(a4)
      if(c == '\n' || c == C('D') || cons.e-cons.r == INPUT_BUF_SIZE){
    80000342:	ff648713          	addi	a4,s1,-10
    80000346:	c371                	beqz	a4,8000040a <consoleintr+0x15e>
    80000348:	14f1                	addi	s1,s1,-4
    8000034a:	c0e1                	beqz	s1,8000040a <consoleintr+0x15e>
    8000034c:	00010717          	auipc	a4,0x10
    80000350:	6ec72703          	lw	a4,1772(a4) # 80010a38 <cons+0x98>
    80000354:	9f99                	subw	a5,a5,a4
    80000356:	08000713          	li	a4,128
    8000035a:	f8e792e3          	bne	a5,a4,800002de <consoleintr+0x32>
    8000035e:	a075                	j	8000040a <consoleintr+0x15e>
    80000360:	e04a                	sd	s2,0(sp)
    while(cons.e != cons.w &&
    80000362:	00010717          	auipc	a4,0x10
    80000366:	63e70713          	addi	a4,a4,1598 # 800109a0 <cons>
    8000036a:	0a072783          	lw	a5,160(a4)
    8000036e:	09c72703          	lw	a4,156(a4)
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000372:	00010497          	auipc	s1,0x10
    80000376:	62e48493          	addi	s1,s1,1582 # 800109a0 <cons>
    while(cons.e != cons.w &&
    8000037a:	4929                	li	s2,10
    8000037c:	02f70863          	beq	a4,a5,800003ac <consoleintr+0x100>
          cons.buf[(cons.e-1) % INPUT_BUF_SIZE] != '\n'){
    80000380:	37fd                	addiw	a5,a5,-1
    80000382:	07f7f713          	andi	a4,a5,127
    80000386:	9726                	add	a4,a4,s1
    while(cons.e != cons.w &&
    80000388:	01874703          	lbu	a4,24(a4)
    8000038c:	03270263          	beq	a4,s2,800003b0 <consoleintr+0x104>
      cons.e--;
    80000390:	0af4a023          	sw	a5,160(s1)
      consputc(BACKSPACE);
    80000394:	10000513          	li	a0,256
    80000398:	ee3ff0ef          	jal	8000027a <consputc>
    while(cons.e != cons.w &&
    8000039c:	0a04a783          	lw	a5,160(s1)
    800003a0:	09c4a703          	lw	a4,156(s1)
    800003a4:	fcf71ee3          	bne	a4,a5,80000380 <consoleintr+0xd4>
    800003a8:	6902                	ld	s2,0(sp)
    800003aa:	bf15                	j	800002de <consoleintr+0x32>
    800003ac:	6902                	ld	s2,0(sp)
    800003ae:	bf05                	j	800002de <consoleintr+0x32>
    800003b0:	6902                	ld	s2,0(sp)
    800003b2:	b735                	j	800002de <consoleintr+0x32>
    if(cons.e != cons.w){
    800003b4:	00010717          	auipc	a4,0x10
    800003b8:	5ec70713          	addi	a4,a4,1516 # 800109a0 <cons>
    800003bc:	0a072783          	lw	a5,160(a4)
    800003c0:	09c72703          	lw	a4,156(a4)
    800003c4:	f0f70de3          	beq	a4,a5,800002de <consoleintr+0x32>
      cons.e--;
    800003c8:	37fd                	addiw	a5,a5,-1
    800003ca:	00010717          	auipc	a4,0x10
    800003ce:	66f72b23          	sw	a5,1654(a4) # 80010a40 <cons+0xa0>
      consputc(BACKSPACE);
    800003d2:	10000513          	li	a0,256
    800003d6:	ea5ff0ef          	jal	8000027a <consputc>
    800003da:	b711                	j	800002de <consoleintr+0x32>
    if(c != 0 && cons.e-cons.r < INPUT_BUF_SIZE){
    800003dc:	f00481e3          	beqz	s1,800002de <consoleintr+0x32>
    800003e0:	bf31                	j	800002fc <consoleintr+0x50>
      consputc(c);
    800003e2:	4529                	li	a0,10
    800003e4:	e97ff0ef          	jal	8000027a <consputc>
      cons.buf[cons.e++ % INPUT_BUF_SIZE] = c;
    800003e8:	00010797          	auipc	a5,0x10
    800003ec:	5b878793          	addi	a5,a5,1464 # 800109a0 <cons>
    800003f0:	0a07a703          	lw	a4,160(a5)
    800003f4:	0017069b          	addiw	a3,a4,1
    800003f8:	8636                	mv	a2,a3
    800003fa:	0ad7a023          	sw	a3,160(a5)
    800003fe:	07f77713          	andi	a4,a4,127
    80000402:	97ba                	add	a5,a5,a4
    80000404:	4729                	li	a4,10
    80000406:	00e78c23          	sb	a4,24(a5)
        cons.w = cons.e;
    8000040a:	00010797          	auipc	a5,0x10
    8000040e:	62c7a923          	sw	a2,1586(a5) # 80010a3c <cons+0x9c>
        wakeup(&cons.r);
    80000412:	00010517          	auipc	a0,0x10
    80000416:	62650513          	addi	a0,a0,1574 # 80010a38 <cons+0x98>
    8000041a:	561010ef          	jal	8000217a <wakeup>
    8000041e:	b5c1                	j	800002de <consoleintr+0x32>

0000000080000420 <consoleinit>:

void
consoleinit(void)
{
    80000420:	1141                	addi	sp,sp,-16
    80000422:	e406                	sd	ra,8(sp)
    80000424:	e022                	sd	s0,0(sp)
    80000426:	0800                	addi	s0,sp,16
  initlock(&cons.lock, "cons");
    80000428:	00008597          	auipc	a1,0x8
    8000042c:	bd858593          	addi	a1,a1,-1064 # 80008000 <etext>
    80000430:	00010517          	auipc	a0,0x10
    80000434:	57050513          	addi	a0,a0,1392 # 800109a0 <cons>
    80000438:	15b000ef          	jal	80000d92 <initlock>

  uartinit();
    8000043c:	448000ef          	jal	80000884 <uartinit>

  // connect read and write system calls
  // to consoleread and consolewrite.
  devsw[CONSOLE].read = consoleread;
    80000440:	00240797          	auipc	a5,0x240
    80000444:	6d078793          	addi	a5,a5,1744 # 80240b10 <devsw>
    80000448:	00000717          	auipc	a4,0x0
    8000044c:	d2e70713          	addi	a4,a4,-722 # 80000176 <consoleread>
    80000450:	eb98                	sd	a4,16(a5)
  devsw[CONSOLE].write = consolewrite;
    80000452:	00000717          	auipc	a4,0x0
    80000456:	c8270713          	addi	a4,a4,-894 # 800000d4 <consolewrite>
    8000045a:	ef98                	sd	a4,24(a5)
}
    8000045c:	60a2                	ld	ra,8(sp)
    8000045e:	6402                	ld	s0,0(sp)
    80000460:	0141                	addi	sp,sp,16
    80000462:	8082                	ret

0000000080000464 <printint>:

static char digits[] = "0123456789abcdef";

static void
printint(long long xx, int base, int sign)
{
    80000464:	7139                	addi	sp,sp,-64
    80000466:	fc06                	sd	ra,56(sp)
    80000468:	f822                	sd	s0,48(sp)
    8000046a:	f04a                	sd	s2,32(sp)
    8000046c:	0080                	addi	s0,sp,64
  char buf[20];
  int i;
  unsigned long long x;

  if(sign && (sign = (xx < 0)))
    8000046e:	c219                	beqz	a2,80000474 <printint+0x10>
    80000470:	08054163          	bltz	a0,800004f2 <printint+0x8e>
    x = -xx;
  else
    x = xx;
    80000474:	4301                	li	t1,0

  i = 0;
    80000476:	fc840913          	addi	s2,s0,-56
    x = xx;
    8000047a:	86ca                	mv	a3,s2
  i = 0;
    8000047c:	4701                	li	a4,0
  do {
    buf[i++] = digits[x % base];
    8000047e:	00008817          	auipc	a6,0x8
    80000482:	39a80813          	addi	a6,a6,922 # 80008818 <digits>
    80000486:	88ba                	mv	a7,a4
    80000488:	0017061b          	addiw	a2,a4,1
    8000048c:	8732                	mv	a4,a2
    8000048e:	02b577b3          	remu	a5,a0,a1
    80000492:	97c2                	add	a5,a5,a6
    80000494:	0007c783          	lbu	a5,0(a5)
    80000498:	00f68023          	sb	a5,0(a3)
  } while((x /= base) != 0);
    8000049c:	87aa                	mv	a5,a0
    8000049e:	02b55533          	divu	a0,a0,a1
    800004a2:	0685                	addi	a3,a3,1
    800004a4:	feb7f1e3          	bgeu	a5,a1,80000486 <printint+0x22>

  if(sign)
    800004a8:	00030c63          	beqz	t1,800004c0 <printint+0x5c>
    buf[i++] = '-';
    800004ac:	fe060793          	addi	a5,a2,-32
    800004b0:	00878633          	add	a2,a5,s0
    800004b4:	02d00793          	li	a5,45
    800004b8:	fef60423          	sb	a5,-24(a2)
    800004bc:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    800004c0:	02e05463          	blez	a4,800004e8 <printint+0x84>
    800004c4:	f426                	sd	s1,40(sp)
    800004c6:	377d                	addiw	a4,a4,-1
    800004c8:	00e904b3          	add	s1,s2,a4
    800004cc:	197d                	addi	s2,s2,-1
    800004ce:	993a                	add	s2,s2,a4
    800004d0:	1702                	slli	a4,a4,0x20
    800004d2:	9301                	srli	a4,a4,0x20
    800004d4:	40e90933          	sub	s2,s2,a4
    consputc(buf[i]);
    800004d8:	0004c503          	lbu	a0,0(s1)
    800004dc:	d9fff0ef          	jal	8000027a <consputc>
  while(--i >= 0)
    800004e0:	14fd                	addi	s1,s1,-1
    800004e2:	ff249be3          	bne	s1,s2,800004d8 <printint+0x74>
    800004e6:	74a2                	ld	s1,40(sp)
}
    800004e8:	70e2                	ld	ra,56(sp)
    800004ea:	7442                	ld	s0,48(sp)
    800004ec:	7902                	ld	s2,32(sp)
    800004ee:	6121                	addi	sp,sp,64
    800004f0:	8082                	ret
    x = -xx;
    800004f2:	40a00533          	neg	a0,a0
  if(sign && (sign = (xx < 0)))
    800004f6:	4305                	li	t1,1
    x = -xx;
    800004f8:	bfbd                	j	80000476 <printint+0x12>

00000000800004fa <printf>:
}

// Print to the console.
int
printf(char *fmt, ...)
{
    800004fa:	7131                	addi	sp,sp,-192
    800004fc:	fc86                	sd	ra,120(sp)
    800004fe:	f8a2                	sd	s0,112(sp)
    80000500:	f0ca                	sd	s2,96(sp)
    80000502:	0100                	addi	s0,sp,128
    80000504:	892a                	mv	s2,a0
    80000506:	e40c                	sd	a1,8(s0)
    80000508:	e810                	sd	a2,16(s0)
    8000050a:	ec14                	sd	a3,24(s0)
    8000050c:	f018                	sd	a4,32(s0)
    8000050e:	f41c                	sd	a5,40(s0)
    80000510:	03043823          	sd	a6,48(s0)
    80000514:	03143c23          	sd	a7,56(s0)
  va_list ap;
  int i, cx, c0, c1, c2;
  char *s;

  if(panicking == 0){
    80000518:	00008797          	auipc	a5,0x8
    8000051c:	45c7a783          	lw	a5,1116(a5) # 80008974 <panicking>
    80000520:	cf9d                	beqz	a5,8000055e <printf+0x64>
    acquire(&pr.lock);
    // acquire(&cons.lock);
  }

  va_start(ap, fmt);
    80000522:	00840793          	addi	a5,s0,8
    80000526:	f8f43423          	sd	a5,-120(s0)
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    8000052a:	00094503          	lbu	a0,0(s2)
    8000052e:	22050663          	beqz	a0,8000075a <printf+0x260>
    80000532:	f4a6                	sd	s1,104(sp)
    80000534:	ecce                	sd	s3,88(sp)
    80000536:	e8d2                	sd	s4,80(sp)
    80000538:	e4d6                	sd	s5,72(sp)
    8000053a:	e0da                	sd	s6,64(sp)
    8000053c:	fc5e                	sd	s7,56(sp)
    8000053e:	f862                	sd	s8,48(sp)
    80000540:	f06a                	sd	s10,32(sp)
    80000542:	ec6e                	sd	s11,24(sp)
    80000544:	4a01                	li	s4,0
    if(cx != '%'){
    80000546:	02500993          	li	s3,37
      printint(va_arg(ap, uint64), 10, 1);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
      printint(va_arg(ap, uint64), 10, 1);
      i += 2;
    } else if(c0 == 'u'){
    8000054a:	07500c13          	li	s8,117
      printint(va_arg(ap, uint64), 10, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
      printint(va_arg(ap, uint64), 10, 0);
      i += 2;
    } else if(c0 == 'x'){
    8000054e:	07800d13          	li	s10,120
      printint(va_arg(ap, uint64), 16, 0);
      i += 1;
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
      printint(va_arg(ap, uint64), 16, 0);
      i += 2;
    } else if(c0 == 'p'){
    80000552:	07000d93          	li	s11,112
      printint(va_arg(ap, uint64), 10, 0);
    80000556:	4b29                	li	s6,10
    if(c0 == 'd'){
    80000558:	06400b93          	li	s7,100
    8000055c:	a015                	j	80000580 <printf+0x86>
    acquire(&pr.lock);
    8000055e:	00010517          	auipc	a0,0x10
    80000562:	4ea50513          	addi	a0,a0,1258 # 80010a48 <pr>
    80000566:	0b7000ef          	jal	80000e1c <acquire>
    8000056a:	bf65                	j	80000522 <printf+0x28>
      consputc(cx);
    8000056c:	d0fff0ef          	jal	8000027a <consputc>
      continue;
    80000570:	84d2                	mv	s1,s4
  for(i = 0; (cx = fmt[i] & 0xff) != 0; i++){
    80000572:	2485                	addiw	s1,s1,1
    80000574:	8a26                	mv	s4,s1
    80000576:	94ca                	add	s1,s1,s2
    80000578:	0004c503          	lbu	a0,0(s1)
    8000057c:	1c050663          	beqz	a0,80000748 <printf+0x24e>
    if(cx != '%'){
    80000580:	ff3516e3          	bne	a0,s3,8000056c <printf+0x72>
    i++;
    80000584:	001a079b          	addiw	a5,s4,1
    80000588:	84be                	mv	s1,a5
    c0 = fmt[i+0] & 0xff;
    8000058a:	00f90733          	add	a4,s2,a5
    8000058e:	00074a83          	lbu	s5,0(a4)
    if(c0) c1 = fmt[i+1] & 0xff;
    80000592:	200a8963          	beqz	s5,800007a4 <printf+0x2aa>
    80000596:	00174683          	lbu	a3,1(a4)
    if(c1) c2 = fmt[i+2] & 0xff;
    8000059a:	1e068c63          	beqz	a3,80000792 <printf+0x298>
    if(c0 == 'd'){
    8000059e:	037a8863          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    800005a2:	f94a8713          	addi	a4,s5,-108
    800005a6:	00173713          	seqz	a4,a4
    800005aa:	f9c68613          	addi	a2,a3,-100
    800005ae:	ee05                	bnez	a2,800005e6 <printf+0xec>
    800005b0:	cb1d                	beqz	a4,800005e6 <printf+0xec>
      printint(va_arg(ap, uint64), 10, 1);
    800005b2:	f8843783          	ld	a5,-120(s0)
    800005b6:	00878713          	addi	a4,a5,8
    800005ba:	f8e43423          	sd	a4,-120(s0)
    800005be:	4605                	li	a2,1
    800005c0:	85da                	mv	a1,s6
    800005c2:	6388                	ld	a0,0(a5)
    800005c4:	ea1ff0ef          	jal	80000464 <printint>
      i += 1;
    800005c8:	002a049b          	addiw	s1,s4,2
    800005cc:	b75d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, int), 10, 1);
    800005ce:	f8843783          	ld	a5,-120(s0)
    800005d2:	00878713          	addi	a4,a5,8
    800005d6:	f8e43423          	sd	a4,-120(s0)
    800005da:	4605                	li	a2,1
    800005dc:	85da                	mv	a1,s6
    800005de:	4388                	lw	a0,0(a5)
    800005e0:	e85ff0ef          	jal	80000464 <printint>
    800005e4:	b779                	j	80000572 <printf+0x78>
    if(c1) c2 = fmt[i+2] & 0xff;
    800005e6:	97ca                	add	a5,a5,s2
    800005e8:	8636                	mv	a2,a3
    800005ea:	0027c683          	lbu	a3,2(a5)
    800005ee:	a2c9                	j	800007b0 <printf+0x2b6>
      printint(va_arg(ap, uint64), 10, 1);
    800005f0:	f8843783          	ld	a5,-120(s0)
    800005f4:	00878713          	addi	a4,a5,8
    800005f8:	f8e43423          	sd	a4,-120(s0)
    800005fc:	4605                	li	a2,1
    800005fe:	45a9                	li	a1,10
    80000600:	6388                	ld	a0,0(a5)
    80000602:	e63ff0ef          	jal	80000464 <printint>
      i += 2;
    80000606:	003a049b          	addiw	s1,s4,3
    8000060a:	b7a5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 10, 0);
    8000060c:	f8843783          	ld	a5,-120(s0)
    80000610:	00878713          	addi	a4,a5,8
    80000614:	f8e43423          	sd	a4,-120(s0)
    80000618:	4601                	li	a2,0
    8000061a:	85da                	mv	a1,s6
    8000061c:	0007e503          	lwu	a0,0(a5)
    80000620:	e45ff0ef          	jal	80000464 <printint>
    80000624:	b7b9                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000626:	f8843783          	ld	a5,-120(s0)
    8000062a:	00878713          	addi	a4,a5,8
    8000062e:	f8e43423          	sd	a4,-120(s0)
    80000632:	4601                	li	a2,0
    80000634:	85da                	mv	a1,s6
    80000636:	6388                	ld	a0,0(a5)
    80000638:	e2dff0ef          	jal	80000464 <printint>
      i += 1;
    8000063c:	002a049b          	addiw	s1,s4,2
    80000640:	bf0d                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 10, 0);
    80000642:	f8843783          	ld	a5,-120(s0)
    80000646:	00878713          	addi	a4,a5,8
    8000064a:	f8e43423          	sd	a4,-120(s0)
    8000064e:	4601                	li	a2,0
    80000650:	45a9                	li	a1,10
    80000652:	6388                	ld	a0,0(a5)
    80000654:	e11ff0ef          	jal	80000464 <printint>
      i += 2;
    80000658:	003a049b          	addiw	s1,s4,3
    8000065c:	bf19                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint32), 16, 0);
    8000065e:	f8843783          	ld	a5,-120(s0)
    80000662:	00878713          	addi	a4,a5,8
    80000666:	f8e43423          	sd	a4,-120(s0)
    8000066a:	4601                	li	a2,0
    8000066c:	45c1                	li	a1,16
    8000066e:	0007e503          	lwu	a0,0(a5)
    80000672:	df3ff0ef          	jal	80000464 <printint>
    80000676:	bdf5                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000678:	f8843783          	ld	a5,-120(s0)
    8000067c:	00878713          	addi	a4,a5,8
    80000680:	f8e43423          	sd	a4,-120(s0)
    80000684:	45c1                	li	a1,16
    80000686:	6388                	ld	a0,0(a5)
    80000688:	dddff0ef          	jal	80000464 <printint>
      i += 1;
    8000068c:	002a049b          	addiw	s1,s4,2
    80000690:	b5cd                	j	80000572 <printf+0x78>
      printint(va_arg(ap, uint64), 16, 0);
    80000692:	f8843783          	ld	a5,-120(s0)
    80000696:	00878713          	addi	a4,a5,8
    8000069a:	f8e43423          	sd	a4,-120(s0)
    8000069e:	4601                	li	a2,0
    800006a0:	45c1                	li	a1,16
    800006a2:	6388                	ld	a0,0(a5)
    800006a4:	dc1ff0ef          	jal	80000464 <printint>
      i += 2;
    800006a8:	003a049b          	addiw	s1,s4,3
    800006ac:	b5d9                	j	80000572 <printf+0x78>
    800006ae:	f466                	sd	s9,40(sp)
      printptr(va_arg(ap, uint64));
    800006b0:	f8843783          	ld	a5,-120(s0)
    800006b4:	00878713          	addi	a4,a5,8
    800006b8:	f8e43423          	sd	a4,-120(s0)
    800006bc:	0007ba83          	ld	s5,0(a5)
  consputc('0');
    800006c0:	03000513          	li	a0,48
    800006c4:	bb7ff0ef          	jal	8000027a <consputc>
  consputc('x');
    800006c8:	07800513          	li	a0,120
    800006cc:	bafff0ef          	jal	8000027a <consputc>
    800006d0:	4a41                	li	s4,16
    consputc(digits[x >> (sizeof(uint64) * 8 - 4)]);
    800006d2:	00008c97          	auipc	s9,0x8
    800006d6:	146c8c93          	addi	s9,s9,326 # 80008818 <digits>
    800006da:	03cad793          	srli	a5,s5,0x3c
    800006de:	97e6                	add	a5,a5,s9
    800006e0:	0007c503          	lbu	a0,0(a5)
    800006e4:	b97ff0ef          	jal	8000027a <consputc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    800006e8:	0a92                	slli	s5,s5,0x4
    800006ea:	3a7d                	addiw	s4,s4,-1
    800006ec:	fe0a17e3          	bnez	s4,800006da <printf+0x1e0>
    800006f0:	7ca2                	ld	s9,40(sp)
    800006f2:	b541                	j	80000572 <printf+0x78>
    } else if(c0 == 'c'){
      consputc(va_arg(ap, uint));
    800006f4:	f8843783          	ld	a5,-120(s0)
    800006f8:	00878713          	addi	a4,a5,8
    800006fc:	f8e43423          	sd	a4,-120(s0)
    80000700:	4388                	lw	a0,0(a5)
    80000702:	b79ff0ef          	jal	8000027a <consputc>
    80000706:	b5b5                	j	80000572 <printf+0x78>
    } else if(c0 == 's'){
      if((s = va_arg(ap, char*)) == 0)
    80000708:	f8843783          	ld	a5,-120(s0)
    8000070c:	00878713          	addi	a4,a5,8
    80000710:	f8e43423          	sd	a4,-120(s0)
    80000714:	0007ba03          	ld	s4,0(a5)
    80000718:	000a0d63          	beqz	s4,80000732 <printf+0x238>
        s = "(null)";
      for(; *s; s++)
    8000071c:	000a4503          	lbu	a0,0(s4)
    80000720:	e40509e3          	beqz	a0,80000572 <printf+0x78>
        consputc(*s);
    80000724:	b57ff0ef          	jal	8000027a <consputc>
      for(; *s; s++)
    80000728:	0a05                	addi	s4,s4,1
    8000072a:	000a4503          	lbu	a0,0(s4)
    8000072e:	f97d                	bnez	a0,80000724 <printf+0x22a>
    80000730:	b589                	j	80000572 <printf+0x78>
        s = "(null)";
    80000732:	00008a17          	auipc	s4,0x8
    80000736:	8d6a0a13          	addi	s4,s4,-1834 # 80008008 <etext+0x8>
      for(; *s; s++)
    8000073a:	02800513          	li	a0,40
    8000073e:	b7dd                	j	80000724 <printf+0x22a>
    } else if(c0 == '%'){
      consputc('%');
    80000740:	8556                	mv	a0,s5
    80000742:	b39ff0ef          	jal	8000027a <consputc>
    80000746:	b535                	j	80000572 <printf+0x78>
    80000748:	74a6                	ld	s1,104(sp)
    8000074a:	69e6                	ld	s3,88(sp)
    8000074c:	6a46                	ld	s4,80(sp)
    8000074e:	6aa6                	ld	s5,72(sp)
    80000750:	6b06                	ld	s6,64(sp)
    80000752:	7be2                	ld	s7,56(sp)
    80000754:	7c42                	ld	s8,48(sp)
    80000756:	7d02                	ld	s10,32(sp)
    80000758:	6de2                	ld	s11,24(sp)
    }

  }
  va_end(ap);

  if(panicking == 0)
    8000075a:	00008797          	auipc	a5,0x8
    8000075e:	21a7a783          	lw	a5,538(a5) # 80008974 <panicking>
    80000762:	c38d                	beqz	a5,80000784 <printf+0x28a>
   { release(&pr.lock);
    //  release(&cons.lock);
  }

  return 0;
}
    80000764:	4501                	li	a0,0
    80000766:	70e6                	ld	ra,120(sp)
    80000768:	7446                	ld	s0,112(sp)
    8000076a:	7906                	ld	s2,96(sp)
    8000076c:	6129                	addi	sp,sp,192
    8000076e:	8082                	ret
    80000770:	74a6                	ld	s1,104(sp)
    80000772:	69e6                	ld	s3,88(sp)
    80000774:	6a46                	ld	s4,80(sp)
    80000776:	6aa6                	ld	s5,72(sp)
    80000778:	6b06                	ld	s6,64(sp)
    8000077a:	7be2                	ld	s7,56(sp)
    8000077c:	7c42                	ld	s8,48(sp)
    8000077e:	7d02                	ld	s10,32(sp)
    80000780:	6de2                	ld	s11,24(sp)
    80000782:	bfe1                	j	8000075a <printf+0x260>
   { release(&pr.lock);
    80000784:	00010517          	auipc	a0,0x10
    80000788:	2c450513          	addi	a0,a0,708 # 80010a48 <pr>
    8000078c:	724000ef          	jal	80000eb0 <release>
  return 0;
    80000790:	bfd1                	j	80000764 <printf+0x26a>
    if(c0 == 'd'){
    80000792:	e37a8ee3          	beq	s5,s7,800005ce <printf+0xd4>
    } else if(c0 == 'l' && c1 == 'd'){
    80000796:	f94a8713          	addi	a4,s5,-108
    8000079a:	00173713          	seqz	a4,a4
    8000079e:	8636                	mv	a2,a3
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007a0:	4781                	li	a5,0
    800007a2:	a00d                	j	800007c4 <printf+0x2ca>
    } else if(c0 == 'l' && c1 == 'd'){
    800007a4:	f94a8713          	addi	a4,s5,-108
    800007a8:	00173713          	seqz	a4,a4
    c1 = c2 = 0;
    800007ac:	8656                	mv	a2,s5
    800007ae:	86d6                	mv	a3,s5
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    800007b0:	f9460793          	addi	a5,a2,-108
    800007b4:	0017b793          	seqz	a5,a5
    800007b8:	8ff9                	and	a5,a5,a4
    800007ba:	f9c68593          	addi	a1,a3,-100
    800007be:	e199                	bnez	a1,800007c4 <printf+0x2ca>
    800007c0:	e20798e3          	bnez	a5,800005f0 <printf+0xf6>
    } else if(c0 == 'u'){
    800007c4:	e58a84e3          	beq	s5,s8,8000060c <printf+0x112>
    } else if(c0 == 'l' && c1 == 'u'){
    800007c8:	f8b60593          	addi	a1,a2,-117
    800007cc:	e199                	bnez	a1,800007d2 <printf+0x2d8>
    800007ce:	e4071ce3          	bnez	a4,80000626 <printf+0x12c>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    800007d2:	f8b68593          	addi	a1,a3,-117
    800007d6:	e199                	bnez	a1,800007dc <printf+0x2e2>
    800007d8:	e60795e3          	bnez	a5,80000642 <printf+0x148>
    } else if(c0 == 'x'){
    800007dc:	e9aa81e3          	beq	s5,s10,8000065e <printf+0x164>
    } else if(c0 == 'l' && c1 == 'x'){
    800007e0:	f8860613          	addi	a2,a2,-120
    800007e4:	e219                	bnez	a2,800007ea <printf+0x2f0>
    800007e6:	e80719e3          	bnez	a4,80000678 <printf+0x17e>
    } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    800007ea:	f8868693          	addi	a3,a3,-120
    800007ee:	e299                	bnez	a3,800007f4 <printf+0x2fa>
    800007f0:	ea0791e3          	bnez	a5,80000692 <printf+0x198>
    } else if(c0 == 'p'){
    800007f4:	ebba8de3          	beq	s5,s11,800006ae <printf+0x1b4>
    } else if(c0 == 'c'){
    800007f8:	06300793          	li	a5,99
    800007fc:	eefa8ce3          	beq	s5,a5,800006f4 <printf+0x1fa>
    } else if(c0 == 's'){
    80000800:	07300793          	li	a5,115
    80000804:	f0fa82e3          	beq	s5,a5,80000708 <printf+0x20e>
    } else if(c0 == '%'){
    80000808:	02500793          	li	a5,37
    8000080c:	f2fa8ae3          	beq	s5,a5,80000740 <printf+0x246>
    } else if(c0 == 0){
    80000810:	f60a80e3          	beqz	s5,80000770 <printf+0x276>
      consputc('%');
    80000814:	02500513          	li	a0,37
    80000818:	a63ff0ef          	jal	8000027a <consputc>
      consputc(c0);
    8000081c:	8556                	mv	a0,s5
    8000081e:	a5dff0ef          	jal	8000027a <consputc>
    80000822:	bb81                	j	80000572 <printf+0x78>

0000000080000824 <panic>:

void
panic(char *s)
{
    80000824:	1101                	addi	sp,sp,-32
    80000826:	ec06                	sd	ra,24(sp)
    80000828:	e822                	sd	s0,16(sp)
    8000082a:	e426                	sd	s1,8(sp)
    8000082c:	e04a                	sd	s2,0(sp)
    8000082e:	1000                	addi	s0,sp,32
    80000830:	892a                	mv	s2,a0
  panicking = 1;
    80000832:	4485                	li	s1,1
    80000834:	00008797          	auipc	a5,0x8
    80000838:	1497a023          	sw	s1,320(a5) # 80008974 <panicking>
  printf("panic: ");
    8000083c:	00007517          	auipc	a0,0x7
    80000840:	7dc50513          	addi	a0,a0,2012 # 80008018 <etext+0x18>
    80000844:	cb7ff0ef          	jal	800004fa <printf>
  printf("%s\n", s);
    80000848:	85ca                	mv	a1,s2
    8000084a:	00007517          	auipc	a0,0x7
    8000084e:	7d650513          	addi	a0,a0,2006 # 80008020 <etext+0x20>
    80000852:	ca9ff0ef          	jal	800004fa <printf>
  panicked = 1; // freeze uart output from other CPUs
    80000856:	00008797          	auipc	a5,0x8
    8000085a:	1097ad23          	sw	s1,282(a5) # 80008970 <panicked>
  for(;;)
    8000085e:	a001                	j	8000085e <panic+0x3a>

0000000080000860 <printfinit>:
    ;
}

void
printfinit(void)
{
    80000860:	1141                	addi	sp,sp,-16
    80000862:	e406                	sd	ra,8(sp)
    80000864:	e022                	sd	s0,0(sp)
    80000866:	0800                	addi	s0,sp,16
  initlock(&pr.lock, "pr");
    80000868:	00007597          	auipc	a1,0x7
    8000086c:	7c058593          	addi	a1,a1,1984 # 80008028 <etext+0x28>
    80000870:	00010517          	auipc	a0,0x10
    80000874:	1d850513          	addi	a0,a0,472 # 80010a48 <pr>
    80000878:	51a000ef          	jal	80000d92 <initlock>
}
    8000087c:	60a2                	ld	ra,8(sp)
    8000087e:	6402                	ld	s0,0(sp)
    80000880:	0141                	addi	sp,sp,16
    80000882:	8082                	ret

0000000080000884 <uartinit>:
extern volatile int panicking; // from printf.c
extern volatile int panicked; // from printf.c

void
uartinit(void)
{
    80000884:	1141                	addi	sp,sp,-16
    80000886:	e406                	sd	ra,8(sp)
    80000888:	e022                	sd	s0,0(sp)
    8000088a:	0800                	addi	s0,sp,16
  // disable interrupts.
  WriteReg(IER, 0x00);
    8000088c:	100007b7          	lui	a5,0x10000
    80000890:	000780a3          	sb	zero,1(a5) # 10000001 <_entry-0x6fffffff>

  // special mode to set baud rate.
  WriteReg(LCR, LCR_BAUD_LATCH);
    80000894:	10000737          	lui	a4,0x10000
    80000898:	f8000693          	li	a3,-128
    8000089c:	00d701a3          	sb	a3,3(a4) # 10000003 <_entry-0x6ffffffd>

  // LSB for baud rate of 38.4K.
  WriteReg(0, 0x03);
    800008a0:	468d                	li	a3,3
    800008a2:	10000637          	lui	a2,0x10000
    800008a6:	00d60023          	sb	a3,0(a2) # 10000000 <_entry-0x70000000>

  // MSB for baud rate of 38.4K.
  WriteReg(1, 0x00);
    800008aa:	000780a3          	sb	zero,1(a5)

  // leave set-baud mode,
  // and set word length to 8 bits, no parity.
  WriteReg(LCR, LCR_EIGHT_BITS);
    800008ae:	00d701a3          	sb	a3,3(a4)

  // reset and enable FIFOs.
  WriteReg(FCR, FCR_FIFO_ENABLE | FCR_FIFO_CLEAR);
    800008b2:	8732                	mv	a4,a2
    800008b4:	461d                	li	a2,7
    800008b6:	00c70123          	sb	a2,2(a4)

  // enable transmit and receive interrupts.
  WriteReg(IER, IER_TX_ENABLE | IER_RX_ENABLE);
    800008ba:	00d780a3          	sb	a3,1(a5)

  initlock(&tx_lock, "uart");
    800008be:	00007597          	auipc	a1,0x7
    800008c2:	77258593          	addi	a1,a1,1906 # 80008030 <etext+0x30>
    800008c6:	00010517          	auipc	a0,0x10
    800008ca:	19a50513          	addi	a0,a0,410 # 80010a60 <tx_lock>
    800008ce:	4c4000ef          	jal	80000d92 <initlock>
}
    800008d2:	60a2                	ld	ra,8(sp)
    800008d4:	6402                	ld	s0,0(sp)
    800008d6:	0141                	addi	sp,sp,16
    800008d8:	8082                	ret

00000000800008da <uartwrite>:
// transmit buf[] to the uart. it blocks if the
// uart is busy, so it cannot be called from
// interrupts, only from write() system calls.
void
uartwrite(char buf[], int n)
{
    800008da:	715d                	addi	sp,sp,-80
    800008dc:	e486                	sd	ra,72(sp)
    800008de:	e0a2                	sd	s0,64(sp)
    800008e0:	fc26                	sd	s1,56(sp)
    800008e2:	ec56                	sd	s5,24(sp)
    800008e4:	0880                	addi	s0,sp,80
    800008e6:	8aaa                	mv	s5,a0
    800008e8:	84ae                	mv	s1,a1
  acquire(&tx_lock);
    800008ea:	00010517          	auipc	a0,0x10
    800008ee:	17650513          	addi	a0,a0,374 # 80010a60 <tx_lock>
    800008f2:	52a000ef          	jal	80000e1c <acquire>

  int i = 0;
  while(i < n){ 
    800008f6:	06905063          	blez	s1,80000956 <uartwrite+0x7c>
    800008fa:	f84a                	sd	s2,48(sp)
    800008fc:	f44e                	sd	s3,40(sp)
    800008fe:	f052                	sd	s4,32(sp)
    80000900:	e85a                	sd	s6,16(sp)
    80000902:	e45e                	sd	s7,8(sp)
    80000904:	8a56                	mv	s4,s5
    80000906:	9aa6                	add	s5,s5,s1
    while(tx_busy != 0){
    80000908:	00008497          	auipc	s1,0x8
    8000090c:	07448493          	addi	s1,s1,116 # 8000897c <tx_busy>
      // wait for a UART transmit-complete interrupt
      // to set tx_busy to 0.
      sleep(&tx_chan, &tx_lock);
    80000910:	00010997          	auipc	s3,0x10
    80000914:	15098993          	addi	s3,s3,336 # 80010a60 <tx_lock>
    80000918:	00008917          	auipc	s2,0x8
    8000091c:	06090913          	addi	s2,s2,96 # 80008978 <tx_chan>
    }   
      
    WriteReg(THR, buf[i]);
    80000920:	10000bb7          	lui	s7,0x10000
    i += 1;
    tx_busy = 1;
    80000924:	4b05                	li	s6,1
    80000926:	a005                	j	80000946 <uartwrite+0x6c>
      sleep(&tx_chan, &tx_lock);
    80000928:	85ce                	mv	a1,s3
    8000092a:	854a                	mv	a0,s2
    8000092c:	003010ef          	jal	8000212e <sleep>
    while(tx_busy != 0){
    80000930:	409c                	lw	a5,0(s1)
    80000932:	fbfd                	bnez	a5,80000928 <uartwrite+0x4e>
    WriteReg(THR, buf[i]);
    80000934:	000a4783          	lbu	a5,0(s4)
    80000938:	00fb8023          	sb	a5,0(s7) # 10000000 <_entry-0x70000000>
    tx_busy = 1;
    8000093c:	0164a023          	sw	s6,0(s1)
  while(i < n){ 
    80000940:	0a05                	addi	s4,s4,1
    80000942:	015a0563          	beq	s4,s5,8000094c <uartwrite+0x72>
    while(tx_busy != 0){
    80000946:	409c                	lw	a5,0(s1)
    80000948:	f3e5                	bnez	a5,80000928 <uartwrite+0x4e>
    8000094a:	b7ed                	j	80000934 <uartwrite+0x5a>
    8000094c:	7942                	ld	s2,48(sp)
    8000094e:	79a2                	ld	s3,40(sp)
    80000950:	7a02                	ld	s4,32(sp)
    80000952:	6b42                	ld	s6,16(sp)
    80000954:	6ba2                	ld	s7,8(sp)
  }

  release(&tx_lock);
    80000956:	00010517          	auipc	a0,0x10
    8000095a:	10a50513          	addi	a0,a0,266 # 80010a60 <tx_lock>
    8000095e:	552000ef          	jal	80000eb0 <release>
}
    80000962:	60a6                	ld	ra,72(sp)
    80000964:	6406                	ld	s0,64(sp)
    80000966:	74e2                	ld	s1,56(sp)
    80000968:	6ae2                	ld	s5,24(sp)
    8000096a:	6161                	addi	sp,sp,80
    8000096c:	8082                	ret

000000008000096e <uartputc_sync>:
// interrupts, for use by kernel printf() and
// to echo characters. it spins waiting for the uart's
// output register to be empty.
void
uartputc_sync(int c)
{
    8000096e:	1101                	addi	sp,sp,-32
    80000970:	ec06                	sd	ra,24(sp)
    80000972:	e822                	sd	s0,16(sp)
    80000974:	e426                	sd	s1,8(sp)
    80000976:	1000                	addi	s0,sp,32
    80000978:	84aa                	mv	s1,a0
  if(panicking == 0)
    8000097a:	00008797          	auipc	a5,0x8
    8000097e:	ffa7a783          	lw	a5,-6(a5) # 80008974 <panicking>
    80000982:	cf95                	beqz	a5,800009be <uartputc_sync+0x50>
    push_off();

  if(panicked){
    80000984:	00008797          	auipc	a5,0x8
    80000988:	fec7a783          	lw	a5,-20(a5) # 80008970 <panicked>
    8000098c:	ef85                	bnez	a5,800009c4 <uartputc_sync+0x56>
    for(;;)
      ;
  }

  // wait for Transmit Holding Empty to be set in LSR.
  while((ReadReg(LSR) & LSR_TX_IDLE) == 0)
    8000098e:	10000737          	lui	a4,0x10000
    80000992:	0715                	addi	a4,a4,5 # 10000005 <_entry-0x6ffffffb>
    80000994:	00074783          	lbu	a5,0(a4)
    80000998:	0207f793          	andi	a5,a5,32
    8000099c:	dfe5                	beqz	a5,80000994 <uartputc_sync+0x26>
    ;
  WriteReg(THR, c);
    8000099e:	0ff4f513          	zext.b	a0,s1
    800009a2:	100007b7          	lui	a5,0x10000
    800009a6:	00a78023          	sb	a0,0(a5) # 10000000 <_entry-0x70000000>

  if(panicking == 0)
    800009aa:	00008797          	auipc	a5,0x8
    800009ae:	fca7a783          	lw	a5,-54(a5) # 80008974 <panicking>
    800009b2:	cb91                	beqz	a5,800009c6 <uartputc_sync+0x58>
    pop_off();
}
    800009b4:	60e2                	ld	ra,24(sp)
    800009b6:	6442                	ld	s0,16(sp)
    800009b8:	64a2                	ld	s1,8(sp)
    800009ba:	6105                	addi	sp,sp,32
    800009bc:	8082                	ret
    push_off();
    800009be:	41a000ef          	jal	80000dd8 <push_off>
    800009c2:	b7c9                	j	80000984 <uartputc_sync+0x16>
    for(;;)
    800009c4:	a001                	j	800009c4 <uartputc_sync+0x56>
    pop_off();
    800009c6:	49a000ef          	jal	80000e60 <pop_off>
}
    800009ca:	b7ed                	j	800009b4 <uartputc_sync+0x46>

00000000800009cc <uartgetc>:

// read one input character from the UART.
// return -1 if none is waiting.
int
uartgetc(void)
{
    800009cc:	1141                	addi	sp,sp,-16
    800009ce:	e406                	sd	ra,8(sp)
    800009d0:	e022                	sd	s0,0(sp)
    800009d2:	0800                	addi	s0,sp,16
  if(ReadReg(LSR) & LSR_RX_READY){
    800009d4:	100007b7          	lui	a5,0x10000
    800009d8:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    800009dc:	8b85                	andi	a5,a5,1
    800009de:	cb89                	beqz	a5,800009f0 <uartgetc+0x24>
    // input data is ready.
    return ReadReg(RHR);
    800009e0:	100007b7          	lui	a5,0x10000
    800009e4:	0007c503          	lbu	a0,0(a5) # 10000000 <_entry-0x70000000>
  } else {
    return -1;
  }
}
    800009e8:	60a2                	ld	ra,8(sp)
    800009ea:	6402                	ld	s0,0(sp)
    800009ec:	0141                	addi	sp,sp,16
    800009ee:	8082                	ret
    return -1;
    800009f0:	557d                	li	a0,-1
    800009f2:	bfdd                	j	800009e8 <uartgetc+0x1c>

00000000800009f4 <uartintr>:
// handle a uart interrupt, raised because input has
// arrived, or the uart is ready for more output, or
// both. called from devintr().
void
uartintr(void)
{
    800009f4:	1101                	addi	sp,sp,-32
    800009f6:	ec06                	sd	ra,24(sp)
    800009f8:	e822                	sd	s0,16(sp)
    800009fa:	e426                	sd	s1,8(sp)
    800009fc:	1000                	addi	s0,sp,32
  ReadReg(ISR); // acknowledge the interrupt
    800009fe:	100007b7          	lui	a5,0x10000
    80000a02:	0027c783          	lbu	a5,2(a5) # 10000002 <_entry-0x6ffffffe>

  acquire(&tx_lock);
    80000a06:	00010517          	auipc	a0,0x10
    80000a0a:	05a50513          	addi	a0,a0,90 # 80010a60 <tx_lock>
    80000a0e:	40e000ef          	jal	80000e1c <acquire>
  if(ReadReg(LSR) & LSR_TX_IDLE){
    80000a12:	100007b7          	lui	a5,0x10000
    80000a16:	0057c783          	lbu	a5,5(a5) # 10000005 <_entry-0x6ffffffb>
    80000a1a:	0207f793          	andi	a5,a5,32
    80000a1e:	ef99                	bnez	a5,80000a3c <uartintr+0x48>
    // UART finished transmitting; wake up sending thread.
    tx_busy = 0;
    wakeup(&tx_chan);
  }
  release(&tx_lock);
    80000a20:	00010517          	auipc	a0,0x10
    80000a24:	04050513          	addi	a0,a0,64 # 80010a60 <tx_lock>
    80000a28:	488000ef          	jal	80000eb0 <release>

  // read and process incoming characters.
  while(1){
    int c = uartgetc();
    if(c == -1)
    80000a2c:	54fd                	li	s1,-1
    int c = uartgetc();
    80000a2e:	f9fff0ef          	jal	800009cc <uartgetc>
    if(c == -1)
    80000a32:	02950063          	beq	a0,s1,80000a52 <uartintr+0x5e>
      break;
    consoleintr(c);
    80000a36:	877ff0ef          	jal	800002ac <consoleintr>
  while(1){
    80000a3a:	bfd5                	j	80000a2e <uartintr+0x3a>
    tx_busy = 0;
    80000a3c:	00008797          	auipc	a5,0x8
    80000a40:	f407a023          	sw	zero,-192(a5) # 8000897c <tx_busy>
    wakeup(&tx_chan);
    80000a44:	00008517          	auipc	a0,0x8
    80000a48:	f3450513          	addi	a0,a0,-204 # 80008978 <tx_chan>
    80000a4c:	72e010ef          	jal	8000217a <wakeup>
    80000a50:	bfc1                	j	80000a20 <uartintr+0x2c>
  }
}
    80000a52:	60e2                	ld	ra,24(sp)
    80000a54:	6442                	ld	s0,16(sp)
    80000a56:	64a2                	ld	s1,8(sp)
    80000a58:	6105                	addi	sp,sp,32
    80000a5a:	8082                	ret

0000000080000a5c <inc>:
}

// increment reference count of a physical page
void
inc(uint64 pa)
{
    80000a5c:	1101                	addi	sp,sp,-32
    80000a5e:	ec06                	sd	ra,24(sp)
    80000a60:	e822                	sd	s0,16(sp)
    80000a62:	e426                	sd	s1,8(sp)
    80000a64:	1000                	addi	s0,sp,32
  if ((pa % PGSIZE) != 0 || pa < (uint64)end || pa >= PHYSTOP)
    80000a66:	0025e797          	auipc	a5,0x25e
    80000a6a:	70278793          	addi	a5,a5,1794 # 8025f168 <end>
    80000a6e:	00f53733          	sltu	a4,a0,a5
    80000a72:	47c5                	li	a5,17
    80000a74:	07ee                	slli	a5,a5,0x1b
    80000a76:	17fd                	addi	a5,a5,-1
    80000a78:	00a7b7b3          	sltu	a5,a5,a0
    80000a7c:	8fd9                	or	a5,a5,a4
    80000a7e:	e3b1                	bnez	a5,80000ac2 <inc+0x66>
    80000a80:	84aa                	mv	s1,a0
    80000a82:	03451793          	slli	a5,a0,0x34
    80000a86:	ef95                	bnez	a5,80000ac2 <inc+0x66>
    panic("inc: bad pa");

  acquire(&kmem.lock);
    80000a88:	00010517          	auipc	a0,0x10
    80000a8c:	ff050513          	addi	a0,a0,-16 # 80010a78 <kmem>
    80000a90:	38c000ef          	jal	80000e1c <acquire>
  uint64 idx = pa / PGSIZE;
    80000a94:	80b1                	srli	s1,s1,0xc
  if (idx >= NPAGES)
    panic("inc: idx out of range");

  kmem.ref[idx]++;
    80000a96:	048a                	slli	s1,s1,0x2
    80000a98:	02048493          	addi	s1,s1,32
    80000a9c:	00010797          	auipc	a5,0x10
    80000aa0:	fdc78793          	addi	a5,a5,-36 # 80010a78 <kmem>
    80000aa4:	97a6                	add	a5,a5,s1
    80000aa6:	4398                	lw	a4,0(a5)
    80000aa8:	2705                	addiw	a4,a4,1
    80000aaa:	c398                	sw	a4,0(a5)
  release(&kmem.lock);
    80000aac:	00010517          	auipc	a0,0x10
    80000ab0:	fcc50513          	addi	a0,a0,-52 # 80010a78 <kmem>
    80000ab4:	3fc000ef          	jal	80000eb0 <release>
}
    80000ab8:	60e2                	ld	ra,24(sp)
    80000aba:	6442                	ld	s0,16(sp)
    80000abc:	64a2                	ld	s1,8(sp)
    80000abe:	6105                	addi	sp,sp,32
    80000ac0:	8082                	ret
    panic("inc: bad pa");
    80000ac2:	00007517          	auipc	a0,0x7
    80000ac6:	57650513          	addi	a0,a0,1398 # 80008038 <etext+0x38>
    80000aca:	d5bff0ef          	jal	80000824 <panic>

0000000080000ace <dec>:

// decrement reference count; return new count
uint64
dec(uint64 pa)
{
    80000ace:	1101                	addi	sp,sp,-32
    80000ad0:	ec06                	sd	ra,24(sp)
    80000ad2:	e822                	sd	s0,16(sp)
    80000ad4:	e426                	sd	s1,8(sp)
    80000ad6:	e04a                	sd	s2,0(sp)
    80000ad8:	1000                	addi	s0,sp,32
  if ((pa % PGSIZE) != 0 || pa < (uint64)end || pa >= PHYSTOP)
    80000ada:	0025e797          	auipc	a5,0x25e
    80000ade:	68e78793          	addi	a5,a5,1678 # 8025f168 <end>
    80000ae2:	00f53733          	sltu	a4,a0,a5
    80000ae6:	47c5                	li	a5,17
    80000ae8:	07ee                	slli	a5,a5,0x1b
    80000aea:	17fd                	addi	a5,a5,-1
    80000aec:	00a7b7b3          	sltu	a5,a5,a0
    80000af0:	8fd9                	or	a5,a5,a4
    80000af2:	e3ad                	bnez	a5,80000b54 <dec+0x86>
    80000af4:	84aa                	mv	s1,a0
    80000af6:	03451793          	slli	a5,a0,0x34
    80000afa:	efa9                	bnez	a5,80000b54 <dec+0x86>
    panic("dec: bad pa");

  acquire(&kmem.lock);
    80000afc:	00010517          	auipc	a0,0x10
    80000b00:	f7c50513          	addi	a0,a0,-132 # 80010a78 <kmem>
    80000b04:	318000ef          	jal	80000e1c <acquire>
  uint64 idx = pa / PGSIZE;
    80000b08:	80b1                	srli	s1,s1,0xc
  if (idx >= NPAGES)
    panic("dec: idx out of range");
  if (kmem.ref[idx] <= 0)
    80000b0a:	00249713          	slli	a4,s1,0x2
    80000b0e:	02070713          	addi	a4,a4,32
    80000b12:	00010797          	auipc	a5,0x10
    80000b16:	f6678793          	addi	a5,a5,-154 # 80010a78 <kmem>
    80000b1a:	97ba                	add	a5,a5,a4
    80000b1c:	0007a903          	lw	s2,0(a5)
    80000b20:	05205063          	blez	s2,80000b60 <dec+0x92>
    panic("dec: ref underflow");

  kmem.ref[idx]--;
    80000b24:	397d                	addiw	s2,s2,-1
    80000b26:	048a                	slli	s1,s1,0x2
    80000b28:	02048493          	addi	s1,s1,32
    80000b2c:	00010797          	auipc	a5,0x10
    80000b30:	f4c78793          	addi	a5,a5,-180 # 80010a78 <kmem>
    80000b34:	97a6                	add	a5,a5,s1
    80000b36:	0127a023          	sw	s2,0(a5)
  int c = kmem.ref[idx];
  release(&kmem.lock);
    80000b3a:	00010517          	auipc	a0,0x10
    80000b3e:	f3e50513          	addi	a0,a0,-194 # 80010a78 <kmem>
    80000b42:	36e000ef          	jal	80000eb0 <release>
  return c;
}
    80000b46:	854a                	mv	a0,s2
    80000b48:	60e2                	ld	ra,24(sp)
    80000b4a:	6442                	ld	s0,16(sp)
    80000b4c:	64a2                	ld	s1,8(sp)
    80000b4e:	6902                	ld	s2,0(sp)
    80000b50:	6105                	addi	sp,sp,32
    80000b52:	8082                	ret
    panic("dec: bad pa");
    80000b54:	00007517          	auipc	a0,0x7
    80000b58:	4f450513          	addi	a0,a0,1268 # 80008048 <etext+0x48>
    80000b5c:	cc9ff0ef          	jal	80000824 <panic>
    panic("dec: ref underflow");
    80000b60:	00007517          	auipc	a0,0x7
    80000b64:	4f850513          	addi	a0,a0,1272 # 80008058 <etext+0x58>
    80000b68:	cbdff0ef          	jal	80000824 <panic>

0000000080000b6c <get>:

// get current refcount
uint64
get(uint64 pa)
{
    80000b6c:	1101                	addi	sp,sp,-32
    80000b6e:	ec06                	sd	ra,24(sp)
    80000b70:	e822                	sd	s0,16(sp)
    80000b72:	e426                	sd	s1,8(sp)
    80000b74:	1000                	addi	s0,sp,32
  if ((pa % PGSIZE) != 0 || pa < (uint64)end || pa >= PHYSTOP)
    80000b76:	0025e797          	auipc	a5,0x25e
    80000b7a:	5f278793          	addi	a5,a5,1522 # 8025f168 <end>
    80000b7e:	00f53733          	sltu	a4,a0,a5
    80000b82:	47c5                	li	a5,17
    80000b84:	07ee                	slli	a5,a5,0x1b
    80000b86:	17fd                	addi	a5,a5,-1
    80000b88:	00a7b7b3          	sltu	a5,a5,a0
    80000b8c:	8fd9                	or	a5,a5,a4
    80000b8e:	e3a9                	bnez	a5,80000bd0 <get+0x64>
    80000b90:	84aa                	mv	s1,a0
    80000b92:	03451793          	slli	a5,a0,0x34
    80000b96:	ef8d                	bnez	a5,80000bd0 <get+0x64>
    panic("get: bad pa");

  acquire(&kmem.lock);
    80000b98:	00010517          	auipc	a0,0x10
    80000b9c:	ee050513          	addi	a0,a0,-288 # 80010a78 <kmem>
    80000ba0:	27c000ef          	jal	80000e1c <acquire>
  uint64 idx = pa / PGSIZE;
    80000ba4:	80b1                	srli	s1,s1,0xc
  if (idx >= NPAGES)
    panic("get: idx out of range");

  int c = kmem.ref[idx];
    80000ba6:	048a                	slli	s1,s1,0x2
    80000ba8:	02048493          	addi	s1,s1,32
    80000bac:	00010797          	auipc	a5,0x10
    80000bb0:	ecc78793          	addi	a5,a5,-308 # 80010a78 <kmem>
    80000bb4:	97a6                	add	a5,a5,s1
    80000bb6:	4384                	lw	s1,0(a5)
  release(&kmem.lock);
    80000bb8:	00010517          	auipc	a0,0x10
    80000bbc:	ec050513          	addi	a0,a0,-320 # 80010a78 <kmem>
    80000bc0:	2f0000ef          	jal	80000eb0 <release>
  return c;
}
    80000bc4:	8526                	mv	a0,s1
    80000bc6:	60e2                	ld	ra,24(sp)
    80000bc8:	6442                	ld	s0,16(sp)
    80000bca:	64a2                	ld	s1,8(sp)
    80000bcc:	6105                	addi	sp,sp,32
    80000bce:	8082                	ret
    panic("get: bad pa");
    80000bd0:	00007517          	auipc	a0,0x7
    80000bd4:	4a050513          	addi	a0,a0,1184 # 80008070 <etext+0x70>
    80000bd8:	c4dff0ef          	jal	80000824 <panic>

0000000080000bdc <kfree>:

// free one 4096-byte physical page
void
kfree(void *pa)
{
    80000bdc:	1101                	addi	sp,sp,-32
    80000bde:	ec06                	sd	ra,24(sp)
    80000be0:	e822                	sd	s0,16(sp)
    80000be2:	e426                	sd	s1,8(sp)
    80000be4:	1000                	addi	s0,sp,32
  struct run *r;

  if (((uint64)pa % PGSIZE) != 0 || (uint64)pa < (uint64)end || (uint64)pa >= PHYSTOP)
    80000be6:	0025e797          	auipc	a5,0x25e
    80000bea:	58278793          	addi	a5,a5,1410 # 8025f168 <end>
    80000bee:	00f53733          	sltu	a4,a0,a5
    80000bf2:	47c5                	li	a5,17
    80000bf4:	07ee                	slli	a5,a5,0x1b
    80000bf6:	17fd                	addi	a5,a5,-1
    80000bf8:	00a7b7b3          	sltu	a5,a5,a0
    80000bfc:	8fd9                	or	a5,a5,a4
    80000bfe:	ef89                	bnez	a5,80000c18 <kfree+0x3c>
    80000c00:	84aa                	mv	s1,a0
    80000c02:	03451793          	slli	a5,a0,0x34
    80000c06:	eb89                	bnez	a5,80000c18 <kfree+0x3c>
    panic("kfree: bad pa");

  // only actually free when refcount reaches 0
  if (dec((uint64)pa) > 0)
    80000c08:	ec7ff0ef          	jal	80000ace <dec>
    80000c0c:	cd01                	beqz	a0,80000c24 <kfree+0x48>

  acquire(&kmem.lock);
  r->next = kmem.freelist;
  kmem.freelist = r;
  release(&kmem.lock);
}
    80000c0e:	60e2                	ld	ra,24(sp)
    80000c10:	6442                	ld	s0,16(sp)
    80000c12:	64a2                	ld	s1,8(sp)
    80000c14:	6105                	addi	sp,sp,32
    80000c16:	8082                	ret
    panic("kfree: bad pa");
    80000c18:	00007517          	auipc	a0,0x7
    80000c1c:	46850513          	addi	a0,a0,1128 # 80008080 <etext+0x80>
    80000c20:	c05ff0ef          	jal	80000824 <panic>
  memset(pa, 1, PGSIZE);
    80000c24:	6605                	lui	a2,0x1
    80000c26:	4585                	li	a1,1
    80000c28:	8526                	mv	a0,s1
    80000c2a:	2c2000ef          	jal	80000eec <memset>
  acquire(&kmem.lock);
    80000c2e:	00010517          	auipc	a0,0x10
    80000c32:	e4a50513          	addi	a0,a0,-438 # 80010a78 <kmem>
    80000c36:	1e6000ef          	jal	80000e1c <acquire>
  r->next = kmem.freelist;
    80000c3a:	00010797          	auipc	a5,0x10
    80000c3e:	e3e78793          	addi	a5,a5,-450 # 80010a78 <kmem>
    80000c42:	6f98                	ld	a4,24(a5)
    80000c44:	e098                	sd	a4,0(s1)
  kmem.freelist = r;
    80000c46:	ef84                	sd	s1,24(a5)
  release(&kmem.lock);
    80000c48:	853e                	mv	a0,a5
    80000c4a:	266000ef          	jal	80000eb0 <release>
    80000c4e:	b7c1                	j	80000c0e <kfree+0x32>

0000000080000c50 <freerange>:
{
    80000c50:	715d                	addi	sp,sp,-80
    80000c52:	e486                	sd	ra,72(sp)
    80000c54:	e0a2                	sd	s0,64(sp)
    80000c56:	fc26                	sd	s1,56(sp)
    80000c58:	0880                	addi	s0,sp,80
  char *p = (char*)PGROUNDUP((uint64)pa_start);
    80000c5a:	6785                	lui	a5,0x1
    80000c5c:	fff78713          	addi	a4,a5,-1 # fff <_entry-0x7ffff001>
    80000c60:	953a                	add	a0,a0,a4
    80000c62:	777d                	lui	a4,0xfffff
    80000c64:	00e574b3          	and	s1,a0,a4
  for (; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
    80000c68:	97a6                	add	a5,a5,s1
    80000c6a:	04f5ec63          	bltu	a1,a5,80000cc2 <freerange+0x72>
    80000c6e:	f84a                	sd	s2,48(sp)
    80000c70:	f44e                	sd	s3,40(sp)
    80000c72:	f052                	sd	s4,32(sp)
    80000c74:	ec56                	sd	s5,24(sp)
    80000c76:	e85a                	sd	s6,16(sp)
    80000c78:	e45e                	sd	s7,8(sp)
    80000c7a:	892e                	mv	s2,a1
    if (idx >= NPAGES)
    80000c7c:	000889b7          	lui	s3,0x88
    kmem.ref[idx] = 1;    // temporary ref to allow kfree()
    80000c80:	00010b97          	auipc	s7,0x10
    80000c84:	df8b8b93          	addi	s7,s7,-520 # 80010a78 <kmem>
    80000c88:	4b05                	li	s6,1
  for (; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
    80000c8a:	6a85                	lui	s5,0x1
    80000c8c:	6a09                	lui	s4,0x2
    80000c8e:	a011                	j	80000c92 <freerange+0x42>
    80000c90:	84be                	mv	s1,a5
    uint64 idx = (uint64)p / PGSIZE;
    80000c92:	00c4d793          	srli	a5,s1,0xc
    if (idx >= NPAGES)
    80000c96:	0337fb63          	bgeu	a5,s3,80000ccc <freerange+0x7c>
    kmem.ref[idx] = 1;    // temporary ref to allow kfree()
    80000c9a:	078a                	slli	a5,a5,0x2
    80000c9c:	02078793          	addi	a5,a5,32
    80000ca0:	97de                	add	a5,a5,s7
    80000ca2:	0167a023          	sw	s6,0(a5)
    kfree(p);
    80000ca6:	8526                	mv	a0,s1
    80000ca8:	f35ff0ef          	jal	80000bdc <kfree>
  for (; p + PGSIZE <= (char*)pa_end; p += PGSIZE) {
    80000cac:	015487b3          	add	a5,s1,s5
    80000cb0:	94d2                	add	s1,s1,s4
    80000cb2:	fc997fe3          	bgeu	s2,s1,80000c90 <freerange+0x40>
    80000cb6:	7942                	ld	s2,48(sp)
    80000cb8:	79a2                	ld	s3,40(sp)
    80000cba:	7a02                	ld	s4,32(sp)
    80000cbc:	6ae2                	ld	s5,24(sp)
    80000cbe:	6b42                	ld	s6,16(sp)
    80000cc0:	6ba2                	ld	s7,8(sp)
}
    80000cc2:	60a6                	ld	ra,72(sp)
    80000cc4:	6406                	ld	s0,64(sp)
    80000cc6:	74e2                	ld	s1,56(sp)
    80000cc8:	6161                	addi	sp,sp,80
    80000cca:	8082                	ret
      panic("freerange: idx out of range");
    80000ccc:	00007517          	auipc	a0,0x7
    80000cd0:	3c450513          	addi	a0,a0,964 # 80008090 <etext+0x90>
    80000cd4:	b51ff0ef          	jal	80000824 <panic>

0000000080000cd8 <kinit>:
{
    80000cd8:	1141                	addi	sp,sp,-16
    80000cda:	e406                	sd	ra,8(sp)
    80000cdc:	e022                	sd	s0,0(sp)
    80000cde:	0800                	addi	s0,sp,16
  initlock(&kmem.lock, "kmem");
    80000ce0:	00007597          	auipc	a1,0x7
    80000ce4:	3d058593          	addi	a1,a1,976 # 800080b0 <etext+0xb0>
    80000ce8:	00010517          	auipc	a0,0x10
    80000cec:	d9050513          	addi	a0,a0,-624 # 80010a78 <kmem>
    80000cf0:	0a2000ef          	jal	80000d92 <initlock>
  freerange(end, (void*)PHYSTOP);
    80000cf4:	45c5                	li	a1,17
    80000cf6:	05ee                	slli	a1,a1,0x1b
    80000cf8:	0025e517          	auipc	a0,0x25e
    80000cfc:	47050513          	addi	a0,a0,1136 # 8025f168 <end>
    80000d00:	f51ff0ef          	jal	80000c50 <freerange>
}
    80000d04:	60a2                	ld	ra,8(sp)
    80000d06:	6402                	ld	s0,0(sp)
    80000d08:	0141                	addi	sp,sp,16
    80000d0a:	8082                	ret

0000000080000d0c <kalloc>:

// allocate one 4096-byte physical page
void *
kalloc(void)
{
    80000d0c:	1101                	addi	sp,sp,-32
    80000d0e:	ec06                	sd	ra,24(sp)
    80000d10:	e822                	sd	s0,16(sp)
    80000d12:	e426                	sd	s1,8(sp)
    80000d14:	1000                	addi	s0,sp,32
  struct run *r;

  acquire(&kmem.lock);
    80000d16:	00010517          	auipc	a0,0x10
    80000d1a:	d6250513          	addi	a0,a0,-670 # 80010a78 <kmem>
    80000d1e:	0fe000ef          	jal	80000e1c <acquire>
  r = kmem.freelist;
    80000d22:	00010497          	auipc	s1,0x10
    80000d26:	d6e4b483          	ld	s1,-658(s1) # 80010a90 <kmem+0x18>
  if (r)
    80000d2a:	cca9                	beqz	s1,80000d84 <kalloc+0x78>
    kmem.freelist = r->next;
    80000d2c:	609c                	ld	a5,0(s1)
    80000d2e:	00010717          	auipc	a4,0x10
    80000d32:	d6f73123          	sd	a5,-670(a4) # 80010a90 <kmem+0x18>
  release(&kmem.lock);
    80000d36:	00010517          	auipc	a0,0x10
    80000d3a:	d4250513          	addi	a0,a0,-702 # 80010a78 <kmem>
    80000d3e:	172000ef          	jal	80000eb0 <release>

  if (r) {
    memset((char*)r, 5, PGSIZE); // fill with junk
    80000d42:	6605                	lui	a2,0x1
    80000d44:	4595                	li	a1,5
    80000d46:	8526                	mv	a0,s1
    80000d48:	1a4000ef          	jal	80000eec <memset>
    uint64 pa = (uint64)r;
    uint64 idx = pa / PGSIZE;
    80000d4c:	00c4d793          	srli	a5,s1,0xc
    if (idx >= NPAGES)
    80000d50:	00088737          	lui	a4,0x88
    80000d54:	02e7f263          	bgeu	a5,a4,80000d78 <kalloc+0x6c>
      panic("kalloc: idx out of range");
    kmem.ref[idx] = 1;
    80000d58:	078a                	slli	a5,a5,0x2
    80000d5a:	02078793          	addi	a5,a5,32
    80000d5e:	00010717          	auipc	a4,0x10
    80000d62:	d1a70713          	addi	a4,a4,-742 # 80010a78 <kmem>
    80000d66:	97ba                	add	a5,a5,a4
    80000d68:	4705                	li	a4,1
    80000d6a:	c398                	sw	a4,0(a5)
  }

  return (void*)r;
}
    80000d6c:	8526                	mv	a0,s1
    80000d6e:	60e2                	ld	ra,24(sp)
    80000d70:	6442                	ld	s0,16(sp)
    80000d72:	64a2                	ld	s1,8(sp)
    80000d74:	6105                	addi	sp,sp,32
    80000d76:	8082                	ret
      panic("kalloc: idx out of range");
    80000d78:	00007517          	auipc	a0,0x7
    80000d7c:	34050513          	addi	a0,a0,832 # 800080b8 <etext+0xb8>
    80000d80:	aa5ff0ef          	jal	80000824 <panic>
  release(&kmem.lock);
    80000d84:	00010517          	auipc	a0,0x10
    80000d88:	cf450513          	addi	a0,a0,-780 # 80010a78 <kmem>
    80000d8c:	124000ef          	jal	80000eb0 <release>
  if (r) {
    80000d90:	bff1                	j	80000d6c <kalloc+0x60>

0000000080000d92 <initlock>:
#include "proc.h"
#include "defs.h"

void
initlock(struct spinlock *lk, char *name)
{
    80000d92:	1141                	addi	sp,sp,-16
    80000d94:	e406                	sd	ra,8(sp)
    80000d96:	e022                	sd	s0,0(sp)
    80000d98:	0800                	addi	s0,sp,16
  lk->name = name;
    80000d9a:	e50c                	sd	a1,8(a0)
  lk->locked = 0;
    80000d9c:	00052023          	sw	zero,0(a0)
  lk->cpu = 0;
    80000da0:	00053823          	sd	zero,16(a0)
}
    80000da4:	60a2                	ld	ra,8(sp)
    80000da6:	6402                	ld	s0,0(sp)
    80000da8:	0141                	addi	sp,sp,16
    80000daa:	8082                	ret

0000000080000dac <holding>:
// Interrupts must be off.
int
holding(struct spinlock *lk)
{
  int r;
  r = (lk->locked && lk->cpu == mycpu());
    80000dac:	411c                	lw	a5,0(a0)
    80000dae:	e399                	bnez	a5,80000db4 <holding+0x8>
    80000db0:	4501                	li	a0,0
  return r;
}
    80000db2:	8082                	ret
{
    80000db4:	1101                	addi	sp,sp,-32
    80000db6:	ec06                	sd	ra,24(sp)
    80000db8:	e822                	sd	s0,16(sp)
    80000dba:	e426                	sd	s1,8(sp)
    80000dbc:	1000                	addi	s0,sp,32
  r = (lk->locked && lk->cpu == mycpu());
    80000dbe:	691c                	ld	a5,16(a0)
    80000dc0:	84be                	mv	s1,a5
    80000dc2:	54f000ef          	jal	80001b10 <mycpu>
    80000dc6:	40a48533          	sub	a0,s1,a0
    80000dca:	00153513          	seqz	a0,a0
}
    80000dce:	60e2                	ld	ra,24(sp)
    80000dd0:	6442                	ld	s0,16(sp)
    80000dd2:	64a2                	ld	s1,8(sp)
    80000dd4:	6105                	addi	sp,sp,32
    80000dd6:	8082                	ret

0000000080000dd8 <push_off>:
// it takes two pop_off()s to undo two push_off()s.  Also, if interrupts
// are initially off, then push_off, pop_off leaves them off.

void
push_off(void)
{
    80000dd8:	1101                	addi	sp,sp,-32
    80000dda:	ec06                	sd	ra,24(sp)
    80000ddc:	e822                	sd	s0,16(sp)
    80000dde:	e426                	sd	s1,8(sp)
    80000de0:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000de2:	100027f3          	csrr	a5,sstatus
    80000de6:	84be                	mv	s1,a5
    80000de8:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80000dec:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000dee:	10079073          	csrw	sstatus,a5

  // disable interrupts to prevent an involuntary context
  // switch while using mycpu().
  intr_off();

  if(mycpu()->noff == 0)
    80000df2:	51f000ef          	jal	80001b10 <mycpu>
    80000df6:	5d3c                	lw	a5,120(a0)
    80000df8:	cb99                	beqz	a5,80000e0e <push_off+0x36>
    mycpu()->intena = old;
  mycpu()->noff += 1;
    80000dfa:	517000ef          	jal	80001b10 <mycpu>
    80000dfe:	5d3c                	lw	a5,120(a0)
    80000e00:	2785                	addiw	a5,a5,1
    80000e02:	dd3c                	sw	a5,120(a0)
}
    80000e04:	60e2                	ld	ra,24(sp)
    80000e06:	6442                	ld	s0,16(sp)
    80000e08:	64a2                	ld	s1,8(sp)
    80000e0a:	6105                	addi	sp,sp,32
    80000e0c:	8082                	ret
    mycpu()->intena = old;
    80000e0e:	503000ef          	jal	80001b10 <mycpu>
  return (x & SSTATUS_SIE) != 0;
    80000e12:	0014d793          	srli	a5,s1,0x1
    80000e16:	8b85                	andi	a5,a5,1
    80000e18:	dd7c                	sw	a5,124(a0)
    80000e1a:	b7c5                	j	80000dfa <push_off+0x22>

0000000080000e1c <acquire>:
{
    80000e1c:	1101                	addi	sp,sp,-32
    80000e1e:	ec06                	sd	ra,24(sp)
    80000e20:	e822                	sd	s0,16(sp)
    80000e22:	e426                	sd	s1,8(sp)
    80000e24:	1000                	addi	s0,sp,32
    80000e26:	84aa                	mv	s1,a0
  push_off(); // disable interrupts to avoid deadlock.
    80000e28:	fb1ff0ef          	jal	80000dd8 <push_off>
  if(holding(lk))
    80000e2c:	8526                	mv	a0,s1
    80000e2e:	f7fff0ef          	jal	80000dac <holding>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000e32:	4705                	li	a4,1
  if(holding(lk))
    80000e34:	e105                	bnez	a0,80000e54 <acquire+0x38>
  while(__sync_lock_test_and_set(&lk->locked, 1) != 0)
    80000e36:	87ba                	mv	a5,a4
    80000e38:	0cf4a7af          	amoswap.w.aq	a5,a5,(s1)
    80000e3c:	2781                	sext.w	a5,a5
    80000e3e:	ffe5                	bnez	a5,80000e36 <acquire+0x1a>
  __sync_synchronize();
    80000e40:	0330000f          	fence	rw,rw
  lk->cpu = mycpu();
    80000e44:	4cd000ef          	jal	80001b10 <mycpu>
    80000e48:	e888                	sd	a0,16(s1)
}
    80000e4a:	60e2                	ld	ra,24(sp)
    80000e4c:	6442                	ld	s0,16(sp)
    80000e4e:	64a2                	ld	s1,8(sp)
    80000e50:	6105                	addi	sp,sp,32
    80000e52:	8082                	ret
    panic("acquire");
    80000e54:	00007517          	auipc	a0,0x7
    80000e58:	28450513          	addi	a0,a0,644 # 800080d8 <etext+0xd8>
    80000e5c:	9c9ff0ef          	jal	80000824 <panic>

0000000080000e60 <pop_off>:

void
pop_off(void)
{
    80000e60:	1141                	addi	sp,sp,-16
    80000e62:	e406                	sd	ra,8(sp)
    80000e64:	e022                	sd	s0,0(sp)
    80000e66:	0800                	addi	s0,sp,16
  struct cpu *c = mycpu();
    80000e68:	4a9000ef          	jal	80001b10 <mycpu>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000e6c:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80000e70:	8b89                	andi	a5,a5,2
  if(intr_get())
    80000e72:	e39d                	bnez	a5,80000e98 <pop_off+0x38>
    panic("pop_off - interruptible");
  if(c->noff < 1)
    80000e74:	5d3c                	lw	a5,120(a0)
    80000e76:	02f05763          	blez	a5,80000ea4 <pop_off+0x44>
    panic("pop_off");
  c->noff -= 1;
    80000e7a:	37fd                	addiw	a5,a5,-1
    80000e7c:	dd3c                	sw	a5,120(a0)
  if(c->noff == 0 && c->intena)
    80000e7e:	eb89                	bnez	a5,80000e90 <pop_off+0x30>
    80000e80:	5d7c                	lw	a5,124(a0)
    80000e82:	c799                	beqz	a5,80000e90 <pop_off+0x30>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80000e84:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    80000e88:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80000e8c:	10079073          	csrw	sstatus,a5
    intr_on();
}
    80000e90:	60a2                	ld	ra,8(sp)
    80000e92:	6402                	ld	s0,0(sp)
    80000e94:	0141                	addi	sp,sp,16
    80000e96:	8082                	ret
    panic("pop_off - interruptible");
    80000e98:	00007517          	auipc	a0,0x7
    80000e9c:	24850513          	addi	a0,a0,584 # 800080e0 <etext+0xe0>
    80000ea0:	985ff0ef          	jal	80000824 <panic>
    panic("pop_off");
    80000ea4:	00007517          	auipc	a0,0x7
    80000ea8:	25450513          	addi	a0,a0,596 # 800080f8 <etext+0xf8>
    80000eac:	979ff0ef          	jal	80000824 <panic>

0000000080000eb0 <release>:
{
    80000eb0:	1101                	addi	sp,sp,-32
    80000eb2:	ec06                	sd	ra,24(sp)
    80000eb4:	e822                	sd	s0,16(sp)
    80000eb6:	e426                	sd	s1,8(sp)
    80000eb8:	1000                	addi	s0,sp,32
    80000eba:	84aa                	mv	s1,a0
  if(!holding(lk))
    80000ebc:	ef1ff0ef          	jal	80000dac <holding>
    80000ec0:	c105                	beqz	a0,80000ee0 <release+0x30>
  lk->cpu = 0;
    80000ec2:	0004b823          	sd	zero,16(s1)
  __sync_synchronize();
    80000ec6:	0330000f          	fence	rw,rw
  __sync_lock_release(&lk->locked);
    80000eca:	0310000f          	fence	rw,w
    80000ece:	0004a023          	sw	zero,0(s1)
  pop_off();
    80000ed2:	f8fff0ef          	jal	80000e60 <pop_off>
}
    80000ed6:	60e2                	ld	ra,24(sp)
    80000ed8:	6442                	ld	s0,16(sp)
    80000eda:	64a2                	ld	s1,8(sp)
    80000edc:	6105                	addi	sp,sp,32
    80000ede:	8082                	ret
    panic("release");
    80000ee0:	00007517          	auipc	a0,0x7
    80000ee4:	22050513          	addi	a0,a0,544 # 80008100 <etext+0x100>
    80000ee8:	93dff0ef          	jal	80000824 <panic>

0000000080000eec <memset>:
#include "types.h"

void*
memset(void *dst, int c, uint n)
{
    80000eec:	1141                	addi	sp,sp,-16
    80000eee:	e406                	sd	ra,8(sp)
    80000ef0:	e022                	sd	s0,0(sp)
    80000ef2:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    80000ef4:	ca19                	beqz	a2,80000f0a <memset+0x1e>
    80000ef6:	87aa                	mv	a5,a0
    80000ef8:	1602                	slli	a2,a2,0x20
    80000efa:	9201                	srli	a2,a2,0x20
    80000efc:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    80000f00:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    80000f04:	0785                	addi	a5,a5,1
    80000f06:	fee79de3          	bne	a5,a4,80000f00 <memset+0x14>
  }
  return dst;
}
    80000f0a:	60a2                	ld	ra,8(sp)
    80000f0c:	6402                	ld	s0,0(sp)
    80000f0e:	0141                	addi	sp,sp,16
    80000f10:	8082                	ret

0000000080000f12 <memcmp>:

int
memcmp(const void *v1, const void *v2, uint n)
{
    80000f12:	1141                	addi	sp,sp,-16
    80000f14:	e406                	sd	ra,8(sp)
    80000f16:	e022                	sd	s0,0(sp)
    80000f18:	0800                	addi	s0,sp,16
  const uchar *s1, *s2;

  s1 = v1;
  s2 = v2;
  while(n-- > 0){
    80000f1a:	c61d                	beqz	a2,80000f48 <memcmp+0x36>
    80000f1c:	1602                	slli	a2,a2,0x20
    80000f1e:	9201                	srli	a2,a2,0x20
    80000f20:	00c506b3          	add	a3,a0,a2
    if(*s1 != *s2)
    80000f24:	00054783          	lbu	a5,0(a0)
    80000f28:	0005c703          	lbu	a4,0(a1)
    80000f2c:	00e79863          	bne	a5,a4,80000f3c <memcmp+0x2a>
      return *s1 - *s2;
    s1++, s2++;
    80000f30:	0505                	addi	a0,a0,1
    80000f32:	0585                	addi	a1,a1,1
  while(n-- > 0){
    80000f34:	fed518e3          	bne	a0,a3,80000f24 <memcmp+0x12>
  }

  return 0;
    80000f38:	4501                	li	a0,0
    80000f3a:	a019                	j	80000f40 <memcmp+0x2e>
      return *s1 - *s2;
    80000f3c:	40e7853b          	subw	a0,a5,a4
}
    80000f40:	60a2                	ld	ra,8(sp)
    80000f42:	6402                	ld	s0,0(sp)
    80000f44:	0141                	addi	sp,sp,16
    80000f46:	8082                	ret
  return 0;
    80000f48:	4501                	li	a0,0
    80000f4a:	bfdd                	j	80000f40 <memcmp+0x2e>

0000000080000f4c <memmove>:

void*
memmove(void *dst, const void *src, uint n)
{
    80000f4c:	1141                	addi	sp,sp,-16
    80000f4e:	e406                	sd	ra,8(sp)
    80000f50:	e022                	sd	s0,0(sp)
    80000f52:	0800                	addi	s0,sp,16
  const char *s;
  char *d;

  if(n == 0)
    80000f54:	c205                	beqz	a2,80000f74 <memmove+0x28>
    return dst;
  
  s = src;
  d = dst;
  if(s < d && s + n > d){
    80000f56:	02a5e363          	bltu	a1,a0,80000f7c <memmove+0x30>
    s += n;
    d += n;
    while(n-- > 0)
      *--d = *--s;
  } else
    while(n-- > 0)
    80000f5a:	1602                	slli	a2,a2,0x20
    80000f5c:	9201                	srli	a2,a2,0x20
    80000f5e:	00c587b3          	add	a5,a1,a2
{
    80000f62:	872a                	mv	a4,a0
      *d++ = *s++;
    80000f64:	0585                	addi	a1,a1,1
    80000f66:	0705                	addi	a4,a4,1
    80000f68:	fff5c683          	lbu	a3,-1(a1)
    80000f6c:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    80000f70:	feb79ae3          	bne	a5,a1,80000f64 <memmove+0x18>

  return dst;
}
    80000f74:	60a2                	ld	ra,8(sp)
    80000f76:	6402                	ld	s0,0(sp)
    80000f78:	0141                	addi	sp,sp,16
    80000f7a:	8082                	ret
  if(s < d && s + n > d){
    80000f7c:	02061693          	slli	a3,a2,0x20
    80000f80:	9281                	srli	a3,a3,0x20
    80000f82:	00d58733          	add	a4,a1,a3
    80000f86:	fce57ae3          	bgeu	a0,a4,80000f5a <memmove+0xe>
    d += n;
    80000f8a:	96aa                	add	a3,a3,a0
    while(n-- > 0)
    80000f8c:	fff6079b          	addiw	a5,a2,-1 # fff <_entry-0x7ffff001>
    80000f90:	1782                	slli	a5,a5,0x20
    80000f92:	9381                	srli	a5,a5,0x20
    80000f94:	fff7c793          	not	a5,a5
    80000f98:	97ba                	add	a5,a5,a4
      *--d = *--s;
    80000f9a:	177d                	addi	a4,a4,-1
    80000f9c:	16fd                	addi	a3,a3,-1
    80000f9e:	00074603          	lbu	a2,0(a4)
    80000fa2:	00c68023          	sb	a2,0(a3)
    while(n-- > 0)
    80000fa6:	fee79ae3          	bne	a5,a4,80000f9a <memmove+0x4e>
    80000faa:	b7e9                	j	80000f74 <memmove+0x28>

0000000080000fac <memcpy>:

// memcpy exists to placate GCC.  Use memmove.
void*
memcpy(void *dst, const void *src, uint n)
{
    80000fac:	1141                	addi	sp,sp,-16
    80000fae:	e406                	sd	ra,8(sp)
    80000fb0:	e022                	sd	s0,0(sp)
    80000fb2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    80000fb4:	f99ff0ef          	jal	80000f4c <memmove>
}
    80000fb8:	60a2                	ld	ra,8(sp)
    80000fba:	6402                	ld	s0,0(sp)
    80000fbc:	0141                	addi	sp,sp,16
    80000fbe:	8082                	ret

0000000080000fc0 <strncmp>:

int
strncmp(const char *p, const char *q, uint n)
{
    80000fc0:	1141                	addi	sp,sp,-16
    80000fc2:	e406                	sd	ra,8(sp)
    80000fc4:	e022                	sd	s0,0(sp)
    80000fc6:	0800                	addi	s0,sp,16
  while(n > 0 && *p && *p == *q)
    80000fc8:	ce11                	beqz	a2,80000fe4 <strncmp+0x24>
    80000fca:	00054783          	lbu	a5,0(a0)
    80000fce:	cf89                	beqz	a5,80000fe8 <strncmp+0x28>
    80000fd0:	0005c703          	lbu	a4,0(a1)
    80000fd4:	00f71a63          	bne	a4,a5,80000fe8 <strncmp+0x28>
    n--, p++, q++;
    80000fd8:	367d                	addiw	a2,a2,-1
    80000fda:	0505                	addi	a0,a0,1
    80000fdc:	0585                	addi	a1,a1,1
  while(n > 0 && *p && *p == *q)
    80000fde:	f675                	bnez	a2,80000fca <strncmp+0xa>
  if(n == 0)
    return 0;
    80000fe0:	4501                	li	a0,0
    80000fe2:	a801                	j	80000ff2 <strncmp+0x32>
    80000fe4:	4501                	li	a0,0
    80000fe6:	a031                	j	80000ff2 <strncmp+0x32>
  return (uchar)*p - (uchar)*q;
    80000fe8:	00054503          	lbu	a0,0(a0)
    80000fec:	0005c783          	lbu	a5,0(a1)
    80000ff0:	9d1d                	subw	a0,a0,a5
}
    80000ff2:	60a2                	ld	ra,8(sp)
    80000ff4:	6402                	ld	s0,0(sp)
    80000ff6:	0141                	addi	sp,sp,16
    80000ff8:	8082                	ret

0000000080000ffa <strncpy>:

char*
strncpy(char *s, const char *t, int n)
{
    80000ffa:	1141                	addi	sp,sp,-16
    80000ffc:	e406                	sd	ra,8(sp)
    80000ffe:	e022                	sd	s0,0(sp)
    80001000:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while(n-- > 0 && (*s++ = *t++) != 0)
    80001002:	87aa                	mv	a5,a0
    80001004:	a011                	j	80001008 <strncpy+0xe>
    80001006:	8636                	mv	a2,a3
    80001008:	02c05863          	blez	a2,80001038 <strncpy+0x3e>
    8000100c:	fff6069b          	addiw	a3,a2,-1
    80001010:	8836                	mv	a6,a3
    80001012:	0785                	addi	a5,a5,1
    80001014:	0005c703          	lbu	a4,0(a1)
    80001018:	fee78fa3          	sb	a4,-1(a5)
    8000101c:	0585                	addi	a1,a1,1
    8000101e:	f765                	bnez	a4,80001006 <strncpy+0xc>
    ;
  while(n-- > 0)
    80001020:	873e                	mv	a4,a5
    80001022:	01005b63          	blez	a6,80001038 <strncpy+0x3e>
    80001026:	9fb1                	addw	a5,a5,a2
    80001028:	37fd                	addiw	a5,a5,-1
    *s++ = 0;
    8000102a:	0705                	addi	a4,a4,1
    8000102c:	fe070fa3          	sb	zero,-1(a4)
  while(n-- > 0)
    80001030:	40e786bb          	subw	a3,a5,a4
    80001034:	fed04be3          	bgtz	a3,8000102a <strncpy+0x30>
  return os;
}
    80001038:	60a2                	ld	ra,8(sp)
    8000103a:	6402                	ld	s0,0(sp)
    8000103c:	0141                	addi	sp,sp,16
    8000103e:	8082                	ret

0000000080001040 <safestrcpy>:

// Like strncpy but guaranteed to NUL-terminate.
char*
safestrcpy(char *s, const char *t, int n)
{
    80001040:	1141                	addi	sp,sp,-16
    80001042:	e406                	sd	ra,8(sp)
    80001044:	e022                	sd	s0,0(sp)
    80001046:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  if(n <= 0)
    80001048:	02c05363          	blez	a2,8000106e <safestrcpy+0x2e>
    8000104c:	fff6069b          	addiw	a3,a2,-1
    80001050:	1682                	slli	a3,a3,0x20
    80001052:	9281                	srli	a3,a3,0x20
    80001054:	96ae                	add	a3,a3,a1
    80001056:	87aa                	mv	a5,a0
    return os;
  while(--n > 0 && (*s++ = *t++) != 0)
    80001058:	00d58963          	beq	a1,a3,8000106a <safestrcpy+0x2a>
    8000105c:	0585                	addi	a1,a1,1
    8000105e:	0785                	addi	a5,a5,1
    80001060:	fff5c703          	lbu	a4,-1(a1)
    80001064:	fee78fa3          	sb	a4,-1(a5)
    80001068:	fb65                	bnez	a4,80001058 <safestrcpy+0x18>
    ;
  *s = 0;
    8000106a:	00078023          	sb	zero,0(a5)
  return os;
}
    8000106e:	60a2                	ld	ra,8(sp)
    80001070:	6402                	ld	s0,0(sp)
    80001072:	0141                	addi	sp,sp,16
    80001074:	8082                	ret

0000000080001076 <strlen>:

int
strlen(const char *s)
{
    80001076:	1141                	addi	sp,sp,-16
    80001078:	e406                	sd	ra,8(sp)
    8000107a:	e022                	sd	s0,0(sp)
    8000107c:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    8000107e:	00054783          	lbu	a5,0(a0)
    80001082:	cf91                	beqz	a5,8000109e <strlen+0x28>
    80001084:	00150793          	addi	a5,a0,1
    80001088:	86be                	mv	a3,a5
    8000108a:	0785                	addi	a5,a5,1
    8000108c:	fff7c703          	lbu	a4,-1(a5)
    80001090:	ff65                	bnez	a4,80001088 <strlen+0x12>
    80001092:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    80001096:	60a2                	ld	ra,8(sp)
    80001098:	6402                	ld	s0,0(sp)
    8000109a:	0141                	addi	sp,sp,16
    8000109c:	8082                	ret
  for(n = 0; s[n]; n++)
    8000109e:	4501                	li	a0,0
    800010a0:	bfdd                	j	80001096 <strlen+0x20>

00000000800010a2 <main>:
volatile static int started = 0;

// start() jumps here in supervisor mode on all CPUs.
void
main()
{
    800010a2:	1141                	addi	sp,sp,-16
    800010a4:	e406                	sd	ra,8(sp)
    800010a6:	e022                	sd	s0,0(sp)
    800010a8:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    800010aa:	253000ef          	jal	80001afc <cpuid>
    virtio_disk_init(); // emulated hard disk
    userinit();      // first user process
    __sync_synchronize();
    started = 1;
  } else {
    while(started == 0)
    800010ae:	00008717          	auipc	a4,0x8
    800010b2:	8d270713          	addi	a4,a4,-1838 # 80008980 <started>
  if(cpuid() == 0){
    800010b6:	c51d                	beqz	a0,800010e4 <main+0x42>
    while(started == 0)
    800010b8:	431c                	lw	a5,0(a4)
    800010ba:	2781                	sext.w	a5,a5
    800010bc:	dff5                	beqz	a5,800010b8 <main+0x16>
      ;
    __sync_synchronize();
    800010be:	0330000f          	fence	rw,rw
    printf("hart %d starting\n", cpuid());
    800010c2:	23b000ef          	jal	80001afc <cpuid>
    800010c6:	85aa                	mv	a1,a0
    800010c8:	00007517          	auipc	a0,0x7
    800010cc:	06050513          	addi	a0,a0,96 # 80008128 <etext+0x128>
    800010d0:	c2aff0ef          	jal	800004fa <printf>
    kvminithart();    // turn on paging
    800010d4:	088000ef          	jal	8000115c <kvminithart>
    trapinithart();   // install kernel trap vector
    800010d8:	576010ef          	jal	8000264e <trapinithart>
    plicinithart();   // ask PLIC for device interrupts
    800010dc:	0ed040ef          	jal	800059c8 <plicinithart>
  }

  scheduler();        
    800010e0:	6b5000ef          	jal	80001f94 <scheduler>
    consoleinit();
    800010e4:	b3cff0ef          	jal	80000420 <consoleinit>
    printfinit();
    800010e8:	f78ff0ef          	jal	80000860 <printfinit>
    printf("\n");
    800010ec:	00007517          	auipc	a0,0x7
    800010f0:	01c50513          	addi	a0,a0,28 # 80008108 <etext+0x108>
    800010f4:	c06ff0ef          	jal	800004fa <printf>
    printf("xv6 kernel is booting\n");
    800010f8:	00007517          	auipc	a0,0x7
    800010fc:	01850513          	addi	a0,a0,24 # 80008110 <etext+0x110>
    80001100:	bfaff0ef          	jal	800004fa <printf>
    printf("\n");
    80001104:	00007517          	auipc	a0,0x7
    80001108:	00450513          	addi	a0,a0,4 # 80008108 <etext+0x108>
    8000110c:	beeff0ef          	jal	800004fa <printf>
    kinit();         // physical page allocator
    80001110:	bc9ff0ef          	jal	80000cd8 <kinit>
    kvminit();       // create kernel page table
    80001114:	2d4000ef          	jal	800013e8 <kvminit>
    kvminithart();   // turn on paging
    80001118:	044000ef          	jal	8000115c <kvminithart>
    procinit();      // process table
    8000111c:	12b000ef          	jal	80001a46 <procinit>
    trapinit();      // trap vectors
    80001120:	50a010ef          	jal	8000262a <trapinit>
    trapinithart();  // install kernel trap vector
    80001124:	52a010ef          	jal	8000264e <trapinithart>
    plicinit();      // set up interrupt controller
    80001128:	087040ef          	jal	800059ae <plicinit>
    plicinithart();  // ask PLIC for device interrupts
    8000112c:	09d040ef          	jal	800059c8 <plicinithart>
    binit();         // buffer cache
    80001130:	5c9010ef          	jal	80002ef8 <binit>
    iinit();         // inode table
    80001134:	3dc020ef          	jal	80003510 <iinit>
    fileinit();      // file table
    80001138:	398030ef          	jal	800044d0 <fileinit>
    shm_init();      // shared memory table
    8000113c:	107040ef          	jal	80005a42 <shm_init>
    mbox_init();     // mail boxes
    80001140:	3e7040ef          	jal	80005d26 <mbox_init>
    virtio_disk_init(); // emulated hard disk
    80001144:	5f3040ef          	jal	80005f36 <virtio_disk_init>
    userinit();      // first user process
    80001148:	4b3000ef          	jal	80001dfa <userinit>
    __sync_synchronize();
    8000114c:	0330000f          	fence	rw,rw
    started = 1;
    80001150:	4785                	li	a5,1
    80001152:	00008717          	auipc	a4,0x8
    80001156:	82f72723          	sw	a5,-2002(a4) # 80008980 <started>
    8000115a:	b759                	j	800010e0 <main+0x3e>

000000008000115c <kvminithart>:

// Switch the current CPU's h/w page table register to
// the kernel's page table, and enable paging.
void
kvminithart()
{
    8000115c:	1141                	addi	sp,sp,-16
    8000115e:	e406                	sd	ra,8(sp)
    80001160:	e022                	sd	s0,0(sp)
    80001162:	0800                	addi	s0,sp,16
// flush the TLB.
static inline void
sfence_vma()
{
  // the zero, zero means flush all TLB entries.
  asm volatile("sfence.vma zero, zero");
    80001164:	12000073          	sfence.vma
  // wait for any previous writes to the page table memory to finish.
  sfence_vma();

  w_satp(MAKE_SATP(kernel_pagetable));
    80001168:	00008797          	auipc	a5,0x8
    8000116c:	8207b783          	ld	a5,-2016(a5) # 80008988 <kernel_pagetable>
    80001170:	83b1                	srli	a5,a5,0xc
    80001172:	577d                	li	a4,-1
    80001174:	177e                	slli	a4,a4,0x3f
    80001176:	8fd9                	or	a5,a5,a4
  asm volatile("csrw satp, %0" : : "r" (x));
    80001178:	18079073          	csrw	satp,a5
  asm volatile("sfence.vma zero, zero");
    8000117c:	12000073          	sfence.vma

  // flush stale entries from the TLB.
  sfence_vma();
}
    80001180:	60a2                	ld	ra,8(sp)
    80001182:	6402                	ld	s0,0(sp)
    80001184:	0141                	addi	sp,sp,16
    80001186:	8082                	ret

0000000080001188 <walk>:
//   21..29 -- 9 bits of level-1 index.
//   12..20 -- 9 bits of level-0 index.
//    0..11 -- 12 bits of byte offset within the page.
pte_t *
walk(pagetable_t pagetable, uint64 va, int alloc)
{
    80001188:	7139                	addi	sp,sp,-64
    8000118a:	fc06                	sd	ra,56(sp)
    8000118c:	f822                	sd	s0,48(sp)
    8000118e:	f426                	sd	s1,40(sp)
    80001190:	f04a                	sd	s2,32(sp)
    80001192:	ec4e                	sd	s3,24(sp)
    80001194:	e852                	sd	s4,16(sp)
    80001196:	e456                	sd	s5,8(sp)
    80001198:	e05a                	sd	s6,0(sp)
    8000119a:	0080                	addi	s0,sp,64
    8000119c:	84aa                	mv	s1,a0
    8000119e:	89ae                	mv	s3,a1
    800011a0:	8b32                	mv	s6,a2
  if(va >= MAXVA)
    800011a2:	57fd                	li	a5,-1
    800011a4:	83e9                	srli	a5,a5,0x1a
    800011a6:	4a79                	li	s4,30
    panic("walk");

  for(int level = 2; level > 0; level--) {
    800011a8:	4ab1                	li	s5,12
  if(va >= MAXVA)
    800011aa:	04b7e263          	bltu	a5,a1,800011ee <walk+0x66>
    pte_t *pte = &pagetable[PX(level, va)];
    800011ae:	0149d933          	srl	s2,s3,s4
    800011b2:	1ff97913          	andi	s2,s2,511
    800011b6:	090e                	slli	s2,s2,0x3
    800011b8:	9926                	add	s2,s2,s1
    if(*pte & PTE_V) {
    800011ba:	00093483          	ld	s1,0(s2)
    800011be:	0014f793          	andi	a5,s1,1
    800011c2:	cf85                	beqz	a5,800011fa <walk+0x72>
      pagetable = (pagetable_t)PTE2PA(*pte);
    800011c4:	80a9                	srli	s1,s1,0xa
    800011c6:	04b2                	slli	s1,s1,0xc
  for(int level = 2; level > 0; level--) {
    800011c8:	3a5d                	addiw	s4,s4,-9 # 1ff7 <_entry-0x7fffe009>
    800011ca:	ff5a12e3          	bne	s4,s5,800011ae <walk+0x26>
        return 0;
      memset(pagetable, 0, PGSIZE);
      *pte = PA2PTE(pagetable) | PTE_V;
    }
  }
  return &pagetable[PX(0, va)];
    800011ce:	00c9d513          	srli	a0,s3,0xc
    800011d2:	1ff57513          	andi	a0,a0,511
    800011d6:	050e                	slli	a0,a0,0x3
    800011d8:	9526                	add	a0,a0,s1
}
    800011da:	70e2                	ld	ra,56(sp)
    800011dc:	7442                	ld	s0,48(sp)
    800011de:	74a2                	ld	s1,40(sp)
    800011e0:	7902                	ld	s2,32(sp)
    800011e2:	69e2                	ld	s3,24(sp)
    800011e4:	6a42                	ld	s4,16(sp)
    800011e6:	6aa2                	ld	s5,8(sp)
    800011e8:	6b02                	ld	s6,0(sp)
    800011ea:	6121                	addi	sp,sp,64
    800011ec:	8082                	ret
    panic("walk");
    800011ee:	00007517          	auipc	a0,0x7
    800011f2:	f5250513          	addi	a0,a0,-174 # 80008140 <etext+0x140>
    800011f6:	e2eff0ef          	jal	80000824 <panic>
      if(!alloc || (pagetable = (pde_t*)kalloc()) == 0)
    800011fa:	020b0263          	beqz	s6,8000121e <walk+0x96>
    800011fe:	b0fff0ef          	jal	80000d0c <kalloc>
    80001202:	84aa                	mv	s1,a0
    80001204:	d979                	beqz	a0,800011da <walk+0x52>
      memset(pagetable, 0, PGSIZE);
    80001206:	6605                	lui	a2,0x1
    80001208:	4581                	li	a1,0
    8000120a:	ce3ff0ef          	jal	80000eec <memset>
      *pte = PA2PTE(pagetable) | PTE_V;
    8000120e:	00c4d793          	srli	a5,s1,0xc
    80001212:	07aa                	slli	a5,a5,0xa
    80001214:	0017e793          	ori	a5,a5,1
    80001218:	00f93023          	sd	a5,0(s2)
    8000121c:	b775                	j	800011c8 <walk+0x40>
        return 0;
    8000121e:	4501                	li	a0,0
    80001220:	bf6d                	j	800011da <walk+0x52>

0000000080001222 <walkaddr>:
walkaddr(pagetable_t pagetable, uint64 va)
{
  pte_t *pte;
  uint64 pa;

  if(va >= MAXVA)
    80001222:	57fd                	li	a5,-1
    80001224:	83e9                	srli	a5,a5,0x1a
    80001226:	00b7f463          	bgeu	a5,a1,8000122e <walkaddr+0xc>
    return 0;
    8000122a:	4501                	li	a0,0
    return 0;
  if((*pte & PTE_U) == 0)
    return 0;
  pa = PTE2PA(*pte);
  return pa;
}
    8000122c:	8082                	ret
{
    8000122e:	1141                	addi	sp,sp,-16
    80001230:	e406                	sd	ra,8(sp)
    80001232:	e022                	sd	s0,0(sp)
    80001234:	0800                	addi	s0,sp,16
  pte = walk(pagetable, va, 0);
    80001236:	4601                	li	a2,0
    80001238:	f51ff0ef          	jal	80001188 <walk>
  if(pte == 0)
    8000123c:	c901                	beqz	a0,8000124c <walkaddr+0x2a>
  if((*pte & PTE_V) == 0)
    8000123e:	611c                	ld	a5,0(a0)
  if((*pte & PTE_U) == 0)
    80001240:	0117f693          	andi	a3,a5,17
    80001244:	4745                	li	a4,17
    return 0;
    80001246:	4501                	li	a0,0
  if((*pte & PTE_U) == 0)
    80001248:	00e68663          	beq	a3,a4,80001254 <walkaddr+0x32>
}
    8000124c:	60a2                	ld	ra,8(sp)
    8000124e:	6402                	ld	s0,0(sp)
    80001250:	0141                	addi	sp,sp,16
    80001252:	8082                	ret
  pa = PTE2PA(*pte);
    80001254:	83a9                	srli	a5,a5,0xa
    80001256:	00c79513          	slli	a0,a5,0xc
  return pa;
    8000125a:	bfcd                	j	8000124c <walkaddr+0x2a>

000000008000125c <mappages>:
// va and size MUST be page-aligned.
// Returns 0 on success, -1 if walk() couldn't
// allocate a needed page-table page.
int
mappages(pagetable_t pagetable, uint64 va, uint64 size, uint64 pa, int perm)
{
    8000125c:	715d                	addi	sp,sp,-80
    8000125e:	e486                	sd	ra,72(sp)
    80001260:	e0a2                	sd	s0,64(sp)
    80001262:	fc26                	sd	s1,56(sp)
    80001264:	f84a                	sd	s2,48(sp)
    80001266:	f44e                	sd	s3,40(sp)
    80001268:	f052                	sd	s4,32(sp)
    8000126a:	ec56                	sd	s5,24(sp)
    8000126c:	e85a                	sd	s6,16(sp)
    8000126e:	e45e                	sd	s7,8(sp)
    80001270:	0880                	addi	s0,sp,80
  uint64 a, last;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001272:	03459793          	slli	a5,a1,0x34
    80001276:	eba1                	bnez	a5,800012c6 <mappages+0x6a>
    80001278:	8a2a                	mv	s4,a0
    8000127a:	8aba                	mv	s5,a4
    panic("mappages: va not aligned");

  if((size % PGSIZE) != 0)
    8000127c:	03461793          	slli	a5,a2,0x34
    80001280:	eba9                	bnez	a5,800012d2 <mappages+0x76>
    panic("mappages: size not aligned");

  if(size == 0)
    80001282:	ce31                	beqz	a2,800012de <mappages+0x82>
    panic("mappages: size");
  
  a = va;
  last = va + size - PGSIZE;
    80001284:	80060613          	addi	a2,a2,-2048 # 800 <_entry-0x7ffff800>
    80001288:	80060613          	addi	a2,a2,-2048
    8000128c:	00b60933          	add	s2,a2,a1
  a = va;
    80001290:	84ae                	mv	s1,a1
  for(;;){
    if((pte = walk(pagetable, a, 1)) == 0)
    80001292:	4b05                	li	s6,1
    80001294:	40b689b3          	sub	s3,a3,a1
    if(*pte & PTE_V)
      panic("mappages: remap");
    *pte = PA2PTE(pa) | perm | PTE_V;
    if(a == last)
      break;
    a += PGSIZE;
    80001298:	6b85                	lui	s7,0x1
    if((pte = walk(pagetable, a, 1)) == 0)
    8000129a:	865a                	mv	a2,s6
    8000129c:	85a6                	mv	a1,s1
    8000129e:	8552                	mv	a0,s4
    800012a0:	ee9ff0ef          	jal	80001188 <walk>
    800012a4:	c929                	beqz	a0,800012f6 <mappages+0x9a>
    if(*pte & PTE_V)
    800012a6:	611c                	ld	a5,0(a0)
    800012a8:	8b85                	andi	a5,a5,1
    800012aa:	e3a1                	bnez	a5,800012ea <mappages+0x8e>
    *pte = PA2PTE(pa) | perm | PTE_V;
    800012ac:	013487b3          	add	a5,s1,s3
    800012b0:	83b1                	srli	a5,a5,0xc
    800012b2:	07aa                	slli	a5,a5,0xa
    800012b4:	0157e7b3          	or	a5,a5,s5
    800012b8:	0017e793          	ori	a5,a5,1
    800012bc:	e11c                	sd	a5,0(a0)
    if(a == last)
    800012be:	05248863          	beq	s1,s2,8000130e <mappages+0xb2>
    a += PGSIZE;
    800012c2:	94de                	add	s1,s1,s7
    if((pte = walk(pagetable, a, 1)) == 0)
    800012c4:	bfd9                	j	8000129a <mappages+0x3e>
    panic("mappages: va not aligned");
    800012c6:	00007517          	auipc	a0,0x7
    800012ca:	e8250513          	addi	a0,a0,-382 # 80008148 <etext+0x148>
    800012ce:	d56ff0ef          	jal	80000824 <panic>
    panic("mappages: size not aligned");
    800012d2:	00007517          	auipc	a0,0x7
    800012d6:	e9650513          	addi	a0,a0,-362 # 80008168 <etext+0x168>
    800012da:	d4aff0ef          	jal	80000824 <panic>
    panic("mappages: size");
    800012de:	00007517          	auipc	a0,0x7
    800012e2:	eaa50513          	addi	a0,a0,-342 # 80008188 <etext+0x188>
    800012e6:	d3eff0ef          	jal	80000824 <panic>
      panic("mappages: remap");
    800012ea:	00007517          	auipc	a0,0x7
    800012ee:	eae50513          	addi	a0,a0,-338 # 80008198 <etext+0x198>
    800012f2:	d32ff0ef          	jal	80000824 <panic>
      return -1;
    800012f6:	557d                	li	a0,-1
    pa += PGSIZE;
  }
  return 0;
}
    800012f8:	60a6                	ld	ra,72(sp)
    800012fa:	6406                	ld	s0,64(sp)
    800012fc:	74e2                	ld	s1,56(sp)
    800012fe:	7942                	ld	s2,48(sp)
    80001300:	79a2                	ld	s3,40(sp)
    80001302:	7a02                	ld	s4,32(sp)
    80001304:	6ae2                	ld	s5,24(sp)
    80001306:	6b42                	ld	s6,16(sp)
    80001308:	6ba2                	ld	s7,8(sp)
    8000130a:	6161                	addi	sp,sp,80
    8000130c:	8082                	ret
  return 0;
    8000130e:	4501                	li	a0,0
    80001310:	b7e5                	j	800012f8 <mappages+0x9c>

0000000080001312 <kvmmap>:
{
    80001312:	1141                	addi	sp,sp,-16
    80001314:	e406                	sd	ra,8(sp)
    80001316:	e022                	sd	s0,0(sp)
    80001318:	0800                	addi	s0,sp,16
    8000131a:	87b6                	mv	a5,a3
  if(mappages(kpgtbl, va, sz, pa, perm) != 0)
    8000131c:	86b2                	mv	a3,a2
    8000131e:	863e                	mv	a2,a5
    80001320:	f3dff0ef          	jal	8000125c <mappages>
    80001324:	e509                	bnez	a0,8000132e <kvmmap+0x1c>
}
    80001326:	60a2                	ld	ra,8(sp)
    80001328:	6402                	ld	s0,0(sp)
    8000132a:	0141                	addi	sp,sp,16
    8000132c:	8082                	ret
    panic("kvmmap");
    8000132e:	00007517          	auipc	a0,0x7
    80001332:	e7a50513          	addi	a0,a0,-390 # 800081a8 <etext+0x1a8>
    80001336:	ceeff0ef          	jal	80000824 <panic>

000000008000133a <kvmmake>:
{
    8000133a:	1101                	addi	sp,sp,-32
    8000133c:	ec06                	sd	ra,24(sp)
    8000133e:	e822                	sd	s0,16(sp)
    80001340:	e426                	sd	s1,8(sp)
    80001342:	1000                	addi	s0,sp,32
  kpgtbl = (pagetable_t) kalloc();
    80001344:	9c9ff0ef          	jal	80000d0c <kalloc>
    80001348:	84aa                	mv	s1,a0
  memset(kpgtbl, 0, PGSIZE);
    8000134a:	6605                	lui	a2,0x1
    8000134c:	4581                	li	a1,0
    8000134e:	b9fff0ef          	jal	80000eec <memset>
  kvmmap(kpgtbl, UART0, UART0, PGSIZE, PTE_R | PTE_W);
    80001352:	4719                	li	a4,6
    80001354:	6685                	lui	a3,0x1
    80001356:	10000637          	lui	a2,0x10000
    8000135a:	85b2                	mv	a1,a2
    8000135c:	8526                	mv	a0,s1
    8000135e:	fb5ff0ef          	jal	80001312 <kvmmap>
  kvmmap(kpgtbl, VIRTIO0, VIRTIO0, PGSIZE, PTE_R | PTE_W);
    80001362:	4719                	li	a4,6
    80001364:	6685                	lui	a3,0x1
    80001366:	10001637          	lui	a2,0x10001
    8000136a:	85b2                	mv	a1,a2
    8000136c:	8526                	mv	a0,s1
    8000136e:	fa5ff0ef          	jal	80001312 <kvmmap>
  kvmmap(kpgtbl, PLIC, PLIC, 0x4000000, PTE_R | PTE_W);
    80001372:	4719                	li	a4,6
    80001374:	040006b7          	lui	a3,0x4000
    80001378:	0c000637          	lui	a2,0xc000
    8000137c:	85b2                	mv	a1,a2
    8000137e:	8526                	mv	a0,s1
    80001380:	f93ff0ef          	jal	80001312 <kvmmap>
  kvmmap(kpgtbl, KERNBASE, KERNBASE, (uint64)etext-KERNBASE, PTE_R | PTE_X);
    80001384:	4729                	li	a4,10
    80001386:	80007697          	auipc	a3,0x80007
    8000138a:	c7a68693          	addi	a3,a3,-902 # 8000 <_entry-0x7fff8000>
    8000138e:	4605                	li	a2,1
    80001390:	067e                	slli	a2,a2,0x1f
    80001392:	85b2                	mv	a1,a2
    80001394:	8526                	mv	a0,s1
    80001396:	f7dff0ef          	jal	80001312 <kvmmap>
  kvmmap(kpgtbl, (uint64)etext, (uint64)etext, PHYSTOP-(uint64)etext, PTE_R | PTE_W);
    8000139a:	4719                	li	a4,6
    8000139c:	00007697          	auipc	a3,0x7
    800013a0:	c6468693          	addi	a3,a3,-924 # 80008000 <etext>
    800013a4:	47c5                	li	a5,17
    800013a6:	07ee                	slli	a5,a5,0x1b
    800013a8:	40d786b3          	sub	a3,a5,a3
    800013ac:	00007617          	auipc	a2,0x7
    800013b0:	c5460613          	addi	a2,a2,-940 # 80008000 <etext>
    800013b4:	85b2                	mv	a1,a2
    800013b6:	8526                	mv	a0,s1
    800013b8:	f5bff0ef          	jal	80001312 <kvmmap>
  kvmmap(kpgtbl, TRAMPOLINE, (uint64)trampoline, PGSIZE, PTE_R | PTE_X);
    800013bc:	4729                	li	a4,10
    800013be:	6685                	lui	a3,0x1
    800013c0:	00006617          	auipc	a2,0x6
    800013c4:	c4060613          	addi	a2,a2,-960 # 80007000 <_trampoline>
    800013c8:	040005b7          	lui	a1,0x4000
    800013cc:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    800013ce:	05b2                	slli	a1,a1,0xc
    800013d0:	8526                	mv	a0,s1
    800013d2:	f41ff0ef          	jal	80001312 <kvmmap>
  proc_mapstacks(kpgtbl);
    800013d6:	8526                	mv	a0,s1
    800013d8:	5ca000ef          	jal	800019a2 <proc_mapstacks>
}
    800013dc:	8526                	mv	a0,s1
    800013de:	60e2                	ld	ra,24(sp)
    800013e0:	6442                	ld	s0,16(sp)
    800013e2:	64a2                	ld	s1,8(sp)
    800013e4:	6105                	addi	sp,sp,32
    800013e6:	8082                	ret

00000000800013e8 <kvminit>:
{
    800013e8:	1141                	addi	sp,sp,-16
    800013ea:	e406                	sd	ra,8(sp)
    800013ec:	e022                	sd	s0,0(sp)
    800013ee:	0800                	addi	s0,sp,16
  kernel_pagetable = kvmmake();
    800013f0:	f4bff0ef          	jal	8000133a <kvmmake>
    800013f4:	00007797          	auipc	a5,0x7
    800013f8:	58a7ba23          	sd	a0,1428(a5) # 80008988 <kernel_pagetable>
}
    800013fc:	60a2                	ld	ra,8(sp)
    800013fe:	6402                	ld	s0,0(sp)
    80001400:	0141                	addi	sp,sp,16
    80001402:	8082                	ret

0000000080001404 <uvmcreate>:

// create an empty user page table.
// returns 0 if out of memory.
pagetable_t
uvmcreate()
{
    80001404:	1101                	addi	sp,sp,-32
    80001406:	ec06                	sd	ra,24(sp)
    80001408:	e822                	sd	s0,16(sp)
    8000140a:	e426                	sd	s1,8(sp)
    8000140c:	1000                	addi	s0,sp,32
  pagetable_t pagetable;
  pagetable = (pagetable_t) kalloc();
    8000140e:	8ffff0ef          	jal	80000d0c <kalloc>
    80001412:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001414:	c509                	beqz	a0,8000141e <uvmcreate+0x1a>
    return 0;
  memset(pagetable, 0, PGSIZE);
    80001416:	6605                	lui	a2,0x1
    80001418:	4581                	li	a1,0
    8000141a:	ad3ff0ef          	jal	80000eec <memset>
  return pagetable;
}
    8000141e:	8526                	mv	a0,s1
    80001420:	60e2                	ld	ra,24(sp)
    80001422:	6442                	ld	s0,16(sp)
    80001424:	64a2                	ld	s1,8(sp)
    80001426:	6105                	addi	sp,sp,32
    80001428:	8082                	ret

000000008000142a <uvmunmap>:
// Remove npages of mappings starting from va. va must be
// page-aligned. It's OK if the mappings don't exist.
// Optionally free the physical memory.
void
uvmunmap(pagetable_t pagetable, uint64 va, uint64 npages, int do_free)
{
    8000142a:	7139                	addi	sp,sp,-64
    8000142c:	fc06                	sd	ra,56(sp)
    8000142e:	f822                	sd	s0,48(sp)
    80001430:	0080                	addi	s0,sp,64
  uint64 a;
  pte_t *pte;

  if((va % PGSIZE) != 0)
    80001432:	03459793          	slli	a5,a1,0x34
    80001436:	e38d                	bnez	a5,80001458 <uvmunmap+0x2e>
    80001438:	f04a                	sd	s2,32(sp)
    8000143a:	ec4e                	sd	s3,24(sp)
    8000143c:	e852                	sd	s4,16(sp)
    8000143e:	e456                	sd	s5,8(sp)
    80001440:	e05a                	sd	s6,0(sp)
    80001442:	8a2a                	mv	s4,a0
    80001444:	892e                	mv	s2,a1
    80001446:	8ab6                	mv	s5,a3
    panic("uvmunmap: not aligned");

  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001448:	0632                	slli	a2,a2,0xc
    8000144a:	00b609b3          	add	s3,a2,a1
    8000144e:	6b05                	lui	s6,0x1
    80001450:	0535f963          	bgeu	a1,s3,800014a2 <uvmunmap+0x78>
    80001454:	f426                	sd	s1,40(sp)
    80001456:	a015                	j	8000147a <uvmunmap+0x50>
    80001458:	f426                	sd	s1,40(sp)
    8000145a:	f04a                	sd	s2,32(sp)
    8000145c:	ec4e                	sd	s3,24(sp)
    8000145e:	e852                	sd	s4,16(sp)
    80001460:	e456                	sd	s5,8(sp)
    80001462:	e05a                	sd	s6,0(sp)
    panic("uvmunmap: not aligned");
    80001464:	00007517          	auipc	a0,0x7
    80001468:	d4c50513          	addi	a0,a0,-692 # 800081b0 <etext+0x1b0>
    8000146c:	bb8ff0ef          	jal	80000824 <panic>
      continue;
    if(do_free){
      uint64 pa = PTE2PA(*pte);
      kfree((void*)pa);
    }
    *pte = 0;
    80001470:	0004b023          	sd	zero,0(s1)
  for(a = va; a < va + npages*PGSIZE; a += PGSIZE){
    80001474:	995a                	add	s2,s2,s6
    80001476:	03397563          	bgeu	s2,s3,800014a0 <uvmunmap+0x76>
    if((pte = walk(pagetable, a, 0)) == 0) // leaf page table entry allocated?
    8000147a:	4601                	li	a2,0
    8000147c:	85ca                	mv	a1,s2
    8000147e:	8552                	mv	a0,s4
    80001480:	d09ff0ef          	jal	80001188 <walk>
    80001484:	84aa                	mv	s1,a0
    80001486:	d57d                	beqz	a0,80001474 <uvmunmap+0x4a>
    if((*pte & PTE_V) == 0)  // has physical page been allocated?
    80001488:	611c                	ld	a5,0(a0)
    8000148a:	0017f713          	andi	a4,a5,1
    8000148e:	d37d                	beqz	a4,80001474 <uvmunmap+0x4a>
    if(do_free){
    80001490:	fe0a80e3          	beqz	s5,80001470 <uvmunmap+0x46>
      uint64 pa = PTE2PA(*pte);
    80001494:	83a9                	srli	a5,a5,0xa
      kfree((void*)pa);
    80001496:	00c79513          	slli	a0,a5,0xc
    8000149a:	f42ff0ef          	jal	80000bdc <kfree>
    8000149e:	bfc9                	j	80001470 <uvmunmap+0x46>
    800014a0:	74a2                	ld	s1,40(sp)
    800014a2:	7902                	ld	s2,32(sp)
    800014a4:	69e2                	ld	s3,24(sp)
    800014a6:	6a42                	ld	s4,16(sp)
    800014a8:	6aa2                	ld	s5,8(sp)
    800014aa:	6b02                	ld	s6,0(sp)
  }
}
    800014ac:	70e2                	ld	ra,56(sp)
    800014ae:	7442                	ld	s0,48(sp)
    800014b0:	6121                	addi	sp,sp,64
    800014b2:	8082                	ret

00000000800014b4 <uvmdealloc>:
// newsz.  oldsz and newsz need not be page-aligned, nor does newsz
// need to be less than oldsz.  oldsz can be larger than the actual
// process size.  Returns the new process size.
uint64
uvmdealloc(pagetable_t pagetable, uint64 oldsz, uint64 newsz)
{
    800014b4:	1101                	addi	sp,sp,-32
    800014b6:	ec06                	sd	ra,24(sp)
    800014b8:	e822                	sd	s0,16(sp)
    800014ba:	e426                	sd	s1,8(sp)
    800014bc:	1000                	addi	s0,sp,32
  if(newsz >= oldsz)
    return oldsz;
    800014be:	84ae                	mv	s1,a1
  if(newsz >= oldsz)
    800014c0:	00b67d63          	bgeu	a2,a1,800014da <uvmdealloc+0x26>
    800014c4:	84b2                	mv	s1,a2

  if(PGROUNDUP(newsz) < PGROUNDUP(oldsz)){
    800014c6:	6785                	lui	a5,0x1
    800014c8:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    800014ca:	00f60733          	add	a4,a2,a5
    800014ce:	76fd                	lui	a3,0xfffff
    800014d0:	8f75                	and	a4,a4,a3
    800014d2:	97ae                	add	a5,a5,a1
    800014d4:	8ff5                	and	a5,a5,a3
    800014d6:	00f76863          	bltu	a4,a5,800014e6 <uvmdealloc+0x32>
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
  }

  return newsz;
}
    800014da:	8526                	mv	a0,s1
    800014dc:	60e2                	ld	ra,24(sp)
    800014de:	6442                	ld	s0,16(sp)
    800014e0:	64a2                	ld	s1,8(sp)
    800014e2:	6105                	addi	sp,sp,32
    800014e4:	8082                	ret
    int npages = (PGROUNDUP(oldsz) - PGROUNDUP(newsz)) / PGSIZE;
    800014e6:	8f99                	sub	a5,a5,a4
    800014e8:	83b1                	srli	a5,a5,0xc
    uvmunmap(pagetable, PGROUNDUP(newsz), npages, 1);
    800014ea:	4685                	li	a3,1
    800014ec:	0007861b          	sext.w	a2,a5
    800014f0:	85ba                	mv	a1,a4
    800014f2:	f39ff0ef          	jal	8000142a <uvmunmap>
    800014f6:	b7d5                	j	800014da <uvmdealloc+0x26>

00000000800014f8 <uvmalloc>:
  if(newsz < oldsz)
    800014f8:	0ab66163          	bltu	a2,a1,8000159a <uvmalloc+0xa2>
{
    800014fc:	715d                	addi	sp,sp,-80
    800014fe:	e486                	sd	ra,72(sp)
    80001500:	e0a2                	sd	s0,64(sp)
    80001502:	f84a                	sd	s2,48(sp)
    80001504:	f052                	sd	s4,32(sp)
    80001506:	ec56                	sd	s5,24(sp)
    80001508:	e45e                	sd	s7,8(sp)
    8000150a:	0880                	addi	s0,sp,80
    8000150c:	8aaa                	mv	s5,a0
    8000150e:	8a32                	mv	s4,a2
  oldsz = PGROUNDUP(oldsz);
    80001510:	6785                	lui	a5,0x1
    80001512:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001514:	95be                	add	a1,a1,a5
    80001516:	77fd                	lui	a5,0xfffff
    80001518:	00f5f933          	and	s2,a1,a5
    8000151c:	8bca                	mv	s7,s2
  for(a = oldsz; a < newsz; a += PGSIZE){
    8000151e:	08c97063          	bgeu	s2,a2,8000159e <uvmalloc+0xa6>
    80001522:	fc26                	sd	s1,56(sp)
    80001524:	f44e                	sd	s3,40(sp)
    80001526:	e85a                	sd	s6,16(sp)
    memset(mem, 0, PGSIZE);
    80001528:	6985                	lui	s3,0x1
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000152a:	0126eb13          	ori	s6,a3,18
    mem = kalloc();
    8000152e:	fdeff0ef          	jal	80000d0c <kalloc>
    80001532:	84aa                	mv	s1,a0
    if(mem == 0){
    80001534:	c50d                	beqz	a0,8000155e <uvmalloc+0x66>
    memset(mem, 0, PGSIZE);
    80001536:	864e                	mv	a2,s3
    80001538:	4581                	li	a1,0
    8000153a:	9b3ff0ef          	jal	80000eec <memset>
    if(mappages(pagetable, a, PGSIZE, (uint64)mem, PTE_R|PTE_U|xperm) != 0){
    8000153e:	875a                	mv	a4,s6
    80001540:	86a6                	mv	a3,s1
    80001542:	864e                	mv	a2,s3
    80001544:	85ca                	mv	a1,s2
    80001546:	8556                	mv	a0,s5
    80001548:	d15ff0ef          	jal	8000125c <mappages>
    8000154c:	e915                	bnez	a0,80001580 <uvmalloc+0x88>
  for(a = oldsz; a < newsz; a += PGSIZE){
    8000154e:	994e                	add	s2,s2,s3
    80001550:	fd496fe3          	bltu	s2,s4,8000152e <uvmalloc+0x36>
  return newsz;
    80001554:	8552                	mv	a0,s4
    80001556:	74e2                	ld	s1,56(sp)
    80001558:	79a2                	ld	s3,40(sp)
    8000155a:	6b42                	ld	s6,16(sp)
    8000155c:	a811                	j	80001570 <uvmalloc+0x78>
      uvmdealloc(pagetable, a, oldsz);
    8000155e:	865e                	mv	a2,s7
    80001560:	85ca                	mv	a1,s2
    80001562:	8556                	mv	a0,s5
    80001564:	f51ff0ef          	jal	800014b4 <uvmdealloc>
      return 0;
    80001568:	4501                	li	a0,0
    8000156a:	74e2                	ld	s1,56(sp)
    8000156c:	79a2                	ld	s3,40(sp)
    8000156e:	6b42                	ld	s6,16(sp)
}
    80001570:	60a6                	ld	ra,72(sp)
    80001572:	6406                	ld	s0,64(sp)
    80001574:	7942                	ld	s2,48(sp)
    80001576:	7a02                	ld	s4,32(sp)
    80001578:	6ae2                	ld	s5,24(sp)
    8000157a:	6ba2                	ld	s7,8(sp)
    8000157c:	6161                	addi	sp,sp,80
    8000157e:	8082                	ret
      kfree(mem);
    80001580:	8526                	mv	a0,s1
    80001582:	e5aff0ef          	jal	80000bdc <kfree>
      uvmdealloc(pagetable, a, oldsz);
    80001586:	865e                	mv	a2,s7
    80001588:	85ca                	mv	a1,s2
    8000158a:	8556                	mv	a0,s5
    8000158c:	f29ff0ef          	jal	800014b4 <uvmdealloc>
      return 0;
    80001590:	4501                	li	a0,0
    80001592:	74e2                	ld	s1,56(sp)
    80001594:	79a2                	ld	s3,40(sp)
    80001596:	6b42                	ld	s6,16(sp)
    80001598:	bfe1                	j	80001570 <uvmalloc+0x78>
    return oldsz;
    8000159a:	852e                	mv	a0,a1
}
    8000159c:	8082                	ret
  return newsz;
    8000159e:	8532                	mv	a0,a2
    800015a0:	bfc1                	j	80001570 <uvmalloc+0x78>

00000000800015a2 <freewalk>:

// Recursively free page-table pages.
// All leaf mappings must already have been removed.
void
freewalk(pagetable_t pagetable)
{
    800015a2:	7179                	addi	sp,sp,-48
    800015a4:	f406                	sd	ra,40(sp)
    800015a6:	f022                	sd	s0,32(sp)
    800015a8:	ec26                	sd	s1,24(sp)
    800015aa:	e84a                	sd	s2,16(sp)
    800015ac:	e44e                	sd	s3,8(sp)
    800015ae:	1800                	addi	s0,sp,48
    800015b0:	89aa                	mv	s3,a0
  // there are 2^9 = 512 PTEs in a page table.
  for(int i = 0; i < 512; i++){
    800015b2:	84aa                	mv	s1,a0
    800015b4:	6905                	lui	s2,0x1
    800015b6:	992a                	add	s2,s2,a0
    800015b8:	a811                	j	800015cc <freewalk+0x2a>
      // this PTE points to a lower-level page table.
      uint64 child = PTE2PA(pte);
      freewalk((pagetable_t)child);
      pagetable[i] = 0;
    } else if(pte & PTE_V){
      panic("freewalk: leaf");
    800015ba:	00007517          	auipc	a0,0x7
    800015be:	c0e50513          	addi	a0,a0,-1010 # 800081c8 <etext+0x1c8>
    800015c2:	a62ff0ef          	jal	80000824 <panic>
  for(int i = 0; i < 512; i++){
    800015c6:	04a1                	addi	s1,s1,8
    800015c8:	03248163          	beq	s1,s2,800015ea <freewalk+0x48>
    pte_t pte = pagetable[i];
    800015cc:	609c                	ld	a5,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800015ce:	0017f713          	andi	a4,a5,1
    800015d2:	db75                	beqz	a4,800015c6 <freewalk+0x24>
    800015d4:	00e7f713          	andi	a4,a5,14
    800015d8:	f36d                	bnez	a4,800015ba <freewalk+0x18>
      uint64 child = PTE2PA(pte);
    800015da:	83a9                	srli	a5,a5,0xa
      freewalk((pagetable_t)child);
    800015dc:	00c79513          	slli	a0,a5,0xc
    800015e0:	fc3ff0ef          	jal	800015a2 <freewalk>
      pagetable[i] = 0;
    800015e4:	0004b023          	sd	zero,0(s1)
    if((pte & PTE_V) && (pte & (PTE_R|PTE_W|PTE_X)) == 0){
    800015e8:	bff9                	j	800015c6 <freewalk+0x24>
    }
  }
  kfree((void*)pagetable);
    800015ea:	854e                	mv	a0,s3
    800015ec:	df0ff0ef          	jal	80000bdc <kfree>
}
    800015f0:	70a2                	ld	ra,40(sp)
    800015f2:	7402                	ld	s0,32(sp)
    800015f4:	64e2                	ld	s1,24(sp)
    800015f6:	6942                	ld	s2,16(sp)
    800015f8:	69a2                	ld	s3,8(sp)
    800015fa:	6145                	addi	sp,sp,48
    800015fc:	8082                	ret

00000000800015fe <uvmfree>:

// Free user memory pages,
// then free page-table pages.
void
uvmfree(pagetable_t pagetable, uint64 sz)
{
    800015fe:	1101                	addi	sp,sp,-32
    80001600:	ec06                	sd	ra,24(sp)
    80001602:	e822                	sd	s0,16(sp)
    80001604:	e426                	sd	s1,8(sp)
    80001606:	1000                	addi	s0,sp,32
    80001608:	84aa                	mv	s1,a0
  if(sz > 0)
    8000160a:	e989                	bnez	a1,8000161c <uvmfree+0x1e>
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
  freewalk(pagetable);
    8000160c:	8526                	mv	a0,s1
    8000160e:	f95ff0ef          	jal	800015a2 <freewalk>
}
    80001612:	60e2                	ld	ra,24(sp)
    80001614:	6442                	ld	s0,16(sp)
    80001616:	64a2                	ld	s1,8(sp)
    80001618:	6105                	addi	sp,sp,32
    8000161a:	8082                	ret
    uvmunmap(pagetable, 0, PGROUNDUP(sz)/PGSIZE, 1);
    8000161c:	6785                	lui	a5,0x1
    8000161e:	17fd                	addi	a5,a5,-1 # fff <_entry-0x7ffff001>
    80001620:	95be                	add	a1,a1,a5
    80001622:	4685                	li	a3,1
    80001624:	00c5d613          	srli	a2,a1,0xc
    80001628:	4581                	li	a1,0
    8000162a:	e01ff0ef          	jal	8000142a <uvmunmap>
    8000162e:	bff9                	j	8000160c <uvmfree+0xe>

0000000080001630 <uvmcopy>:
  pte_t *pte;
  uint64 pa, i;
  uint flags;
  // char *mem;

  for(i = 0; i < sz; i += PGSIZE){
    80001630:	ce51                	beqz	a2,800016cc <uvmcopy+0x9c>
{
    80001632:	715d                	addi	sp,sp,-80
    80001634:	e486                	sd	ra,72(sp)
    80001636:	e0a2                	sd	s0,64(sp)
    80001638:	fc26                	sd	s1,56(sp)
    8000163a:	f84a                	sd	s2,48(sp)
    8000163c:	f44e                	sd	s3,40(sp)
    8000163e:	f052                	sd	s4,32(sp)
    80001640:	ec56                	sd	s5,24(sp)
    80001642:	e85a                	sd	s6,16(sp)
    80001644:	e45e                	sd	s7,8(sp)
    80001646:	0880                	addi	s0,sp,80
    80001648:	8a2a                	mv	s4,a0
    8000164a:	8aae                	mv	s5,a1
    8000164c:	89b2                	mv	s3,a2
  for(i = 0; i < sz; i += PGSIZE){
    8000164e:	4481                	li	s1,0
    if((*pte & PTE_V) == 0)
      continue;   // physical page hasn't been allocated
    pa = PTE2PA(*pte);
    flags = PTE_FLAGS(*pte);
    flags = (flags & ~PTE_W) | PTE_COW;
    *pte = PA2PTE(pa) | flags;
    80001650:	7b7d                	lui	s6,0xfffff
    80001652:	002b5b13          	srli	s6,s6,0x2
    // if((mem = kalloc()) == 0)
      // goto err;
    // memmove(mem, (char*)pa, PGSIZE);
    if(mappages(new, i, PGSIZE, pa, flags) != 0){
    80001656:	6905                	lui	s2,0x1
    80001658:	a829                	j	80001672 <uvmcopy+0x42>
    inc(pa);
  }
  return 0;

 err:
  uvmunmap(new, 0, i / PGSIZE, 1);
    8000165a:	4685                	li	a3,1
    8000165c:	00c4d613          	srli	a2,s1,0xc
    80001660:	4581                	li	a1,0
    80001662:	8556                	mv	a0,s5
    80001664:	dc7ff0ef          	jal	8000142a <uvmunmap>
  return -1;
    80001668:	557d                	li	a0,-1
    8000166a:	a0b1                	j	800016b6 <uvmcopy+0x86>
  for(i = 0; i < sz; i += PGSIZE){
    8000166c:	94ca                	add	s1,s1,s2
    8000166e:	0534f363          	bgeu	s1,s3,800016b4 <uvmcopy+0x84>
    if((pte = walk(old, i, 0)) == 0)
    80001672:	4601                	li	a2,0
    80001674:	85a6                	mv	a1,s1
    80001676:	8552                	mv	a0,s4
    80001678:	b11ff0ef          	jal	80001188 <walk>
    8000167c:	d965                	beqz	a0,8000166c <uvmcopy+0x3c>
    if((*pte & PTE_V) == 0)
    8000167e:	611c                	ld	a5,0(a0)
    80001680:	0017f713          	andi	a4,a5,1
    80001684:	d765                	beqz	a4,8000166c <uvmcopy+0x3c>
    pa = PTE2PA(*pte);
    80001686:	00a7db93          	srli	s7,a5,0xa
    8000168a:	0bb2                	slli	s7,s7,0xc
    flags = (flags & ~PTE_W) | PTE_COW;
    8000168c:	2fb7f713          	andi	a4,a5,763
    *pte = PA2PTE(pa) | flags;
    80001690:	0167f7b3          	and	a5,a5,s6
    80001694:	10076693          	ori	a3,a4,256
    80001698:	8fd5                	or	a5,a5,a3
    8000169a:	e11c                	sd	a5,0(a0)
    if(mappages(new, i, PGSIZE, pa, flags) != 0){
    8000169c:	8736                	mv	a4,a3
    8000169e:	86de                	mv	a3,s7
    800016a0:	864a                	mv	a2,s2
    800016a2:	85a6                	mv	a1,s1
    800016a4:	8556                	mv	a0,s5
    800016a6:	bb7ff0ef          	jal	8000125c <mappages>
    800016aa:	f945                	bnez	a0,8000165a <uvmcopy+0x2a>
    inc(pa);
    800016ac:	855e                	mv	a0,s7
    800016ae:	baeff0ef          	jal	80000a5c <inc>
    800016b2:	bf6d                	j	8000166c <uvmcopy+0x3c>
  return 0;
    800016b4:	4501                	li	a0,0
}
    800016b6:	60a6                	ld	ra,72(sp)
    800016b8:	6406                	ld	s0,64(sp)
    800016ba:	74e2                	ld	s1,56(sp)
    800016bc:	7942                	ld	s2,48(sp)
    800016be:	79a2                	ld	s3,40(sp)
    800016c0:	7a02                	ld	s4,32(sp)
    800016c2:	6ae2                	ld	s5,24(sp)
    800016c4:	6b42                	ld	s6,16(sp)
    800016c6:	6ba2                	ld	s7,8(sp)
    800016c8:	6161                	addi	sp,sp,80
    800016ca:	8082                	ret
  return 0;
    800016cc:	4501                	li	a0,0
}
    800016ce:	8082                	ret

00000000800016d0 <uvmclear>:

// mark a PTE invalid for user access.
// used by exec for the user stack guard page.
void
uvmclear(pagetable_t pagetable, uint64 va)
{
    800016d0:	1141                	addi	sp,sp,-16
    800016d2:	e406                	sd	ra,8(sp)
    800016d4:	e022                	sd	s0,0(sp)
    800016d6:	0800                	addi	s0,sp,16
  pte_t *pte;
  
  pte = walk(pagetable, va, 0);
    800016d8:	4601                	li	a2,0
    800016da:	aafff0ef          	jal	80001188 <walk>
  if(pte == 0)
    800016de:	c901                	beqz	a0,800016ee <uvmclear+0x1e>
    panic("uvmclear");
  *pte &= ~PTE_U;
    800016e0:	611c                	ld	a5,0(a0)
    800016e2:	9bbd                	andi	a5,a5,-17
    800016e4:	e11c                	sd	a5,0(a0)
}
    800016e6:	60a2                	ld	ra,8(sp)
    800016e8:	6402                	ld	s0,0(sp)
    800016ea:	0141                	addi	sp,sp,16
    800016ec:	8082                	ret
    panic("uvmclear");
    800016ee:	00007517          	auipc	a0,0x7
    800016f2:	aea50513          	addi	a0,a0,-1302 # 800081d8 <etext+0x1d8>
    800016f6:	92eff0ef          	jal	80000824 <panic>

00000000800016fa <copyinstr>:
copyinstr(pagetable_t pagetable, char *dst, uint64 srcva, uint64 max)
{
  uint64 n, va0, pa0;
  int got_null = 0;

  while(got_null == 0 && max > 0){
    800016fa:	cac5                	beqz	a3,800017aa <copyinstr+0xb0>
{
    800016fc:	715d                	addi	sp,sp,-80
    800016fe:	e486                	sd	ra,72(sp)
    80001700:	e0a2                	sd	s0,64(sp)
    80001702:	fc26                	sd	s1,56(sp)
    80001704:	f84a                	sd	s2,48(sp)
    80001706:	f44e                	sd	s3,40(sp)
    80001708:	f052                	sd	s4,32(sp)
    8000170a:	ec56                	sd	s5,24(sp)
    8000170c:	e85a                	sd	s6,16(sp)
    8000170e:	e45e                	sd	s7,8(sp)
    80001710:	0880                	addi	s0,sp,80
    80001712:	8aaa                	mv	s5,a0
    80001714:	84ae                	mv	s1,a1
    80001716:	8bb2                	mv	s7,a2
    80001718:	89b6                	mv	s3,a3
    va0 = PGROUNDDOWN(srcva);
    8000171a:	7b7d                	lui	s6,0xfffff
    pa0 = walkaddr(pagetable, va0);
    if(pa0 == 0)
      return -1;
    n = PGSIZE - (srcva - va0);
    8000171c:	6a05                	lui	s4,0x1
    8000171e:	a82d                	j	80001758 <copyinstr+0x5e>
      n = max;

    char *p = (char *) (pa0 + (srcva - va0));
    while(n > 0){
      if(*p == '\0'){
        *dst = '\0';
    80001720:	00078023          	sb	zero,0(a5)
        got_null = 1;
    80001724:	4785                	li	a5,1
      dst++;
    }

    srcva = va0 + PGSIZE;
  }
  if(got_null){
    80001726:	0017c793          	xori	a5,a5,1
    8000172a:	40f0053b          	negw	a0,a5
    return 0;
  } else {
    return -1;
  }
}
    8000172e:	60a6                	ld	ra,72(sp)
    80001730:	6406                	ld	s0,64(sp)
    80001732:	74e2                	ld	s1,56(sp)
    80001734:	7942                	ld	s2,48(sp)
    80001736:	79a2                	ld	s3,40(sp)
    80001738:	7a02                	ld	s4,32(sp)
    8000173a:	6ae2                	ld	s5,24(sp)
    8000173c:	6b42                	ld	s6,16(sp)
    8000173e:	6ba2                	ld	s7,8(sp)
    80001740:	6161                	addi	sp,sp,80
    80001742:	8082                	ret
    80001744:	fff98713          	addi	a4,s3,-1 # fff <_entry-0x7ffff001>
    80001748:	9726                	add	a4,a4,s1
      --max;
    8000174a:	40b709b3          	sub	s3,a4,a1
    srcva = va0 + PGSIZE;
    8000174e:	01490bb3          	add	s7,s2,s4
  while(got_null == 0 && max > 0){
    80001752:	04e58463          	beq	a1,a4,8000179a <copyinstr+0xa0>
{
    80001756:	84be                	mv	s1,a5
    va0 = PGROUNDDOWN(srcva);
    80001758:	016bf933          	and	s2,s7,s6
    pa0 = walkaddr(pagetable, va0);
    8000175c:	85ca                	mv	a1,s2
    8000175e:	8556                	mv	a0,s5
    80001760:	ac3ff0ef          	jal	80001222 <walkaddr>
    if(pa0 == 0)
    80001764:	cd0d                	beqz	a0,8000179e <copyinstr+0xa4>
    n = PGSIZE - (srcva - va0);
    80001766:	417906b3          	sub	a3,s2,s7
    8000176a:	96d2                	add	a3,a3,s4
    if(n > max)
    8000176c:	00d9f363          	bgeu	s3,a3,80001772 <copyinstr+0x78>
    80001770:	86ce                	mv	a3,s3
    while(n > 0){
    80001772:	ca85                	beqz	a3,800017a2 <copyinstr+0xa8>
    char *p = (char *) (pa0 + (srcva - va0));
    80001774:	01750633          	add	a2,a0,s7
    80001778:	41260633          	sub	a2,a2,s2
    8000177c:	87a6                	mv	a5,s1
      if(*p == '\0'){
    8000177e:	8e05                	sub	a2,a2,s1
    while(n > 0){
    80001780:	96a6                	add	a3,a3,s1
    80001782:	85be                	mv	a1,a5
      if(*p == '\0'){
    80001784:	00f60733          	add	a4,a2,a5
    80001788:	00074703          	lbu	a4,0(a4)
    8000178c:	db51                	beqz	a4,80001720 <copyinstr+0x26>
        *dst = *p;
    8000178e:	00e78023          	sb	a4,0(a5)
      dst++;
    80001792:	0785                	addi	a5,a5,1
    while(n > 0){
    80001794:	fed797e3          	bne	a5,a3,80001782 <copyinstr+0x88>
    80001798:	b775                	j	80001744 <copyinstr+0x4a>
    8000179a:	4781                	li	a5,0
    8000179c:	b769                	j	80001726 <copyinstr+0x2c>
      return -1;
    8000179e:	557d                	li	a0,-1
    800017a0:	b779                	j	8000172e <copyinstr+0x34>
    srcva = va0 + PGSIZE;
    800017a2:	6b85                	lui	s7,0x1
    800017a4:	9bca                	add	s7,s7,s2
    800017a6:	87a6                	mv	a5,s1
    800017a8:	b77d                	j	80001756 <copyinstr+0x5c>
  int got_null = 0;
    800017aa:	4781                	li	a5,0
  if(got_null){
    800017ac:	0017c793          	xori	a5,a5,1
    800017b0:	40f0053b          	negw	a0,a5
}
    800017b4:	8082                	ret

00000000800017b6 <ismapped>:
  return mem;
}

int
ismapped(pagetable_t pagetable, uint64 va)
{
    800017b6:	1141                	addi	sp,sp,-16
    800017b8:	e406                	sd	ra,8(sp)
    800017ba:	e022                	sd	s0,0(sp)
    800017bc:	0800                	addi	s0,sp,16
  pte_t *pte = walk(pagetable, va, 0);
    800017be:	4601                	li	a2,0
    800017c0:	9c9ff0ef          	jal	80001188 <walk>
  if (pte == 0) {
    800017c4:	c119                	beqz	a0,800017ca <ismapped+0x14>
    return 0;
  }
  if (*pte & PTE_V){
    800017c6:	6108                	ld	a0,0(a0)
    800017c8:	8905                	andi	a0,a0,1
    return 1;
  }
  return 0;
}
    800017ca:	60a2                	ld	ra,8(sp)
    800017cc:	6402                	ld	s0,0(sp)
    800017ce:	0141                	addi	sp,sp,16
    800017d0:	8082                	ret

00000000800017d2 <vmfault>:
{
    800017d2:	7179                	addi	sp,sp,-48
    800017d4:	f406                	sd	ra,40(sp)
    800017d6:	f022                	sd	s0,32(sp)
    800017d8:	e84a                	sd	s2,16(sp)
    800017da:	e44e                	sd	s3,8(sp)
    800017dc:	1800                	addi	s0,sp,48
    800017de:	89aa                	mv	s3,a0
    800017e0:	892e                	mv	s2,a1
  struct proc *p = myproc();
    800017e2:	34e000ef          	jal	80001b30 <myproc>
  if (va >= p->sz)
    800017e6:	653c                	ld	a5,72(a0)
    800017e8:	00f96a63          	bltu	s2,a5,800017fc <vmfault+0x2a>
    return 0;
    800017ec:	4981                	li	s3,0
}
    800017ee:	854e                	mv	a0,s3
    800017f0:	70a2                	ld	ra,40(sp)
    800017f2:	7402                	ld	s0,32(sp)
    800017f4:	6942                	ld	s2,16(sp)
    800017f6:	69a2                	ld	s3,8(sp)
    800017f8:	6145                	addi	sp,sp,48
    800017fa:	8082                	ret
    800017fc:	ec26                	sd	s1,24(sp)
    800017fe:	e052                	sd	s4,0(sp)
    80001800:	84aa                	mv	s1,a0
  va = PGROUNDDOWN(va);
    80001802:	77fd                	lui	a5,0xfffff
    80001804:	00f97a33          	and	s4,s2,a5
  if(ismapped(pagetable, va)) {
    80001808:	85d2                	mv	a1,s4
    8000180a:	854e                	mv	a0,s3
    8000180c:	fabff0ef          	jal	800017b6 <ismapped>
    return 0;
    80001810:	4981                	li	s3,0
  if(ismapped(pagetable, va)) {
    80001812:	c501                	beqz	a0,8000181a <vmfault+0x48>
    80001814:	64e2                	ld	s1,24(sp)
    80001816:	6a02                	ld	s4,0(sp)
    80001818:	bfd9                	j	800017ee <vmfault+0x1c>
  mem = (uint64) kalloc();
    8000181a:	cf2ff0ef          	jal	80000d0c <kalloc>
    8000181e:	892a                	mv	s2,a0
  if(mem == 0)
    80001820:	c905                	beqz	a0,80001850 <vmfault+0x7e>
  mem = (uint64) kalloc();
    80001822:	89aa                	mv	s3,a0
  memset((void *) mem, 0, PGSIZE);
    80001824:	6605                	lui	a2,0x1
    80001826:	4581                	li	a1,0
    80001828:	ec4ff0ef          	jal	80000eec <memset>
  if (mappages(p->pagetable, va, PGSIZE, mem, PTE_W|PTE_U|PTE_R) != 0) {
    8000182c:	4759                	li	a4,22
    8000182e:	86ca                	mv	a3,s2
    80001830:	6605                	lui	a2,0x1
    80001832:	85d2                	mv	a1,s4
    80001834:	68a8                	ld	a0,80(s1)
    80001836:	a27ff0ef          	jal	8000125c <mappages>
    8000183a:	e501                	bnez	a0,80001842 <vmfault+0x70>
    8000183c:	64e2                	ld	s1,24(sp)
    8000183e:	6a02                	ld	s4,0(sp)
    80001840:	b77d                	j	800017ee <vmfault+0x1c>
    kfree((void *)mem);
    80001842:	854a                	mv	a0,s2
    80001844:	b98ff0ef          	jal	80000bdc <kfree>
    return 0;
    80001848:	4981                	li	s3,0
    8000184a:	64e2                	ld	s1,24(sp)
    8000184c:	6a02                	ld	s4,0(sp)
    8000184e:	b745                	j	800017ee <vmfault+0x1c>
    80001850:	64e2                	ld	s1,24(sp)
    80001852:	6a02                	ld	s4,0(sp)
    80001854:	bf69                	j	800017ee <vmfault+0x1c>

0000000080001856 <copyout>:
  while(len > 0){
    80001856:	cad1                	beqz	a3,800018ea <copyout+0x94>
{
    80001858:	711d                	addi	sp,sp,-96
    8000185a:	ec86                	sd	ra,88(sp)
    8000185c:	e8a2                	sd	s0,80(sp)
    8000185e:	e4a6                	sd	s1,72(sp)
    80001860:	e0ca                	sd	s2,64(sp)
    80001862:	fc4e                	sd	s3,56(sp)
    80001864:	f852                	sd	s4,48(sp)
    80001866:	f456                	sd	s5,40(sp)
    80001868:	f05a                	sd	s6,32(sp)
    8000186a:	ec5e                	sd	s7,24(sp)
    8000186c:	e862                	sd	s8,16(sp)
    8000186e:	e466                	sd	s9,8(sp)
    80001870:	e06a                	sd	s10,0(sp)
    80001872:	1080                	addi	s0,sp,96
    80001874:	8baa                	mv	s7,a0
    80001876:	8a2e                	mv	s4,a1
    80001878:	8b32                	mv	s6,a2
    8000187a:	8ab6                	mv	s5,a3
    va0 = PGROUNDDOWN(dstva);
    8000187c:	7d7d                	lui	s10,0xfffff
    if(va0 >= MAXVA)
    8000187e:	5cfd                	li	s9,-1
    80001880:	01acdc93          	srli	s9,s9,0x1a
    n = PGSIZE - (dstva - va0);
    80001884:	6c05                	lui	s8,0x1
    80001886:	a005                	j	800018a6 <copyout+0x50>
    memmove((void *)(pa0 + (dstva - va0)), src, n);
    80001888:	409a0533          	sub	a0,s4,s1
    8000188c:	0009061b          	sext.w	a2,s2
    80001890:	85da                	mv	a1,s6
    80001892:	954e                	add	a0,a0,s3
    80001894:	eb8ff0ef          	jal	80000f4c <memmove>
    len -= n;
    80001898:	412a8ab3          	sub	s5,s5,s2
    src += n;
    8000189c:	9b4a                	add	s6,s6,s2
    dstva = va0 + PGSIZE;
    8000189e:	01848a33          	add	s4,s1,s8
  while(len > 0){
    800018a2:	040a8263          	beqz	s5,800018e6 <copyout+0x90>
    va0 = PGROUNDDOWN(dstva);
    800018a6:	01aa74b3          	and	s1,s4,s10
    if(va0 >= MAXVA)
    800018aa:	049ce263          	bltu	s9,s1,800018ee <copyout+0x98>
    pa0 = walkaddr(pagetable, va0);
    800018ae:	85a6                	mv	a1,s1
    800018b0:	855e                	mv	a0,s7
    800018b2:	971ff0ef          	jal	80001222 <walkaddr>
    800018b6:	89aa                	mv	s3,a0
    if(pa0 == 0) {
    800018b8:	e901                	bnez	a0,800018c8 <copyout+0x72>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    800018ba:	4601                	li	a2,0
    800018bc:	85a6                	mv	a1,s1
    800018be:	855e                	mv	a0,s7
    800018c0:	f13ff0ef          	jal	800017d2 <vmfault>
    800018c4:	89aa                	mv	s3,a0
    800018c6:	c139                	beqz	a0,8000190c <copyout+0xb6>
    pte = walk(pagetable, va0, 0);
    800018c8:	4601                	li	a2,0
    800018ca:	85a6                	mv	a1,s1
    800018cc:	855e                	mv	a0,s7
    800018ce:	8bbff0ef          	jal	80001188 <walk>
    if((*pte & PTE_W) == 0)
    800018d2:	611c                	ld	a5,0(a0)
    800018d4:	8b91                	andi	a5,a5,4
    800018d6:	cf8d                	beqz	a5,80001910 <copyout+0xba>
    n = PGSIZE - (dstva - va0);
    800018d8:	41448933          	sub	s2,s1,s4
    800018dc:	9962                	add	s2,s2,s8
    if(n > len)
    800018de:	fb2af5e3          	bgeu	s5,s2,80001888 <copyout+0x32>
    800018e2:	8956                	mv	s2,s5
    800018e4:	b755                	j	80001888 <copyout+0x32>
  return 0;
    800018e6:	4501                	li	a0,0
    800018e8:	a021                	j	800018f0 <copyout+0x9a>
    800018ea:	4501                	li	a0,0
}
    800018ec:	8082                	ret
      return -1;
    800018ee:	557d                	li	a0,-1
}
    800018f0:	60e6                	ld	ra,88(sp)
    800018f2:	6446                	ld	s0,80(sp)
    800018f4:	64a6                	ld	s1,72(sp)
    800018f6:	6906                	ld	s2,64(sp)
    800018f8:	79e2                	ld	s3,56(sp)
    800018fa:	7a42                	ld	s4,48(sp)
    800018fc:	7aa2                	ld	s5,40(sp)
    800018fe:	7b02                	ld	s6,32(sp)
    80001900:	6be2                	ld	s7,24(sp)
    80001902:	6c42                	ld	s8,16(sp)
    80001904:	6ca2                	ld	s9,8(sp)
    80001906:	6d02                	ld	s10,0(sp)
    80001908:	6125                	addi	sp,sp,96
    8000190a:	8082                	ret
        return -1;
    8000190c:	557d                	li	a0,-1
    8000190e:	b7cd                	j	800018f0 <copyout+0x9a>
      return -1;
    80001910:	557d                	li	a0,-1
    80001912:	bff9                	j	800018f0 <copyout+0x9a>

0000000080001914 <copyin>:
  while(len > 0){
    80001914:	c6c9                	beqz	a3,8000199e <copyin+0x8a>
{
    80001916:	715d                	addi	sp,sp,-80
    80001918:	e486                	sd	ra,72(sp)
    8000191a:	e0a2                	sd	s0,64(sp)
    8000191c:	fc26                	sd	s1,56(sp)
    8000191e:	f84a                	sd	s2,48(sp)
    80001920:	f44e                	sd	s3,40(sp)
    80001922:	f052                	sd	s4,32(sp)
    80001924:	ec56                	sd	s5,24(sp)
    80001926:	e85a                	sd	s6,16(sp)
    80001928:	e45e                	sd	s7,8(sp)
    8000192a:	e062                	sd	s8,0(sp)
    8000192c:	0880                	addi	s0,sp,80
    8000192e:	8baa                	mv	s7,a0
    80001930:	8aae                	mv	s5,a1
    80001932:	8932                	mv	s2,a2
    80001934:	8a36                	mv	s4,a3
    va0 = PGROUNDDOWN(srcva);
    80001936:	7c7d                	lui	s8,0xfffff
    n = PGSIZE - (srcva - va0);
    80001938:	6b05                	lui	s6,0x1
    8000193a:	a035                	j	80001966 <copyin+0x52>
    8000193c:	412984b3          	sub	s1,s3,s2
    80001940:	94da                	add	s1,s1,s6
    if(n > len)
    80001942:	009a7363          	bgeu	s4,s1,80001948 <copyin+0x34>
    80001946:	84d2                	mv	s1,s4
    memmove(dst, (void *)(pa0 + (srcva - va0)), n);
    80001948:	413905b3          	sub	a1,s2,s3
    8000194c:	0004861b          	sext.w	a2,s1
    80001950:	95aa                	add	a1,a1,a0
    80001952:	8556                	mv	a0,s5
    80001954:	df8ff0ef          	jal	80000f4c <memmove>
    len -= n;
    80001958:	409a0a33          	sub	s4,s4,s1
    dst += n;
    8000195c:	9aa6                	add	s5,s5,s1
    srcva = va0 + PGSIZE;
    8000195e:	01698933          	add	s2,s3,s6
  while(len > 0){
    80001962:	020a0163          	beqz	s4,80001984 <copyin+0x70>
    va0 = PGROUNDDOWN(srcva);
    80001966:	018979b3          	and	s3,s2,s8
    pa0 = walkaddr(pagetable, va0);
    8000196a:	85ce                	mv	a1,s3
    8000196c:	855e                	mv	a0,s7
    8000196e:	8b5ff0ef          	jal	80001222 <walkaddr>
    if(pa0 == 0) {
    80001972:	f569                	bnez	a0,8000193c <copyin+0x28>
      if((pa0 = vmfault(pagetable, va0, 0)) == 0) {
    80001974:	4601                	li	a2,0
    80001976:	85ce                	mv	a1,s3
    80001978:	855e                	mv	a0,s7
    8000197a:	e59ff0ef          	jal	800017d2 <vmfault>
    8000197e:	fd5d                	bnez	a0,8000193c <copyin+0x28>
        return -1;
    80001980:	557d                	li	a0,-1
    80001982:	a011                	j	80001986 <copyin+0x72>
  return 0;
    80001984:	4501                	li	a0,0
}
    80001986:	60a6                	ld	ra,72(sp)
    80001988:	6406                	ld	s0,64(sp)
    8000198a:	74e2                	ld	s1,56(sp)
    8000198c:	7942                	ld	s2,48(sp)
    8000198e:	79a2                	ld	s3,40(sp)
    80001990:	7a02                	ld	s4,32(sp)
    80001992:	6ae2                	ld	s5,24(sp)
    80001994:	6b42                	ld	s6,16(sp)
    80001996:	6ba2                	ld	s7,8(sp)
    80001998:	6c02                	ld	s8,0(sp)
    8000199a:	6161                	addi	sp,sp,80
    8000199c:	8082                	ret
  return 0;
    8000199e:	4501                	li	a0,0
}
    800019a0:	8082                	ret

00000000800019a2 <proc_mapstacks>:
// Allocate a page for each process's kernel stack.
// Map it high in memory, followed by an invalid
// guard page.
void
proc_mapstacks(pagetable_t kpgtbl)
{
    800019a2:	715d                	addi	sp,sp,-80
    800019a4:	e486                	sd	ra,72(sp)
    800019a6:	e0a2                	sd	s0,64(sp)
    800019a8:	fc26                	sd	s1,56(sp)
    800019aa:	f84a                	sd	s2,48(sp)
    800019ac:	f44e                	sd	s3,40(sp)
    800019ae:	f052                	sd	s4,32(sp)
    800019b0:	ec56                	sd	s5,24(sp)
    800019b2:	e85a                	sd	s6,16(sp)
    800019b4:	e45e                	sd	s7,8(sp)
    800019b6:	e062                	sd	s8,0(sp)
    800019b8:	0880                	addi	s0,sp,80
    800019ba:	8a2a                	mv	s4,a0
  struct proc *p;
  
  for(p = proc; p < &proc[NPROC]; p++) {
    800019bc:	0022f497          	auipc	s1,0x22f
    800019c0:	50c48493          	addi	s1,s1,1292 # 80230ec8 <proc>
    char *pa = kalloc();
    if(pa == 0)
      panic("kalloc");
    uint64 va = KSTACK((int) (p - proc));
    800019c4:	8c26                	mv	s8,s1
    800019c6:	000a57b7          	lui	a5,0xa5
    800019ca:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    800019ce:	07b2                	slli	a5,a5,0xc
    800019d0:	fa578793          	addi	a5,a5,-91
    800019d4:	4fa50937          	lui	s2,0x4fa50
    800019d8:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    800019dc:	1902                	slli	s2,s2,0x20
    800019de:	993e                	add	s2,s2,a5
    800019e0:	040009b7          	lui	s3,0x4000
    800019e4:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    800019e6:	09b2                	slli	s3,s3,0xc
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    800019e8:	4b99                	li	s7,6
    800019ea:	6b05                	lui	s6,0x1
  for(p = proc; p < &proc[NPROC]; p++) {
    800019ec:	00235a97          	auipc	s5,0x235
    800019f0:	edca8a93          	addi	s5,s5,-292 # 802368c8 <tickslock>
    char *pa = kalloc();
    800019f4:	b18ff0ef          	jal	80000d0c <kalloc>
    800019f8:	862a                	mv	a2,a0
    if(pa == 0)
    800019fa:	c121                	beqz	a0,80001a3a <proc_mapstacks+0x98>
    uint64 va = KSTACK((int) (p - proc));
    800019fc:	418485b3          	sub	a1,s1,s8
    80001a00:	858d                	srai	a1,a1,0x3
    80001a02:	032585b3          	mul	a1,a1,s2
    80001a06:	05b6                	slli	a1,a1,0xd
    80001a08:	6789                	lui	a5,0x2
    80001a0a:	9dbd                	addw	a1,a1,a5
    kvmmap(kpgtbl, va, (uint64)pa, PGSIZE, PTE_R | PTE_W);
    80001a0c:	875e                	mv	a4,s7
    80001a0e:	86da                	mv	a3,s6
    80001a10:	40b985b3          	sub	a1,s3,a1
    80001a14:	8552                	mv	a0,s4
    80001a16:	8fdff0ef          	jal	80001312 <kvmmap>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001a1a:	16848493          	addi	s1,s1,360
    80001a1e:	fd549be3          	bne	s1,s5,800019f4 <proc_mapstacks+0x52>
  }
}
    80001a22:	60a6                	ld	ra,72(sp)
    80001a24:	6406                	ld	s0,64(sp)
    80001a26:	74e2                	ld	s1,56(sp)
    80001a28:	7942                	ld	s2,48(sp)
    80001a2a:	79a2                	ld	s3,40(sp)
    80001a2c:	7a02                	ld	s4,32(sp)
    80001a2e:	6ae2                	ld	s5,24(sp)
    80001a30:	6b42                	ld	s6,16(sp)
    80001a32:	6ba2                	ld	s7,8(sp)
    80001a34:	6c02                	ld	s8,0(sp)
    80001a36:	6161                	addi	sp,sp,80
    80001a38:	8082                	ret
      panic("kalloc");
    80001a3a:	00006517          	auipc	a0,0x6
    80001a3e:	7ae50513          	addi	a0,a0,1966 # 800081e8 <etext+0x1e8>
    80001a42:	de3fe0ef          	jal	80000824 <panic>

0000000080001a46 <procinit>:

// initialize the proc table.
void
procinit(void)
{
    80001a46:	7139                	addi	sp,sp,-64
    80001a48:	fc06                	sd	ra,56(sp)
    80001a4a:	f822                	sd	s0,48(sp)
    80001a4c:	f426                	sd	s1,40(sp)
    80001a4e:	f04a                	sd	s2,32(sp)
    80001a50:	ec4e                	sd	s3,24(sp)
    80001a52:	e852                	sd	s4,16(sp)
    80001a54:	e456                	sd	s5,8(sp)
    80001a56:	e05a                	sd	s6,0(sp)
    80001a58:	0080                	addi	s0,sp,64
  struct proc *p;
  
  initlock(&pid_lock, "nextpid");
    80001a5a:	00006597          	auipc	a1,0x6
    80001a5e:	79658593          	addi	a1,a1,1942 # 800081f0 <etext+0x1f0>
    80001a62:	0022f517          	auipc	a0,0x22f
    80001a66:	03650513          	addi	a0,a0,54 # 80230a98 <pid_lock>
    80001a6a:	b28ff0ef          	jal	80000d92 <initlock>
  initlock(&wait_lock, "wait_lock");
    80001a6e:	00006597          	auipc	a1,0x6
    80001a72:	78a58593          	addi	a1,a1,1930 # 800081f8 <etext+0x1f8>
    80001a76:	0022f517          	auipc	a0,0x22f
    80001a7a:	03a50513          	addi	a0,a0,58 # 80230ab0 <wait_lock>
    80001a7e:	b14ff0ef          	jal	80000d92 <initlock>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001a82:	0022f497          	auipc	s1,0x22f
    80001a86:	44648493          	addi	s1,s1,1094 # 80230ec8 <proc>
      initlock(&p->lock, "proc");
    80001a8a:	00006b17          	auipc	s6,0x6
    80001a8e:	77eb0b13          	addi	s6,s6,1918 # 80008208 <etext+0x208>
      p->state = UNUSED;
      p->kstack = KSTACK((int) (p - proc));
    80001a92:	8aa6                	mv	s5,s1
    80001a94:	000a57b7          	lui	a5,0xa5
    80001a98:	fa578793          	addi	a5,a5,-91 # a4fa5 <_entry-0x7ff5b05b>
    80001a9c:	07b2                	slli	a5,a5,0xc
    80001a9e:	fa578793          	addi	a5,a5,-91
    80001aa2:	4fa50937          	lui	s2,0x4fa50
    80001aa6:	a4f90913          	addi	s2,s2,-1457 # 4fa4fa4f <_entry-0x305b05b1>
    80001aaa:	1902                	slli	s2,s2,0x20
    80001aac:	993e                	add	s2,s2,a5
    80001aae:	040009b7          	lui	s3,0x4000
    80001ab2:	19fd                	addi	s3,s3,-1 # 3ffffff <_entry-0x7c000001>
    80001ab4:	09b2                	slli	s3,s3,0xc
  for(p = proc; p < &proc[NPROC]; p++) {
    80001ab6:	00235a17          	auipc	s4,0x235
    80001aba:	e12a0a13          	addi	s4,s4,-494 # 802368c8 <tickslock>
      initlock(&p->lock, "proc");
    80001abe:	85da                	mv	a1,s6
    80001ac0:	8526                	mv	a0,s1
    80001ac2:	ad0ff0ef          	jal	80000d92 <initlock>
      p->state = UNUSED;
    80001ac6:	0004ac23          	sw	zero,24(s1)
      p->kstack = KSTACK((int) (p - proc));
    80001aca:	415487b3          	sub	a5,s1,s5
    80001ace:	878d                	srai	a5,a5,0x3
    80001ad0:	032787b3          	mul	a5,a5,s2
    80001ad4:	07b6                	slli	a5,a5,0xd
    80001ad6:	6709                	lui	a4,0x2
    80001ad8:	9fb9                	addw	a5,a5,a4
    80001ada:	40f987b3          	sub	a5,s3,a5
    80001ade:	e0bc                	sd	a5,64(s1)
  for(p = proc; p < &proc[NPROC]; p++) {
    80001ae0:	16848493          	addi	s1,s1,360
    80001ae4:	fd449de3          	bne	s1,s4,80001abe <procinit+0x78>
  }
}
    80001ae8:	70e2                	ld	ra,56(sp)
    80001aea:	7442                	ld	s0,48(sp)
    80001aec:	74a2                	ld	s1,40(sp)
    80001aee:	7902                	ld	s2,32(sp)
    80001af0:	69e2                	ld	s3,24(sp)
    80001af2:	6a42                	ld	s4,16(sp)
    80001af4:	6aa2                	ld	s5,8(sp)
    80001af6:	6b02                	ld	s6,0(sp)
    80001af8:	6121                	addi	sp,sp,64
    80001afa:	8082                	ret

0000000080001afc <cpuid>:
// Must be called with interrupts disabled,
// to prevent race with process being moved
// to a different CPU.
int
cpuid()
{
    80001afc:	1141                	addi	sp,sp,-16
    80001afe:	e406                	sd	ra,8(sp)
    80001b00:	e022                	sd	s0,0(sp)
    80001b02:	0800                	addi	s0,sp,16
  asm volatile("mv %0, tp" : "=r" (x) );
    80001b04:	8512                	mv	a0,tp
  int id = r_tp();
  return id;
}
    80001b06:	2501                	sext.w	a0,a0
    80001b08:	60a2                	ld	ra,8(sp)
    80001b0a:	6402                	ld	s0,0(sp)
    80001b0c:	0141                	addi	sp,sp,16
    80001b0e:	8082                	ret

0000000080001b10 <mycpu>:

// Return this CPU's cpu struct.
// Interrupts must be disabled.
struct cpu*
mycpu(void)
{
    80001b10:	1141                	addi	sp,sp,-16
    80001b12:	e406                	sd	ra,8(sp)
    80001b14:	e022                	sd	s0,0(sp)
    80001b16:	0800                	addi	s0,sp,16
    80001b18:	8792                	mv	a5,tp
  int id = cpuid();
  struct cpu *c = &cpus[id];
    80001b1a:	2781                	sext.w	a5,a5
    80001b1c:	079e                	slli	a5,a5,0x7
  return c;
}
    80001b1e:	0022f517          	auipc	a0,0x22f
    80001b22:	faa50513          	addi	a0,a0,-86 # 80230ac8 <cpus>
    80001b26:	953e                	add	a0,a0,a5
    80001b28:	60a2                	ld	ra,8(sp)
    80001b2a:	6402                	ld	s0,0(sp)
    80001b2c:	0141                	addi	sp,sp,16
    80001b2e:	8082                	ret

0000000080001b30 <myproc>:

// Return the current struct proc *, or zero if none.
struct proc*
myproc(void)
{
    80001b30:	1101                	addi	sp,sp,-32
    80001b32:	ec06                	sd	ra,24(sp)
    80001b34:	e822                	sd	s0,16(sp)
    80001b36:	e426                	sd	s1,8(sp)
    80001b38:	1000                	addi	s0,sp,32
  push_off();
    80001b3a:	a9eff0ef          	jal	80000dd8 <push_off>
    80001b3e:	8792                	mv	a5,tp
  struct cpu *c = mycpu();
  struct proc *p = c->proc;
    80001b40:	2781                	sext.w	a5,a5
    80001b42:	079e                	slli	a5,a5,0x7
    80001b44:	0022f717          	auipc	a4,0x22f
    80001b48:	f5470713          	addi	a4,a4,-172 # 80230a98 <pid_lock>
    80001b4c:	97ba                	add	a5,a5,a4
    80001b4e:	7b9c                	ld	a5,48(a5)
    80001b50:	84be                	mv	s1,a5
  pop_off();
    80001b52:	b0eff0ef          	jal	80000e60 <pop_off>
  return p;
}
    80001b56:	8526                	mv	a0,s1
    80001b58:	60e2                	ld	ra,24(sp)
    80001b5a:	6442                	ld	s0,16(sp)
    80001b5c:	64a2                	ld	s1,8(sp)
    80001b5e:	6105                	addi	sp,sp,32
    80001b60:	8082                	ret

0000000080001b62 <forkret>:

// A fork child's very first scheduling by scheduler()
// will swtch to forkret.
void
forkret(void)
{
    80001b62:	7179                	addi	sp,sp,-48
    80001b64:	f406                	sd	ra,40(sp)
    80001b66:	f022                	sd	s0,32(sp)
    80001b68:	ec26                	sd	s1,24(sp)
    80001b6a:	1800                	addi	s0,sp,48
  extern char userret[];
  static int first = 1;
  struct proc *p = myproc();
    80001b6c:	fc5ff0ef          	jal	80001b30 <myproc>
    80001b70:	84aa                	mv	s1,a0

  // Still holding p->lock from scheduler.
  release(&p->lock);
    80001b72:	b3eff0ef          	jal	80000eb0 <release>

  if (first) {
    80001b76:	00007797          	auipc	a5,0x7
    80001b7a:	dea7a783          	lw	a5,-534(a5) # 80008960 <first.1>
    80001b7e:	cf95                	beqz	a5,80001bba <forkret+0x58>
    // File system initialization must be run in the context of a
    // regular process (e.g., because it calls sleep), and thus cannot
    // be run from main().
    fsinit(ROOTDEV);
    80001b80:	4505                	li	a0,1
    80001b82:	6d9010ef          	jal	80003a5a <fsinit>

    first = 0;
    80001b86:	00007797          	auipc	a5,0x7
    80001b8a:	dc07ad23          	sw	zero,-550(a5) # 80008960 <first.1>
    // ensure other cores see first=0.
    __sync_synchronize();
    80001b8e:	0330000f          	fence	rw,rw

    // We can invoke kexec() now that file system is initialized.
    // Put the return value (argc) of kexec into a0.
    p->trapframe->a0 = kexec("/init", (char *[]){ "/init", 0 });
    80001b92:	00006797          	auipc	a5,0x6
    80001b96:	67e78793          	addi	a5,a5,1662 # 80008210 <etext+0x210>
    80001b9a:	fcf43823          	sd	a5,-48(s0)
    80001b9e:	fc043c23          	sd	zero,-40(s0)
    80001ba2:	fd040593          	addi	a1,s0,-48
    80001ba6:	853e                	mv	a0,a5
    80001ba8:	032030ef          	jal	80004bda <kexec>
    80001bac:	6cbc                	ld	a5,88(s1)
    80001bae:	fba8                	sd	a0,112(a5)
    if (p->trapframe->a0 == -1) {
    80001bb0:	6cbc                	ld	a5,88(s1)
    80001bb2:	7bb8                	ld	a4,112(a5)
    80001bb4:	57fd                	li	a5,-1
    80001bb6:	02f70d63          	beq	a4,a5,80001bf0 <forkret+0x8e>
      panic("exec");
    }
  }

  // return to user space, mimicing usertrap()'s return.
  prepare_return();
    80001bba:	367000ef          	jal	80002720 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80001bbe:	68a8                	ld	a0,80(s1)
    80001bc0:	8131                	srli	a0,a0,0xc
  uint64 trampoline_userret = TRAMPOLINE + (userret - trampoline);
    80001bc2:	04000737          	lui	a4,0x4000
    80001bc6:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    80001bc8:	0732                	slli	a4,a4,0xc
    80001bca:	00005797          	auipc	a5,0x5
    80001bce:	4d278793          	addi	a5,a5,1234 # 8000709c <userret>
    80001bd2:	00005697          	auipc	a3,0x5
    80001bd6:	42e68693          	addi	a3,a3,1070 # 80007000 <_trampoline>
    80001bda:	8f95                	sub	a5,a5,a3
    80001bdc:	97ba                	add	a5,a5,a4
  ((void (*)(uint64))trampoline_userret)(satp);
    80001bde:	577d                	li	a4,-1
    80001be0:	177e                	slli	a4,a4,0x3f
    80001be2:	8d59                	or	a0,a0,a4
    80001be4:	9782                	jalr	a5
}
    80001be6:	70a2                	ld	ra,40(sp)
    80001be8:	7402                	ld	s0,32(sp)
    80001bea:	64e2                	ld	s1,24(sp)
    80001bec:	6145                	addi	sp,sp,48
    80001bee:	8082                	ret
      panic("exec");
    80001bf0:	00006517          	auipc	a0,0x6
    80001bf4:	62850513          	addi	a0,a0,1576 # 80008218 <etext+0x218>
    80001bf8:	c2dfe0ef          	jal	80000824 <panic>

0000000080001bfc <allocpid>:
{
    80001bfc:	1101                	addi	sp,sp,-32
    80001bfe:	ec06                	sd	ra,24(sp)
    80001c00:	e822                	sd	s0,16(sp)
    80001c02:	e426                	sd	s1,8(sp)
    80001c04:	1000                	addi	s0,sp,32
  acquire(&pid_lock);
    80001c06:	0022f517          	auipc	a0,0x22f
    80001c0a:	e9250513          	addi	a0,a0,-366 # 80230a98 <pid_lock>
    80001c0e:	a0eff0ef          	jal	80000e1c <acquire>
  pid = nextpid;
    80001c12:	00007797          	auipc	a5,0x7
    80001c16:	d5278793          	addi	a5,a5,-686 # 80008964 <nextpid>
    80001c1a:	4384                	lw	s1,0(a5)
  nextpid = nextpid + 1;
    80001c1c:	0014871b          	addiw	a4,s1,1
    80001c20:	c398                	sw	a4,0(a5)
  release(&pid_lock);
    80001c22:	0022f517          	auipc	a0,0x22f
    80001c26:	e7650513          	addi	a0,a0,-394 # 80230a98 <pid_lock>
    80001c2a:	a86ff0ef          	jal	80000eb0 <release>
}
    80001c2e:	8526                	mv	a0,s1
    80001c30:	60e2                	ld	ra,24(sp)
    80001c32:	6442                	ld	s0,16(sp)
    80001c34:	64a2                	ld	s1,8(sp)
    80001c36:	6105                	addi	sp,sp,32
    80001c38:	8082                	ret

0000000080001c3a <proc_pagetable>:
{
    80001c3a:	1101                	addi	sp,sp,-32
    80001c3c:	ec06                	sd	ra,24(sp)
    80001c3e:	e822                	sd	s0,16(sp)
    80001c40:	e426                	sd	s1,8(sp)
    80001c42:	e04a                	sd	s2,0(sp)
    80001c44:	1000                	addi	s0,sp,32
    80001c46:	892a                	mv	s2,a0
  pagetable = uvmcreate();
    80001c48:	fbcff0ef          	jal	80001404 <uvmcreate>
    80001c4c:	84aa                	mv	s1,a0
  if(pagetable == 0)
    80001c4e:	cd05                	beqz	a0,80001c86 <proc_pagetable+0x4c>
  if(mappages(pagetable, TRAMPOLINE, PGSIZE,
    80001c50:	4729                	li	a4,10
    80001c52:	00005697          	auipc	a3,0x5
    80001c56:	3ae68693          	addi	a3,a3,942 # 80007000 <_trampoline>
    80001c5a:	6605                	lui	a2,0x1
    80001c5c:	040005b7          	lui	a1,0x4000
    80001c60:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001c62:	05b2                	slli	a1,a1,0xc
    80001c64:	df8ff0ef          	jal	8000125c <mappages>
    80001c68:	02054663          	bltz	a0,80001c94 <proc_pagetable+0x5a>
  if(mappages(pagetable, TRAPFRAME, PGSIZE,
    80001c6c:	4719                	li	a4,6
    80001c6e:	05893683          	ld	a3,88(s2)
    80001c72:	6605                	lui	a2,0x1
    80001c74:	020005b7          	lui	a1,0x2000
    80001c78:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001c7a:	05b6                	slli	a1,a1,0xd
    80001c7c:	8526                	mv	a0,s1
    80001c7e:	ddeff0ef          	jal	8000125c <mappages>
    80001c82:	00054f63          	bltz	a0,80001ca0 <proc_pagetable+0x66>
}
    80001c86:	8526                	mv	a0,s1
    80001c88:	60e2                	ld	ra,24(sp)
    80001c8a:	6442                	ld	s0,16(sp)
    80001c8c:	64a2                	ld	s1,8(sp)
    80001c8e:	6902                	ld	s2,0(sp)
    80001c90:	6105                	addi	sp,sp,32
    80001c92:	8082                	ret
    uvmfree(pagetable, 0);
    80001c94:	4581                	li	a1,0
    80001c96:	8526                	mv	a0,s1
    80001c98:	967ff0ef          	jal	800015fe <uvmfree>
    return 0;
    80001c9c:	4481                	li	s1,0
    80001c9e:	b7e5                	j	80001c86 <proc_pagetable+0x4c>
    uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001ca0:	4681                	li	a3,0
    80001ca2:	4605                	li	a2,1
    80001ca4:	040005b7          	lui	a1,0x4000
    80001ca8:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001caa:	05b2                	slli	a1,a1,0xc
    80001cac:	8526                	mv	a0,s1
    80001cae:	f7cff0ef          	jal	8000142a <uvmunmap>
    uvmfree(pagetable, 0);
    80001cb2:	4581                	li	a1,0
    80001cb4:	8526                	mv	a0,s1
    80001cb6:	949ff0ef          	jal	800015fe <uvmfree>
    return 0;
    80001cba:	4481                	li	s1,0
    80001cbc:	b7e9                	j	80001c86 <proc_pagetable+0x4c>

0000000080001cbe <proc_freepagetable>:
{
    80001cbe:	1101                	addi	sp,sp,-32
    80001cc0:	ec06                	sd	ra,24(sp)
    80001cc2:	e822                	sd	s0,16(sp)
    80001cc4:	e426                	sd	s1,8(sp)
    80001cc6:	e04a                	sd	s2,0(sp)
    80001cc8:	1000                	addi	s0,sp,32
    80001cca:	84aa                	mv	s1,a0
    80001ccc:	892e                	mv	s2,a1
  uvmunmap(pagetable, TRAMPOLINE, 1, 0);
    80001cce:	4681                	li	a3,0
    80001cd0:	4605                	li	a2,1
    80001cd2:	040005b7          	lui	a1,0x4000
    80001cd6:	15fd                	addi	a1,a1,-1 # 3ffffff <_entry-0x7c000001>
    80001cd8:	05b2                	slli	a1,a1,0xc
    80001cda:	f50ff0ef          	jal	8000142a <uvmunmap>
  uvmunmap(pagetable, TRAPFRAME, 1, 0);
    80001cde:	4681                	li	a3,0
    80001ce0:	4605                	li	a2,1
    80001ce2:	020005b7          	lui	a1,0x2000
    80001ce6:	15fd                	addi	a1,a1,-1 # 1ffffff <_entry-0x7e000001>
    80001ce8:	05b6                	slli	a1,a1,0xd
    80001cea:	8526                	mv	a0,s1
    80001cec:	f3eff0ef          	jal	8000142a <uvmunmap>
  uvmfree(pagetable, sz);
    80001cf0:	85ca                	mv	a1,s2
    80001cf2:	8526                	mv	a0,s1
    80001cf4:	90bff0ef          	jal	800015fe <uvmfree>
}
    80001cf8:	60e2                	ld	ra,24(sp)
    80001cfa:	6442                	ld	s0,16(sp)
    80001cfc:	64a2                	ld	s1,8(sp)
    80001cfe:	6902                	ld	s2,0(sp)
    80001d00:	6105                	addi	sp,sp,32
    80001d02:	8082                	ret

0000000080001d04 <freeproc>:
{
    80001d04:	1101                	addi	sp,sp,-32
    80001d06:	ec06                	sd	ra,24(sp)
    80001d08:	e822                	sd	s0,16(sp)
    80001d0a:	e426                	sd	s1,8(sp)
    80001d0c:	1000                	addi	s0,sp,32
    80001d0e:	84aa                	mv	s1,a0
  if(p->trapframe)
    80001d10:	6d28                	ld	a0,88(a0)
    80001d12:	c119                	beqz	a0,80001d18 <freeproc+0x14>
    kfree((void*)p->trapframe);
    80001d14:	ec9fe0ef          	jal	80000bdc <kfree>
  p->trapframe = 0;
    80001d18:	0404bc23          	sd	zero,88(s1)
  if(p->pagetable)
    80001d1c:	68a8                	ld	a0,80(s1)
    80001d1e:	c501                	beqz	a0,80001d26 <freeproc+0x22>
    proc_freepagetable(p->pagetable, p->sz);
    80001d20:	64ac                	ld	a1,72(s1)
    80001d22:	f9dff0ef          	jal	80001cbe <proc_freepagetable>
  p->pagetable = 0;
    80001d26:	0404b823          	sd	zero,80(s1)
  p->sz = 0;
    80001d2a:	0404b423          	sd	zero,72(s1)
  p->pid = 0;
    80001d2e:	0204a823          	sw	zero,48(s1)
  p->parent = 0;
    80001d32:	0204bc23          	sd	zero,56(s1)
  p->name[0] = 0;
    80001d36:	14048c23          	sb	zero,344(s1)
  p->chan = 0;
    80001d3a:	0204b023          	sd	zero,32(s1)
  p->killed = 0;
    80001d3e:	0204a423          	sw	zero,40(s1)
  p->xstate = 0;
    80001d42:	0204a623          	sw	zero,44(s1)
  p->state = UNUSED;
    80001d46:	0004ac23          	sw	zero,24(s1)
}
    80001d4a:	60e2                	ld	ra,24(sp)
    80001d4c:	6442                	ld	s0,16(sp)
    80001d4e:	64a2                	ld	s1,8(sp)
    80001d50:	6105                	addi	sp,sp,32
    80001d52:	8082                	ret

0000000080001d54 <allocproc>:
{
    80001d54:	1101                	addi	sp,sp,-32
    80001d56:	ec06                	sd	ra,24(sp)
    80001d58:	e822                	sd	s0,16(sp)
    80001d5a:	e426                	sd	s1,8(sp)
    80001d5c:	e04a                	sd	s2,0(sp)
    80001d5e:	1000                	addi	s0,sp,32
  for(p = proc; p < &proc[NPROC]; p++) {
    80001d60:	0022f497          	auipc	s1,0x22f
    80001d64:	16848493          	addi	s1,s1,360 # 80230ec8 <proc>
    80001d68:	00235917          	auipc	s2,0x235
    80001d6c:	b6090913          	addi	s2,s2,-1184 # 802368c8 <tickslock>
    acquire(&p->lock);
    80001d70:	8526                	mv	a0,s1
    80001d72:	8aaff0ef          	jal	80000e1c <acquire>
    if(p->state == UNUSED) {
    80001d76:	4c9c                	lw	a5,24(s1)
    80001d78:	cb91                	beqz	a5,80001d8c <allocproc+0x38>
      release(&p->lock);
    80001d7a:	8526                	mv	a0,s1
    80001d7c:	934ff0ef          	jal	80000eb0 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    80001d80:	16848493          	addi	s1,s1,360
    80001d84:	ff2496e3          	bne	s1,s2,80001d70 <allocproc+0x1c>
  return 0;
    80001d88:	4481                	li	s1,0
    80001d8a:	a089                	j	80001dcc <allocproc+0x78>
  p->pid = allocpid();
    80001d8c:	e71ff0ef          	jal	80001bfc <allocpid>
    80001d90:	d888                	sw	a0,48(s1)
  p->state = USED;
    80001d92:	4785                	li	a5,1
    80001d94:	cc9c                	sw	a5,24(s1)
  if((p->trapframe = (struct trapframe *)kalloc()) == 0){
    80001d96:	f77fe0ef          	jal	80000d0c <kalloc>
    80001d9a:	892a                	mv	s2,a0
    80001d9c:	eca8                	sd	a0,88(s1)
    80001d9e:	cd15                	beqz	a0,80001dda <allocproc+0x86>
  p->pagetable = proc_pagetable(p);
    80001da0:	8526                	mv	a0,s1
    80001da2:	e99ff0ef          	jal	80001c3a <proc_pagetable>
    80001da6:	892a                	mv	s2,a0
    80001da8:	e8a8                	sd	a0,80(s1)
  if(p->pagetable == 0){
    80001daa:	c121                	beqz	a0,80001dea <allocproc+0x96>
  memset(&p->context, 0, sizeof(p->context));
    80001dac:	07000613          	li	a2,112
    80001db0:	4581                	li	a1,0
    80001db2:	06048513          	addi	a0,s1,96
    80001db6:	936ff0ef          	jal	80000eec <memset>
  p->context.ra = (uint64)forkret;
    80001dba:	00000797          	auipc	a5,0x0
    80001dbe:	da878793          	addi	a5,a5,-600 # 80001b62 <forkret>
    80001dc2:	f0bc                	sd	a5,96(s1)
  p->context.sp = p->kstack + PGSIZE;
    80001dc4:	60bc                	ld	a5,64(s1)
    80001dc6:	6705                	lui	a4,0x1
    80001dc8:	97ba                	add	a5,a5,a4
    80001dca:	f4bc                	sd	a5,104(s1)
}
    80001dcc:	8526                	mv	a0,s1
    80001dce:	60e2                	ld	ra,24(sp)
    80001dd0:	6442                	ld	s0,16(sp)
    80001dd2:	64a2                	ld	s1,8(sp)
    80001dd4:	6902                	ld	s2,0(sp)
    80001dd6:	6105                	addi	sp,sp,32
    80001dd8:	8082                	ret
    freeproc(p);
    80001dda:	8526                	mv	a0,s1
    80001ddc:	f29ff0ef          	jal	80001d04 <freeproc>
    release(&p->lock);
    80001de0:	8526                	mv	a0,s1
    80001de2:	8ceff0ef          	jal	80000eb0 <release>
    return 0;
    80001de6:	84ca                	mv	s1,s2
    80001de8:	b7d5                	j	80001dcc <allocproc+0x78>
    freeproc(p);
    80001dea:	8526                	mv	a0,s1
    80001dec:	f19ff0ef          	jal	80001d04 <freeproc>
    release(&p->lock);
    80001df0:	8526                	mv	a0,s1
    80001df2:	8beff0ef          	jal	80000eb0 <release>
    return 0;
    80001df6:	84ca                	mv	s1,s2
    80001df8:	bfd1                	j	80001dcc <allocproc+0x78>

0000000080001dfa <userinit>:
{
    80001dfa:	1101                	addi	sp,sp,-32
    80001dfc:	ec06                	sd	ra,24(sp)
    80001dfe:	e822                	sd	s0,16(sp)
    80001e00:	e426                	sd	s1,8(sp)
    80001e02:	1000                	addi	s0,sp,32
  p = allocproc();
    80001e04:	f51ff0ef          	jal	80001d54 <allocproc>
    80001e08:	84aa                	mv	s1,a0
  initproc = p;
    80001e0a:	00007797          	auipc	a5,0x7
    80001e0e:	b8a7b323          	sd	a0,-1146(a5) # 80008990 <initproc>
  p->cwd = namei("/");
    80001e12:	00006517          	auipc	a0,0x6
    80001e16:	40e50513          	addi	a0,a0,1038 # 80008220 <etext+0x220>
    80001e1a:	17c020ef          	jal	80003f96 <namei>
    80001e1e:	14a4b823          	sd	a0,336(s1)
  p->state = RUNNABLE;
    80001e22:	478d                	li	a5,3
    80001e24:	cc9c                	sw	a5,24(s1)
  release(&p->lock);
    80001e26:	8526                	mv	a0,s1
    80001e28:	888ff0ef          	jal	80000eb0 <release>
}
    80001e2c:	60e2                	ld	ra,24(sp)
    80001e2e:	6442                	ld	s0,16(sp)
    80001e30:	64a2                	ld	s1,8(sp)
    80001e32:	6105                	addi	sp,sp,32
    80001e34:	8082                	ret

0000000080001e36 <growproc>:
{
    80001e36:	1101                	addi	sp,sp,-32
    80001e38:	ec06                	sd	ra,24(sp)
    80001e3a:	e822                	sd	s0,16(sp)
    80001e3c:	e426                	sd	s1,8(sp)
    80001e3e:	e04a                	sd	s2,0(sp)
    80001e40:	1000                	addi	s0,sp,32
    80001e42:	892a                	mv	s2,a0
  struct proc *p = myproc();
    80001e44:	cedff0ef          	jal	80001b30 <myproc>
    80001e48:	84aa                	mv	s1,a0
  sz = p->sz;
    80001e4a:	652c                	ld	a1,72(a0)
  if(n > 0){
    80001e4c:	01204c63          	bgtz	s2,80001e64 <growproc+0x2e>
  } else if(n < 0){
    80001e50:	02094463          	bltz	s2,80001e78 <growproc+0x42>
  p->sz = sz;
    80001e54:	e4ac                	sd	a1,72(s1)
  return 0;
    80001e56:	4501                	li	a0,0
}
    80001e58:	60e2                	ld	ra,24(sp)
    80001e5a:	6442                	ld	s0,16(sp)
    80001e5c:	64a2                	ld	s1,8(sp)
    80001e5e:	6902                	ld	s2,0(sp)
    80001e60:	6105                	addi	sp,sp,32
    80001e62:	8082                	ret
    if((sz = uvmalloc(p->pagetable, sz, sz + n, PTE_W)) == 0) {
    80001e64:	4691                	li	a3,4
    80001e66:	00b90633          	add	a2,s2,a1
    80001e6a:	6928                	ld	a0,80(a0)
    80001e6c:	e8cff0ef          	jal	800014f8 <uvmalloc>
    80001e70:	85aa                	mv	a1,a0
    80001e72:	f16d                	bnez	a0,80001e54 <growproc+0x1e>
      return -1;
    80001e74:	557d                	li	a0,-1
    80001e76:	b7cd                	j	80001e58 <growproc+0x22>
    sz = uvmdealloc(p->pagetable, sz, sz + n);
    80001e78:	00b90633          	add	a2,s2,a1
    80001e7c:	6928                	ld	a0,80(a0)
    80001e7e:	e36ff0ef          	jal	800014b4 <uvmdealloc>
    80001e82:	85aa                	mv	a1,a0
    80001e84:	bfc1                	j	80001e54 <growproc+0x1e>

0000000080001e86 <kfork>:
{
    80001e86:	7139                	addi	sp,sp,-64
    80001e88:	fc06                	sd	ra,56(sp)
    80001e8a:	f822                	sd	s0,48(sp)
    80001e8c:	f426                	sd	s1,40(sp)
    80001e8e:	e456                	sd	s5,8(sp)
    80001e90:	0080                	addi	s0,sp,64
  struct proc *p = myproc();
    80001e92:	c9fff0ef          	jal	80001b30 <myproc>
    80001e96:	8aaa                	mv	s5,a0
  if((np = allocproc()) == 0){
    80001e98:	ebdff0ef          	jal	80001d54 <allocproc>
    80001e9c:	0e050a63          	beqz	a0,80001f90 <kfork+0x10a>
    80001ea0:	e852                	sd	s4,16(sp)
    80001ea2:	8a2a                	mv	s4,a0
  if(uvmcopy(p->pagetable, np->pagetable, p->sz) < 0){
    80001ea4:	048ab603          	ld	a2,72(s5)
    80001ea8:	692c                	ld	a1,80(a0)
    80001eaa:	050ab503          	ld	a0,80(s5)
    80001eae:	f82ff0ef          	jal	80001630 <uvmcopy>
    80001eb2:	04054863          	bltz	a0,80001f02 <kfork+0x7c>
    80001eb6:	f04a                	sd	s2,32(sp)
    80001eb8:	ec4e                	sd	s3,24(sp)
  np->sz = p->sz;
    80001eba:	048ab783          	ld	a5,72(s5)
    80001ebe:	04fa3423          	sd	a5,72(s4)
  *(np->trapframe) = *(p->trapframe);
    80001ec2:	058ab683          	ld	a3,88(s5)
    80001ec6:	87b6                	mv	a5,a3
    80001ec8:	058a3703          	ld	a4,88(s4)
    80001ecc:	12068693          	addi	a3,a3,288
    80001ed0:	6388                	ld	a0,0(a5)
    80001ed2:	678c                	ld	a1,8(a5)
    80001ed4:	6b90                	ld	a2,16(a5)
    80001ed6:	e308                	sd	a0,0(a4)
    80001ed8:	e70c                	sd	a1,8(a4)
    80001eda:	eb10                	sd	a2,16(a4)
    80001edc:	6f90                	ld	a2,24(a5)
    80001ede:	ef10                	sd	a2,24(a4)
    80001ee0:	02078793          	addi	a5,a5,32
    80001ee4:	02070713          	addi	a4,a4,32 # 1020 <_entry-0x7fffefe0>
    80001ee8:	fed794e3          	bne	a5,a3,80001ed0 <kfork+0x4a>
  np->trapframe->a0 = 0;
    80001eec:	058a3783          	ld	a5,88(s4)
    80001ef0:	0607b823          	sd	zero,112(a5)
  for(i = 0; i < NOFILE; i++)
    80001ef4:	0d0a8493          	addi	s1,s5,208
    80001ef8:	0d0a0913          	addi	s2,s4,208
    80001efc:	150a8993          	addi	s3,s5,336
    80001f00:	a831                	j	80001f1c <kfork+0x96>
    freeproc(np);
    80001f02:	8552                	mv	a0,s4
    80001f04:	e01ff0ef          	jal	80001d04 <freeproc>
    release(&np->lock);
    80001f08:	8552                	mv	a0,s4
    80001f0a:	fa7fe0ef          	jal	80000eb0 <release>
    return -1;
    80001f0e:	54fd                	li	s1,-1
    80001f10:	6a42                	ld	s4,16(sp)
    80001f12:	a885                	j	80001f82 <kfork+0xfc>
  for(i = 0; i < NOFILE; i++)
    80001f14:	04a1                	addi	s1,s1,8
    80001f16:	0921                	addi	s2,s2,8
    80001f18:	01348963          	beq	s1,s3,80001f2a <kfork+0xa4>
    if(p->ofile[i])
    80001f1c:	6088                	ld	a0,0(s1)
    80001f1e:	d97d                	beqz	a0,80001f14 <kfork+0x8e>
      np->ofile[i] = filedup(p->ofile[i]);
    80001f20:	632020ef          	jal	80004552 <filedup>
    80001f24:	00a93023          	sd	a0,0(s2)
    80001f28:	b7f5                	j	80001f14 <kfork+0x8e>
  np->cwd = idup(p->cwd);
    80001f2a:	150ab503          	ld	a0,336(s5)
    80001f2e:	774010ef          	jal	800036a2 <idup>
    80001f32:	14aa3823          	sd	a0,336(s4)
  safestrcpy(np->name, p->name, sizeof(p->name));
    80001f36:	4641                	li	a2,16
    80001f38:	158a8593          	addi	a1,s5,344
    80001f3c:	158a0513          	addi	a0,s4,344
    80001f40:	900ff0ef          	jal	80001040 <safestrcpy>
  pid = np->pid;
    80001f44:	030a2483          	lw	s1,48(s4)
  release(&np->lock);
    80001f48:	8552                	mv	a0,s4
    80001f4a:	f67fe0ef          	jal	80000eb0 <release>
  acquire(&wait_lock);
    80001f4e:	0022f517          	auipc	a0,0x22f
    80001f52:	b6250513          	addi	a0,a0,-1182 # 80230ab0 <wait_lock>
    80001f56:	ec7fe0ef          	jal	80000e1c <acquire>
  np->parent = p;
    80001f5a:	035a3c23          	sd	s5,56(s4)
  release(&wait_lock);
    80001f5e:	0022f517          	auipc	a0,0x22f
    80001f62:	b5250513          	addi	a0,a0,-1198 # 80230ab0 <wait_lock>
    80001f66:	f4bfe0ef          	jal	80000eb0 <release>
  acquire(&np->lock);
    80001f6a:	8552                	mv	a0,s4
    80001f6c:	eb1fe0ef          	jal	80000e1c <acquire>
  np->state = RUNNABLE;
    80001f70:	478d                	li	a5,3
    80001f72:	00fa2c23          	sw	a5,24(s4)
  release(&np->lock);
    80001f76:	8552                	mv	a0,s4
    80001f78:	f39fe0ef          	jal	80000eb0 <release>
  return pid;
    80001f7c:	7902                	ld	s2,32(sp)
    80001f7e:	69e2                	ld	s3,24(sp)
    80001f80:	6a42                	ld	s4,16(sp)
}
    80001f82:	8526                	mv	a0,s1
    80001f84:	70e2                	ld	ra,56(sp)
    80001f86:	7442                	ld	s0,48(sp)
    80001f88:	74a2                	ld	s1,40(sp)
    80001f8a:	6aa2                	ld	s5,8(sp)
    80001f8c:	6121                	addi	sp,sp,64
    80001f8e:	8082                	ret
    return -1;
    80001f90:	54fd                	li	s1,-1
    80001f92:	bfc5                	j	80001f82 <kfork+0xfc>

0000000080001f94 <scheduler>:
{
    80001f94:	715d                	addi	sp,sp,-80
    80001f96:	e486                	sd	ra,72(sp)
    80001f98:	e0a2                	sd	s0,64(sp)
    80001f9a:	fc26                	sd	s1,56(sp)
    80001f9c:	f84a                	sd	s2,48(sp)
    80001f9e:	f44e                	sd	s3,40(sp)
    80001fa0:	f052                	sd	s4,32(sp)
    80001fa2:	ec56                	sd	s5,24(sp)
    80001fa4:	e85a                	sd	s6,16(sp)
    80001fa6:	e45e                	sd	s7,8(sp)
    80001fa8:	e062                	sd	s8,0(sp)
    80001faa:	0880                	addi	s0,sp,80
    80001fac:	8792                	mv	a5,tp
  int id = r_tp();
    80001fae:	2781                	sext.w	a5,a5
  c->proc = 0;
    80001fb0:	00779b13          	slli	s6,a5,0x7
    80001fb4:	0022f717          	auipc	a4,0x22f
    80001fb8:	ae470713          	addi	a4,a4,-1308 # 80230a98 <pid_lock>
    80001fbc:	975a                	add	a4,a4,s6
    80001fbe:	02073823          	sd	zero,48(a4)
        swtch(&c->context, &p->context);
    80001fc2:	0022f717          	auipc	a4,0x22f
    80001fc6:	b0e70713          	addi	a4,a4,-1266 # 80230ad0 <cpus+0x8>
    80001fca:	9b3a                	add	s6,s6,a4
        p->state = RUNNING;
    80001fcc:	4c11                	li	s8,4
        c->proc = p;
    80001fce:	079e                	slli	a5,a5,0x7
    80001fd0:	0022fa17          	auipc	s4,0x22f
    80001fd4:	ac8a0a13          	addi	s4,s4,-1336 # 80230a98 <pid_lock>
    80001fd8:	9a3e                	add	s4,s4,a5
        found = 1;
    80001fda:	4b85                	li	s7,1
    80001fdc:	a83d                	j	8000201a <scheduler+0x86>
      release(&p->lock);
    80001fde:	8526                	mv	a0,s1
    80001fe0:	ed1fe0ef          	jal	80000eb0 <release>
    for(p = proc; p < &proc[NPROC]; p++) {
    80001fe4:	16848493          	addi	s1,s1,360
    80001fe8:	03248563          	beq	s1,s2,80002012 <scheduler+0x7e>
      acquire(&p->lock);
    80001fec:	8526                	mv	a0,s1
    80001fee:	e2ffe0ef          	jal	80000e1c <acquire>
      if(p->state == RUNNABLE) {
    80001ff2:	4c9c                	lw	a5,24(s1)
    80001ff4:	ff3795e3          	bne	a5,s3,80001fde <scheduler+0x4a>
        p->state = RUNNING;
    80001ff8:	0184ac23          	sw	s8,24(s1)
        c->proc = p;
    80001ffc:	029a3823          	sd	s1,48(s4)
        swtch(&c->context, &p->context);
    80002000:	06048593          	addi	a1,s1,96
    80002004:	855a                	mv	a0,s6
    80002006:	5ba000ef          	jal	800025c0 <swtch>
        c->proc = 0;
    8000200a:	020a3823          	sd	zero,48(s4)
        found = 1;
    8000200e:	8ade                	mv	s5,s7
    80002010:	b7f9                	j	80001fde <scheduler+0x4a>
    if(found == 0) {
    80002012:	000a9463          	bnez	s5,8000201a <scheduler+0x86>
      asm volatile("wfi");
    80002016:	10500073          	wfi
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000201a:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000201e:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002022:	10079073          	csrw	sstatus,a5
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002026:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    8000202a:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    8000202c:	10079073          	csrw	sstatus,a5
    int found = 0;
    80002030:	4a81                	li	s5,0
    for(p = proc; p < &proc[NPROC]; p++) {
    80002032:	0022f497          	auipc	s1,0x22f
    80002036:	e9648493          	addi	s1,s1,-362 # 80230ec8 <proc>
      if(p->state == RUNNABLE) {
    8000203a:	498d                	li	s3,3
    for(p = proc; p < &proc[NPROC]; p++) {
    8000203c:	00235917          	auipc	s2,0x235
    80002040:	88c90913          	addi	s2,s2,-1908 # 802368c8 <tickslock>
    80002044:	b765                	j	80001fec <scheduler+0x58>

0000000080002046 <sched>:
{
    80002046:	7179                	addi	sp,sp,-48
    80002048:	f406                	sd	ra,40(sp)
    8000204a:	f022                	sd	s0,32(sp)
    8000204c:	ec26                	sd	s1,24(sp)
    8000204e:	e84a                	sd	s2,16(sp)
    80002050:	e44e                	sd	s3,8(sp)
    80002052:	1800                	addi	s0,sp,48
  struct proc *p = myproc();
    80002054:	addff0ef          	jal	80001b30 <myproc>
    80002058:	84aa                	mv	s1,a0
  if(!holding(&p->lock))
    8000205a:	d53fe0ef          	jal	80000dac <holding>
    8000205e:	c935                	beqz	a0,800020d2 <sched+0x8c>
  asm volatile("mv %0, tp" : "=r" (x) );
    80002060:	8792                	mv	a5,tp
  if(mycpu()->noff != 1)
    80002062:	2781                	sext.w	a5,a5
    80002064:	079e                	slli	a5,a5,0x7
    80002066:	0022f717          	auipc	a4,0x22f
    8000206a:	a3270713          	addi	a4,a4,-1486 # 80230a98 <pid_lock>
    8000206e:	97ba                	add	a5,a5,a4
    80002070:	0a87a703          	lw	a4,168(a5)
    80002074:	4785                	li	a5,1
    80002076:	06f71463          	bne	a4,a5,800020de <sched+0x98>
  if(p->state == RUNNING)
    8000207a:	4c98                	lw	a4,24(s1)
    8000207c:	4791                	li	a5,4
    8000207e:	06f70663          	beq	a4,a5,800020ea <sched+0xa4>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002082:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    80002086:	8b89                	andi	a5,a5,2
  if(intr_get())
    80002088:	e7bd                	bnez	a5,800020f6 <sched+0xb0>
  asm volatile("mv %0, tp" : "=r" (x) );
    8000208a:	8792                	mv	a5,tp
  intena = mycpu()->intena;
    8000208c:	0022f917          	auipc	s2,0x22f
    80002090:	a0c90913          	addi	s2,s2,-1524 # 80230a98 <pid_lock>
    80002094:	2781                	sext.w	a5,a5
    80002096:	079e                	slli	a5,a5,0x7
    80002098:	97ca                	add	a5,a5,s2
    8000209a:	0ac7a983          	lw	s3,172(a5)
    8000209e:	8792                	mv	a5,tp
  swtch(&p->context, &mycpu()->context);
    800020a0:	2781                	sext.w	a5,a5
    800020a2:	079e                	slli	a5,a5,0x7
    800020a4:	07a1                	addi	a5,a5,8
    800020a6:	0022f597          	auipc	a1,0x22f
    800020aa:	a2258593          	addi	a1,a1,-1502 # 80230ac8 <cpus>
    800020ae:	95be                	add	a1,a1,a5
    800020b0:	06048513          	addi	a0,s1,96
    800020b4:	50c000ef          	jal	800025c0 <swtch>
    800020b8:	8792                	mv	a5,tp
  mycpu()->intena = intena;
    800020ba:	2781                	sext.w	a5,a5
    800020bc:	079e                	slli	a5,a5,0x7
    800020be:	993e                	add	s2,s2,a5
    800020c0:	0b392623          	sw	s3,172(s2)
}
    800020c4:	70a2                	ld	ra,40(sp)
    800020c6:	7402                	ld	s0,32(sp)
    800020c8:	64e2                	ld	s1,24(sp)
    800020ca:	6942                	ld	s2,16(sp)
    800020cc:	69a2                	ld	s3,8(sp)
    800020ce:	6145                	addi	sp,sp,48
    800020d0:	8082                	ret
    panic("sched p->lock");
    800020d2:	00006517          	auipc	a0,0x6
    800020d6:	15650513          	addi	a0,a0,342 # 80008228 <etext+0x228>
    800020da:	f4afe0ef          	jal	80000824 <panic>
    panic("sched locks");
    800020de:	00006517          	auipc	a0,0x6
    800020e2:	15a50513          	addi	a0,a0,346 # 80008238 <etext+0x238>
    800020e6:	f3efe0ef          	jal	80000824 <panic>
    panic("sched RUNNING");
    800020ea:	00006517          	auipc	a0,0x6
    800020ee:	15e50513          	addi	a0,a0,350 # 80008248 <etext+0x248>
    800020f2:	f32fe0ef          	jal	80000824 <panic>
    panic("sched interruptible");
    800020f6:	00006517          	auipc	a0,0x6
    800020fa:	16250513          	addi	a0,a0,354 # 80008258 <etext+0x258>
    800020fe:	f26fe0ef          	jal	80000824 <panic>

0000000080002102 <yield>:
{
    80002102:	1101                	addi	sp,sp,-32
    80002104:	ec06                	sd	ra,24(sp)
    80002106:	e822                	sd	s0,16(sp)
    80002108:	e426                	sd	s1,8(sp)
    8000210a:	1000                	addi	s0,sp,32
  struct proc *p = myproc();
    8000210c:	a25ff0ef          	jal	80001b30 <myproc>
    80002110:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002112:	d0bfe0ef          	jal	80000e1c <acquire>
  p->state = RUNNABLE;
    80002116:	478d                	li	a5,3
    80002118:	cc9c                	sw	a5,24(s1)
  sched();
    8000211a:	f2dff0ef          	jal	80002046 <sched>
  release(&p->lock);
    8000211e:	8526                	mv	a0,s1
    80002120:	d91fe0ef          	jal	80000eb0 <release>
}
    80002124:	60e2                	ld	ra,24(sp)
    80002126:	6442                	ld	s0,16(sp)
    80002128:	64a2                	ld	s1,8(sp)
    8000212a:	6105                	addi	sp,sp,32
    8000212c:	8082                	ret

000000008000212e <sleep>:

// Sleep on channel chan, releasing condition lock lk.
// Re-acquires lk when awakened.
void
sleep(void *chan, struct spinlock *lk)
{
    8000212e:	7179                	addi	sp,sp,-48
    80002130:	f406                	sd	ra,40(sp)
    80002132:	f022                	sd	s0,32(sp)
    80002134:	ec26                	sd	s1,24(sp)
    80002136:	e84a                	sd	s2,16(sp)
    80002138:	e44e                	sd	s3,8(sp)
    8000213a:	1800                	addi	s0,sp,48
    8000213c:	89aa                	mv	s3,a0
    8000213e:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002140:	9f1ff0ef          	jal	80001b30 <myproc>
    80002144:	84aa                	mv	s1,a0
  // Once we hold p->lock, we can be
  // guaranteed that we won't miss any wakeup
  // (wakeup locks p->lock),
  // so it's okay to release lk.

  acquire(&p->lock);  //DOC: sleeplock1
    80002146:	cd7fe0ef          	jal	80000e1c <acquire>
  release(lk);
    8000214a:	854a                	mv	a0,s2
    8000214c:	d65fe0ef          	jal	80000eb0 <release>

  // Go to sleep.
  p->chan = chan;
    80002150:	0334b023          	sd	s3,32(s1)
  p->state = SLEEPING;
    80002154:	4789                	li	a5,2
    80002156:	cc9c                	sw	a5,24(s1)

  sched();
    80002158:	eefff0ef          	jal	80002046 <sched>

  // Tidy up.
  p->chan = 0;
    8000215c:	0204b023          	sd	zero,32(s1)

  // Reacquire original lock.
  release(&p->lock);
    80002160:	8526                	mv	a0,s1
    80002162:	d4ffe0ef          	jal	80000eb0 <release>
  acquire(lk);
    80002166:	854a                	mv	a0,s2
    80002168:	cb5fe0ef          	jal	80000e1c <acquire>
}
    8000216c:	70a2                	ld	ra,40(sp)
    8000216e:	7402                	ld	s0,32(sp)
    80002170:	64e2                	ld	s1,24(sp)
    80002172:	6942                	ld	s2,16(sp)
    80002174:	69a2                	ld	s3,8(sp)
    80002176:	6145                	addi	sp,sp,48
    80002178:	8082                	ret

000000008000217a <wakeup>:

// Wake up all processes sleeping on channel chan.
// Caller should hold the condition lock.
void
wakeup(void *chan)
{
    8000217a:	7139                	addi	sp,sp,-64
    8000217c:	fc06                	sd	ra,56(sp)
    8000217e:	f822                	sd	s0,48(sp)
    80002180:	f426                	sd	s1,40(sp)
    80002182:	f04a                	sd	s2,32(sp)
    80002184:	ec4e                	sd	s3,24(sp)
    80002186:	e852                	sd	s4,16(sp)
    80002188:	e456                	sd	s5,8(sp)
    8000218a:	0080                	addi	s0,sp,64
    8000218c:	8a2a                	mv	s4,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++) {
    8000218e:	0022f497          	auipc	s1,0x22f
    80002192:	d3a48493          	addi	s1,s1,-710 # 80230ec8 <proc>
    if(p != myproc()){
      acquire(&p->lock);
      if(p->state == SLEEPING && p->chan == chan) {
    80002196:	4989                	li	s3,2
        p->state = RUNNABLE;
    80002198:	4a8d                	li	s5,3
  for(p = proc; p < &proc[NPROC]; p++) {
    8000219a:	00234917          	auipc	s2,0x234
    8000219e:	72e90913          	addi	s2,s2,1838 # 802368c8 <tickslock>
    800021a2:	a801                	j	800021b2 <wakeup+0x38>
      }
      release(&p->lock);
    800021a4:	8526                	mv	a0,s1
    800021a6:	d0bfe0ef          	jal	80000eb0 <release>
  for(p = proc; p < &proc[NPROC]; p++) {
    800021aa:	16848493          	addi	s1,s1,360
    800021ae:	03248263          	beq	s1,s2,800021d2 <wakeup+0x58>
    if(p != myproc()){
    800021b2:	97fff0ef          	jal	80001b30 <myproc>
    800021b6:	fe950ae3          	beq	a0,s1,800021aa <wakeup+0x30>
      acquire(&p->lock);
    800021ba:	8526                	mv	a0,s1
    800021bc:	c61fe0ef          	jal	80000e1c <acquire>
      if(p->state == SLEEPING && p->chan == chan) {
    800021c0:	4c9c                	lw	a5,24(s1)
    800021c2:	ff3791e3          	bne	a5,s3,800021a4 <wakeup+0x2a>
    800021c6:	709c                	ld	a5,32(s1)
    800021c8:	fd479ee3          	bne	a5,s4,800021a4 <wakeup+0x2a>
        p->state = RUNNABLE;
    800021cc:	0154ac23          	sw	s5,24(s1)
    800021d0:	bfd1                	j	800021a4 <wakeup+0x2a>
    }
  }
}
    800021d2:	70e2                	ld	ra,56(sp)
    800021d4:	7442                	ld	s0,48(sp)
    800021d6:	74a2                	ld	s1,40(sp)
    800021d8:	7902                	ld	s2,32(sp)
    800021da:	69e2                	ld	s3,24(sp)
    800021dc:	6a42                	ld	s4,16(sp)
    800021de:	6aa2                	ld	s5,8(sp)
    800021e0:	6121                	addi	sp,sp,64
    800021e2:	8082                	ret

00000000800021e4 <reparent>:
{
    800021e4:	7179                	addi	sp,sp,-48
    800021e6:	f406                	sd	ra,40(sp)
    800021e8:	f022                	sd	s0,32(sp)
    800021ea:	ec26                	sd	s1,24(sp)
    800021ec:	e84a                	sd	s2,16(sp)
    800021ee:	e44e                	sd	s3,8(sp)
    800021f0:	e052                	sd	s4,0(sp)
    800021f2:	1800                	addi	s0,sp,48
    800021f4:	892a                	mv	s2,a0
  for(pp = proc; pp < &proc[NPROC]; pp++){
    800021f6:	0022f497          	auipc	s1,0x22f
    800021fa:	cd248493          	addi	s1,s1,-814 # 80230ec8 <proc>
      pp->parent = initproc;
    800021fe:	00006a17          	auipc	s4,0x6
    80002202:	792a0a13          	addi	s4,s4,1938 # 80008990 <initproc>
  for(pp = proc; pp < &proc[NPROC]; pp++){
    80002206:	00234997          	auipc	s3,0x234
    8000220a:	6c298993          	addi	s3,s3,1730 # 802368c8 <tickslock>
    8000220e:	a029                	j	80002218 <reparent+0x34>
    80002210:	16848493          	addi	s1,s1,360
    80002214:	01348b63          	beq	s1,s3,8000222a <reparent+0x46>
    if(pp->parent == p){
    80002218:	7c9c                	ld	a5,56(s1)
    8000221a:	ff279be3          	bne	a5,s2,80002210 <reparent+0x2c>
      pp->parent = initproc;
    8000221e:	000a3503          	ld	a0,0(s4)
    80002222:	fc88                	sd	a0,56(s1)
      wakeup(initproc);
    80002224:	f57ff0ef          	jal	8000217a <wakeup>
    80002228:	b7e5                	j	80002210 <reparent+0x2c>
}
    8000222a:	70a2                	ld	ra,40(sp)
    8000222c:	7402                	ld	s0,32(sp)
    8000222e:	64e2                	ld	s1,24(sp)
    80002230:	6942                	ld	s2,16(sp)
    80002232:	69a2                	ld	s3,8(sp)
    80002234:	6a02                	ld	s4,0(sp)
    80002236:	6145                	addi	sp,sp,48
    80002238:	8082                	ret

000000008000223a <kexit>:
{
    8000223a:	7179                	addi	sp,sp,-48
    8000223c:	f406                	sd	ra,40(sp)
    8000223e:	f022                	sd	s0,32(sp)
    80002240:	ec26                	sd	s1,24(sp)
    80002242:	e84a                	sd	s2,16(sp)
    80002244:	e44e                	sd	s3,8(sp)
    80002246:	e052                	sd	s4,0(sp)
    80002248:	1800                	addi	s0,sp,48
    8000224a:	8a2a                	mv	s4,a0
  struct proc *p = myproc();
    8000224c:	8e5ff0ef          	jal	80001b30 <myproc>
    80002250:	89aa                	mv	s3,a0
  if(p == initproc)
    80002252:	00006797          	auipc	a5,0x6
    80002256:	73e7b783          	ld	a5,1854(a5) # 80008990 <initproc>
    8000225a:	0d050493          	addi	s1,a0,208
    8000225e:	15050913          	addi	s2,a0,336
    80002262:	00a79b63          	bne	a5,a0,80002278 <kexit+0x3e>
    panic("init exiting");
    80002266:	00006517          	auipc	a0,0x6
    8000226a:	00a50513          	addi	a0,a0,10 # 80008270 <etext+0x270>
    8000226e:	db6fe0ef          	jal	80000824 <panic>
  for(int fd = 0; fd < NOFILE; fd++){
    80002272:	04a1                	addi	s1,s1,8
    80002274:	01248963          	beq	s1,s2,80002286 <kexit+0x4c>
    if(p->ofile[fd]){
    80002278:	6088                	ld	a0,0(s1)
    8000227a:	dd65                	beqz	a0,80002272 <kexit+0x38>
      fileclose(f);
    8000227c:	31c020ef          	jal	80004598 <fileclose>
      p->ofile[fd] = 0;
    80002280:	0004b023          	sd	zero,0(s1)
    80002284:	b7fd                	j	80002272 <kexit+0x38>
  begin_op();
    80002286:	6ef010ef          	jal	80004174 <begin_op>
  iput(p->cwd);
    8000228a:	1509b503          	ld	a0,336(s3)
    8000228e:	65a010ef          	jal	800038e8 <iput>
  end_op();
    80002292:	753010ef          	jal	800041e4 <end_op>
  p->cwd = 0;
    80002296:	1409b823          	sd	zero,336(s3)
  acquire(&wait_lock);
    8000229a:	0022f517          	auipc	a0,0x22f
    8000229e:	81650513          	addi	a0,a0,-2026 # 80230ab0 <wait_lock>
    800022a2:	b7bfe0ef          	jal	80000e1c <acquire>
  reparent(p);
    800022a6:	854e                	mv	a0,s3
    800022a8:	f3dff0ef          	jal	800021e4 <reparent>
  wakeup(p->parent);
    800022ac:	0389b503          	ld	a0,56(s3)
    800022b0:	ecbff0ef          	jal	8000217a <wakeup>
  acquire(&p->lock);
    800022b4:	854e                	mv	a0,s3
    800022b6:	b67fe0ef          	jal	80000e1c <acquire>
  p->xstate = status;
    800022ba:	0349a623          	sw	s4,44(s3)
  p->state = ZOMBIE;
    800022be:	4795                	li	a5,5
    800022c0:	00f9ac23          	sw	a5,24(s3)
  release(&wait_lock);
    800022c4:	0022e517          	auipc	a0,0x22e
    800022c8:	7ec50513          	addi	a0,a0,2028 # 80230ab0 <wait_lock>
    800022cc:	be5fe0ef          	jal	80000eb0 <release>
  sched();
    800022d0:	d77ff0ef          	jal	80002046 <sched>
  panic("zombie exit");
    800022d4:	00006517          	auipc	a0,0x6
    800022d8:	fac50513          	addi	a0,a0,-84 # 80008280 <etext+0x280>
    800022dc:	d48fe0ef          	jal	80000824 <panic>

00000000800022e0 <kkill>:
// Kill the process with the given pid.
// The victim won't exit until it tries to return
// to user space (see usertrap() in trap.c).
int
kkill(int pid)
{
    800022e0:	7179                	addi	sp,sp,-48
    800022e2:	f406                	sd	ra,40(sp)
    800022e4:	f022                	sd	s0,32(sp)
    800022e6:	ec26                	sd	s1,24(sp)
    800022e8:	e84a                	sd	s2,16(sp)
    800022ea:	e44e                	sd	s3,8(sp)
    800022ec:	1800                	addi	s0,sp,48
    800022ee:	892a                	mv	s2,a0
  struct proc *p;

  for(p = proc; p < &proc[NPROC]; p++){
    800022f0:	0022f497          	auipc	s1,0x22f
    800022f4:	bd848493          	addi	s1,s1,-1064 # 80230ec8 <proc>
    800022f8:	00234997          	auipc	s3,0x234
    800022fc:	5d098993          	addi	s3,s3,1488 # 802368c8 <tickslock>
    acquire(&p->lock);
    80002300:	8526                	mv	a0,s1
    80002302:	b1bfe0ef          	jal	80000e1c <acquire>
    if(p->pid == pid){
    80002306:	589c                	lw	a5,48(s1)
    80002308:	01278b63          	beq	a5,s2,8000231e <kkill+0x3e>
        p->state = RUNNABLE;
      }
      release(&p->lock);
      return 0;
    }
    release(&p->lock);
    8000230c:	8526                	mv	a0,s1
    8000230e:	ba3fe0ef          	jal	80000eb0 <release>
  for(p = proc; p < &proc[NPROC]; p++){
    80002312:	16848493          	addi	s1,s1,360
    80002316:	ff3495e3          	bne	s1,s3,80002300 <kkill+0x20>
  }
  return -1;
    8000231a:	557d                	li	a0,-1
    8000231c:	a819                	j	80002332 <kkill+0x52>
      p->killed = 1;
    8000231e:	4785                	li	a5,1
    80002320:	d49c                	sw	a5,40(s1)
      if(p->state == SLEEPING){
    80002322:	4c98                	lw	a4,24(s1)
    80002324:	4789                	li	a5,2
    80002326:	00f70d63          	beq	a4,a5,80002340 <kkill+0x60>
      release(&p->lock);
    8000232a:	8526                	mv	a0,s1
    8000232c:	b85fe0ef          	jal	80000eb0 <release>
      return 0;
    80002330:	4501                	li	a0,0
}
    80002332:	70a2                	ld	ra,40(sp)
    80002334:	7402                	ld	s0,32(sp)
    80002336:	64e2                	ld	s1,24(sp)
    80002338:	6942                	ld	s2,16(sp)
    8000233a:	69a2                	ld	s3,8(sp)
    8000233c:	6145                	addi	sp,sp,48
    8000233e:	8082                	ret
        p->state = RUNNABLE;
    80002340:	478d                	li	a5,3
    80002342:	cc9c                	sw	a5,24(s1)
    80002344:	b7dd                	j	8000232a <kkill+0x4a>

0000000080002346 <setkilled>:

void
setkilled(struct proc *p)
{
    80002346:	1101                	addi	sp,sp,-32
    80002348:	ec06                	sd	ra,24(sp)
    8000234a:	e822                	sd	s0,16(sp)
    8000234c:	e426                	sd	s1,8(sp)
    8000234e:	1000                	addi	s0,sp,32
    80002350:	84aa                	mv	s1,a0
  acquire(&p->lock);
    80002352:	acbfe0ef          	jal	80000e1c <acquire>
  p->killed = 1;
    80002356:	4785                	li	a5,1
    80002358:	d49c                	sw	a5,40(s1)
  release(&p->lock);
    8000235a:	8526                	mv	a0,s1
    8000235c:	b55fe0ef          	jal	80000eb0 <release>
}
    80002360:	60e2                	ld	ra,24(sp)
    80002362:	6442                	ld	s0,16(sp)
    80002364:	64a2                	ld	s1,8(sp)
    80002366:	6105                	addi	sp,sp,32
    80002368:	8082                	ret

000000008000236a <killed>:

int
killed(struct proc *p)
{
    8000236a:	1101                	addi	sp,sp,-32
    8000236c:	ec06                	sd	ra,24(sp)
    8000236e:	e822                	sd	s0,16(sp)
    80002370:	e426                	sd	s1,8(sp)
    80002372:	e04a                	sd	s2,0(sp)
    80002374:	1000                	addi	s0,sp,32
    80002376:	84aa                	mv	s1,a0
  int k;
  
  acquire(&p->lock);
    80002378:	aa5fe0ef          	jal	80000e1c <acquire>
  k = p->killed;
    8000237c:	549c                	lw	a5,40(s1)
    8000237e:	893e                	mv	s2,a5
  release(&p->lock);
    80002380:	8526                	mv	a0,s1
    80002382:	b2ffe0ef          	jal	80000eb0 <release>
  return k;
}
    80002386:	854a                	mv	a0,s2
    80002388:	60e2                	ld	ra,24(sp)
    8000238a:	6442                	ld	s0,16(sp)
    8000238c:	64a2                	ld	s1,8(sp)
    8000238e:	6902                	ld	s2,0(sp)
    80002390:	6105                	addi	sp,sp,32
    80002392:	8082                	ret

0000000080002394 <kwait>:
{
    80002394:	715d                	addi	sp,sp,-80
    80002396:	e486                	sd	ra,72(sp)
    80002398:	e0a2                	sd	s0,64(sp)
    8000239a:	fc26                	sd	s1,56(sp)
    8000239c:	f84a                	sd	s2,48(sp)
    8000239e:	f44e                	sd	s3,40(sp)
    800023a0:	f052                	sd	s4,32(sp)
    800023a2:	ec56                	sd	s5,24(sp)
    800023a4:	e85a                	sd	s6,16(sp)
    800023a6:	e45e                	sd	s7,8(sp)
    800023a8:	0880                	addi	s0,sp,80
    800023aa:	8baa                	mv	s7,a0
  struct proc *p = myproc();
    800023ac:	f84ff0ef          	jal	80001b30 <myproc>
    800023b0:	892a                	mv	s2,a0
  acquire(&wait_lock);
    800023b2:	0022e517          	auipc	a0,0x22e
    800023b6:	6fe50513          	addi	a0,a0,1790 # 80230ab0 <wait_lock>
    800023ba:	a63fe0ef          	jal	80000e1c <acquire>
        if(pp->state == ZOMBIE){
    800023be:	4a15                	li	s4,5
        havekids = 1;
    800023c0:	4a85                	li	s5,1
    for(pp = proc; pp < &proc[NPROC]; pp++){
    800023c2:	00234997          	auipc	s3,0x234
    800023c6:	50698993          	addi	s3,s3,1286 # 802368c8 <tickslock>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    800023ca:	0022eb17          	auipc	s6,0x22e
    800023ce:	6e6b0b13          	addi	s6,s6,1766 # 80230ab0 <wait_lock>
    800023d2:	a869                	j	8000246c <kwait+0xd8>
          pid = pp->pid;
    800023d4:	0304a983          	lw	s3,48(s1)
          if(addr != 0 && copyout(p->pagetable, addr, (char *)&pp->xstate,
    800023d8:	000b8c63          	beqz	s7,800023f0 <kwait+0x5c>
    800023dc:	4691                	li	a3,4
    800023de:	02c48613          	addi	a2,s1,44
    800023e2:	85de                	mv	a1,s7
    800023e4:	05093503          	ld	a0,80(s2)
    800023e8:	c6eff0ef          	jal	80001856 <copyout>
    800023ec:	02054a63          	bltz	a0,80002420 <kwait+0x8c>
          freeproc(pp);
    800023f0:	8526                	mv	a0,s1
    800023f2:	913ff0ef          	jal	80001d04 <freeproc>
          release(&pp->lock);
    800023f6:	8526                	mv	a0,s1
    800023f8:	ab9fe0ef          	jal	80000eb0 <release>
          release(&wait_lock);
    800023fc:	0022e517          	auipc	a0,0x22e
    80002400:	6b450513          	addi	a0,a0,1716 # 80230ab0 <wait_lock>
    80002404:	aadfe0ef          	jal	80000eb0 <release>
}
    80002408:	854e                	mv	a0,s3
    8000240a:	60a6                	ld	ra,72(sp)
    8000240c:	6406                	ld	s0,64(sp)
    8000240e:	74e2                	ld	s1,56(sp)
    80002410:	7942                	ld	s2,48(sp)
    80002412:	79a2                	ld	s3,40(sp)
    80002414:	7a02                	ld	s4,32(sp)
    80002416:	6ae2                	ld	s5,24(sp)
    80002418:	6b42                	ld	s6,16(sp)
    8000241a:	6ba2                	ld	s7,8(sp)
    8000241c:	6161                	addi	sp,sp,80
    8000241e:	8082                	ret
            release(&pp->lock);
    80002420:	8526                	mv	a0,s1
    80002422:	a8ffe0ef          	jal	80000eb0 <release>
            release(&wait_lock);
    80002426:	0022e517          	auipc	a0,0x22e
    8000242a:	68a50513          	addi	a0,a0,1674 # 80230ab0 <wait_lock>
    8000242e:	a83fe0ef          	jal	80000eb0 <release>
            return -1;
    80002432:	59fd                	li	s3,-1
    80002434:	bfd1                	j	80002408 <kwait+0x74>
    for(pp = proc; pp < &proc[NPROC]; pp++){
    80002436:	16848493          	addi	s1,s1,360
    8000243a:	03348063          	beq	s1,s3,8000245a <kwait+0xc6>
      if(pp->parent == p){
    8000243e:	7c9c                	ld	a5,56(s1)
    80002440:	ff279be3          	bne	a5,s2,80002436 <kwait+0xa2>
        acquire(&pp->lock);
    80002444:	8526                	mv	a0,s1
    80002446:	9d7fe0ef          	jal	80000e1c <acquire>
        if(pp->state == ZOMBIE){
    8000244a:	4c9c                	lw	a5,24(s1)
    8000244c:	f94784e3          	beq	a5,s4,800023d4 <kwait+0x40>
        release(&pp->lock);
    80002450:	8526                	mv	a0,s1
    80002452:	a5ffe0ef          	jal	80000eb0 <release>
        havekids = 1;
    80002456:	8756                	mv	a4,s5
    80002458:	bff9                	j	80002436 <kwait+0xa2>
    if(!havekids || killed(p)){
    8000245a:	cf19                	beqz	a4,80002478 <kwait+0xe4>
    8000245c:	854a                	mv	a0,s2
    8000245e:	f0dff0ef          	jal	8000236a <killed>
    80002462:	e919                	bnez	a0,80002478 <kwait+0xe4>
    sleep(p, &wait_lock);  //DOC: wait-sleep
    80002464:	85da                	mv	a1,s6
    80002466:	854a                	mv	a0,s2
    80002468:	cc7ff0ef          	jal	8000212e <sleep>
    havekids = 0;
    8000246c:	4701                	li	a4,0
    for(pp = proc; pp < &proc[NPROC]; pp++){
    8000246e:	0022f497          	auipc	s1,0x22f
    80002472:	a5a48493          	addi	s1,s1,-1446 # 80230ec8 <proc>
    80002476:	b7e1                	j	8000243e <kwait+0xaa>
      release(&wait_lock);
    80002478:	0022e517          	auipc	a0,0x22e
    8000247c:	63850513          	addi	a0,a0,1592 # 80230ab0 <wait_lock>
    80002480:	a31fe0ef          	jal	80000eb0 <release>
      return -1;
    80002484:	59fd                	li	s3,-1
    80002486:	b749                	j	80002408 <kwait+0x74>

0000000080002488 <either_copyout>:
// Copy to either a user address, or kernel address,
// depending on usr_dst.
// Returns 0 on success, -1 on error.
int
either_copyout(int user_dst, uint64 dst, void *src, uint64 len)
{
    80002488:	7179                	addi	sp,sp,-48
    8000248a:	f406                	sd	ra,40(sp)
    8000248c:	f022                	sd	s0,32(sp)
    8000248e:	ec26                	sd	s1,24(sp)
    80002490:	e84a                	sd	s2,16(sp)
    80002492:	e44e                	sd	s3,8(sp)
    80002494:	e052                	sd	s4,0(sp)
    80002496:	1800                	addi	s0,sp,48
    80002498:	84aa                	mv	s1,a0
    8000249a:	8a2e                	mv	s4,a1
    8000249c:	89b2                	mv	s3,a2
    8000249e:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800024a0:	e90ff0ef          	jal	80001b30 <myproc>
  if(user_dst){
    800024a4:	cc99                	beqz	s1,800024c2 <either_copyout+0x3a>
    return copyout(p->pagetable, dst, src, len);
    800024a6:	86ca                	mv	a3,s2
    800024a8:	864e                	mv	a2,s3
    800024aa:	85d2                	mv	a1,s4
    800024ac:	6928                	ld	a0,80(a0)
    800024ae:	ba8ff0ef          	jal	80001856 <copyout>
  } else {
    memmove((char *)dst, src, len);
    return 0;
  }
}
    800024b2:	70a2                	ld	ra,40(sp)
    800024b4:	7402                	ld	s0,32(sp)
    800024b6:	64e2                	ld	s1,24(sp)
    800024b8:	6942                	ld	s2,16(sp)
    800024ba:	69a2                	ld	s3,8(sp)
    800024bc:	6a02                	ld	s4,0(sp)
    800024be:	6145                	addi	sp,sp,48
    800024c0:	8082                	ret
    memmove((char *)dst, src, len);
    800024c2:	0009061b          	sext.w	a2,s2
    800024c6:	85ce                	mv	a1,s3
    800024c8:	8552                	mv	a0,s4
    800024ca:	a83fe0ef          	jal	80000f4c <memmove>
    return 0;
    800024ce:	8526                	mv	a0,s1
    800024d0:	b7cd                	j	800024b2 <either_copyout+0x2a>

00000000800024d2 <either_copyin>:
// Copy from either a user address, or kernel address,
// depending on usr_src.
// Returns 0 on success, -1 on error.
int
either_copyin(void *dst, int user_src, uint64 src, uint64 len)
{
    800024d2:	7179                	addi	sp,sp,-48
    800024d4:	f406                	sd	ra,40(sp)
    800024d6:	f022                	sd	s0,32(sp)
    800024d8:	ec26                	sd	s1,24(sp)
    800024da:	e84a                	sd	s2,16(sp)
    800024dc:	e44e                	sd	s3,8(sp)
    800024de:	e052                	sd	s4,0(sp)
    800024e0:	1800                	addi	s0,sp,48
    800024e2:	8a2a                	mv	s4,a0
    800024e4:	84ae                	mv	s1,a1
    800024e6:	89b2                	mv	s3,a2
    800024e8:	8936                	mv	s2,a3
  struct proc *p = myproc();
    800024ea:	e46ff0ef          	jal	80001b30 <myproc>
  if(user_src){
    800024ee:	cc99                	beqz	s1,8000250c <either_copyin+0x3a>
    return copyin(p->pagetable, dst, src, len);
    800024f0:	86ca                	mv	a3,s2
    800024f2:	864e                	mv	a2,s3
    800024f4:	85d2                	mv	a1,s4
    800024f6:	6928                	ld	a0,80(a0)
    800024f8:	c1cff0ef          	jal	80001914 <copyin>
  } else {
    memmove(dst, (char*)src, len);
    return 0;
  }
}
    800024fc:	70a2                	ld	ra,40(sp)
    800024fe:	7402                	ld	s0,32(sp)
    80002500:	64e2                	ld	s1,24(sp)
    80002502:	6942                	ld	s2,16(sp)
    80002504:	69a2                	ld	s3,8(sp)
    80002506:	6a02                	ld	s4,0(sp)
    80002508:	6145                	addi	sp,sp,48
    8000250a:	8082                	ret
    memmove(dst, (char*)src, len);
    8000250c:	0009061b          	sext.w	a2,s2
    80002510:	85ce                	mv	a1,s3
    80002512:	8552                	mv	a0,s4
    80002514:	a39fe0ef          	jal	80000f4c <memmove>
    return 0;
    80002518:	8526                	mv	a0,s1
    8000251a:	b7cd                	j	800024fc <either_copyin+0x2a>

000000008000251c <procdump>:
// Print a process listing to console.  For debugging.
// Runs when user types ^P on console.
// No lock to avoid wedging a stuck machine further.
void
procdump(void)
{
    8000251c:	715d                	addi	sp,sp,-80
    8000251e:	e486                	sd	ra,72(sp)
    80002520:	e0a2                	sd	s0,64(sp)
    80002522:	fc26                	sd	s1,56(sp)
    80002524:	f84a                	sd	s2,48(sp)
    80002526:	f44e                	sd	s3,40(sp)
    80002528:	f052                	sd	s4,32(sp)
    8000252a:	ec56                	sd	s5,24(sp)
    8000252c:	e85a                	sd	s6,16(sp)
    8000252e:	e45e                	sd	s7,8(sp)
    80002530:	0880                	addi	s0,sp,80
  [ZOMBIE]    "zombie"
  };
  struct proc *p;
  char *state;

  printf("\n");
    80002532:	00006517          	auipc	a0,0x6
    80002536:	bd650513          	addi	a0,a0,-1066 # 80008108 <etext+0x108>
    8000253a:	fc1fd0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    8000253e:	0022f497          	auipc	s1,0x22f
    80002542:	ae248493          	addi	s1,s1,-1310 # 80231020 <proc+0x158>
    80002546:	00234917          	auipc	s2,0x234
    8000254a:	4da90913          	addi	s2,s2,1242 # 80236a20 <bcache+0x140>
    if(p->state == UNUSED)
      continue;
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    8000254e:	4b15                	li	s6,5
      state = states[p->state];
    else
      state = "???";
    80002550:	00006997          	auipc	s3,0x6
    80002554:	d4098993          	addi	s3,s3,-704 # 80008290 <etext+0x290>
    printf("%d %s %s", p->pid, state, p->name);
    80002558:	00006a97          	auipc	s5,0x6
    8000255c:	d40a8a93          	addi	s5,s5,-704 # 80008298 <etext+0x298>
    printf("\n");
    80002560:	00006a17          	auipc	s4,0x6
    80002564:	ba8a0a13          	addi	s4,s4,-1112 # 80008108 <etext+0x108>
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002568:	00006b97          	auipc	s7,0x6
    8000256c:	2c8b8b93          	addi	s7,s7,712 # 80008830 <states.0>
    80002570:	a829                	j	8000258a <procdump+0x6e>
    printf("%d %s %s", p->pid, state, p->name);
    80002572:	ed86a583          	lw	a1,-296(a3)
    80002576:	8556                	mv	a0,s5
    80002578:	f83fd0ef          	jal	800004fa <printf>
    printf("\n");
    8000257c:	8552                	mv	a0,s4
    8000257e:	f7dfd0ef          	jal	800004fa <printf>
  for(p = proc; p < &proc[NPROC]; p++){
    80002582:	16848493          	addi	s1,s1,360
    80002586:	03248263          	beq	s1,s2,800025aa <procdump+0x8e>
    if(p->state == UNUSED)
    8000258a:	86a6                	mv	a3,s1
    8000258c:	ec04a783          	lw	a5,-320(s1)
    80002590:	dbed                	beqz	a5,80002582 <procdump+0x66>
      state = "???";
    80002592:	864e                	mv	a2,s3
    if(p->state >= 0 && p->state < NELEM(states) && states[p->state])
    80002594:	fcfb6fe3          	bltu	s6,a5,80002572 <procdump+0x56>
    80002598:	02079713          	slli	a4,a5,0x20
    8000259c:	01d75793          	srli	a5,a4,0x1d
    800025a0:	97de                	add	a5,a5,s7
    800025a2:	6390                	ld	a2,0(a5)
    800025a4:	f679                	bnez	a2,80002572 <procdump+0x56>
      state = "???";
    800025a6:	864e                	mv	a2,s3
    800025a8:	b7e9                	j	80002572 <procdump+0x56>
  }
}
    800025aa:	60a6                	ld	ra,72(sp)
    800025ac:	6406                	ld	s0,64(sp)
    800025ae:	74e2                	ld	s1,56(sp)
    800025b0:	7942                	ld	s2,48(sp)
    800025b2:	79a2                	ld	s3,40(sp)
    800025b4:	7a02                	ld	s4,32(sp)
    800025b6:	6ae2                	ld	s5,24(sp)
    800025b8:	6b42                	ld	s6,16(sp)
    800025ba:	6ba2                	ld	s7,8(sp)
    800025bc:	6161                	addi	sp,sp,80
    800025be:	8082                	ret

00000000800025c0 <swtch>:
# Save current registers in old. Load from new.	


.globl swtch
swtch:
        sd ra, 0(a0)
    800025c0:	00153023          	sd	ra,0(a0)
        sd sp, 8(a0)
    800025c4:	00253423          	sd	sp,8(a0)
        sd s0, 16(a0)
    800025c8:	e900                	sd	s0,16(a0)
        sd s1, 24(a0)
    800025ca:	ed04                	sd	s1,24(a0)
        sd s2, 32(a0)
    800025cc:	03253023          	sd	s2,32(a0)
        sd s3, 40(a0)
    800025d0:	03353423          	sd	s3,40(a0)
        sd s4, 48(a0)
    800025d4:	03453823          	sd	s4,48(a0)
        sd s5, 56(a0)
    800025d8:	03553c23          	sd	s5,56(a0)
        sd s6, 64(a0)
    800025dc:	05653023          	sd	s6,64(a0)
        sd s7, 72(a0)
    800025e0:	05753423          	sd	s7,72(a0)
        sd s8, 80(a0)
    800025e4:	05853823          	sd	s8,80(a0)
        sd s9, 88(a0)
    800025e8:	05953c23          	sd	s9,88(a0)
        sd s10, 96(a0)
    800025ec:	07a53023          	sd	s10,96(a0)
        sd s11, 104(a0)
    800025f0:	07b53423          	sd	s11,104(a0)

        ld ra, 0(a1)
    800025f4:	0005b083          	ld	ra,0(a1)
        ld sp, 8(a1)
    800025f8:	0085b103          	ld	sp,8(a1)
        ld s0, 16(a1)
    800025fc:	6980                	ld	s0,16(a1)
        ld s1, 24(a1)
    800025fe:	6d84                	ld	s1,24(a1)
        ld s2, 32(a1)
    80002600:	0205b903          	ld	s2,32(a1)
        ld s3, 40(a1)
    80002604:	0285b983          	ld	s3,40(a1)
        ld s4, 48(a1)
    80002608:	0305ba03          	ld	s4,48(a1)
        ld s5, 56(a1)
    8000260c:	0385ba83          	ld	s5,56(a1)
        ld s6, 64(a1)
    80002610:	0405bb03          	ld	s6,64(a1)
        ld s7, 72(a1)
    80002614:	0485bb83          	ld	s7,72(a1)
        ld s8, 80(a1)
    80002618:	0505bc03          	ld	s8,80(a1)
        ld s9, 88(a1)
    8000261c:	0585bc83          	ld	s9,88(a1)
        ld s10, 96(a1)
    80002620:	0605bd03          	ld	s10,96(a1)
        ld s11, 104(a1)
    80002624:	0685bd83          	ld	s11,104(a1)
        
        ret
    80002628:	8082                	ret

000000008000262a <trapinit>:

extern int devintr();

void
trapinit(void)
{
    8000262a:	1141                	addi	sp,sp,-16
    8000262c:	e406                	sd	ra,8(sp)
    8000262e:	e022                	sd	s0,0(sp)
    80002630:	0800                	addi	s0,sp,16
  initlock(&tickslock, "time");
    80002632:	00006597          	auipc	a1,0x6
    80002636:	ca658593          	addi	a1,a1,-858 # 800082d8 <etext+0x2d8>
    8000263a:	00234517          	auipc	a0,0x234
    8000263e:	28e50513          	addi	a0,a0,654 # 802368c8 <tickslock>
    80002642:	f50fe0ef          	jal	80000d92 <initlock>
}
    80002646:	60a2                	ld	ra,8(sp)
    80002648:	6402                	ld	s0,0(sp)
    8000264a:	0141                	addi	sp,sp,16
    8000264c:	8082                	ret

000000008000264e <trapinithart>:

// set up to take exceptions and traps while in the kernel.
void
trapinithart(void)
{
    8000264e:	1141                	addi	sp,sp,-16
    80002650:	e406                	sd	ra,8(sp)
    80002652:	e022                	sd	s0,0(sp)
    80002654:	0800                	addi	s0,sp,16
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002656:	00003797          	auipc	a5,0x3
    8000265a:	2fa78793          	addi	a5,a5,762 # 80005950 <kernelvec>
    8000265e:	10579073          	csrw	stvec,a5
  w_stvec((uint64)kernelvec);
}
    80002662:	60a2                	ld	ra,8(sp)
    80002664:	6402                	ld	s0,0(sp)
    80002666:	0141                	addi	sp,sp,16
    80002668:	8082                	ret

000000008000266a <handle_cow_fault>:
// called from, and returns to, trampoline.S
// return value is user satp for trampoline.S to switch to.
//

int handle_cow_fault(pagetable_t pagetable, uint64 va) {
    if(va >= MAXVA) return -1;
    8000266a:	57fd                	li	a5,-1
    8000266c:	83e9                	srli	a5,a5,0x1a
    8000266e:	08b7ee63          	bltu	a5,a1,8000270a <handle_cow_fault+0xa0>
int handle_cow_fault(pagetable_t pagetable, uint64 va) {
    80002672:	7179                	addi	sp,sp,-48
    80002674:	f406                	sd	ra,40(sp)
    80002676:	f022                	sd	s0,32(sp)
    80002678:	ec26                	sd	s1,24(sp)
    8000267a:	1800                	addi	s0,sp,48

    pte_t *pte;
    pte = walk(pagetable, va, 0);
    8000267c:	4601                	li	a2,0
    8000267e:	b0bfe0ef          	jal	80001188 <walk>
    80002682:	84aa                	mv	s1,a0

    if(pte == 0) return -1;
    80002684:	c549                	beqz	a0,8000270e <handle_cow_fault+0xa4>
    80002686:	e84a                	sd	s2,16(sp)
    if((*pte & PTE_V) == 0) return -1;
    80002688:	00053903          	ld	s2,0(a0)
    if((*pte & PTE_COW) == 0) return -1;
    8000268c:	10197713          	andi	a4,s2,257
    80002690:	10100793          	li	a5,257
    80002694:	06f71f63          	bne	a4,a5,80002712 <handle_cow_fault+0xa8>
    80002698:	e44e                	sd	s3,8(sp)

    uint64 pa = PTE2PA(*pte);
    8000269a:	00a95993          	srli	s3,s2,0xa
    8000269e:	09b2                	slli	s3,s3,0xc
    uint64 flags = PTE_FLAGS(*pte);

    if(get(pa) == 1) {
    800026a0:	854e                	mv	a0,s3
    800026a2:	ccafe0ef          	jal	80000b6c <get>
    800026a6:	4785                	li	a5,1
    800026a8:	04f50363          	beq	a0,a5,800026ee <handle_cow_fault+0x84>
        *pte = PA2PTE(pa) | flags;
        sfence_vma();
        return 0;
    }

    char *mem = kalloc();
    800026ac:	e60fe0ef          	jal	80000d0c <kalloc>
    if(mem == 0) return -1;
    800026b0:	c525                	beqz	a0,80002718 <handle_cow_fault+0xae>
    800026b2:	e052                	sd	s4,0(sp)
    memmove(mem, (char*)pa, PGSIZE);
    800026b4:	6605                	lui	a2,0x1
    800026b6:	85ce                	mv	a1,s3
    800026b8:	8a2a                	mv	s4,a0
    800026ba:	893fe0ef          	jal	80000f4c <memmove>

    flags = (flags & ~PTE_COW) | PTE_W;
    *pte = PA2PTE((uint64)mem) | flags;
    800026be:	00ca5793          	srli	a5,s4,0xc
    800026c2:	07aa                	slli	a5,a5,0xa
    flags = (flags & ~PTE_COW) | PTE_W;
    800026c4:	2fb97913          	andi	s2,s2,763
    *pte = PA2PTE((uint64)mem) | flags;
    800026c8:	0127e7b3          	or	a5,a5,s2
    800026cc:	0047e793          	ori	a5,a5,4
    800026d0:	e09c                	sd	a5,0(s1)
  asm volatile("sfence.vma zero, zero");
    800026d2:	12000073          	sfence.vma
    sfence_vma();

    kfree((void*)pa);
    800026d6:	854e                	mv	a0,s3
    800026d8:	d04fe0ef          	jal	80000bdc <kfree>
    return 0;
    800026dc:	4501                	li	a0,0
    800026de:	6942                	ld	s2,16(sp)
    800026e0:	69a2                	ld	s3,8(sp)
    800026e2:	6a02                	ld	s4,0(sp)
}
    800026e4:	70a2                	ld	ra,40(sp)
    800026e6:	7402                	ld	s0,32(sp)
    800026e8:	64e2                	ld	s1,24(sp)
    800026ea:	6145                	addi	sp,sp,48
    800026ec:	8082                	ret
        *pte = PA2PTE(pa) | flags;
    800026ee:	bef00793          	li	a5,-1041
    800026f2:	8389                	srli	a5,a5,0x2
    800026f4:	00f977b3          	and	a5,s2,a5
    800026f8:	0047e793          	ori	a5,a5,4
    800026fc:	e09c                	sd	a5,0(s1)
    800026fe:	12000073          	sfence.vma
        return 0;
    80002702:	4501                	li	a0,0
    80002704:	6942                	ld	s2,16(sp)
    80002706:	69a2                	ld	s3,8(sp)
    80002708:	bff1                	j	800026e4 <handle_cow_fault+0x7a>
    if(va >= MAXVA) return -1;
    8000270a:	557d                	li	a0,-1
}
    8000270c:	8082                	ret
    if(pte == 0) return -1;
    8000270e:	557d                	li	a0,-1
    80002710:	bfd1                	j	800026e4 <handle_cow_fault+0x7a>
    if((*pte & PTE_COW) == 0) return -1;
    80002712:	557d                	li	a0,-1
    80002714:	6942                	ld	s2,16(sp)
    80002716:	b7f9                	j	800026e4 <handle_cow_fault+0x7a>
    if(mem == 0) return -1;
    80002718:	557d                	li	a0,-1
    8000271a:	6942                	ld	s2,16(sp)
    8000271c:	69a2                	ld	s3,8(sp)
    8000271e:	b7d9                	j	800026e4 <handle_cow_fault+0x7a>

0000000080002720 <prepare_return>:
//
// set up trapframe and control registers for a return to user space
//
void
prepare_return(void)
{
    80002720:	1141                	addi	sp,sp,-16
    80002722:	e406                	sd	ra,8(sp)
    80002724:	e022                	sd	s0,0(sp)
    80002726:	0800                	addi	s0,sp,16
  struct proc *p = myproc();
    80002728:	c08ff0ef          	jal	80001b30 <myproc>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000272c:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() & ~SSTATUS_SIE);
    80002730:	9bf5                	andi	a5,a5,-3
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002732:	10079073          	csrw	sstatus,a5
  // kerneltrap() to usertrap(). because a trap from kernel
  // code to usertrap would be a disaster, turn off interrupts.
  intr_off();

  // send syscalls, interrupts, and exceptions to uservec in trampoline.S
  uint64 trampoline_uservec = TRAMPOLINE + (uservec - trampoline);
    80002736:	04000737          	lui	a4,0x4000
    8000273a:	177d                	addi	a4,a4,-1 # 3ffffff <_entry-0x7c000001>
    8000273c:	0732                	slli	a4,a4,0xc
    8000273e:	00005797          	auipc	a5,0x5
    80002742:	8c278793          	addi	a5,a5,-1854 # 80007000 <_trampoline>
    80002746:	00005697          	auipc	a3,0x5
    8000274a:	8ba68693          	addi	a3,a3,-1862 # 80007000 <_trampoline>
    8000274e:	8f95                	sub	a5,a5,a3
    80002750:	97ba                	add	a5,a5,a4
  asm volatile("csrw stvec, %0" : : "r" (x));
    80002752:	10579073          	csrw	stvec,a5
  w_stvec(trampoline_uservec);

  // set up trapframe values that uservec will need when
  // the process next traps into the kernel.
  p->trapframe->kernel_satp = r_satp();         // kernel page table
    80002756:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, satp" : "=r" (x) );
    80002758:	18002773          	csrr	a4,satp
    8000275c:	e398                	sd	a4,0(a5)
  p->trapframe->kernel_sp = p->kstack + PGSIZE; // process's kernel stack
    8000275e:	6d38                	ld	a4,88(a0)
    80002760:	613c                	ld	a5,64(a0)
    80002762:	6685                	lui	a3,0x1
    80002764:	97b6                	add	a5,a5,a3
    80002766:	e71c                	sd	a5,8(a4)
  p->trapframe->kernel_trap = (uint64)usertrap;
    80002768:	6d3c                	ld	a5,88(a0)
    8000276a:	00000717          	auipc	a4,0x0
    8000276e:	0fc70713          	addi	a4,a4,252 # 80002866 <usertrap>
    80002772:	eb98                	sd	a4,16(a5)
  p->trapframe->kernel_hartid = r_tp();         // hartid for cpuid()
    80002774:	6d3c                	ld	a5,88(a0)
  asm volatile("mv %0, tp" : "=r" (x) );
    80002776:	8712                	mv	a4,tp
    80002778:	f398                	sd	a4,32(a5)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    8000277a:	100027f3          	csrr	a5,sstatus
  // set up the registers that trampoline.S's sret will use
  // to get to user space.
  
  // set S Previous Privilege mode to User.
  unsigned long x = r_sstatus();
  x &= ~SSTATUS_SPP; // clear SPP to 0 for user mode
    8000277e:	eff7f793          	andi	a5,a5,-257
  x |= SSTATUS_SPIE; // enable interrupts in user mode
    80002782:	0207e793          	ori	a5,a5,32
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002786:	10079073          	csrw	sstatus,a5
  w_sstatus(x);

  // set S Exception Program Counter to the saved user pc.
  w_sepc(p->trapframe->epc);
    8000278a:	6d3c                	ld	a5,88(a0)
  asm volatile("csrw sepc, %0" : : "r" (x));
    8000278c:	6f9c                	ld	a5,24(a5)
    8000278e:	14179073          	csrw	sepc,a5
}
    80002792:	60a2                	ld	ra,8(sp)
    80002794:	6402                	ld	s0,0(sp)
    80002796:	0141                	addi	sp,sp,16
    80002798:	8082                	ret

000000008000279a <clockintr>:
  w_sstatus(sstatus);
}

void
clockintr()
{
    8000279a:	1141                	addi	sp,sp,-16
    8000279c:	e406                	sd	ra,8(sp)
    8000279e:	e022                	sd	s0,0(sp)
    800027a0:	0800                	addi	s0,sp,16
  if(cpuid() == 0){
    800027a2:	b5aff0ef          	jal	80001afc <cpuid>
    800027a6:	cd11                	beqz	a0,800027c2 <clockintr+0x28>
  asm volatile("csrr %0, time" : "=r" (x) );
    800027a8:	c01027f3          	rdtime	a5
  }

  // ask for the next timer interrupt. this also clears
  // the interrupt request. 1000000 is about a tenth
  // of a second.
  w_stimecmp(r_time() + 1000000);
    800027ac:	000f4737          	lui	a4,0xf4
    800027b0:	24070713          	addi	a4,a4,576 # f4240 <_entry-0x7ff0bdc0>
    800027b4:	97ba                	add	a5,a5,a4
  asm volatile("csrw 0x14d, %0" : : "r" (x));
    800027b6:	14d79073          	csrw	stimecmp,a5
}
    800027ba:	60a2                	ld	ra,8(sp)
    800027bc:	6402                	ld	s0,0(sp)
    800027be:	0141                	addi	sp,sp,16
    800027c0:	8082                	ret
    acquire(&tickslock);
    800027c2:	00234517          	auipc	a0,0x234
    800027c6:	10650513          	addi	a0,a0,262 # 802368c8 <tickslock>
    800027ca:	e52fe0ef          	jal	80000e1c <acquire>
    ticks++;
    800027ce:	00006717          	auipc	a4,0x6
    800027d2:	1ca70713          	addi	a4,a4,458 # 80008998 <ticks>
    800027d6:	431c                	lw	a5,0(a4)
    800027d8:	2785                	addiw	a5,a5,1
    800027da:	c31c                	sw	a5,0(a4)
    wakeup(&ticks);
    800027dc:	853a                	mv	a0,a4
    800027de:	99dff0ef          	jal	8000217a <wakeup>
    release(&tickslock);
    800027e2:	00234517          	auipc	a0,0x234
    800027e6:	0e650513          	addi	a0,a0,230 # 802368c8 <tickslock>
    800027ea:	ec6fe0ef          	jal	80000eb0 <release>
    800027ee:	bf6d                	j	800027a8 <clockintr+0xe>

00000000800027f0 <devintr>:
// returns 2 if timer interrupt,
// 1 if other device,
// 0 if not recognized.
int
devintr()
{
    800027f0:	1101                	addi	sp,sp,-32
    800027f2:	ec06                	sd	ra,24(sp)
    800027f4:	e822                	sd	s0,16(sp)
    800027f6:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, scause" : "=r" (x) );
    800027f8:	14202773          	csrr	a4,scause
  uint64 scause = r_scause();

  if(scause == 0x8000000000000009L){
    800027fc:	57fd                	li	a5,-1
    800027fe:	17fe                	slli	a5,a5,0x3f
    80002800:	07a5                	addi	a5,a5,9
    80002802:	00f70c63          	beq	a4,a5,8000281a <devintr+0x2a>
    // now allowed to interrupt again.
    if(irq)
      plic_complete(irq);

    return 1;
  } else if(scause == 0x8000000000000005L){
    80002806:	57fd                	li	a5,-1
    80002808:	17fe                	slli	a5,a5,0x3f
    8000280a:	0795                	addi	a5,a5,5
    // timer interrupt.
    clockintr();
    return 2;
  } else {
    return 0;
    8000280c:	4501                	li	a0,0
  } else if(scause == 0x8000000000000005L){
    8000280e:	04f70863          	beq	a4,a5,8000285e <devintr+0x6e>
  }
}
    80002812:	60e2                	ld	ra,24(sp)
    80002814:	6442                	ld	s0,16(sp)
    80002816:	6105                	addi	sp,sp,32
    80002818:	8082                	ret
    8000281a:	e426                	sd	s1,8(sp)
    int irq = plic_claim();
    8000281c:	1e0030ef          	jal	800059fc <plic_claim>
    80002820:	872a                	mv	a4,a0
    80002822:	84aa                	mv	s1,a0
    if(irq == UART0_IRQ){
    80002824:	47a9                	li	a5,10
    80002826:	00f50963          	beq	a0,a5,80002838 <devintr+0x48>
    } else if(irq == VIRTIO0_IRQ){
    8000282a:	4785                	li	a5,1
    8000282c:	00f50963          	beq	a0,a5,8000283e <devintr+0x4e>
    return 1;
    80002830:	4505                	li	a0,1
    } else if(irq){
    80002832:	eb09                	bnez	a4,80002844 <devintr+0x54>
    80002834:	64a2                	ld	s1,8(sp)
    80002836:	bff1                	j	80002812 <devintr+0x22>
      uartintr();
    80002838:	9bcfe0ef          	jal	800009f4 <uartintr>
    if(irq)
    8000283c:	a819                	j	80002852 <devintr+0x62>
      virtio_disk_intr();
    8000283e:	2d3030ef          	jal	80006310 <virtio_disk_intr>
    if(irq)
    80002842:	a801                	j	80002852 <devintr+0x62>
      printf("unexpected interrupt irq=%d\n", irq);
    80002844:	85ba                	mv	a1,a4
    80002846:	00006517          	auipc	a0,0x6
    8000284a:	a9a50513          	addi	a0,a0,-1382 # 800082e0 <etext+0x2e0>
    8000284e:	cadfd0ef          	jal	800004fa <printf>
      plic_complete(irq);
    80002852:	8526                	mv	a0,s1
    80002854:	1c8030ef          	jal	80005a1c <plic_complete>
    return 1;
    80002858:	4505                	li	a0,1
    8000285a:	64a2                	ld	s1,8(sp)
    8000285c:	bf5d                	j	80002812 <devintr+0x22>
    clockintr();
    8000285e:	f3dff0ef          	jal	8000279a <clockintr>
    return 2;
    80002862:	4509                	li	a0,2
    80002864:	b77d                	j	80002812 <devintr+0x22>

0000000080002866 <usertrap>:
{
    80002866:	1101                	addi	sp,sp,-32
    80002868:	ec06                	sd	ra,24(sp)
    8000286a:	e822                	sd	s0,16(sp)
    8000286c:	e426                	sd	s1,8(sp)
    8000286e:	e04a                	sd	s2,0(sp)
    80002870:	1000                	addi	s0,sp,32
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002872:	100027f3          	csrr	a5,sstatus
  if((r_sstatus() & SSTATUS_SPP) != 0)
    80002876:	1007f793          	andi	a5,a5,256
    8000287a:	ebd1                	bnez	a5,8000290e <usertrap+0xa8>
  asm volatile("csrw stvec, %0" : : "r" (x));
    8000287c:	00003797          	auipc	a5,0x3
    80002880:	0d478793          	addi	a5,a5,212 # 80005950 <kernelvec>
    80002884:	10579073          	csrw	stvec,a5
  struct proc *p = myproc();
    80002888:	aa8ff0ef          	jal	80001b30 <myproc>
    8000288c:	84aa                	mv	s1,a0
  p->trapframe->epc = r_sepc();
    8000288e:	6d3c                	ld	a5,88(a0)
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002890:	14102773          	csrr	a4,sepc
    80002894:	ef98                	sd	a4,24(a5)
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002896:	14202773          	csrr	a4,scause
  if(r_scause() == 8){
    8000289a:	47a1                	li	a5,8
    8000289c:	06f70f63          	beq	a4,a5,8000291a <usertrap+0xb4>
  } else if((which_dev = devintr()) != 0){
    800028a0:	f51ff0ef          	jal	800027f0 <devintr>
    800028a4:	892a                	mv	s2,a0
    800028a6:	0e051563          	bnez	a0,80002990 <usertrap+0x12a>
    800028aa:	14202773          	csrr	a4,scause
  } else if (r_scause() == 15 || r_scause() == 13) {
    800028ae:	47bd                	li	a5,15
    800028b0:	00f70763          	beq	a4,a5,800028be <usertrap+0x58>
    800028b4:	14202773          	csrr	a4,scause
    800028b8:	47b5                	li	a5,13
    800028ba:	0af71463          	bne	a4,a5,80002962 <usertrap+0xfc>
  asm volatile("csrr %0, stval" : "=r" (x) );
    800028be:	143025f3          	csrr	a1,stval
    800028c2:	892e                	mv	s2,a1
  asm volatile("csrr %0, scause" : "=r" (x) );
    800028c4:	14202673          	csrr	a2,scause
    if (vmfault(p->pagetable, va, (r_scause() == 13) ? 1 : 0) != 0) {
    800028c8:	164d                	addi	a2,a2,-13 # ff3 <_entry-0x7ffff00d>
    800028ca:	00163613          	seqz	a2,a2
    800028ce:	68a8                	ld	a0,80(s1)
    800028d0:	f03fe0ef          	jal	800017d2 <vmfault>
    800028d4:	e135                	bnez	a0,80002938 <usertrap+0xd2>
    } else if (handle_cow_fault(p->pagetable, va) == 0) {
    800028d6:	85ca                	mv	a1,s2
    800028d8:	68a8                	ld	a0,80(s1)
    800028da:	d91ff0ef          	jal	8000266a <handle_cow_fault>
    800028de:	cd29                	beqz	a0,80002938 <usertrap+0xd2>
    800028e0:	142025f3          	csrr	a1,scause
      printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    800028e4:	5890                	lw	a2,48(s1)
    800028e6:	00006517          	auipc	a0,0x6
    800028ea:	a3a50513          	addi	a0,a0,-1478 # 80008320 <etext+0x320>
    800028ee:	c0dfd0ef          	jal	800004fa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800028f2:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    800028f6:	14302673          	csrr	a2,stval
      printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    800028fa:	00006517          	auipc	a0,0x6
    800028fe:	a5650513          	addi	a0,a0,-1450 # 80008350 <etext+0x350>
    80002902:	bf9fd0ef          	jal	800004fa <printf>
      setkilled(p);
    80002906:	8526                	mv	a0,s1
    80002908:	a3fff0ef          	jal	80002346 <setkilled>
    8000290c:	a035                	j	80002938 <usertrap+0xd2>
    panic("usertrap: not from user mode");
    8000290e:	00006517          	auipc	a0,0x6
    80002912:	9f250513          	addi	a0,a0,-1550 # 80008300 <etext+0x300>
    80002916:	f0ffd0ef          	jal	80000824 <panic>
    if(killed(p))
    8000291a:	a51ff0ef          	jal	8000236a <killed>
    8000291e:	ed15                	bnez	a0,8000295a <usertrap+0xf4>
    p->trapframe->epc += 4;
    80002920:	6cb8                	ld	a4,88(s1)
    80002922:	6f1c                	ld	a5,24(a4)
    80002924:	0791                	addi	a5,a5,4
    80002926:	ef1c                	sd	a5,24(a4)
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    80002928:	100027f3          	csrr	a5,sstatus
  w_sstatus(r_sstatus() | SSTATUS_SIE);
    8000292c:	0027e793          	ori	a5,a5,2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    80002930:	10079073          	csrw	sstatus,a5
    syscall();
    80002934:	256000ef          	jal	80002b8a <syscall>
  if(killed(p))
    80002938:	8526                	mv	a0,s1
    8000293a:	a31ff0ef          	jal	8000236a <killed>
    8000293e:	ed31                	bnez	a0,8000299a <usertrap+0x134>
  prepare_return();
    80002940:	de1ff0ef          	jal	80002720 <prepare_return>
  uint64 satp = MAKE_SATP(p->pagetable);
    80002944:	68a8                	ld	a0,80(s1)
    80002946:	8131                	srli	a0,a0,0xc
    80002948:	57fd                	li	a5,-1
    8000294a:	17fe                	slli	a5,a5,0x3f
    8000294c:	8d5d                	or	a0,a0,a5
}
    8000294e:	60e2                	ld	ra,24(sp)
    80002950:	6442                	ld	s0,16(sp)
    80002952:	64a2                	ld	s1,8(sp)
    80002954:	6902                	ld	s2,0(sp)
    80002956:	6105                	addi	sp,sp,32
    80002958:	8082                	ret
      kexit(-1);
    8000295a:	557d                	li	a0,-1
    8000295c:	8dfff0ef          	jal	8000223a <kexit>
    80002960:	b7c1                	j	80002920 <usertrap+0xba>
  asm volatile("csrr %0, scause" : "=r" (x) );
    80002962:	142025f3          	csrr	a1,scause
    printf("usertrap(): unexpected scause 0x%lx pid=%d\n", r_scause(), p->pid);
    80002966:	5890                	lw	a2,48(s1)
    80002968:	00006517          	auipc	a0,0x6
    8000296c:	9b850513          	addi	a0,a0,-1608 # 80008320 <etext+0x320>
    80002970:	b8bfd0ef          	jal	800004fa <printf>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002974:	141025f3          	csrr	a1,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002978:	14302673          	csrr	a2,stval
    printf("            sepc=0x%lx stval=0x%lx\n", r_sepc(), r_stval());
    8000297c:	00006517          	auipc	a0,0x6
    80002980:	9d450513          	addi	a0,a0,-1580 # 80008350 <etext+0x350>
    80002984:	b77fd0ef          	jal	800004fa <printf>
    setkilled(p);
    80002988:	8526                	mv	a0,s1
    8000298a:	9bdff0ef          	jal	80002346 <setkilled>
    8000298e:	b76d                	j	80002938 <usertrap+0xd2>
  if(killed(p))
    80002990:	8526                	mv	a0,s1
    80002992:	9d9ff0ef          	jal	8000236a <killed>
    80002996:	c511                	beqz	a0,800029a2 <usertrap+0x13c>
    80002998:	a011                	j	8000299c <usertrap+0x136>
    8000299a:	4901                	li	s2,0
    kexit(-1);
    8000299c:	557d                	li	a0,-1
    8000299e:	89dff0ef          	jal	8000223a <kexit>
  if(which_dev == 2)
    800029a2:	4789                	li	a5,2
    800029a4:	f8f91ee3          	bne	s2,a5,80002940 <usertrap+0xda>
    yield();
    800029a8:	f5aff0ef          	jal	80002102 <yield>
    800029ac:	bf51                	j	80002940 <usertrap+0xda>

00000000800029ae <kerneltrap>:
{
    800029ae:	7179                	addi	sp,sp,-48
    800029b0:	f406                	sd	ra,40(sp)
    800029b2:	f022                	sd	s0,32(sp)
    800029b4:	ec26                	sd	s1,24(sp)
    800029b6:	e84a                	sd	s2,16(sp)
    800029b8:	e44e                	sd	s3,8(sp)
    800029ba:	1800                	addi	s0,sp,48
  asm volatile("csrr %0, sepc" : "=r" (x) );
    800029bc:	14102973          	csrr	s2,sepc
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800029c0:	100024f3          	csrr	s1,sstatus
  asm volatile("csrr %0, scause" : "=r" (x) );
    800029c4:	142027f3          	csrr	a5,scause
    800029c8:	89be                	mv	s3,a5
  if((sstatus & SSTATUS_SPP) == 0)
    800029ca:	1004f793          	andi	a5,s1,256
    800029ce:	c795                	beqz	a5,800029fa <kerneltrap+0x4c>
  asm volatile("csrr %0, sstatus" : "=r" (x) );
    800029d0:	100027f3          	csrr	a5,sstatus
  return (x & SSTATUS_SIE) != 0;
    800029d4:	8b89                	andi	a5,a5,2
  if(intr_get() != 0)
    800029d6:	eb85                	bnez	a5,80002a06 <kerneltrap+0x58>
  if((which_dev = devintr()) == 0){
    800029d8:	e19ff0ef          	jal	800027f0 <devintr>
    800029dc:	c91d                	beqz	a0,80002a12 <kerneltrap+0x64>
  if(which_dev == 2 && myproc() != 0)
    800029de:	4789                	li	a5,2
    800029e0:	04f50a63          	beq	a0,a5,80002a34 <kerneltrap+0x86>
  asm volatile("csrw sepc, %0" : : "r" (x));
    800029e4:	14191073          	csrw	sepc,s2
  asm volatile("csrw sstatus, %0" : : "r" (x));
    800029e8:	10049073          	csrw	sstatus,s1
}
    800029ec:	70a2                	ld	ra,40(sp)
    800029ee:	7402                	ld	s0,32(sp)
    800029f0:	64e2                	ld	s1,24(sp)
    800029f2:	6942                	ld	s2,16(sp)
    800029f4:	69a2                	ld	s3,8(sp)
    800029f6:	6145                	addi	sp,sp,48
    800029f8:	8082                	ret
    panic("kerneltrap: not from supervisor mode");
    800029fa:	00006517          	auipc	a0,0x6
    800029fe:	97e50513          	addi	a0,a0,-1666 # 80008378 <etext+0x378>
    80002a02:	e23fd0ef          	jal	80000824 <panic>
    panic("kerneltrap: interrupts enabled");
    80002a06:	00006517          	auipc	a0,0x6
    80002a0a:	99a50513          	addi	a0,a0,-1638 # 800083a0 <etext+0x3a0>
    80002a0e:	e17fd0ef          	jal	80000824 <panic>
  asm volatile("csrr %0, sepc" : "=r" (x) );
    80002a12:	14102673          	csrr	a2,sepc
  asm volatile("csrr %0, stval" : "=r" (x) );
    80002a16:	143026f3          	csrr	a3,stval
    printf("scause=0x%lx sepc=0x%lx stval=0x%lx\n", scause, r_sepc(), r_stval());
    80002a1a:	85ce                	mv	a1,s3
    80002a1c:	00006517          	auipc	a0,0x6
    80002a20:	9a450513          	addi	a0,a0,-1628 # 800083c0 <etext+0x3c0>
    80002a24:	ad7fd0ef          	jal	800004fa <printf>
    panic("kerneltrap");
    80002a28:	00006517          	auipc	a0,0x6
    80002a2c:	9c050513          	addi	a0,a0,-1600 # 800083e8 <etext+0x3e8>
    80002a30:	df5fd0ef          	jal	80000824 <panic>
  if(which_dev == 2 && myproc() != 0)
    80002a34:	8fcff0ef          	jal	80001b30 <myproc>
    80002a38:	d555                	beqz	a0,800029e4 <kerneltrap+0x36>
    yield();
    80002a3a:	ec8ff0ef          	jal	80002102 <yield>
    80002a3e:	b75d                	j	800029e4 <kerneltrap+0x36>

0000000080002a40 <argraw>:
  return strlen(buf);
}

static uint64
argraw(int n)
{
    80002a40:	1101                	addi	sp,sp,-32
    80002a42:	ec06                	sd	ra,24(sp)
    80002a44:	e822                	sd	s0,16(sp)
    80002a46:	e426                	sd	s1,8(sp)
    80002a48:	1000                	addi	s0,sp,32
    80002a4a:	84aa                	mv	s1,a0
  struct proc *p = myproc();
    80002a4c:	8e4ff0ef          	jal	80001b30 <myproc>
  switch (n) {
    80002a50:	4795                	li	a5,5
    80002a52:	0497e163          	bltu	a5,s1,80002a94 <argraw+0x54>
    80002a56:	048a                	slli	s1,s1,0x2
    80002a58:	00006717          	auipc	a4,0x6
    80002a5c:	e0870713          	addi	a4,a4,-504 # 80008860 <states.0+0x30>
    80002a60:	94ba                	add	s1,s1,a4
    80002a62:	409c                	lw	a5,0(s1)
    80002a64:	97ba                	add	a5,a5,a4
    80002a66:	8782                	jr	a5
  case 0:
    return p->trapframe->a0;
    80002a68:	6d3c                	ld	a5,88(a0)
    80002a6a:	7ba8                	ld	a0,112(a5)
  case 5:
    return p->trapframe->a5;
  }
  panic("argraw");
  return -1;
}
    80002a6c:	60e2                	ld	ra,24(sp)
    80002a6e:	6442                	ld	s0,16(sp)
    80002a70:	64a2                	ld	s1,8(sp)
    80002a72:	6105                	addi	sp,sp,32
    80002a74:	8082                	ret
    return p->trapframe->a1;
    80002a76:	6d3c                	ld	a5,88(a0)
    80002a78:	7fa8                	ld	a0,120(a5)
    80002a7a:	bfcd                	j	80002a6c <argraw+0x2c>
    return p->trapframe->a2;
    80002a7c:	6d3c                	ld	a5,88(a0)
    80002a7e:	63c8                	ld	a0,128(a5)
    80002a80:	b7f5                	j	80002a6c <argraw+0x2c>
    return p->trapframe->a3;
    80002a82:	6d3c                	ld	a5,88(a0)
    80002a84:	67c8                	ld	a0,136(a5)
    80002a86:	b7dd                	j	80002a6c <argraw+0x2c>
    return p->trapframe->a4;
    80002a88:	6d3c                	ld	a5,88(a0)
    80002a8a:	6bc8                	ld	a0,144(a5)
    80002a8c:	b7c5                	j	80002a6c <argraw+0x2c>
    return p->trapframe->a5;
    80002a8e:	6d3c                	ld	a5,88(a0)
    80002a90:	6fc8                	ld	a0,152(a5)
    80002a92:	bfe9                	j	80002a6c <argraw+0x2c>
  panic("argraw");
    80002a94:	00006517          	auipc	a0,0x6
    80002a98:	96450513          	addi	a0,a0,-1692 # 800083f8 <etext+0x3f8>
    80002a9c:	d89fd0ef          	jal	80000824 <panic>

0000000080002aa0 <fetchaddr>:
{
    80002aa0:	1101                	addi	sp,sp,-32
    80002aa2:	ec06                	sd	ra,24(sp)
    80002aa4:	e822                	sd	s0,16(sp)
    80002aa6:	e426                	sd	s1,8(sp)
    80002aa8:	e04a                	sd	s2,0(sp)
    80002aaa:	1000                	addi	s0,sp,32
    80002aac:	84aa                	mv	s1,a0
    80002aae:	892e                	mv	s2,a1
  struct proc *p = myproc();
    80002ab0:	880ff0ef          	jal	80001b30 <myproc>
  if(addr >= p->sz || addr+sizeof(uint64) > p->sz) // both tests needed, in case of overflow
    80002ab4:	653c                	ld	a5,72(a0)
    80002ab6:	02f4f663          	bgeu	s1,a5,80002ae2 <fetchaddr+0x42>
    80002aba:	00848713          	addi	a4,s1,8
    80002abe:	02e7e463          	bltu	a5,a4,80002ae6 <fetchaddr+0x46>
  if(copyin(p->pagetable, (char *)ip, addr, sizeof(*ip)) != 0)
    80002ac2:	46a1                	li	a3,8
    80002ac4:	8626                	mv	a2,s1
    80002ac6:	85ca                	mv	a1,s2
    80002ac8:	6928                	ld	a0,80(a0)
    80002aca:	e4bfe0ef          	jal	80001914 <copyin>
    80002ace:	00a03533          	snez	a0,a0
    80002ad2:	40a0053b          	negw	a0,a0
}
    80002ad6:	60e2                	ld	ra,24(sp)
    80002ad8:	6442                	ld	s0,16(sp)
    80002ada:	64a2                	ld	s1,8(sp)
    80002adc:	6902                	ld	s2,0(sp)
    80002ade:	6105                	addi	sp,sp,32
    80002ae0:	8082                	ret
    return -1;
    80002ae2:	557d                	li	a0,-1
    80002ae4:	bfcd                	j	80002ad6 <fetchaddr+0x36>
    80002ae6:	557d                	li	a0,-1
    80002ae8:	b7fd                	j	80002ad6 <fetchaddr+0x36>

0000000080002aea <fetchstr>:
{
    80002aea:	7179                	addi	sp,sp,-48
    80002aec:	f406                	sd	ra,40(sp)
    80002aee:	f022                	sd	s0,32(sp)
    80002af0:	ec26                	sd	s1,24(sp)
    80002af2:	e84a                	sd	s2,16(sp)
    80002af4:	e44e                	sd	s3,8(sp)
    80002af6:	1800                	addi	s0,sp,48
    80002af8:	89aa                	mv	s3,a0
    80002afa:	84ae                	mv	s1,a1
    80002afc:	8932                	mv	s2,a2
  struct proc *p = myproc();
    80002afe:	832ff0ef          	jal	80001b30 <myproc>
  if(copyinstr(p->pagetable, buf, addr, max) < 0)
    80002b02:	86ca                	mv	a3,s2
    80002b04:	864e                	mv	a2,s3
    80002b06:	85a6                	mv	a1,s1
    80002b08:	6928                	ld	a0,80(a0)
    80002b0a:	bf1fe0ef          	jal	800016fa <copyinstr>
    80002b0e:	00054c63          	bltz	a0,80002b26 <fetchstr+0x3c>
  return strlen(buf);
    80002b12:	8526                	mv	a0,s1
    80002b14:	d62fe0ef          	jal	80001076 <strlen>
}
    80002b18:	70a2                	ld	ra,40(sp)
    80002b1a:	7402                	ld	s0,32(sp)
    80002b1c:	64e2                	ld	s1,24(sp)
    80002b1e:	6942                	ld	s2,16(sp)
    80002b20:	69a2                	ld	s3,8(sp)
    80002b22:	6145                	addi	sp,sp,48
    80002b24:	8082                	ret
    return -1;
    80002b26:	557d                	li	a0,-1
    80002b28:	bfc5                	j	80002b18 <fetchstr+0x2e>

0000000080002b2a <argint>:

// Fetch the nth 32-bit system call argument.
void
argint(int n, int *ip)
{
    80002b2a:	1101                	addi	sp,sp,-32
    80002b2c:	ec06                	sd	ra,24(sp)
    80002b2e:	e822                	sd	s0,16(sp)
    80002b30:	e426                	sd	s1,8(sp)
    80002b32:	1000                	addi	s0,sp,32
    80002b34:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002b36:	f0bff0ef          	jal	80002a40 <argraw>
    80002b3a:	c088                	sw	a0,0(s1)
}
    80002b3c:	60e2                	ld	ra,24(sp)
    80002b3e:	6442                	ld	s0,16(sp)
    80002b40:	64a2                	ld	s1,8(sp)
    80002b42:	6105                	addi	sp,sp,32
    80002b44:	8082                	ret

0000000080002b46 <argaddr>:
// Retrieve an argument as a pointer.
// Doesn't check for legality, since
// copyin/copyout will do that.
void
argaddr(int n, uint64 *ip)
{
    80002b46:	1101                	addi	sp,sp,-32
    80002b48:	ec06                	sd	ra,24(sp)
    80002b4a:	e822                	sd	s0,16(sp)
    80002b4c:	e426                	sd	s1,8(sp)
    80002b4e:	1000                	addi	s0,sp,32
    80002b50:	84ae                	mv	s1,a1
  *ip = argraw(n);
    80002b52:	eefff0ef          	jal	80002a40 <argraw>
    80002b56:	e088                	sd	a0,0(s1)
}
    80002b58:	60e2                	ld	ra,24(sp)
    80002b5a:	6442                	ld	s0,16(sp)
    80002b5c:	64a2                	ld	s1,8(sp)
    80002b5e:	6105                	addi	sp,sp,32
    80002b60:	8082                	ret

0000000080002b62 <argstr>:
// Fetch the nth word-sized system call argument as a null-terminated string.
// Copies into buf, at most max.
// Returns string length if OK (including nul), -1 if error.
int
argstr(int n, char *buf, int max)
{
    80002b62:	1101                	addi	sp,sp,-32
    80002b64:	ec06                	sd	ra,24(sp)
    80002b66:	e822                	sd	s0,16(sp)
    80002b68:	e426                	sd	s1,8(sp)
    80002b6a:	e04a                	sd	s2,0(sp)
    80002b6c:	1000                	addi	s0,sp,32
    80002b6e:	892e                	mv	s2,a1
    80002b70:	84b2                	mv	s1,a2
  *ip = argraw(n);
    80002b72:	ecfff0ef          	jal	80002a40 <argraw>
  uint64 addr;
  argaddr(n, &addr);
  return fetchstr(addr, buf, max);
    80002b76:	8626                	mv	a2,s1
    80002b78:	85ca                	mv	a1,s2
    80002b7a:	f71ff0ef          	jal	80002aea <fetchstr>
}
    80002b7e:	60e2                	ld	ra,24(sp)
    80002b80:	6442                	ld	s0,16(sp)
    80002b82:	64a2                	ld	s1,8(sp)
    80002b84:	6902                	ld	s2,0(sp)
    80002b86:	6105                	addi	sp,sp,32
    80002b88:	8082                	ret

0000000080002b8a <syscall>:
[SYS_va2pa]   sys_va2pa,
};

void
syscall(void)
{
    80002b8a:	1101                	addi	sp,sp,-32
    80002b8c:	ec06                	sd	ra,24(sp)
    80002b8e:	e822                	sd	s0,16(sp)
    80002b90:	e426                	sd	s1,8(sp)
    80002b92:	e04a                	sd	s2,0(sp)
    80002b94:	1000                	addi	s0,sp,32
  int num;
  struct proc *p = myproc();
    80002b96:	f9bfe0ef          	jal	80001b30 <myproc>
    80002b9a:	84aa                	mv	s1,a0

  num = p->trapframe->a7;
    80002b9c:	05853903          	ld	s2,88(a0)
    80002ba0:	0a893783          	ld	a5,168(s2)
    80002ba4:	0007869b          	sext.w	a3,a5
  if(num > 0 && num < NELEM(syscalls) && syscalls[num]) {
    80002ba8:	37fd                	addiw	a5,a5,-1
    80002baa:	476d                	li	a4,27
    80002bac:	00f76f63          	bltu	a4,a5,80002bca <syscall+0x40>
    80002bb0:	00369713          	slli	a4,a3,0x3
    80002bb4:	00006797          	auipc	a5,0x6
    80002bb8:	cc478793          	addi	a5,a5,-828 # 80008878 <syscalls>
    80002bbc:	97ba                	add	a5,a5,a4
    80002bbe:	639c                	ld	a5,0(a5)
    80002bc0:	c789                	beqz	a5,80002bca <syscall+0x40>
    // Use num to lookup the system call function for num, call it,
    // and store its return value in p->trapframe->a0
    p->trapframe->a0 = syscalls[num]();
    80002bc2:	9782                	jalr	a5
    80002bc4:	06a93823          	sd	a0,112(s2)
    80002bc8:	a829                	j	80002be2 <syscall+0x58>
  } else {
    printf("%d %s: unknown sys call %d\n",
    80002bca:	15848613          	addi	a2,s1,344
    80002bce:	588c                	lw	a1,48(s1)
    80002bd0:	00006517          	auipc	a0,0x6
    80002bd4:	83050513          	addi	a0,a0,-2000 # 80008400 <etext+0x400>
    80002bd8:	923fd0ef          	jal	800004fa <printf>
            p->pid, p->name, num);
    p->trapframe->a0 = -1;
    80002bdc:	6cbc                	ld	a5,88(s1)
    80002bde:	577d                	li	a4,-1
    80002be0:	fbb8                	sd	a4,112(a5)
  }
}
    80002be2:	60e2                	ld	ra,24(sp)
    80002be4:	6442                	ld	s0,16(sp)
    80002be6:	64a2                	ld	s1,8(sp)
    80002be8:	6902                	ld	s2,0(sp)
    80002bea:	6105                	addi	sp,sp,32
    80002bec:	8082                	ret

0000000080002bee <sys_exit>:
#include "vm.h"
#include "shm.h"
#include "mbox.h"
uint64
sys_exit(void)
{
    80002bee:	1101                	addi	sp,sp,-32
    80002bf0:	ec06                	sd	ra,24(sp)
    80002bf2:	e822                	sd	s0,16(sp)
    80002bf4:	1000                	addi	s0,sp,32
  int n;
  argint(0, &n);
    80002bf6:	fec40593          	addi	a1,s0,-20
    80002bfa:	4501                	li	a0,0
    80002bfc:	f2fff0ef          	jal	80002b2a <argint>
  kexit(n);
    80002c00:	fec42503          	lw	a0,-20(s0)
    80002c04:	e36ff0ef          	jal	8000223a <kexit>
  return 0;  // not reached
}
    80002c08:	4501                	li	a0,0
    80002c0a:	60e2                	ld	ra,24(sp)
    80002c0c:	6442                	ld	s0,16(sp)
    80002c0e:	6105                	addi	sp,sp,32
    80002c10:	8082                	ret

0000000080002c12 <sys_getpid>:

uint64
sys_getpid(void)
{
    80002c12:	1141                	addi	sp,sp,-16
    80002c14:	e406                	sd	ra,8(sp)
    80002c16:	e022                	sd	s0,0(sp)
    80002c18:	0800                	addi	s0,sp,16
  return myproc()->pid;
    80002c1a:	f17fe0ef          	jal	80001b30 <myproc>
}
    80002c1e:	5908                	lw	a0,48(a0)
    80002c20:	60a2                	ld	ra,8(sp)
    80002c22:	6402                	ld	s0,0(sp)
    80002c24:	0141                	addi	sp,sp,16
    80002c26:	8082                	ret

0000000080002c28 <sys_fork>:

uint64
sys_fork(void)
{
    80002c28:	1141                	addi	sp,sp,-16
    80002c2a:	e406                	sd	ra,8(sp)
    80002c2c:	e022                	sd	s0,0(sp)
    80002c2e:	0800                	addi	s0,sp,16
  return kfork();
    80002c30:	a56ff0ef          	jal	80001e86 <kfork>
}
    80002c34:	60a2                	ld	ra,8(sp)
    80002c36:	6402                	ld	s0,0(sp)
    80002c38:	0141                	addi	sp,sp,16
    80002c3a:	8082                	ret

0000000080002c3c <sys_wait>:

uint64
sys_wait(void)
{
    80002c3c:	1101                	addi	sp,sp,-32
    80002c3e:	ec06                	sd	ra,24(sp)
    80002c40:	e822                	sd	s0,16(sp)
    80002c42:	1000                	addi	s0,sp,32
  uint64 p;
  argaddr(0, &p);
    80002c44:	fe840593          	addi	a1,s0,-24
    80002c48:	4501                	li	a0,0
    80002c4a:	efdff0ef          	jal	80002b46 <argaddr>
  return kwait(p);
    80002c4e:	fe843503          	ld	a0,-24(s0)
    80002c52:	f42ff0ef          	jal	80002394 <kwait>
}
    80002c56:	60e2                	ld	ra,24(sp)
    80002c58:	6442                	ld	s0,16(sp)
    80002c5a:	6105                	addi	sp,sp,32
    80002c5c:	8082                	ret

0000000080002c5e <sys_sbrk>:

uint64
sys_sbrk(void)
{
    80002c5e:	7179                	addi	sp,sp,-48
    80002c60:	f406                	sd	ra,40(sp)
    80002c62:	f022                	sd	s0,32(sp)
    80002c64:	ec26                	sd	s1,24(sp)
    80002c66:	1800                	addi	s0,sp,48
  uint64 addr;
  int t;
  int n;

  argint(0, &n);
    80002c68:	fd840593          	addi	a1,s0,-40
    80002c6c:	4501                	li	a0,0
    80002c6e:	ebdff0ef          	jal	80002b2a <argint>
  argint(1, &t);
    80002c72:	fdc40593          	addi	a1,s0,-36
    80002c76:	4505                	li	a0,1
    80002c78:	eb3ff0ef          	jal	80002b2a <argint>
  addr = myproc()->sz;
    80002c7c:	eb5fe0ef          	jal	80001b30 <myproc>
    80002c80:	6524                	ld	s1,72(a0)

  if(t == SBRK_EAGER || n < 0) {
    80002c82:	fdc42703          	lw	a4,-36(s0)
    80002c86:	4785                	li	a5,1
    80002c88:	02f70163          	beq	a4,a5,80002caa <sys_sbrk+0x4c>
    80002c8c:	fd842783          	lw	a5,-40(s0)
    80002c90:	0007cd63          	bltz	a5,80002caa <sys_sbrk+0x4c>
    }
  } else {
    // Lazily allocate memory for this process: increase its memory
    // size but don't allocate memory. If the processes uses the
    // memory, vmfault() will allocate it.
    if(addr + n < addr)
    80002c94:	97a6                	add	a5,a5,s1
    80002c96:	0297e863          	bltu	a5,s1,80002cc6 <sys_sbrk+0x68>
      return -1;
    myproc()->sz += n;
    80002c9a:	e97fe0ef          	jal	80001b30 <myproc>
    80002c9e:	fd842703          	lw	a4,-40(s0)
    80002ca2:	653c                	ld	a5,72(a0)
    80002ca4:	97ba                	add	a5,a5,a4
    80002ca6:	e53c                	sd	a5,72(a0)
    80002ca8:	a039                	j	80002cb6 <sys_sbrk+0x58>
    if(growproc(n) < 0) {
    80002caa:	fd842503          	lw	a0,-40(s0)
    80002cae:	988ff0ef          	jal	80001e36 <growproc>
    80002cb2:	00054863          	bltz	a0,80002cc2 <sys_sbrk+0x64>
  }
  return addr;
}
    80002cb6:	8526                	mv	a0,s1
    80002cb8:	70a2                	ld	ra,40(sp)
    80002cba:	7402                	ld	s0,32(sp)
    80002cbc:	64e2                	ld	s1,24(sp)
    80002cbe:	6145                	addi	sp,sp,48
    80002cc0:	8082                	ret
      return -1;
    80002cc2:	54fd                	li	s1,-1
    80002cc4:	bfcd                	j	80002cb6 <sys_sbrk+0x58>
      return -1;
    80002cc6:	54fd                	li	s1,-1
    80002cc8:	b7fd                	j	80002cb6 <sys_sbrk+0x58>

0000000080002cca <sys_pause>:

uint64
sys_pause(void)
{
    80002cca:	7139                	addi	sp,sp,-64
    80002ccc:	fc06                	sd	ra,56(sp)
    80002cce:	f822                	sd	s0,48(sp)
    80002cd0:	0080                	addi	s0,sp,64
  int n;
  uint ticks0;

  argint(0, &n);
    80002cd2:	fcc40593          	addi	a1,s0,-52
    80002cd6:	4501                	li	a0,0
    80002cd8:	e53ff0ef          	jal	80002b2a <argint>
  if(n < 0)
    80002cdc:	fcc42783          	lw	a5,-52(s0)
    80002ce0:	0607c863          	bltz	a5,80002d50 <sys_pause+0x86>
    n = 0;
  acquire(&tickslock);
    80002ce4:	00234517          	auipc	a0,0x234
    80002ce8:	be450513          	addi	a0,a0,-1052 # 802368c8 <tickslock>
    80002cec:	930fe0ef          	jal	80000e1c <acquire>
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    80002cf0:	fcc42783          	lw	a5,-52(s0)
    80002cf4:	c3b9                	beqz	a5,80002d3a <sys_pause+0x70>
    80002cf6:	f426                	sd	s1,40(sp)
    80002cf8:	f04a                	sd	s2,32(sp)
    80002cfa:	ec4e                	sd	s3,24(sp)
  ticks0 = ticks;
    80002cfc:	00006997          	auipc	s3,0x6
    80002d00:	c9c9a983          	lw	s3,-868(s3) # 80008998 <ticks>
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
    80002d04:	00234917          	auipc	s2,0x234
    80002d08:	bc490913          	addi	s2,s2,-1084 # 802368c8 <tickslock>
    80002d0c:	00006497          	auipc	s1,0x6
    80002d10:	c8c48493          	addi	s1,s1,-884 # 80008998 <ticks>
    if(killed(myproc())){
    80002d14:	e1dfe0ef          	jal	80001b30 <myproc>
    80002d18:	e52ff0ef          	jal	8000236a <killed>
    80002d1c:	ed0d                	bnez	a0,80002d56 <sys_pause+0x8c>
    sleep(&ticks, &tickslock);
    80002d1e:	85ca                	mv	a1,s2
    80002d20:	8526                	mv	a0,s1
    80002d22:	c0cff0ef          	jal	8000212e <sleep>
  while(ticks - ticks0 < n){
    80002d26:	409c                	lw	a5,0(s1)
    80002d28:	413787bb          	subw	a5,a5,s3
    80002d2c:	fcc42703          	lw	a4,-52(s0)
    80002d30:	fee7e2e3          	bltu	a5,a4,80002d14 <sys_pause+0x4a>
    80002d34:	74a2                	ld	s1,40(sp)
    80002d36:	7902                	ld	s2,32(sp)
    80002d38:	69e2                	ld	s3,24(sp)
  }
  release(&tickslock);
    80002d3a:	00234517          	auipc	a0,0x234
    80002d3e:	b8e50513          	addi	a0,a0,-1138 # 802368c8 <tickslock>
    80002d42:	96efe0ef          	jal	80000eb0 <release>
  return 0;
    80002d46:	4501                	li	a0,0
}
    80002d48:	70e2                	ld	ra,56(sp)
    80002d4a:	7442                	ld	s0,48(sp)
    80002d4c:	6121                	addi	sp,sp,64
    80002d4e:	8082                	ret
    n = 0;
    80002d50:	fc042623          	sw	zero,-52(s0)
    80002d54:	bf41                	j	80002ce4 <sys_pause+0x1a>
      release(&tickslock);
    80002d56:	00234517          	auipc	a0,0x234
    80002d5a:	b7250513          	addi	a0,a0,-1166 # 802368c8 <tickslock>
    80002d5e:	952fe0ef          	jal	80000eb0 <release>
      return -1;
    80002d62:	557d                	li	a0,-1
    80002d64:	74a2                	ld	s1,40(sp)
    80002d66:	7902                	ld	s2,32(sp)
    80002d68:	69e2                	ld	s3,24(sp)
    80002d6a:	bff9                	j	80002d48 <sys_pause+0x7e>

0000000080002d6c <sys_kill>:

uint64
sys_kill(void)
{
    80002d6c:	1101                	addi	sp,sp,-32
    80002d6e:	ec06                	sd	ra,24(sp)
    80002d70:	e822                	sd	s0,16(sp)
    80002d72:	1000                	addi	s0,sp,32
  int pid;

  argint(0, &pid);
    80002d74:	fec40593          	addi	a1,s0,-20
    80002d78:	4501                	li	a0,0
    80002d7a:	db1ff0ef          	jal	80002b2a <argint>
  return kkill(pid);
    80002d7e:	fec42503          	lw	a0,-20(s0)
    80002d82:	d5eff0ef          	jal	800022e0 <kkill>
}
    80002d86:	60e2                	ld	ra,24(sp)
    80002d88:	6442                	ld	s0,16(sp)
    80002d8a:	6105                	addi	sp,sp,32
    80002d8c:	8082                	ret

0000000080002d8e <sys_uptime>:

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
    80002d8e:	1101                	addi	sp,sp,-32
    80002d90:	ec06                	sd	ra,24(sp)
    80002d92:	e822                	sd	s0,16(sp)
    80002d94:	e426                	sd	s1,8(sp)
    80002d96:	1000                	addi	s0,sp,32
  uint xticks;

  acquire(&tickslock);
    80002d98:	00234517          	auipc	a0,0x234
    80002d9c:	b3050513          	addi	a0,a0,-1232 # 802368c8 <tickslock>
    80002da0:	87cfe0ef          	jal	80000e1c <acquire>
  xticks = ticks;
    80002da4:	00006797          	auipc	a5,0x6
    80002da8:	bf47a783          	lw	a5,-1036(a5) # 80008998 <ticks>
    80002dac:	84be                	mv	s1,a5
  release(&tickslock);
    80002dae:	00234517          	auipc	a0,0x234
    80002db2:	b1a50513          	addi	a0,a0,-1254 # 802368c8 <tickslock>
    80002db6:	8fafe0ef          	jal	80000eb0 <release>
  return xticks;
}
    80002dba:	02049513          	slli	a0,s1,0x20
    80002dbe:	9101                	srli	a0,a0,0x20
    80002dc0:	60e2                	ld	ra,24(sp)
    80002dc2:	6442                	ld	s0,16(sp)
    80002dc4:	64a2                	ld	s1,8(sp)
    80002dc6:	6105                	addi	sp,sp,32
    80002dc8:	8082                	ret

0000000080002dca <sys_shm_create>:

uint64 
sys_shm_create(void){
    80002dca:	1101                	addi	sp,sp,-32
    80002dcc:	ec06                	sd	ra,24(sp)
    80002dce:	e822                	sd	s0,16(sp)
    80002dd0:	1000                	addi	s0,sp,32
  int n;
  argint(0,&n);
    80002dd2:	fec40593          	addi	a1,s0,-20
    80002dd6:	4501                	li	a0,0
    80002dd8:	d53ff0ef          	jal	80002b2a <argint>
  return shm_create(n);
    80002ddc:	fec42503          	lw	a0,-20(s0)
    80002de0:	4af020ef          	jal	80005a8e <shm_create>
}
    80002de4:	60e2                	ld	ra,24(sp)
    80002de6:	6442                	ld	s0,16(sp)
    80002de8:	6105                	addi	sp,sp,32
    80002dea:	8082                	ret

0000000080002dec <sys_shm_get>:
uint64 
sys_shm_get(void){
    80002dec:	1101                	addi	sp,sp,-32
    80002dee:	ec06                	sd	ra,24(sp)
    80002df0:	e822                	sd	s0,16(sp)
    80002df2:	1000                	addi	s0,sp,32
  int n;
  argint(0,&n);
    80002df4:	fec40593          	addi	a1,s0,-20
    80002df8:	4501                	li	a0,0
    80002dfa:	d31ff0ef          	jal	80002b2a <argint>
  return (uint64)shm_get(n);
    80002dfe:	fec42503          	lw	a0,-20(s0)
    80002e02:	4e3020ef          	jal	80005ae4 <shm_get>
}
    80002e06:	60e2                	ld	ra,24(sp)
    80002e08:	6442                	ld	s0,16(sp)
    80002e0a:	6105                	addi	sp,sp,32
    80002e0c:	8082                	ret

0000000080002e0e <sys_shm_close>:
uint64 
sys_shm_close(void){
    80002e0e:	1101                	addi	sp,sp,-32
    80002e10:	ec06                	sd	ra,24(sp)
    80002e12:	e822                	sd	s0,16(sp)
    80002e14:	1000                	addi	s0,sp,32
  int n;
  argint(0,&n);
    80002e16:	fec40593          	addi	a1,s0,-20
    80002e1a:	4501                	li	a0,0
    80002e1c:	d0fff0ef          	jal	80002b2a <argint>
  return shm_close(n);
    80002e20:	fec42503          	lw	a0,-20(s0)
    80002e24:	575020ef          	jal	80005b98 <shm_close>
}
    80002e28:	60e2                	ld	ra,24(sp)
    80002e2a:	6442                	ld	s0,16(sp)
    80002e2c:	6105                	addi	sp,sp,32
    80002e2e:	8082                	ret

0000000080002e30 <sys_mbox_create>:
uint64
sys_mbox_create(void){
    80002e30:	1101                	addi	sp,sp,-32
    80002e32:	ec06                	sd	ra,24(sp)
    80002e34:	e822                	sd	s0,16(sp)
    80002e36:	1000                	addi	s0,sp,32
  int n;
  argint(0,&n);
    80002e38:	fec40593          	addi	a1,s0,-20
    80002e3c:	4501                	li	a0,0
    80002e3e:	cedff0ef          	jal	80002b2a <argint>
  return mbox_create(n);
    80002e42:	fec42503          	lw	a0,-20(s0)
    80002e46:	73b020ef          	jal	80005d80 <mbox_create>
}
    80002e4a:	60e2                	ld	ra,24(sp)
    80002e4c:	6442                	ld	s0,16(sp)
    80002e4e:	6105                	addi	sp,sp,32
    80002e50:	8082                	ret

0000000080002e52 <sys_mbox_send>:
uint64
sys_mbox_send(void){
    80002e52:	1101                	addi	sp,sp,-32
    80002e54:	ec06                	sd	ra,24(sp)
    80002e56:	e822                	sd	s0,16(sp)
    80002e58:	1000                	addi	s0,sp,32
  int n,m;
  argint(0,&n);
    80002e5a:	fec40593          	addi	a1,s0,-20
    80002e5e:	4501                	li	a0,0
    80002e60:	ccbff0ef          	jal	80002b2a <argint>
  argint(1,&m);
    80002e64:	fe840593          	addi	a1,s0,-24
    80002e68:	4505                	li	a0,1
    80002e6a:	cc1ff0ef          	jal	80002b2a <argint>
  return mbox_send(n,m);
    80002e6e:	fe842583          	lw	a1,-24(s0)
    80002e72:	fec42503          	lw	a0,-20(s0)
    80002e76:	745020ef          	jal	80005dba <mbox_send>
}
    80002e7a:	60e2                	ld	ra,24(sp)
    80002e7c:	6442                	ld	s0,16(sp)
    80002e7e:	6105                	addi	sp,sp,32
    80002e80:	8082                	ret

0000000080002e82 <sys_mbox_recv>:
uint64
sys_mbox_recv(void){
    80002e82:	7179                	addi	sp,sp,-48
    80002e84:	f406                	sd	ra,40(sp)
    80002e86:	f022                	sd	s0,32(sp)
    80002e88:	1800                	addi	s0,sp,48
  int n;
  uint64 m;
  argint(0,&n);
    80002e8a:	fec40593          	addi	a1,s0,-20
    80002e8e:	4501                	li	a0,0
    80002e90:	c9bff0ef          	jal	80002b2a <argint>
  argaddr(1,&m);
    80002e94:	fe040593          	addi	a1,s0,-32
    80002e98:	4505                	li	a0,1
    80002e9a:	cadff0ef          	jal	80002b46 <argaddr>
  int msg;
  if(mbox_recv(n,&msg)<0)return -1;
    80002e9e:	fdc40593          	addi	a1,s0,-36
    80002ea2:	fec42503          	lw	a0,-20(s0)
    80002ea6:	797020ef          	jal	80005e3c <mbox_recv>
    80002eaa:	87aa                	mv	a5,a0
    80002eac:	557d                	li	a0,-1
    80002eae:	0007cd63          	bltz	a5,80002ec8 <sys_mbox_recv+0x46>
  if(copyout(myproc()->pagetable,m, (char*)&msg, sizeof(msg)) < 0)  return -1;
    80002eb2:	c7ffe0ef          	jal	80001b30 <myproc>
    80002eb6:	4691                	li	a3,4
    80002eb8:	fdc40613          	addi	a2,s0,-36
    80002ebc:	fe043583          	ld	a1,-32(s0)
    80002ec0:	6928                	ld	a0,80(a0)
    80002ec2:	995fe0ef          	jal	80001856 <copyout>
    80002ec6:	957d                	srai	a0,a0,0x3f
  return 0;
}
    80002ec8:	70a2                	ld	ra,40(sp)
    80002eca:	7402                	ld	s0,32(sp)
    80002ecc:	6145                	addi	sp,sp,48
    80002ece:	8082                	ret

0000000080002ed0 <sys_va2pa>:
//

uint64
sys_va2pa(void)
{
    80002ed0:	1101                	addi	sp,sp,-32
    80002ed2:	ec06                	sd	ra,24(sp)
    80002ed4:	e822                	sd	s0,16(sp)
    80002ed6:	1000                	addi	s0,sp,32
  uint64 va;
  argaddr(0, &va);
    80002ed8:	fe840593          	addi	a1,s0,-24
    80002edc:	4501                	li	a0,0
    80002ede:	c69ff0ef          	jal	80002b46 <argaddr>
  return walkaddr(myproc()->pagetable, va);
    80002ee2:	c4ffe0ef          	jal	80001b30 <myproc>
    80002ee6:	fe843583          	ld	a1,-24(s0)
    80002eea:	6928                	ld	a0,80(a0)
    80002eec:	b36fe0ef          	jal	80001222 <walkaddr>
}
    80002ef0:	60e2                	ld	ra,24(sp)
    80002ef2:	6442                	ld	s0,16(sp)
    80002ef4:	6105                	addi	sp,sp,32
    80002ef6:	8082                	ret

0000000080002ef8 <binit>:
  struct buf head;
} bcache;

void
binit(void)
{
    80002ef8:	7179                	addi	sp,sp,-48
    80002efa:	f406                	sd	ra,40(sp)
    80002efc:	f022                	sd	s0,32(sp)
    80002efe:	ec26                	sd	s1,24(sp)
    80002f00:	e84a                	sd	s2,16(sp)
    80002f02:	e44e                	sd	s3,8(sp)
    80002f04:	e052                	sd	s4,0(sp)
    80002f06:	1800                	addi	s0,sp,48
  struct buf *b;

  initlock(&bcache.lock, "bcache");
    80002f08:	00005597          	auipc	a1,0x5
    80002f0c:	51858593          	addi	a1,a1,1304 # 80008420 <etext+0x420>
    80002f10:	00234517          	auipc	a0,0x234
    80002f14:	9d050513          	addi	a0,a0,-1584 # 802368e0 <bcache>
    80002f18:	e7bfd0ef          	jal	80000d92 <initlock>

  // Create linked list of buffers
  bcache.head.prev = &bcache.head;
    80002f1c:	0023c797          	auipc	a5,0x23c
    80002f20:	9c478793          	addi	a5,a5,-1596 # 8023e8e0 <bcache+0x8000>
    80002f24:	0023c717          	auipc	a4,0x23c
    80002f28:	c2470713          	addi	a4,a4,-988 # 8023eb48 <bcache+0x8268>
    80002f2c:	2ae7b823          	sd	a4,688(a5)
  bcache.head.next = &bcache.head;
    80002f30:	2ae7bc23          	sd	a4,696(a5)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002f34:	00234497          	auipc	s1,0x234
    80002f38:	9c448493          	addi	s1,s1,-1596 # 802368f8 <bcache+0x18>
    b->next = bcache.head.next;
    80002f3c:	893e                	mv	s2,a5
    b->prev = &bcache.head;
    80002f3e:	89ba                	mv	s3,a4
    initsleeplock(&b->lock, "buffer");
    80002f40:	00005a17          	auipc	s4,0x5
    80002f44:	4e8a0a13          	addi	s4,s4,1256 # 80008428 <etext+0x428>
    b->next = bcache.head.next;
    80002f48:	2b893783          	ld	a5,696(s2)
    80002f4c:	e8bc                	sd	a5,80(s1)
    b->prev = &bcache.head;
    80002f4e:	0534b423          	sd	s3,72(s1)
    initsleeplock(&b->lock, "buffer");
    80002f52:	85d2                	mv	a1,s4
    80002f54:	01048513          	addi	a0,s1,16
    80002f58:	47a010ef          	jal	800043d2 <initsleeplock>
    bcache.head.next->prev = b;
    80002f5c:	2b893783          	ld	a5,696(s2)
    80002f60:	e7a4                	sd	s1,72(a5)
    bcache.head.next = b;
    80002f62:	2a993c23          	sd	s1,696(s2)
  for(b = bcache.buf; b < bcache.buf+NBUF; b++){
    80002f66:	45848493          	addi	s1,s1,1112
    80002f6a:	fd349fe3          	bne	s1,s3,80002f48 <binit+0x50>
  }
}
    80002f6e:	70a2                	ld	ra,40(sp)
    80002f70:	7402                	ld	s0,32(sp)
    80002f72:	64e2                	ld	s1,24(sp)
    80002f74:	6942                	ld	s2,16(sp)
    80002f76:	69a2                	ld	s3,8(sp)
    80002f78:	6a02                	ld	s4,0(sp)
    80002f7a:	6145                	addi	sp,sp,48
    80002f7c:	8082                	ret

0000000080002f7e <bread>:
}

// Return a locked buf with the contents of the indicated block.
struct buf*
bread(uint dev, uint blockno)
{
    80002f7e:	7179                	addi	sp,sp,-48
    80002f80:	f406                	sd	ra,40(sp)
    80002f82:	f022                	sd	s0,32(sp)
    80002f84:	ec26                	sd	s1,24(sp)
    80002f86:	e84a                	sd	s2,16(sp)
    80002f88:	e44e                	sd	s3,8(sp)
    80002f8a:	1800                	addi	s0,sp,48
    80002f8c:	892a                	mv	s2,a0
    80002f8e:	89ae                	mv	s3,a1
  acquire(&bcache.lock);
    80002f90:	00234517          	auipc	a0,0x234
    80002f94:	95050513          	addi	a0,a0,-1712 # 802368e0 <bcache>
    80002f98:	e85fd0ef          	jal	80000e1c <acquire>
  for(b = bcache.head.next; b != &bcache.head; b = b->next){
    80002f9c:	0023c497          	auipc	s1,0x23c
    80002fa0:	bfc4b483          	ld	s1,-1028(s1) # 8023eb98 <bcache+0x82b8>
    80002fa4:	0023c797          	auipc	a5,0x23c
    80002fa8:	ba478793          	addi	a5,a5,-1116 # 8023eb48 <bcache+0x8268>
    80002fac:	02f48b63          	beq	s1,a5,80002fe2 <bread+0x64>
    80002fb0:	873e                	mv	a4,a5
    80002fb2:	a021                	j	80002fba <bread+0x3c>
    80002fb4:	68a4                	ld	s1,80(s1)
    80002fb6:	02e48663          	beq	s1,a4,80002fe2 <bread+0x64>
    if(b->dev == dev && b->blockno == blockno){
    80002fba:	449c                	lw	a5,8(s1)
    80002fbc:	ff279ce3          	bne	a5,s2,80002fb4 <bread+0x36>
    80002fc0:	44dc                	lw	a5,12(s1)
    80002fc2:	ff3799e3          	bne	a5,s3,80002fb4 <bread+0x36>
      b->refcnt++;
    80002fc6:	40bc                	lw	a5,64(s1)
    80002fc8:	2785                	addiw	a5,a5,1
    80002fca:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    80002fcc:	00234517          	auipc	a0,0x234
    80002fd0:	91450513          	addi	a0,a0,-1772 # 802368e0 <bcache>
    80002fd4:	eddfd0ef          	jal	80000eb0 <release>
      acquiresleep(&b->lock);
    80002fd8:	01048513          	addi	a0,s1,16
    80002fdc:	42c010ef          	jal	80004408 <acquiresleep>
      return b;
    80002fe0:	a889                	j	80003032 <bread+0xb4>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002fe2:	0023c497          	auipc	s1,0x23c
    80002fe6:	bae4b483          	ld	s1,-1106(s1) # 8023eb90 <bcache+0x82b0>
    80002fea:	0023c797          	auipc	a5,0x23c
    80002fee:	b5e78793          	addi	a5,a5,-1186 # 8023eb48 <bcache+0x8268>
    80002ff2:	00f48863          	beq	s1,a5,80003002 <bread+0x84>
    80002ff6:	873e                	mv	a4,a5
    if(b->refcnt == 0) {
    80002ff8:	40bc                	lw	a5,64(s1)
    80002ffa:	cb91                	beqz	a5,8000300e <bread+0x90>
  for(b = bcache.head.prev; b != &bcache.head; b = b->prev){
    80002ffc:	64a4                	ld	s1,72(s1)
    80002ffe:	fee49de3          	bne	s1,a4,80002ff8 <bread+0x7a>
  panic("bget: no buffers");
    80003002:	00005517          	auipc	a0,0x5
    80003006:	42e50513          	addi	a0,a0,1070 # 80008430 <etext+0x430>
    8000300a:	81bfd0ef          	jal	80000824 <panic>
      b->dev = dev;
    8000300e:	0124a423          	sw	s2,8(s1)
      b->blockno = blockno;
    80003012:	0134a623          	sw	s3,12(s1)
      b->valid = 0;
    80003016:	0004a023          	sw	zero,0(s1)
      b->refcnt = 1;
    8000301a:	4785                	li	a5,1
    8000301c:	c0bc                	sw	a5,64(s1)
      release(&bcache.lock);
    8000301e:	00234517          	auipc	a0,0x234
    80003022:	8c250513          	addi	a0,a0,-1854 # 802368e0 <bcache>
    80003026:	e8bfd0ef          	jal	80000eb0 <release>
      acquiresleep(&b->lock);
    8000302a:	01048513          	addi	a0,s1,16
    8000302e:	3da010ef          	jal	80004408 <acquiresleep>
  struct buf *b;

  b = bget(dev, blockno);
  if(!b->valid) {
    80003032:	409c                	lw	a5,0(s1)
    80003034:	cb89                	beqz	a5,80003046 <bread+0xc8>
    virtio_disk_rw(b, 0);
    b->valid = 1;
  }
  return b;
}
    80003036:	8526                	mv	a0,s1
    80003038:	70a2                	ld	ra,40(sp)
    8000303a:	7402                	ld	s0,32(sp)
    8000303c:	64e2                	ld	s1,24(sp)
    8000303e:	6942                	ld	s2,16(sp)
    80003040:	69a2                	ld	s3,8(sp)
    80003042:	6145                	addi	sp,sp,48
    80003044:	8082                	ret
    virtio_disk_rw(b, 0);
    80003046:	4581                	li	a1,0
    80003048:	8526                	mv	a0,s1
    8000304a:	0b4030ef          	jal	800060fe <virtio_disk_rw>
    b->valid = 1;
    8000304e:	4785                	li	a5,1
    80003050:	c09c                	sw	a5,0(s1)
  return b;
    80003052:	b7d5                	j	80003036 <bread+0xb8>

0000000080003054 <bwrite>:

// Write b's contents to disk.  Must be locked.
void
bwrite(struct buf *b)
{
    80003054:	1101                	addi	sp,sp,-32
    80003056:	ec06                	sd	ra,24(sp)
    80003058:	e822                	sd	s0,16(sp)
    8000305a:	e426                	sd	s1,8(sp)
    8000305c:	1000                	addi	s0,sp,32
    8000305e:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003060:	0541                	addi	a0,a0,16
    80003062:	424010ef          	jal	80004486 <holdingsleep>
    80003066:	c911                	beqz	a0,8000307a <bwrite+0x26>
    panic("bwrite");
  virtio_disk_rw(b, 1);
    80003068:	4585                	li	a1,1
    8000306a:	8526                	mv	a0,s1
    8000306c:	092030ef          	jal	800060fe <virtio_disk_rw>
}
    80003070:	60e2                	ld	ra,24(sp)
    80003072:	6442                	ld	s0,16(sp)
    80003074:	64a2                	ld	s1,8(sp)
    80003076:	6105                	addi	sp,sp,32
    80003078:	8082                	ret
    panic("bwrite");
    8000307a:	00005517          	auipc	a0,0x5
    8000307e:	3ce50513          	addi	a0,a0,974 # 80008448 <etext+0x448>
    80003082:	fa2fd0ef          	jal	80000824 <panic>

0000000080003086 <brelse>:

// Release a locked buffer.
// Move to the head of the most-recently-used list.
void
brelse(struct buf *b)
{
    80003086:	1101                	addi	sp,sp,-32
    80003088:	ec06                	sd	ra,24(sp)
    8000308a:	e822                	sd	s0,16(sp)
    8000308c:	e426                	sd	s1,8(sp)
    8000308e:	e04a                	sd	s2,0(sp)
    80003090:	1000                	addi	s0,sp,32
    80003092:	84aa                	mv	s1,a0
  if(!holdingsleep(&b->lock))
    80003094:	01050913          	addi	s2,a0,16
    80003098:	854a                	mv	a0,s2
    8000309a:	3ec010ef          	jal	80004486 <holdingsleep>
    8000309e:	c125                	beqz	a0,800030fe <brelse+0x78>
    panic("brelse");

  releasesleep(&b->lock);
    800030a0:	854a                	mv	a0,s2
    800030a2:	3ac010ef          	jal	8000444e <releasesleep>

  acquire(&bcache.lock);
    800030a6:	00234517          	auipc	a0,0x234
    800030aa:	83a50513          	addi	a0,a0,-1990 # 802368e0 <bcache>
    800030ae:	d6ffd0ef          	jal	80000e1c <acquire>
  b->refcnt--;
    800030b2:	40bc                	lw	a5,64(s1)
    800030b4:	37fd                	addiw	a5,a5,-1
    800030b6:	c0bc                	sw	a5,64(s1)
  if (b->refcnt == 0) {
    800030b8:	e79d                	bnez	a5,800030e6 <brelse+0x60>
    // no one is waiting for it.
    b->next->prev = b->prev;
    800030ba:	68b8                	ld	a4,80(s1)
    800030bc:	64bc                	ld	a5,72(s1)
    800030be:	e73c                	sd	a5,72(a4)
    b->prev->next = b->next;
    800030c0:	68b8                	ld	a4,80(s1)
    800030c2:	ebb8                	sd	a4,80(a5)
    b->next = bcache.head.next;
    800030c4:	0023c797          	auipc	a5,0x23c
    800030c8:	81c78793          	addi	a5,a5,-2020 # 8023e8e0 <bcache+0x8000>
    800030cc:	2b87b703          	ld	a4,696(a5)
    800030d0:	e8b8                	sd	a4,80(s1)
    b->prev = &bcache.head;
    800030d2:	0023c717          	auipc	a4,0x23c
    800030d6:	a7670713          	addi	a4,a4,-1418 # 8023eb48 <bcache+0x8268>
    800030da:	e4b8                	sd	a4,72(s1)
    bcache.head.next->prev = b;
    800030dc:	2b87b703          	ld	a4,696(a5)
    800030e0:	e724                	sd	s1,72(a4)
    bcache.head.next = b;
    800030e2:	2a97bc23          	sd	s1,696(a5)
  }
  
  release(&bcache.lock);
    800030e6:	00233517          	auipc	a0,0x233
    800030ea:	7fa50513          	addi	a0,a0,2042 # 802368e0 <bcache>
    800030ee:	dc3fd0ef          	jal	80000eb0 <release>
}
    800030f2:	60e2                	ld	ra,24(sp)
    800030f4:	6442                	ld	s0,16(sp)
    800030f6:	64a2                	ld	s1,8(sp)
    800030f8:	6902                	ld	s2,0(sp)
    800030fa:	6105                	addi	sp,sp,32
    800030fc:	8082                	ret
    panic("brelse");
    800030fe:	00005517          	auipc	a0,0x5
    80003102:	35250513          	addi	a0,a0,850 # 80008450 <etext+0x450>
    80003106:	f1efd0ef          	jal	80000824 <panic>

000000008000310a <bpin>:

void
bpin(struct buf *b) {
    8000310a:	1101                	addi	sp,sp,-32
    8000310c:	ec06                	sd	ra,24(sp)
    8000310e:	e822                	sd	s0,16(sp)
    80003110:	e426                	sd	s1,8(sp)
    80003112:	1000                	addi	s0,sp,32
    80003114:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    80003116:	00233517          	auipc	a0,0x233
    8000311a:	7ca50513          	addi	a0,a0,1994 # 802368e0 <bcache>
    8000311e:	cfffd0ef          	jal	80000e1c <acquire>
  b->refcnt++;
    80003122:	40bc                	lw	a5,64(s1)
    80003124:	2785                	addiw	a5,a5,1
    80003126:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    80003128:	00233517          	auipc	a0,0x233
    8000312c:	7b850513          	addi	a0,a0,1976 # 802368e0 <bcache>
    80003130:	d81fd0ef          	jal	80000eb0 <release>
}
    80003134:	60e2                	ld	ra,24(sp)
    80003136:	6442                	ld	s0,16(sp)
    80003138:	64a2                	ld	s1,8(sp)
    8000313a:	6105                	addi	sp,sp,32
    8000313c:	8082                	ret

000000008000313e <bunpin>:

void
bunpin(struct buf *b) {
    8000313e:	1101                	addi	sp,sp,-32
    80003140:	ec06                	sd	ra,24(sp)
    80003142:	e822                	sd	s0,16(sp)
    80003144:	e426                	sd	s1,8(sp)
    80003146:	1000                	addi	s0,sp,32
    80003148:	84aa                	mv	s1,a0
  acquire(&bcache.lock);
    8000314a:	00233517          	auipc	a0,0x233
    8000314e:	79650513          	addi	a0,a0,1942 # 802368e0 <bcache>
    80003152:	ccbfd0ef          	jal	80000e1c <acquire>
  b->refcnt--;
    80003156:	40bc                	lw	a5,64(s1)
    80003158:	37fd                	addiw	a5,a5,-1
    8000315a:	c0bc                	sw	a5,64(s1)
  release(&bcache.lock);
    8000315c:	00233517          	auipc	a0,0x233
    80003160:	78450513          	addi	a0,a0,1924 # 802368e0 <bcache>
    80003164:	d4dfd0ef          	jal	80000eb0 <release>
}
    80003168:	60e2                	ld	ra,24(sp)
    8000316a:	6442                	ld	s0,16(sp)
    8000316c:	64a2                	ld	s1,8(sp)
    8000316e:	6105                	addi	sp,sp,32
    80003170:	8082                	ret

0000000080003172 <bfree>:
}

// Free a disk block.
static void
bfree(int dev, uint b)
{
    80003172:	1101                	addi	sp,sp,-32
    80003174:	ec06                	sd	ra,24(sp)
    80003176:	e822                	sd	s0,16(sp)
    80003178:	e426                	sd	s1,8(sp)
    8000317a:	e04a                	sd	s2,0(sp)
    8000317c:	1000                	addi	s0,sp,32
    8000317e:	84ae                	mv	s1,a1
  struct buf *bp;
  int bi, m;

  bp = bread(dev, BBLOCK(b, sb));
    80003180:	00d5d79b          	srliw	a5,a1,0xd
    80003184:	0023c597          	auipc	a1,0x23c
    80003188:	e385a583          	lw	a1,-456(a1) # 8023efbc <sb+0x1c>
    8000318c:	9dbd                	addw	a1,a1,a5
    8000318e:	df1ff0ef          	jal	80002f7e <bread>
  bi = b % BPB;
  m = 1 << (bi % 8);
    80003192:	0074f713          	andi	a4,s1,7
    80003196:	4785                	li	a5,1
    80003198:	00e797bb          	sllw	a5,a5,a4
  bi = b % BPB;
    8000319c:	14ce                	slli	s1,s1,0x33
  if((bp->data[bi/8] & m) == 0)
    8000319e:	90d9                	srli	s1,s1,0x36
    800031a0:	00950733          	add	a4,a0,s1
    800031a4:	05874703          	lbu	a4,88(a4)
    800031a8:	00e7f6b3          	and	a3,a5,a4
    800031ac:	c29d                	beqz	a3,800031d2 <bfree+0x60>
    800031ae:	892a                	mv	s2,a0
    panic("freeing free block");
  bp->data[bi/8] &= ~m;
    800031b0:	94aa                	add	s1,s1,a0
    800031b2:	fff7c793          	not	a5,a5
    800031b6:	8f7d                	and	a4,a4,a5
    800031b8:	04e48c23          	sb	a4,88(s1)
  log_write(bp);
    800031bc:	152010ef          	jal	8000430e <log_write>
  brelse(bp);
    800031c0:	854a                	mv	a0,s2
    800031c2:	ec5ff0ef          	jal	80003086 <brelse>
}
    800031c6:	60e2                	ld	ra,24(sp)
    800031c8:	6442                	ld	s0,16(sp)
    800031ca:	64a2                	ld	s1,8(sp)
    800031cc:	6902                	ld	s2,0(sp)
    800031ce:	6105                	addi	sp,sp,32
    800031d0:	8082                	ret
    panic("freeing free block");
    800031d2:	00005517          	auipc	a0,0x5
    800031d6:	28650513          	addi	a0,a0,646 # 80008458 <etext+0x458>
    800031da:	e4afd0ef          	jal	80000824 <panic>

00000000800031de <balloc>:
{
    800031de:	715d                	addi	sp,sp,-80
    800031e0:	e486                	sd	ra,72(sp)
    800031e2:	e0a2                	sd	s0,64(sp)
    800031e4:	fc26                	sd	s1,56(sp)
    800031e6:	0880                	addi	s0,sp,80
  for(b = 0; b < sb.size; b += BPB){
    800031e8:	0023c797          	auipc	a5,0x23c
    800031ec:	dbc7a783          	lw	a5,-580(a5) # 8023efa4 <sb+0x4>
    800031f0:	0e078263          	beqz	a5,800032d4 <balloc+0xf6>
    800031f4:	f84a                	sd	s2,48(sp)
    800031f6:	f44e                	sd	s3,40(sp)
    800031f8:	f052                	sd	s4,32(sp)
    800031fa:	ec56                	sd	s5,24(sp)
    800031fc:	e85a                	sd	s6,16(sp)
    800031fe:	e45e                	sd	s7,8(sp)
    80003200:	e062                	sd	s8,0(sp)
    80003202:	8baa                	mv	s7,a0
    80003204:	4a81                	li	s5,0
    bp = bread(dev, BBLOCK(b, sb));
    80003206:	0023cb17          	auipc	s6,0x23c
    8000320a:	d9ab0b13          	addi	s6,s6,-614 # 8023efa0 <sb>
      m = 1 << (bi % 8);
    8000320e:	4985                	li	s3,1
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    80003210:	6a09                	lui	s4,0x2
  for(b = 0; b < sb.size; b += BPB){
    80003212:	6c09                	lui	s8,0x2
    80003214:	a09d                	j	8000327a <balloc+0x9c>
        bp->data[bi/8] |= m;  // Mark block in use.
    80003216:	97ca                	add	a5,a5,s2
    80003218:	8e55                	or	a2,a2,a3
    8000321a:	04c78c23          	sb	a2,88(a5)
        log_write(bp);
    8000321e:	854a                	mv	a0,s2
    80003220:	0ee010ef          	jal	8000430e <log_write>
        brelse(bp);
    80003224:	854a                	mv	a0,s2
    80003226:	e61ff0ef          	jal	80003086 <brelse>
  bp = bread(dev, bno);
    8000322a:	85a6                	mv	a1,s1
    8000322c:	855e                	mv	a0,s7
    8000322e:	d51ff0ef          	jal	80002f7e <bread>
    80003232:	892a                	mv	s2,a0
  memset(bp->data, 0, BSIZE);
    80003234:	40000613          	li	a2,1024
    80003238:	4581                	li	a1,0
    8000323a:	05850513          	addi	a0,a0,88
    8000323e:	caffd0ef          	jal	80000eec <memset>
  log_write(bp);
    80003242:	854a                	mv	a0,s2
    80003244:	0ca010ef          	jal	8000430e <log_write>
  brelse(bp);
    80003248:	854a                	mv	a0,s2
    8000324a:	e3dff0ef          	jal	80003086 <brelse>
}
    8000324e:	7942                	ld	s2,48(sp)
    80003250:	79a2                	ld	s3,40(sp)
    80003252:	7a02                	ld	s4,32(sp)
    80003254:	6ae2                	ld	s5,24(sp)
    80003256:	6b42                	ld	s6,16(sp)
    80003258:	6ba2                	ld	s7,8(sp)
    8000325a:	6c02                	ld	s8,0(sp)
}
    8000325c:	8526                	mv	a0,s1
    8000325e:	60a6                	ld	ra,72(sp)
    80003260:	6406                	ld	s0,64(sp)
    80003262:	74e2                	ld	s1,56(sp)
    80003264:	6161                	addi	sp,sp,80
    80003266:	8082                	ret
    brelse(bp);
    80003268:	854a                	mv	a0,s2
    8000326a:	e1dff0ef          	jal	80003086 <brelse>
  for(b = 0; b < sb.size; b += BPB){
    8000326e:	015c0abb          	addw	s5,s8,s5
    80003272:	004b2783          	lw	a5,4(s6)
    80003276:	04faf863          	bgeu	s5,a5,800032c6 <balloc+0xe8>
    bp = bread(dev, BBLOCK(b, sb));
    8000327a:	40dad59b          	sraiw	a1,s5,0xd
    8000327e:	01cb2783          	lw	a5,28(s6)
    80003282:	9dbd                	addw	a1,a1,a5
    80003284:	855e                	mv	a0,s7
    80003286:	cf9ff0ef          	jal	80002f7e <bread>
    8000328a:	892a                	mv	s2,a0
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    8000328c:	004b2503          	lw	a0,4(s6)
    80003290:	84d6                	mv	s1,s5
    80003292:	4701                	li	a4,0
    80003294:	fca4fae3          	bgeu	s1,a0,80003268 <balloc+0x8a>
      m = 1 << (bi % 8);
    80003298:	00777693          	andi	a3,a4,7
    8000329c:	00d996bb          	sllw	a3,s3,a3
      if((bp->data[bi/8] & m) == 0){  // Is block free?
    800032a0:	41f7579b          	sraiw	a5,a4,0x1f
    800032a4:	01d7d79b          	srliw	a5,a5,0x1d
    800032a8:	9fb9                	addw	a5,a5,a4
    800032aa:	4037d79b          	sraiw	a5,a5,0x3
    800032ae:	00f90633          	add	a2,s2,a5
    800032b2:	05864603          	lbu	a2,88(a2)
    800032b6:	00c6f5b3          	and	a1,a3,a2
    800032ba:	ddb1                	beqz	a1,80003216 <balloc+0x38>
    for(bi = 0; bi < BPB && b + bi < sb.size; bi++){
    800032bc:	2705                	addiw	a4,a4,1
    800032be:	2485                	addiw	s1,s1,1
    800032c0:	fd471ae3          	bne	a4,s4,80003294 <balloc+0xb6>
    800032c4:	b755                	j	80003268 <balloc+0x8a>
    800032c6:	7942                	ld	s2,48(sp)
    800032c8:	79a2                	ld	s3,40(sp)
    800032ca:	7a02                	ld	s4,32(sp)
    800032cc:	6ae2                	ld	s5,24(sp)
    800032ce:	6b42                	ld	s6,16(sp)
    800032d0:	6ba2                	ld	s7,8(sp)
    800032d2:	6c02                	ld	s8,0(sp)
  printf("balloc: out of blocks\n");
    800032d4:	00005517          	auipc	a0,0x5
    800032d8:	19c50513          	addi	a0,a0,412 # 80008470 <etext+0x470>
    800032dc:	a1efd0ef          	jal	800004fa <printf>
  return 0;
    800032e0:	4481                	li	s1,0
    800032e2:	bfad                	j	8000325c <balloc+0x7e>

00000000800032e4 <bmap>:
// Return the disk block address of the nth block in inode ip.
// If there is no such block, bmap allocates one.
// returns 0 if out of disk space.
static uint
bmap(struct inode *ip, uint bn)
{
    800032e4:	7139                	addi	sp,sp,-64
    800032e6:	fc06                	sd	ra,56(sp)
    800032e8:	f822                	sd	s0,48(sp)
    800032ea:	f426                	sd	s1,40(sp)
    800032ec:	f04a                	sd	s2,32(sp)
    800032ee:	ec4e                	sd	s3,24(sp)
    800032f0:	0080                	addi	s0,sp,64
    800032f2:	892a                	mv	s2,a0
  uint addr, *a;
  struct buf *bp;

  if(bn < NDIRECT){
    800032f4:	47a9                	li	a5,10
    800032f6:	02b7eb63          	bltu	a5,a1,8000332c <bmap+0x48>
    if((addr = ip->addrs[bn]) == 0){
    800032fa:	02059793          	slli	a5,a1,0x20
    800032fe:	01e7d593          	srli	a1,a5,0x1e
    80003302:	00b509b3          	add	s3,a0,a1
    80003306:	0509a483          	lw	s1,80(s3)
    8000330a:	c889                	beqz	s1,8000331c <bmap+0x38>
    brelse(bp);
    return addr;
  }

  panic("bmap: out of range");
}
    8000330c:	8526                	mv	a0,s1
    8000330e:	70e2                	ld	ra,56(sp)
    80003310:	7442                	ld	s0,48(sp)
    80003312:	74a2                	ld	s1,40(sp)
    80003314:	7902                	ld	s2,32(sp)
    80003316:	69e2                	ld	s3,24(sp)
    80003318:	6121                	addi	sp,sp,64
    8000331a:	8082                	ret
      addr = balloc(ip->dev);
    8000331c:	4108                	lw	a0,0(a0)
    8000331e:	ec1ff0ef          	jal	800031de <balloc>
    80003322:	84aa                	mv	s1,a0
      if(addr == 0)
    80003324:	d565                	beqz	a0,8000330c <bmap+0x28>
      ip->addrs[bn] = addr;
    80003326:	04a9a823          	sw	a0,80(s3)
    8000332a:	b7cd                	j	8000330c <bmap+0x28>
  bn -= NDIRECT;
    8000332c:	ff55879b          	addiw	a5,a1,-11
    80003330:	873e                	mv	a4,a5
    80003332:	89be                	mv	s3,a5
  if(bn < NINDIRECT){
    80003334:	0ff00793          	li	a5,255
    80003338:	04e7ef63          	bltu	a5,a4,80003396 <bmap+0xb2>
    if((addr = ip->addrs[NDIRECT]) == 0){
    8000333c:	5d64                	lw	s1,124(a0)
    8000333e:	e891                	bnez	s1,80003352 <bmap+0x6e>
      addr = balloc(ip->dev);
    80003340:	4108                	lw	a0,0(a0)
    80003342:	e9dff0ef          	jal	800031de <balloc>
    80003346:	84aa                	mv	s1,a0
      if(addr == 0)
    80003348:	d171                	beqz	a0,8000330c <bmap+0x28>
    8000334a:	e852                	sd	s4,16(sp)
      ip->addrs[NDIRECT] = addr;
    8000334c:	06a92e23          	sw	a0,124(s2)
    80003350:	a011                	j	80003354 <bmap+0x70>
    80003352:	e852                	sd	s4,16(sp)
    bp = bread(ip->dev, addr);
    80003354:	85a6                	mv	a1,s1
    80003356:	00092503          	lw	a0,0(s2)
    8000335a:	c25ff0ef          	jal	80002f7e <bread>
    8000335e:	8a2a                	mv	s4,a0
    a = (uint*)bp->data;
    80003360:	05850713          	addi	a4,a0,88
    if((addr = a[bn]) == 0){
    80003364:	02099693          	slli	a3,s3,0x20
    80003368:	01e6d793          	srli	a5,a3,0x1e
    8000336c:	97ba                	add	a5,a5,a4
    8000336e:	89be                	mv	s3,a5
    80003370:	4384                	lw	s1,0(a5)
    80003372:	c491                	beqz	s1,8000337e <bmap+0x9a>
    brelse(bp);
    80003374:	8552                	mv	a0,s4
    80003376:	d11ff0ef          	jal	80003086 <brelse>
    return addr;
    8000337a:	6a42                	ld	s4,16(sp)
    8000337c:	bf41                	j	8000330c <bmap+0x28>
      addr = balloc(ip->dev);
    8000337e:	00092503          	lw	a0,0(s2)
    80003382:	e5dff0ef          	jal	800031de <balloc>
    80003386:	84aa                	mv	s1,a0
      if(addr){
    80003388:	d575                	beqz	a0,80003374 <bmap+0x90>
        a[bn] = addr;
    8000338a:	00a9a023          	sw	a0,0(s3)
        log_write(bp);
    8000338e:	8552                	mv	a0,s4
    80003390:	77f000ef          	jal	8000430e <log_write>
    80003394:	b7c5                	j	80003374 <bmap+0x90>
    80003396:	e852                	sd	s4,16(sp)
  bn -= NINDIRECT;
    80003398:	ef55879b          	addiw	a5,a1,-267
    8000339c:	873e                	mv	a4,a5
    8000339e:	8a3e                	mv	s4,a5
  if (bn < NDOUBLY_INDIRECT) {
    800033a0:	67c1                	lui	a5,0x10
    800033a2:	0af77963          	bgeu	a4,a5,80003454 <bmap+0x170>
    if ((addr = ip->addrs[NDIRECT+1]) == 0){
    800033a6:	08052783          	lw	a5,128(a0)
    800033aa:	eb91                	bnez	a5,800033be <bmap+0xda>
      addr = balloc(ip->dev);
    800033ac:	4108                	lw	a0,0(a0)
    800033ae:	e31ff0ef          	jal	800031de <balloc>
    800033b2:	84aa                	mv	s1,a0
      if (addr == 0)
    800033b4:	c55d                	beqz	a0,80003462 <bmap+0x17e>
    800033b6:	e456                	sd	s5,8(sp)
      ip->addrs[NDIRECT+1] = addr;
    800033b8:	08a92023          	sw	a0,128(s2)
    800033bc:	a011                	j	800033c0 <bmap+0xdc>
    800033be:	e456                	sd	s5,8(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT+1]);
    800033c0:	08092583          	lw	a1,128(s2)
    800033c4:	00092503          	lw	a0,0(s2)
    800033c8:	bb7ff0ef          	jal	80002f7e <bread>
    800033cc:	89aa                	mv	s3,a0
    a = (uint*)bp->data;
    800033ce:	05850793          	addi	a5,a0,88
    if ((addr = a[outer_index]) == 0){
    800033d2:	008a571b          	srliw	a4,s4,0x8
    800033d6:	070a                	slli	a4,a4,0x2
    800033d8:	97ba                	add	a5,a5,a4
    800033da:	8abe                	mv	s5,a5
    800033dc:	4384                	lw	s1,0(a5)
    800033de:	ec81                	bnez	s1,800033f6 <bmap+0x112>
      addr = balloc(ip->dev);
    800033e0:	00092503          	lw	a0,0(s2)
    800033e4:	dfbff0ef          	jal	800031de <balloc>
    800033e8:	84aa                	mv	s1,a0
      if (addr == 0){
    800033ea:	c521                	beqz	a0,80003432 <bmap+0x14e>
      a[outer_index] = addr;
    800033ec:	00aaa023          	sw	a0,0(s5)
      log_write(bp);
    800033f0:	854e                	mv	a0,s3
    800033f2:	71d000ef          	jal	8000430e <log_write>
    brelse(bp);
    800033f6:	854e                	mv	a0,s3
    800033f8:	c8fff0ef          	jal	80003086 <brelse>
    bp = bread(ip->dev, addr);
    800033fc:	85a6                	mv	a1,s1
    800033fe:	00092503          	lw	a0,0(s2)
    80003402:	b7dff0ef          	jal	80002f7e <bread>
    80003406:	89aa                	mv	s3,a0
    a = (uint*)bp->data;
    80003408:	05850793          	addi	a5,a0,88
    if ((addr = a[inner_index]) == 0){
    8000340c:	0ffa7593          	zext.b	a1,s4
    80003410:	058a                	slli	a1,a1,0x2
    80003412:	97ae                	add	a5,a5,a1
    80003414:	8a3e                	mv	s4,a5
    80003416:	4384                	lw	s1,0(a5)
    80003418:	e885                	bnez	s1,80003448 <bmap+0x164>
      addr = balloc(ip->dev);
    8000341a:	00092503          	lw	a0,0(s2)
    8000341e:	dc1ff0ef          	jal	800031de <balloc>
    80003422:	84aa                	mv	s1,a0
      if (addr == 0){
    80003424:	ed09                	bnez	a0,8000343e <bmap+0x15a>
        brelse(bp);
    80003426:	854e                	mv	a0,s3
    80003428:	c5fff0ef          	jal	80003086 <brelse>
        return 0;
    8000342c:	6a42                	ld	s4,16(sp)
    8000342e:	6aa2                	ld	s5,8(sp)
    80003430:	bdf1                	j	8000330c <bmap+0x28>
        brelse(bp);
    80003432:	854e                	mv	a0,s3
    80003434:	c53ff0ef          	jal	80003086 <brelse>
        return 0;
    80003438:	6a42                	ld	s4,16(sp)
    8000343a:	6aa2                	ld	s5,8(sp)
    8000343c:	bdc1                	j	8000330c <bmap+0x28>
      a[inner_index] = addr;
    8000343e:	00aa2023          	sw	a0,0(s4) # 2000 <_entry-0x7fffe000>
      log_write(bp);
    80003442:	854e                	mv	a0,s3
    80003444:	6cb000ef          	jal	8000430e <log_write>
    brelse(bp);
    80003448:	854e                	mv	a0,s3
    8000344a:	c3dff0ef          	jal	80003086 <brelse>
    return addr;
    8000344e:	6a42                	ld	s4,16(sp)
    80003450:	6aa2                	ld	s5,8(sp)
    80003452:	bd6d                	j	8000330c <bmap+0x28>
    80003454:	e456                	sd	s5,8(sp)
  panic("bmap: out of range");
    80003456:	00005517          	auipc	a0,0x5
    8000345a:	03250513          	addi	a0,a0,50 # 80008488 <etext+0x488>
    8000345e:	bc6fd0ef          	jal	80000824 <panic>
    80003462:	6a42                	ld	s4,16(sp)
    80003464:	b565                	j	8000330c <bmap+0x28>

0000000080003466 <iget>:
{
    80003466:	7179                	addi	sp,sp,-48
    80003468:	f406                	sd	ra,40(sp)
    8000346a:	f022                	sd	s0,32(sp)
    8000346c:	ec26                	sd	s1,24(sp)
    8000346e:	e84a                	sd	s2,16(sp)
    80003470:	e44e                	sd	s3,8(sp)
    80003472:	e052                	sd	s4,0(sp)
    80003474:	1800                	addi	s0,sp,48
    80003476:	892a                	mv	s2,a0
    80003478:	8a2e                	mv	s4,a1
  acquire(&itable.lock);
    8000347a:	0023c517          	auipc	a0,0x23c
    8000347e:	b4650513          	addi	a0,a0,-1210 # 8023efc0 <itable>
    80003482:	99bfd0ef          	jal	80000e1c <acquire>
  empty = 0;
    80003486:	4981                	li	s3,0
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    80003488:	0023c497          	auipc	s1,0x23c
    8000348c:	b5048493          	addi	s1,s1,-1200 # 8023efd8 <itable+0x18>
    80003490:	0023d697          	auipc	a3,0x23d
    80003494:	5d868693          	addi	a3,a3,1496 # 80240a68 <log>
    80003498:	a809                	j	800034aa <iget+0x44>
    if(empty == 0 && ip->ref == 0)    // Remember empty slot.
    8000349a:	e781                	bnez	a5,800034a2 <iget+0x3c>
    8000349c:	00099363          	bnez	s3,800034a2 <iget+0x3c>
      empty = ip;
    800034a0:	89a6                	mv	s3,s1
  for(ip = &itable.inode[0]; ip < &itable.inode[NINODE]; ip++){
    800034a2:	08848493          	addi	s1,s1,136
    800034a6:	02d48563          	beq	s1,a3,800034d0 <iget+0x6a>
    if(ip->ref > 0 && ip->dev == dev && ip->inum == inum){
    800034aa:	449c                	lw	a5,8(s1)
    800034ac:	fef057e3          	blez	a5,8000349a <iget+0x34>
    800034b0:	4098                	lw	a4,0(s1)
    800034b2:	ff2718e3          	bne	a4,s2,800034a2 <iget+0x3c>
    800034b6:	40d8                	lw	a4,4(s1)
    800034b8:	ff4715e3          	bne	a4,s4,800034a2 <iget+0x3c>
      ip->ref++;
    800034bc:	2785                	addiw	a5,a5,1 # 10001 <_entry-0x7ffeffff>
    800034be:	c49c                	sw	a5,8(s1)
      release(&itable.lock);
    800034c0:	0023c517          	auipc	a0,0x23c
    800034c4:	b0050513          	addi	a0,a0,-1280 # 8023efc0 <itable>
    800034c8:	9e9fd0ef          	jal	80000eb0 <release>
      return ip;
    800034cc:	89a6                	mv	s3,s1
    800034ce:	a015                	j	800034f2 <iget+0x8c>
  if(empty == 0)
    800034d0:	02098a63          	beqz	s3,80003504 <iget+0x9e>
  ip->dev = dev;
    800034d4:	0129a023          	sw	s2,0(s3)
  ip->inum = inum;
    800034d8:	0149a223          	sw	s4,4(s3)
  ip->ref = 1;
    800034dc:	4785                	li	a5,1
    800034de:	00f9a423          	sw	a5,8(s3)
  ip->valid = 0;
    800034e2:	0409a023          	sw	zero,64(s3)
  release(&itable.lock);
    800034e6:	0023c517          	auipc	a0,0x23c
    800034ea:	ada50513          	addi	a0,a0,-1318 # 8023efc0 <itable>
    800034ee:	9c3fd0ef          	jal	80000eb0 <release>
}
    800034f2:	854e                	mv	a0,s3
    800034f4:	70a2                	ld	ra,40(sp)
    800034f6:	7402                	ld	s0,32(sp)
    800034f8:	64e2                	ld	s1,24(sp)
    800034fa:	6942                	ld	s2,16(sp)
    800034fc:	69a2                	ld	s3,8(sp)
    800034fe:	6a02                	ld	s4,0(sp)
    80003500:	6145                	addi	sp,sp,48
    80003502:	8082                	ret
    panic("iget: no inodes");
    80003504:	00005517          	auipc	a0,0x5
    80003508:	f9c50513          	addi	a0,a0,-100 # 800084a0 <etext+0x4a0>
    8000350c:	b18fd0ef          	jal	80000824 <panic>

0000000080003510 <iinit>:
{
    80003510:	7179                	addi	sp,sp,-48
    80003512:	f406                	sd	ra,40(sp)
    80003514:	f022                	sd	s0,32(sp)
    80003516:	ec26                	sd	s1,24(sp)
    80003518:	e84a                	sd	s2,16(sp)
    8000351a:	e44e                	sd	s3,8(sp)
    8000351c:	1800                	addi	s0,sp,48
  initlock(&itable.lock, "itable");
    8000351e:	00005597          	auipc	a1,0x5
    80003522:	f9258593          	addi	a1,a1,-110 # 800084b0 <etext+0x4b0>
    80003526:	0023c517          	auipc	a0,0x23c
    8000352a:	a9a50513          	addi	a0,a0,-1382 # 8023efc0 <itable>
    8000352e:	865fd0ef          	jal	80000d92 <initlock>
  for(i = 0; i < NINODE; i++) {
    80003532:	0023c497          	auipc	s1,0x23c
    80003536:	ab648493          	addi	s1,s1,-1354 # 8023efe8 <itable+0x28>
    8000353a:	0023d997          	auipc	s3,0x23d
    8000353e:	53e98993          	addi	s3,s3,1342 # 80240a78 <log+0x10>
    initsleeplock(&itable.inode[i].lock, "inode");
    80003542:	00005917          	auipc	s2,0x5
    80003546:	f7690913          	addi	s2,s2,-138 # 800084b8 <etext+0x4b8>
    8000354a:	85ca                	mv	a1,s2
    8000354c:	8526                	mv	a0,s1
    8000354e:	685000ef          	jal	800043d2 <initsleeplock>
  for(i = 0; i < NINODE; i++) {
    80003552:	08848493          	addi	s1,s1,136
    80003556:	ff349ae3          	bne	s1,s3,8000354a <iinit+0x3a>
}
    8000355a:	70a2                	ld	ra,40(sp)
    8000355c:	7402                	ld	s0,32(sp)
    8000355e:	64e2                	ld	s1,24(sp)
    80003560:	6942                	ld	s2,16(sp)
    80003562:	69a2                	ld	s3,8(sp)
    80003564:	6145                	addi	sp,sp,48
    80003566:	8082                	ret

0000000080003568 <ialloc>:
{
    80003568:	7139                	addi	sp,sp,-64
    8000356a:	fc06                	sd	ra,56(sp)
    8000356c:	f822                	sd	s0,48(sp)
    8000356e:	0080                	addi	s0,sp,64
  for(inum = 1; inum < sb.ninodes; inum++){
    80003570:	0023c717          	auipc	a4,0x23c
    80003574:	a3c72703          	lw	a4,-1476(a4) # 8023efac <sb+0xc>
    80003578:	4785                	li	a5,1
    8000357a:	06e7f063          	bgeu	a5,a4,800035da <ialloc+0x72>
    8000357e:	f426                	sd	s1,40(sp)
    80003580:	f04a                	sd	s2,32(sp)
    80003582:	ec4e                	sd	s3,24(sp)
    80003584:	e852                	sd	s4,16(sp)
    80003586:	e456                	sd	s5,8(sp)
    80003588:	e05a                	sd	s6,0(sp)
    8000358a:	8aaa                	mv	s5,a0
    8000358c:	8b2e                	mv	s6,a1
    8000358e:	893e                	mv	s2,a5
    bp = bread(dev, IBLOCK(inum, sb));
    80003590:	0023ca17          	auipc	s4,0x23c
    80003594:	a10a0a13          	addi	s4,s4,-1520 # 8023efa0 <sb>
    80003598:	00495593          	srli	a1,s2,0x4
    8000359c:	018a2783          	lw	a5,24(s4)
    800035a0:	9dbd                	addw	a1,a1,a5
    800035a2:	8556                	mv	a0,s5
    800035a4:	9dbff0ef          	jal	80002f7e <bread>
    800035a8:	84aa                	mv	s1,a0
    dip = (struct dinode*)bp->data + inum%IPB;
    800035aa:	05850993          	addi	s3,a0,88
    800035ae:	00f97793          	andi	a5,s2,15
    800035b2:	079a                	slli	a5,a5,0x6
    800035b4:	99be                	add	s3,s3,a5
    if(dip->type == 0){  // a free inode
    800035b6:	00099783          	lh	a5,0(s3)
    800035ba:	cb9d                	beqz	a5,800035f0 <ialloc+0x88>
    brelse(bp);
    800035bc:	acbff0ef          	jal	80003086 <brelse>
  for(inum = 1; inum < sb.ninodes; inum++){
    800035c0:	0905                	addi	s2,s2,1
    800035c2:	00ca2703          	lw	a4,12(s4)
    800035c6:	0009079b          	sext.w	a5,s2
    800035ca:	fce7e7e3          	bltu	a5,a4,80003598 <ialloc+0x30>
    800035ce:	74a2                	ld	s1,40(sp)
    800035d0:	7902                	ld	s2,32(sp)
    800035d2:	69e2                	ld	s3,24(sp)
    800035d4:	6a42                	ld	s4,16(sp)
    800035d6:	6aa2                	ld	s5,8(sp)
    800035d8:	6b02                	ld	s6,0(sp)
  printf("ialloc: no inodes\n");
    800035da:	00005517          	auipc	a0,0x5
    800035de:	ee650513          	addi	a0,a0,-282 # 800084c0 <etext+0x4c0>
    800035e2:	f19fc0ef          	jal	800004fa <printf>
  return 0;
    800035e6:	4501                	li	a0,0
}
    800035e8:	70e2                	ld	ra,56(sp)
    800035ea:	7442                	ld	s0,48(sp)
    800035ec:	6121                	addi	sp,sp,64
    800035ee:	8082                	ret
      memset(dip, 0, sizeof(*dip));
    800035f0:	04000613          	li	a2,64
    800035f4:	4581                	li	a1,0
    800035f6:	854e                	mv	a0,s3
    800035f8:	8f5fd0ef          	jal	80000eec <memset>
      dip->type = type;
    800035fc:	01699023          	sh	s6,0(s3)
      log_write(bp);   // mark it allocated on the disk
    80003600:	8526                	mv	a0,s1
    80003602:	50d000ef          	jal	8000430e <log_write>
      brelse(bp);
    80003606:	8526                	mv	a0,s1
    80003608:	a7fff0ef          	jal	80003086 <brelse>
      return iget(dev, inum);
    8000360c:	0009059b          	sext.w	a1,s2
    80003610:	8556                	mv	a0,s5
    80003612:	e55ff0ef          	jal	80003466 <iget>
    80003616:	74a2                	ld	s1,40(sp)
    80003618:	7902                	ld	s2,32(sp)
    8000361a:	69e2                	ld	s3,24(sp)
    8000361c:	6a42                	ld	s4,16(sp)
    8000361e:	6aa2                	ld	s5,8(sp)
    80003620:	6b02                	ld	s6,0(sp)
    80003622:	b7d9                	j	800035e8 <ialloc+0x80>

0000000080003624 <iupdate>:
{
    80003624:	1101                	addi	sp,sp,-32
    80003626:	ec06                	sd	ra,24(sp)
    80003628:	e822                	sd	s0,16(sp)
    8000362a:	e426                	sd	s1,8(sp)
    8000362c:	e04a                	sd	s2,0(sp)
    8000362e:	1000                	addi	s0,sp,32
    80003630:	84aa                	mv	s1,a0
  bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003632:	415c                	lw	a5,4(a0)
    80003634:	0047d79b          	srliw	a5,a5,0x4
    80003638:	0023c597          	auipc	a1,0x23c
    8000363c:	9805a583          	lw	a1,-1664(a1) # 8023efb8 <sb+0x18>
    80003640:	9dbd                	addw	a1,a1,a5
    80003642:	4108                	lw	a0,0(a0)
    80003644:	93bff0ef          	jal	80002f7e <bread>
    80003648:	892a                	mv	s2,a0
  dip = (struct dinode*)bp->data + ip->inum%IPB;
    8000364a:	05850793          	addi	a5,a0,88
    8000364e:	40d8                	lw	a4,4(s1)
    80003650:	8b3d                	andi	a4,a4,15
    80003652:	071a                	slli	a4,a4,0x6
    80003654:	97ba                	add	a5,a5,a4
  dip->type = ip->type;
    80003656:	04449703          	lh	a4,68(s1)
    8000365a:	00e79023          	sh	a4,0(a5)
  dip->major = ip->major;
    8000365e:	04649703          	lh	a4,70(s1)
    80003662:	00e79123          	sh	a4,2(a5)
  dip->minor = ip->minor;
    80003666:	04849703          	lh	a4,72(s1)
    8000366a:	00e79223          	sh	a4,4(a5)
  dip->nlink = ip->nlink;
    8000366e:	04a49703          	lh	a4,74(s1)
    80003672:	00e79323          	sh	a4,6(a5)
  dip->size = ip->size;
    80003676:	44f8                	lw	a4,76(s1)
    80003678:	c798                	sw	a4,8(a5)
  memmove(dip->addrs, ip->addrs, sizeof(ip->addrs));
    8000367a:	03400613          	li	a2,52
    8000367e:	05048593          	addi	a1,s1,80
    80003682:	00c78513          	addi	a0,a5,12
    80003686:	8c7fd0ef          	jal	80000f4c <memmove>
  log_write(bp);
    8000368a:	854a                	mv	a0,s2
    8000368c:	483000ef          	jal	8000430e <log_write>
  brelse(bp);
    80003690:	854a                	mv	a0,s2
    80003692:	9f5ff0ef          	jal	80003086 <brelse>
}
    80003696:	60e2                	ld	ra,24(sp)
    80003698:	6442                	ld	s0,16(sp)
    8000369a:	64a2                	ld	s1,8(sp)
    8000369c:	6902                	ld	s2,0(sp)
    8000369e:	6105                	addi	sp,sp,32
    800036a0:	8082                	ret

00000000800036a2 <idup>:
{
    800036a2:	1101                	addi	sp,sp,-32
    800036a4:	ec06                	sd	ra,24(sp)
    800036a6:	e822                	sd	s0,16(sp)
    800036a8:	e426                	sd	s1,8(sp)
    800036aa:	1000                	addi	s0,sp,32
    800036ac:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800036ae:	0023c517          	auipc	a0,0x23c
    800036b2:	91250513          	addi	a0,a0,-1774 # 8023efc0 <itable>
    800036b6:	f66fd0ef          	jal	80000e1c <acquire>
  ip->ref++;
    800036ba:	449c                	lw	a5,8(s1)
    800036bc:	2785                	addiw	a5,a5,1
    800036be:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    800036c0:	0023c517          	auipc	a0,0x23c
    800036c4:	90050513          	addi	a0,a0,-1792 # 8023efc0 <itable>
    800036c8:	fe8fd0ef          	jal	80000eb0 <release>
}
    800036cc:	8526                	mv	a0,s1
    800036ce:	60e2                	ld	ra,24(sp)
    800036d0:	6442                	ld	s0,16(sp)
    800036d2:	64a2                	ld	s1,8(sp)
    800036d4:	6105                	addi	sp,sp,32
    800036d6:	8082                	ret

00000000800036d8 <ilock>:
{
    800036d8:	1101                	addi	sp,sp,-32
    800036da:	ec06                	sd	ra,24(sp)
    800036dc:	e822                	sd	s0,16(sp)
    800036de:	e426                	sd	s1,8(sp)
    800036e0:	1000                	addi	s0,sp,32
  if(ip == 0 || ip->ref < 1)
    800036e2:	cd19                	beqz	a0,80003700 <ilock+0x28>
    800036e4:	84aa                	mv	s1,a0
    800036e6:	451c                	lw	a5,8(a0)
    800036e8:	00f05c63          	blez	a5,80003700 <ilock+0x28>
  acquiresleep(&ip->lock);
    800036ec:	0541                	addi	a0,a0,16
    800036ee:	51b000ef          	jal	80004408 <acquiresleep>
  if(ip->valid == 0){
    800036f2:	40bc                	lw	a5,64(s1)
    800036f4:	cf89                	beqz	a5,8000370e <ilock+0x36>
}
    800036f6:	60e2                	ld	ra,24(sp)
    800036f8:	6442                	ld	s0,16(sp)
    800036fa:	64a2                	ld	s1,8(sp)
    800036fc:	6105                	addi	sp,sp,32
    800036fe:	8082                	ret
    80003700:	e04a                	sd	s2,0(sp)
    panic("ilock");
    80003702:	00005517          	auipc	a0,0x5
    80003706:	dd650513          	addi	a0,a0,-554 # 800084d8 <etext+0x4d8>
    8000370a:	91afd0ef          	jal	80000824 <panic>
    8000370e:	e04a                	sd	s2,0(sp)
    bp = bread(ip->dev, IBLOCK(ip->inum, sb));
    80003710:	40dc                	lw	a5,4(s1)
    80003712:	0047d79b          	srliw	a5,a5,0x4
    80003716:	0023c597          	auipc	a1,0x23c
    8000371a:	8a25a583          	lw	a1,-1886(a1) # 8023efb8 <sb+0x18>
    8000371e:	9dbd                	addw	a1,a1,a5
    80003720:	4088                	lw	a0,0(s1)
    80003722:	85dff0ef          	jal	80002f7e <bread>
    80003726:	892a                	mv	s2,a0
    dip = (struct dinode*)bp->data + ip->inum%IPB;
    80003728:	05850593          	addi	a1,a0,88
    8000372c:	40dc                	lw	a5,4(s1)
    8000372e:	8bbd                	andi	a5,a5,15
    80003730:	079a                	slli	a5,a5,0x6
    80003732:	95be                	add	a1,a1,a5
    ip->type = dip->type;
    80003734:	00059783          	lh	a5,0(a1)
    80003738:	04f49223          	sh	a5,68(s1)
    ip->major = dip->major;
    8000373c:	00259783          	lh	a5,2(a1)
    80003740:	04f49323          	sh	a5,70(s1)
    ip->minor = dip->minor;
    80003744:	00459783          	lh	a5,4(a1)
    80003748:	04f49423          	sh	a5,72(s1)
    ip->nlink = dip->nlink;
    8000374c:	00659783          	lh	a5,6(a1)
    80003750:	04f49523          	sh	a5,74(s1)
    ip->size = dip->size;
    80003754:	459c                	lw	a5,8(a1)
    80003756:	c4fc                	sw	a5,76(s1)
    memmove(ip->addrs, dip->addrs, sizeof(ip->addrs));
    80003758:	03400613          	li	a2,52
    8000375c:	05b1                	addi	a1,a1,12
    8000375e:	05048513          	addi	a0,s1,80
    80003762:	feafd0ef          	jal	80000f4c <memmove>
    brelse(bp);
    80003766:	854a                	mv	a0,s2
    80003768:	91fff0ef          	jal	80003086 <brelse>
    ip->valid = 1;
    8000376c:	4785                	li	a5,1
    8000376e:	c0bc                	sw	a5,64(s1)
    if(ip->type == 0)
    80003770:	04449783          	lh	a5,68(s1)
    80003774:	c399                	beqz	a5,8000377a <ilock+0xa2>
    80003776:	6902                	ld	s2,0(sp)
    80003778:	bfbd                	j	800036f6 <ilock+0x1e>
      panic("ilock: no type");
    8000377a:	00005517          	auipc	a0,0x5
    8000377e:	d6650513          	addi	a0,a0,-666 # 800084e0 <etext+0x4e0>
    80003782:	8a2fd0ef          	jal	80000824 <panic>

0000000080003786 <iunlock>:
{
    80003786:	1101                	addi	sp,sp,-32
    80003788:	ec06                	sd	ra,24(sp)
    8000378a:	e822                	sd	s0,16(sp)
    8000378c:	e426                	sd	s1,8(sp)
    8000378e:	e04a                	sd	s2,0(sp)
    80003790:	1000                	addi	s0,sp,32
  if(ip == 0 || !holdingsleep(&ip->lock) || ip->ref < 1)
    80003792:	c505                	beqz	a0,800037ba <iunlock+0x34>
    80003794:	84aa                	mv	s1,a0
    80003796:	01050913          	addi	s2,a0,16
    8000379a:	854a                	mv	a0,s2
    8000379c:	4eb000ef          	jal	80004486 <holdingsleep>
    800037a0:	cd09                	beqz	a0,800037ba <iunlock+0x34>
    800037a2:	449c                	lw	a5,8(s1)
    800037a4:	00f05b63          	blez	a5,800037ba <iunlock+0x34>
  releasesleep(&ip->lock);
    800037a8:	854a                	mv	a0,s2
    800037aa:	4a5000ef          	jal	8000444e <releasesleep>
}
    800037ae:	60e2                	ld	ra,24(sp)
    800037b0:	6442                	ld	s0,16(sp)
    800037b2:	64a2                	ld	s1,8(sp)
    800037b4:	6902                	ld	s2,0(sp)
    800037b6:	6105                	addi	sp,sp,32
    800037b8:	8082                	ret
    panic("iunlock");
    800037ba:	00005517          	auipc	a0,0x5
    800037be:	d3650513          	addi	a0,a0,-714 # 800084f0 <etext+0x4f0>
    800037c2:	862fd0ef          	jal	80000824 <panic>

00000000800037c6 <itrunc>:

// Truncate inode (discard contents).
// Caller must hold ip->lock.
void
itrunc(struct inode *ip)
{
    800037c6:	715d                	addi	sp,sp,-80
    800037c8:	e486                	sd	ra,72(sp)
    800037ca:	e0a2                	sd	s0,64(sp)
    800037cc:	fc26                	sd	s1,56(sp)
    800037ce:	f84a                	sd	s2,48(sp)
    800037d0:	f44e                	sd	s3,40(sp)
    800037d2:	0880                	addi	s0,sp,80
    800037d4:	89aa                	mv	s3,a0
  int i, j, k;
  struct buf *bp, *bp2; // bp2 for NDOUBLY_INDIRECT reference
  uint *a, *a2; // a2 for NDOUBLY_INDIRECT reference

  for(i = 0; i < NDIRECT; i++){
    800037d6:	05050493          	addi	s1,a0,80
    800037da:	07c50913          	addi	s2,a0,124
    800037de:	a021                	j	800037e6 <itrunc+0x20>
    800037e0:	0491                	addi	s1,s1,4
    800037e2:	01248b63          	beq	s1,s2,800037f8 <itrunc+0x32>
    if(ip->addrs[i]){
    800037e6:	408c                	lw	a1,0(s1)
    800037e8:	dde5                	beqz	a1,800037e0 <itrunc+0x1a>
      bfree(ip->dev, ip->addrs[i]);
    800037ea:	0009a503          	lw	a0,0(s3)
    800037ee:	985ff0ef          	jal	80003172 <bfree>
      ip->addrs[i] = 0;
    800037f2:	0004a023          	sw	zero,0(s1)
    800037f6:	b7ed                	j	800037e0 <itrunc+0x1a>
    }
  }

  if(ip->addrs[NDIRECT]){
    800037f8:	07c9a583          	lw	a1,124(s3)
    800037fc:	e185                	bnez	a1,8000381c <itrunc+0x56>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    ip->addrs[NDIRECT] = 0;
  }

  // Task 5.1: free the doubly indirect blocks
  if (ip->addrs[NDIRECT + 1]){
    800037fe:	0809a583          	lw	a1,128(s3)
    80003802:	edb9                	bnez	a1,80003860 <itrunc+0x9a>
    brelse(bp);
    bfree(ip->dev, ip->addrs[NDIRECT+1]);
    ip->addrs[NDIRECT+1] = 0;
  }

  ip->size = 0;
    80003804:	0409a623          	sw	zero,76(s3)
  iupdate(ip);
    80003808:	854e                	mv	a0,s3
    8000380a:	e1bff0ef          	jal	80003624 <iupdate>
}
    8000380e:	60a6                	ld	ra,72(sp)
    80003810:	6406                	ld	s0,64(sp)
    80003812:	74e2                	ld	s1,56(sp)
    80003814:	7942                	ld	s2,48(sp)
    80003816:	79a2                	ld	s3,40(sp)
    80003818:	6161                	addi	sp,sp,80
    8000381a:	8082                	ret
    8000381c:	f052                	sd	s4,32(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT]);
    8000381e:	0009a503          	lw	a0,0(s3)
    80003822:	f5cff0ef          	jal	80002f7e <bread>
    80003826:	8a2a                	mv	s4,a0
    for(j = 0; j < NINDIRECT; j++){
    80003828:	05850493          	addi	s1,a0,88
    8000382c:	45850913          	addi	s2,a0,1112
    80003830:	a021                	j	80003838 <itrunc+0x72>
    80003832:	0491                	addi	s1,s1,4
    80003834:	01248963          	beq	s1,s2,80003846 <itrunc+0x80>
      if(a[j])
    80003838:	408c                	lw	a1,0(s1)
    8000383a:	dde5                	beqz	a1,80003832 <itrunc+0x6c>
        bfree(ip->dev, a[j]);
    8000383c:	0009a503          	lw	a0,0(s3)
    80003840:	933ff0ef          	jal	80003172 <bfree>
    80003844:	b7fd                	j	80003832 <itrunc+0x6c>
    brelse(bp);
    80003846:	8552                	mv	a0,s4
    80003848:	83fff0ef          	jal	80003086 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT]);
    8000384c:	07c9a583          	lw	a1,124(s3)
    80003850:	0009a503          	lw	a0,0(s3)
    80003854:	91fff0ef          	jal	80003172 <bfree>
    ip->addrs[NDIRECT] = 0;
    80003858:	0609ae23          	sw	zero,124(s3)
    8000385c:	7a02                	ld	s4,32(sp)
    8000385e:	b745                	j	800037fe <itrunc+0x38>
    80003860:	f052                	sd	s4,32(sp)
    80003862:	ec56                	sd	s5,24(sp)
    80003864:	e85a                	sd	s6,16(sp)
    80003866:	e45e                	sd	s7,8(sp)
    80003868:	e062                	sd	s8,0(sp)
    bp = bread(ip->dev, ip->addrs[NDIRECT+1]);
    8000386a:	0009a503          	lw	a0,0(s3)
    8000386e:	f10ff0ef          	jal	80002f7e <bread>
    80003872:	8c2a                	mv	s8,a0
    for(j = 0; j < NINDIRECT; j++){
    80003874:	05850a13          	addi	s4,a0,88
    80003878:	45850b13          	addi	s6,a0,1112
    8000387c:	a03d                	j	800038aa <itrunc+0xe4>
            bfree(ip->dev, a2[k]);
    8000387e:	0009a503          	lw	a0,0(s3)
    80003882:	8f1ff0ef          	jal	80003172 <bfree>
        for(k = 0; k < NINDIRECT; k++){
    80003886:	0491                	addi	s1,s1,4
    80003888:	01248563          	beq	s1,s2,80003892 <itrunc+0xcc>
          if (a2[k])
    8000388c:	408c                	lw	a1,0(s1)
    8000388e:	dde5                	beqz	a1,80003886 <itrunc+0xc0>
    80003890:	b7fd                	j	8000387e <itrunc+0xb8>
        brelse(bp2);
    80003892:	855e                	mv	a0,s7
    80003894:	ff2ff0ef          	jal	80003086 <brelse>
        bfree(ip->dev, a[j]);
    80003898:	000aa583          	lw	a1,0(s5)
    8000389c:	0009a503          	lw	a0,0(s3)
    800038a0:	8d3ff0ef          	jal	80003172 <bfree>
    for(j = 0; j < NINDIRECT; j++){
    800038a4:	0a11                	addi	s4,s4,4
    800038a6:	036a0063          	beq	s4,s6,800038c6 <itrunc+0x100>
      if (a[j]){
    800038aa:	8ad2                	mv	s5,s4
    800038ac:	000a2583          	lw	a1,0(s4)
    800038b0:	d9f5                	beqz	a1,800038a4 <itrunc+0xde>
        bp2 = bread(ip->dev, a[j]);
    800038b2:	0009a503          	lw	a0,0(s3)
    800038b6:	ec8ff0ef          	jal	80002f7e <bread>
    800038ba:	8baa                	mv	s7,a0
        for(k = 0; k < NINDIRECT; k++){
    800038bc:	05850493          	addi	s1,a0,88
    800038c0:	45850913          	addi	s2,a0,1112
    800038c4:	b7e1                	j	8000388c <itrunc+0xc6>
    brelse(bp);
    800038c6:	8562                	mv	a0,s8
    800038c8:	fbeff0ef          	jal	80003086 <brelse>
    bfree(ip->dev, ip->addrs[NDIRECT+1]);
    800038cc:	0809a583          	lw	a1,128(s3)
    800038d0:	0009a503          	lw	a0,0(s3)
    800038d4:	89fff0ef          	jal	80003172 <bfree>
    ip->addrs[NDIRECT+1] = 0;
    800038d8:	0809a023          	sw	zero,128(s3)
    800038dc:	7a02                	ld	s4,32(sp)
    800038de:	6ae2                	ld	s5,24(sp)
    800038e0:	6b42                	ld	s6,16(sp)
    800038e2:	6ba2                	ld	s7,8(sp)
    800038e4:	6c02                	ld	s8,0(sp)
    800038e6:	bf39                	j	80003804 <itrunc+0x3e>

00000000800038e8 <iput>:
{
    800038e8:	1101                	addi	sp,sp,-32
    800038ea:	ec06                	sd	ra,24(sp)
    800038ec:	e822                	sd	s0,16(sp)
    800038ee:	e426                	sd	s1,8(sp)
    800038f0:	1000                	addi	s0,sp,32
    800038f2:	84aa                	mv	s1,a0
  acquire(&itable.lock);
    800038f4:	0023b517          	auipc	a0,0x23b
    800038f8:	6cc50513          	addi	a0,a0,1740 # 8023efc0 <itable>
    800038fc:	d20fd0ef          	jal	80000e1c <acquire>
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003900:	4498                	lw	a4,8(s1)
    80003902:	4785                	li	a5,1
    80003904:	02f70063          	beq	a4,a5,80003924 <iput+0x3c>
  ip->ref--;
    80003908:	449c                	lw	a5,8(s1)
    8000390a:	37fd                	addiw	a5,a5,-1
    8000390c:	c49c                	sw	a5,8(s1)
  release(&itable.lock);
    8000390e:	0023b517          	auipc	a0,0x23b
    80003912:	6b250513          	addi	a0,a0,1714 # 8023efc0 <itable>
    80003916:	d9afd0ef          	jal	80000eb0 <release>
}
    8000391a:	60e2                	ld	ra,24(sp)
    8000391c:	6442                	ld	s0,16(sp)
    8000391e:	64a2                	ld	s1,8(sp)
    80003920:	6105                	addi	sp,sp,32
    80003922:	8082                	ret
  if(ip->ref == 1 && ip->valid && ip->nlink == 0){
    80003924:	40bc                	lw	a5,64(s1)
    80003926:	d3ed                	beqz	a5,80003908 <iput+0x20>
    80003928:	04a49783          	lh	a5,74(s1)
    8000392c:	fff1                	bnez	a5,80003908 <iput+0x20>
    8000392e:	e04a                	sd	s2,0(sp)
    acquiresleep(&ip->lock);
    80003930:	01048793          	addi	a5,s1,16
    80003934:	893e                	mv	s2,a5
    80003936:	853e                	mv	a0,a5
    80003938:	2d1000ef          	jal	80004408 <acquiresleep>
    release(&itable.lock);
    8000393c:	0023b517          	auipc	a0,0x23b
    80003940:	68450513          	addi	a0,a0,1668 # 8023efc0 <itable>
    80003944:	d6cfd0ef          	jal	80000eb0 <release>
    itrunc(ip);
    80003948:	8526                	mv	a0,s1
    8000394a:	e7dff0ef          	jal	800037c6 <itrunc>
    ip->type = 0;
    8000394e:	04049223          	sh	zero,68(s1)
    iupdate(ip);
    80003952:	8526                	mv	a0,s1
    80003954:	cd1ff0ef          	jal	80003624 <iupdate>
    ip->valid = 0;
    80003958:	0404a023          	sw	zero,64(s1)
    releasesleep(&ip->lock);
    8000395c:	854a                	mv	a0,s2
    8000395e:	2f1000ef          	jal	8000444e <releasesleep>
    acquire(&itable.lock);
    80003962:	0023b517          	auipc	a0,0x23b
    80003966:	65e50513          	addi	a0,a0,1630 # 8023efc0 <itable>
    8000396a:	cb2fd0ef          	jal	80000e1c <acquire>
    8000396e:	6902                	ld	s2,0(sp)
    80003970:	bf61                	j	80003908 <iput+0x20>

0000000080003972 <iunlockput>:
{
    80003972:	1101                	addi	sp,sp,-32
    80003974:	ec06                	sd	ra,24(sp)
    80003976:	e822                	sd	s0,16(sp)
    80003978:	e426                	sd	s1,8(sp)
    8000397a:	1000                	addi	s0,sp,32
    8000397c:	84aa                	mv	s1,a0
  iunlock(ip);
    8000397e:	e09ff0ef          	jal	80003786 <iunlock>
  iput(ip);
    80003982:	8526                	mv	a0,s1
    80003984:	f65ff0ef          	jal	800038e8 <iput>
}
    80003988:	60e2                	ld	ra,24(sp)
    8000398a:	6442                	ld	s0,16(sp)
    8000398c:	64a2                	ld	s1,8(sp)
    8000398e:	6105                	addi	sp,sp,32
    80003990:	8082                	ret

0000000080003992 <ireclaim>:
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003992:	0023b717          	auipc	a4,0x23b
    80003996:	61a72703          	lw	a4,1562(a4) # 8023efac <sb+0xc>
    8000399a:	4785                	li	a5,1
    8000399c:	0ae7fe63          	bgeu	a5,a4,80003a58 <ireclaim+0xc6>
{
    800039a0:	7139                	addi	sp,sp,-64
    800039a2:	fc06                	sd	ra,56(sp)
    800039a4:	f822                	sd	s0,48(sp)
    800039a6:	f426                	sd	s1,40(sp)
    800039a8:	f04a                	sd	s2,32(sp)
    800039aa:	ec4e                	sd	s3,24(sp)
    800039ac:	e852                	sd	s4,16(sp)
    800039ae:	e456                	sd	s5,8(sp)
    800039b0:	e05a                	sd	s6,0(sp)
    800039b2:	0080                	addi	s0,sp,64
    800039b4:	8aaa                	mv	s5,a0
  for (int inum = 1; inum < sb.ninodes; inum++) {
    800039b6:	84be                	mv	s1,a5
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    800039b8:	0023ba17          	auipc	s4,0x23b
    800039bc:	5e8a0a13          	addi	s4,s4,1512 # 8023efa0 <sb>
      printf("ireclaim: orphaned inode %d\n", inum);
    800039c0:	00005b17          	auipc	s6,0x5
    800039c4:	b38b0b13          	addi	s6,s6,-1224 # 800084f8 <etext+0x4f8>
    800039c8:	a099                	j	80003a0e <ireclaim+0x7c>
    800039ca:	85ce                	mv	a1,s3
    800039cc:	855a                	mv	a0,s6
    800039ce:	b2dfc0ef          	jal	800004fa <printf>
      ip = iget(dev, inum);
    800039d2:	85ce                	mv	a1,s3
    800039d4:	8556                	mv	a0,s5
    800039d6:	a91ff0ef          	jal	80003466 <iget>
    800039da:	89aa                	mv	s3,a0
    brelse(bp);
    800039dc:	854a                	mv	a0,s2
    800039de:	ea8ff0ef          	jal	80003086 <brelse>
    if (ip) {
    800039e2:	00098f63          	beqz	s3,80003a00 <ireclaim+0x6e>
      begin_op();
    800039e6:	78e000ef          	jal	80004174 <begin_op>
      ilock(ip);
    800039ea:	854e                	mv	a0,s3
    800039ec:	cedff0ef          	jal	800036d8 <ilock>
      iunlock(ip);
    800039f0:	854e                	mv	a0,s3
    800039f2:	d95ff0ef          	jal	80003786 <iunlock>
      iput(ip);
    800039f6:	854e                	mv	a0,s3
    800039f8:	ef1ff0ef          	jal	800038e8 <iput>
      end_op();
    800039fc:	7e8000ef          	jal	800041e4 <end_op>
  for (int inum = 1; inum < sb.ninodes; inum++) {
    80003a00:	0485                	addi	s1,s1,1
    80003a02:	00ca2703          	lw	a4,12(s4)
    80003a06:	0004879b          	sext.w	a5,s1
    80003a0a:	02e7fd63          	bgeu	a5,a4,80003a44 <ireclaim+0xb2>
    80003a0e:	0004899b          	sext.w	s3,s1
    struct buf *bp = bread(dev, IBLOCK(inum, sb));
    80003a12:	0044d593          	srli	a1,s1,0x4
    80003a16:	018a2783          	lw	a5,24(s4)
    80003a1a:	9dbd                	addw	a1,a1,a5
    80003a1c:	8556                	mv	a0,s5
    80003a1e:	d60ff0ef          	jal	80002f7e <bread>
    80003a22:	892a                	mv	s2,a0
    struct dinode *dip = (struct dinode *)bp->data + inum % IPB;
    80003a24:	05850793          	addi	a5,a0,88
    80003a28:	00f9f713          	andi	a4,s3,15
    80003a2c:	071a                	slli	a4,a4,0x6
    80003a2e:	97ba                	add	a5,a5,a4
    if (dip->type != 0 && dip->nlink == 0) {  // is an orphaned inode
    80003a30:	00079703          	lh	a4,0(a5)
    80003a34:	c701                	beqz	a4,80003a3c <ireclaim+0xaa>
    80003a36:	00679783          	lh	a5,6(a5)
    80003a3a:	dbc1                	beqz	a5,800039ca <ireclaim+0x38>
    brelse(bp);
    80003a3c:	854a                	mv	a0,s2
    80003a3e:	e48ff0ef          	jal	80003086 <brelse>
    if (ip) {
    80003a42:	bf7d                	j	80003a00 <ireclaim+0x6e>
}
    80003a44:	70e2                	ld	ra,56(sp)
    80003a46:	7442                	ld	s0,48(sp)
    80003a48:	74a2                	ld	s1,40(sp)
    80003a4a:	7902                	ld	s2,32(sp)
    80003a4c:	69e2                	ld	s3,24(sp)
    80003a4e:	6a42                	ld	s4,16(sp)
    80003a50:	6aa2                	ld	s5,8(sp)
    80003a52:	6b02                	ld	s6,0(sp)
    80003a54:	6121                	addi	sp,sp,64
    80003a56:	8082                	ret
    80003a58:	8082                	ret

0000000080003a5a <fsinit>:
fsinit(int dev) {
    80003a5a:	1101                	addi	sp,sp,-32
    80003a5c:	ec06                	sd	ra,24(sp)
    80003a5e:	e822                	sd	s0,16(sp)
    80003a60:	e426                	sd	s1,8(sp)
    80003a62:	e04a                	sd	s2,0(sp)
    80003a64:	1000                	addi	s0,sp,32
    80003a66:	892a                	mv	s2,a0
  bp = bread(dev, 1);
    80003a68:	4585                	li	a1,1
    80003a6a:	d14ff0ef          	jal	80002f7e <bread>
    80003a6e:	84aa                	mv	s1,a0
  memmove(sb, bp->data, sizeof(*sb));
    80003a70:	02000613          	li	a2,32
    80003a74:	05850593          	addi	a1,a0,88
    80003a78:	0023b517          	auipc	a0,0x23b
    80003a7c:	52850513          	addi	a0,a0,1320 # 8023efa0 <sb>
    80003a80:	cccfd0ef          	jal	80000f4c <memmove>
  brelse(bp);
    80003a84:	8526                	mv	a0,s1
    80003a86:	e00ff0ef          	jal	80003086 <brelse>
  if(sb.magic != FSMAGIC)
    80003a8a:	0023b717          	auipc	a4,0x23b
    80003a8e:	51672703          	lw	a4,1302(a4) # 8023efa0 <sb>
    80003a92:	102037b7          	lui	a5,0x10203
    80003a96:	04078793          	addi	a5,a5,64 # 10203040 <_entry-0x6fdfcfc0>
    80003a9a:	02f71263          	bne	a4,a5,80003abe <fsinit+0x64>
  initlog(dev, &sb);
    80003a9e:	0023b597          	auipc	a1,0x23b
    80003aa2:	50258593          	addi	a1,a1,1282 # 8023efa0 <sb>
    80003aa6:	854a                	mv	a0,s2
    80003aa8:	64a000ef          	jal	800040f2 <initlog>
  ireclaim(dev);
    80003aac:	854a                	mv	a0,s2
    80003aae:	ee5ff0ef          	jal	80003992 <ireclaim>
}
    80003ab2:	60e2                	ld	ra,24(sp)
    80003ab4:	6442                	ld	s0,16(sp)
    80003ab6:	64a2                	ld	s1,8(sp)
    80003ab8:	6902                	ld	s2,0(sp)
    80003aba:	6105                	addi	sp,sp,32
    80003abc:	8082                	ret
    panic("invalid file system");
    80003abe:	00005517          	auipc	a0,0x5
    80003ac2:	a5a50513          	addi	a0,a0,-1446 # 80008518 <etext+0x518>
    80003ac6:	d5ffc0ef          	jal	80000824 <panic>

0000000080003aca <stati>:

// Copy stat information from inode.
// Caller must hold ip->lock.
void
stati(struct inode *ip, struct stat *st)
{
    80003aca:	1141                	addi	sp,sp,-16
    80003acc:	e406                	sd	ra,8(sp)
    80003ace:	e022                	sd	s0,0(sp)
    80003ad0:	0800                	addi	s0,sp,16
  st->dev = ip->dev;
    80003ad2:	411c                	lw	a5,0(a0)
    80003ad4:	c19c                	sw	a5,0(a1)
  st->ino = ip->inum;
    80003ad6:	415c                	lw	a5,4(a0)
    80003ad8:	c1dc                	sw	a5,4(a1)
  st->type = ip->type;
    80003ada:	04451783          	lh	a5,68(a0)
    80003ade:	00f59423          	sh	a5,8(a1)
  st->nlink = ip->nlink;
    80003ae2:	04a51783          	lh	a5,74(a0)
    80003ae6:	00f59523          	sh	a5,10(a1)
  st->size = ip->size;
    80003aea:	04c56783          	lwu	a5,76(a0)
    80003aee:	e99c                	sd	a5,16(a1)
}
    80003af0:	60a2                	ld	ra,8(sp)
    80003af2:	6402                	ld	s0,0(sp)
    80003af4:	0141                	addi	sp,sp,16
    80003af6:	8082                	ret

0000000080003af8 <readi>:
readi(struct inode *ip, int user_dst, uint64 dst, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003af8:	457c                	lw	a5,76(a0)
    80003afa:	0ed7e663          	bltu	a5,a3,80003be6 <readi+0xee>
{
    80003afe:	7159                	addi	sp,sp,-112
    80003b00:	f486                	sd	ra,104(sp)
    80003b02:	f0a2                	sd	s0,96(sp)
    80003b04:	eca6                	sd	s1,88(sp)
    80003b06:	e0d2                	sd	s4,64(sp)
    80003b08:	fc56                	sd	s5,56(sp)
    80003b0a:	f85a                	sd	s6,48(sp)
    80003b0c:	f45e                	sd	s7,40(sp)
    80003b0e:	1880                	addi	s0,sp,112
    80003b10:	8b2a                	mv	s6,a0
    80003b12:	8bae                	mv	s7,a1
    80003b14:	8a32                	mv	s4,a2
    80003b16:	84b6                	mv	s1,a3
    80003b18:	8aba                	mv	s5,a4
  if(off > ip->size || off + n < off)
    80003b1a:	9f35                	addw	a4,a4,a3
    return 0;
    80003b1c:	4501                	li	a0,0
  if(off > ip->size || off + n < off)
    80003b1e:	0ad76b63          	bltu	a4,a3,80003bd4 <readi+0xdc>
    80003b22:	e4ce                	sd	s3,72(sp)
  if(off + n > ip->size)
    80003b24:	00e7f463          	bgeu	a5,a4,80003b2c <readi+0x34>
    n = ip->size - off;
    80003b28:	40d78abb          	subw	s5,a5,a3

  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003b2c:	080a8b63          	beqz	s5,80003bc2 <readi+0xca>
    80003b30:	e8ca                	sd	s2,80(sp)
    80003b32:	f062                	sd	s8,32(sp)
    80003b34:	ec66                	sd	s9,24(sp)
    80003b36:	e86a                	sd	s10,16(sp)
    80003b38:	e46e                	sd	s11,8(sp)
    80003b3a:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003b3c:	40000c93          	li	s9,1024
    if(either_copyout(user_dst, dst, bp->data + (off % BSIZE), m) == -1) {
    80003b40:	5c7d                	li	s8,-1
    80003b42:	a80d                	j	80003b74 <readi+0x7c>
    80003b44:	020d1d93          	slli	s11,s10,0x20
    80003b48:	020ddd93          	srli	s11,s11,0x20
    80003b4c:	05890613          	addi	a2,s2,88
    80003b50:	86ee                	mv	a3,s11
    80003b52:	963e                	add	a2,a2,a5
    80003b54:	85d2                	mv	a1,s4
    80003b56:	855e                	mv	a0,s7
    80003b58:	931fe0ef          	jal	80002488 <either_copyout>
    80003b5c:	05850363          	beq	a0,s8,80003ba2 <readi+0xaa>
      brelse(bp);
      tot = -1;
      break;
    }
    brelse(bp);
    80003b60:	854a                	mv	a0,s2
    80003b62:	d24ff0ef          	jal	80003086 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003b66:	013d09bb          	addw	s3,s10,s3
    80003b6a:	009d04bb          	addw	s1,s10,s1
    80003b6e:	9a6e                	add	s4,s4,s11
    80003b70:	0559f363          	bgeu	s3,s5,80003bb6 <readi+0xbe>
    uint addr = bmap(ip, off/BSIZE);
    80003b74:	00a4d59b          	srliw	a1,s1,0xa
    80003b78:	855a                	mv	a0,s6
    80003b7a:	f6aff0ef          	jal	800032e4 <bmap>
    80003b7e:	85aa                	mv	a1,a0
    if(addr == 0)
    80003b80:	c139                	beqz	a0,80003bc6 <readi+0xce>
    bp = bread(ip->dev, addr);
    80003b82:	000b2503          	lw	a0,0(s6)
    80003b86:	bf8ff0ef          	jal	80002f7e <bread>
    80003b8a:	892a                	mv	s2,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003b8c:	3ff4f793          	andi	a5,s1,1023
    80003b90:	40fc873b          	subw	a4,s9,a5
    80003b94:	413a86bb          	subw	a3,s5,s3
    80003b98:	8d3a                	mv	s10,a4
    80003b9a:	fae6f5e3          	bgeu	a3,a4,80003b44 <readi+0x4c>
    80003b9e:	8d36                	mv	s10,a3
    80003ba0:	b755                	j	80003b44 <readi+0x4c>
      brelse(bp);
    80003ba2:	854a                	mv	a0,s2
    80003ba4:	ce2ff0ef          	jal	80003086 <brelse>
      tot = -1;
    80003ba8:	59fd                	li	s3,-1
      break;
    80003baa:	6946                	ld	s2,80(sp)
    80003bac:	7c02                	ld	s8,32(sp)
    80003bae:	6ce2                	ld	s9,24(sp)
    80003bb0:	6d42                	ld	s10,16(sp)
    80003bb2:	6da2                	ld	s11,8(sp)
    80003bb4:	a831                	j	80003bd0 <readi+0xd8>
    80003bb6:	6946                	ld	s2,80(sp)
    80003bb8:	7c02                	ld	s8,32(sp)
    80003bba:	6ce2                	ld	s9,24(sp)
    80003bbc:	6d42                	ld	s10,16(sp)
    80003bbe:	6da2                	ld	s11,8(sp)
    80003bc0:	a801                	j	80003bd0 <readi+0xd8>
  for(tot=0; tot<n; tot+=m, off+=m, dst+=m){
    80003bc2:	89d6                	mv	s3,s5
    80003bc4:	a031                	j	80003bd0 <readi+0xd8>
    80003bc6:	6946                	ld	s2,80(sp)
    80003bc8:	7c02                	ld	s8,32(sp)
    80003bca:	6ce2                	ld	s9,24(sp)
    80003bcc:	6d42                	ld	s10,16(sp)
    80003bce:	6da2                	ld	s11,8(sp)
  }
  return tot;
    80003bd0:	854e                	mv	a0,s3
    80003bd2:	69a6                	ld	s3,72(sp)
}
    80003bd4:	70a6                	ld	ra,104(sp)
    80003bd6:	7406                	ld	s0,96(sp)
    80003bd8:	64e6                	ld	s1,88(sp)
    80003bda:	6a06                	ld	s4,64(sp)
    80003bdc:	7ae2                	ld	s5,56(sp)
    80003bde:	7b42                	ld	s6,48(sp)
    80003be0:	7ba2                	ld	s7,40(sp)
    80003be2:	6165                	addi	sp,sp,112
    80003be4:	8082                	ret
    return 0;
    80003be6:	4501                	li	a0,0
}
    80003be8:	8082                	ret

0000000080003bea <writei>:
writei(struct inode *ip, int user_src, uint64 src, uint off, uint n)
{
  uint tot, m;
  struct buf *bp;

  if(off > ip->size || off + n < off)
    80003bea:	457c                	lw	a5,76(a0)
    80003bec:	0ed7ec63          	bltu	a5,a3,80003ce4 <writei+0xfa>
{
    80003bf0:	7159                	addi	sp,sp,-112
    80003bf2:	f486                	sd	ra,104(sp)
    80003bf4:	f0a2                	sd	s0,96(sp)
    80003bf6:	e8ca                	sd	s2,80(sp)
    80003bf8:	e0d2                	sd	s4,64(sp)
    80003bfa:	fc56                	sd	s5,56(sp)
    80003bfc:	f85a                	sd	s6,48(sp)
    80003bfe:	f45e                	sd	s7,40(sp)
    80003c00:	1880                	addi	s0,sp,112
    80003c02:	8aaa                	mv	s5,a0
    80003c04:	8bae                	mv	s7,a1
    80003c06:	8a32                	mv	s4,a2
    80003c08:	8936                	mv	s2,a3
    80003c0a:	8b3a                	mv	s6,a4
  if(off > ip->size || off + n < off)
    80003c0c:	9f35                	addw	a4,a4,a3
    return -1;
  if(off + n > MAXFILE*BSIZE)
    80003c0e:	040437b7          	lui	a5,0x4043
    80003c12:	c0078793          	addi	a5,a5,-1024 # 4042c00 <_entry-0x7bfbd400>
    80003c16:	0ce7e963          	bltu	a5,a4,80003ce8 <writei+0xfe>
    80003c1a:	0cd76763          	bltu	a4,a3,80003ce8 <writei+0xfe>
    80003c1e:	e4ce                	sd	s3,72(sp)
    return -1;

  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003c20:	0a0b0a63          	beqz	s6,80003cd4 <writei+0xea>
    80003c24:	eca6                	sd	s1,88(sp)
    80003c26:	f062                	sd	s8,32(sp)
    80003c28:	ec66                	sd	s9,24(sp)
    80003c2a:	e86a                	sd	s10,16(sp)
    80003c2c:	e46e                	sd	s11,8(sp)
    80003c2e:	4981                	li	s3,0
    uint addr = bmap(ip, off/BSIZE);
    if(addr == 0)
      break;
    bp = bread(ip->dev, addr);
    m = min(n - tot, BSIZE - off%BSIZE);
    80003c30:	40000c93          	li	s9,1024
    if(either_copyin(bp->data + (off % BSIZE), user_src, src, m) == -1) {
    80003c34:	5c7d                	li	s8,-1
    80003c36:	a825                	j	80003c6e <writei+0x84>
    80003c38:	020d1d93          	slli	s11,s10,0x20
    80003c3c:	020ddd93          	srli	s11,s11,0x20
    80003c40:	05848513          	addi	a0,s1,88
    80003c44:	86ee                	mv	a3,s11
    80003c46:	8652                	mv	a2,s4
    80003c48:	85de                	mv	a1,s7
    80003c4a:	953e                	add	a0,a0,a5
    80003c4c:	887fe0ef          	jal	800024d2 <either_copyin>
    80003c50:	05850663          	beq	a0,s8,80003c9c <writei+0xb2>
      brelse(bp);
      break;
    }
    log_write(bp);
    80003c54:	8526                	mv	a0,s1
    80003c56:	6b8000ef          	jal	8000430e <log_write>
    brelse(bp);
    80003c5a:	8526                	mv	a0,s1
    80003c5c:	c2aff0ef          	jal	80003086 <brelse>
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003c60:	013d09bb          	addw	s3,s10,s3
    80003c64:	012d093b          	addw	s2,s10,s2
    80003c68:	9a6e                	add	s4,s4,s11
    80003c6a:	0369fc63          	bgeu	s3,s6,80003ca2 <writei+0xb8>
    uint addr = bmap(ip, off/BSIZE);
    80003c6e:	00a9559b          	srliw	a1,s2,0xa
    80003c72:	8556                	mv	a0,s5
    80003c74:	e70ff0ef          	jal	800032e4 <bmap>
    80003c78:	85aa                	mv	a1,a0
    if(addr == 0)
    80003c7a:	c505                	beqz	a0,80003ca2 <writei+0xb8>
    bp = bread(ip->dev, addr);
    80003c7c:	000aa503          	lw	a0,0(s5)
    80003c80:	afeff0ef          	jal	80002f7e <bread>
    80003c84:	84aa                	mv	s1,a0
    m = min(n - tot, BSIZE - off%BSIZE);
    80003c86:	3ff97793          	andi	a5,s2,1023
    80003c8a:	40fc873b          	subw	a4,s9,a5
    80003c8e:	413b06bb          	subw	a3,s6,s3
    80003c92:	8d3a                	mv	s10,a4
    80003c94:	fae6f2e3          	bgeu	a3,a4,80003c38 <writei+0x4e>
    80003c98:	8d36                	mv	s10,a3
    80003c9a:	bf79                	j	80003c38 <writei+0x4e>
      brelse(bp);
    80003c9c:	8526                	mv	a0,s1
    80003c9e:	be8ff0ef          	jal	80003086 <brelse>
  }

  if(off > ip->size)
    80003ca2:	04caa783          	lw	a5,76(s5)
    80003ca6:	0327f963          	bgeu	a5,s2,80003cd8 <writei+0xee>
    ip->size = off;
    80003caa:	052aa623          	sw	s2,76(s5)
    80003cae:	64e6                	ld	s1,88(sp)
    80003cb0:	7c02                	ld	s8,32(sp)
    80003cb2:	6ce2                	ld	s9,24(sp)
    80003cb4:	6d42                	ld	s10,16(sp)
    80003cb6:	6da2                	ld	s11,8(sp)

  // write the i-node back to disk even if the size didn't change
  // because the loop above might have called bmap() and added a new
  // block to ip->addrs[].
  iupdate(ip);
    80003cb8:	8556                	mv	a0,s5
    80003cba:	96bff0ef          	jal	80003624 <iupdate>

  return tot;
    80003cbe:	854e                	mv	a0,s3
    80003cc0:	69a6                	ld	s3,72(sp)
}
    80003cc2:	70a6                	ld	ra,104(sp)
    80003cc4:	7406                	ld	s0,96(sp)
    80003cc6:	6946                	ld	s2,80(sp)
    80003cc8:	6a06                	ld	s4,64(sp)
    80003cca:	7ae2                	ld	s5,56(sp)
    80003ccc:	7b42                	ld	s6,48(sp)
    80003cce:	7ba2                	ld	s7,40(sp)
    80003cd0:	6165                	addi	sp,sp,112
    80003cd2:	8082                	ret
  for(tot=0; tot<n; tot+=m, off+=m, src+=m){
    80003cd4:	89da                	mv	s3,s6
    80003cd6:	b7cd                	j	80003cb8 <writei+0xce>
    80003cd8:	64e6                	ld	s1,88(sp)
    80003cda:	7c02                	ld	s8,32(sp)
    80003cdc:	6ce2                	ld	s9,24(sp)
    80003cde:	6d42                	ld	s10,16(sp)
    80003ce0:	6da2                	ld	s11,8(sp)
    80003ce2:	bfd9                	j	80003cb8 <writei+0xce>
    return -1;
    80003ce4:	557d                	li	a0,-1
}
    80003ce6:	8082                	ret
    return -1;
    80003ce8:	557d                	li	a0,-1
    80003cea:	bfe1                	j	80003cc2 <writei+0xd8>

0000000080003cec <namecmp>:

// Directories

int
namecmp(const char *s, const char *t)
{
    80003cec:	1141                	addi	sp,sp,-16
    80003cee:	e406                	sd	ra,8(sp)
    80003cf0:	e022                	sd	s0,0(sp)
    80003cf2:	0800                	addi	s0,sp,16
  return strncmp(s, t, DIRSIZ);
    80003cf4:	4639                	li	a2,14
    80003cf6:	acafd0ef          	jal	80000fc0 <strncmp>
}
    80003cfa:	60a2                	ld	ra,8(sp)
    80003cfc:	6402                	ld	s0,0(sp)
    80003cfe:	0141                	addi	sp,sp,16
    80003d00:	8082                	ret

0000000080003d02 <dirlookup>:

// Look for a directory entry in a directory.
// If found, set *poff to byte offset of entry.
struct inode*
dirlookup(struct inode *dp, char *name, uint *poff)
{
    80003d02:	711d                	addi	sp,sp,-96
    80003d04:	ec86                	sd	ra,88(sp)
    80003d06:	e8a2                	sd	s0,80(sp)
    80003d08:	e4a6                	sd	s1,72(sp)
    80003d0a:	e0ca                	sd	s2,64(sp)
    80003d0c:	fc4e                	sd	s3,56(sp)
    80003d0e:	f852                	sd	s4,48(sp)
    80003d10:	f456                	sd	s5,40(sp)
    80003d12:	f05a                	sd	s6,32(sp)
    80003d14:	ec5e                	sd	s7,24(sp)
    80003d16:	1080                	addi	s0,sp,96
  uint off, inum;
  struct dirent de;

  if(dp->type != T_DIR)
    80003d18:	04451703          	lh	a4,68(a0)
    80003d1c:	4785                	li	a5,1
    80003d1e:	00f71f63          	bne	a4,a5,80003d3c <dirlookup+0x3a>
    80003d22:	892a                	mv	s2,a0
    80003d24:	8aae                	mv	s5,a1
    80003d26:	8bb2                	mv	s7,a2
    panic("dirlookup not DIR");

  for(off = 0; off < dp->size; off += sizeof(de)){
    80003d28:	457c                	lw	a5,76(a0)
    80003d2a:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003d2c:	fa040a13          	addi	s4,s0,-96
    80003d30:	49c1                	li	s3,16
      panic("dirlookup read");
    if(de.inum == 0)
      continue;
    if(namecmp(name, de.name) == 0){
    80003d32:	fa240b13          	addi	s6,s0,-94
      inum = de.inum;
      return iget(dp->dev, inum);
    }
  }

  return 0;
    80003d36:	4501                	li	a0,0
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003d38:	e39d                	bnez	a5,80003d5e <dirlookup+0x5c>
    80003d3a:	a8b9                	j	80003d98 <dirlookup+0x96>
    panic("dirlookup not DIR");
    80003d3c:	00004517          	auipc	a0,0x4
    80003d40:	7f450513          	addi	a0,a0,2036 # 80008530 <etext+0x530>
    80003d44:	ae1fc0ef          	jal	80000824 <panic>
      panic("dirlookup read");
    80003d48:	00005517          	auipc	a0,0x5
    80003d4c:	80050513          	addi	a0,a0,-2048 # 80008548 <etext+0x548>
    80003d50:	ad5fc0ef          	jal	80000824 <panic>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003d54:	24c1                	addiw	s1,s1,16
    80003d56:	04c92783          	lw	a5,76(s2)
    80003d5a:	02f4fe63          	bgeu	s1,a5,80003d96 <dirlookup+0x94>
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003d5e:	874e                	mv	a4,s3
    80003d60:	86a6                	mv	a3,s1
    80003d62:	8652                	mv	a2,s4
    80003d64:	4581                	li	a1,0
    80003d66:	854a                	mv	a0,s2
    80003d68:	d91ff0ef          	jal	80003af8 <readi>
    80003d6c:	fd351ee3          	bne	a0,s3,80003d48 <dirlookup+0x46>
    if(de.inum == 0)
    80003d70:	fa045783          	lhu	a5,-96(s0)
    80003d74:	d3e5                	beqz	a5,80003d54 <dirlookup+0x52>
    if(namecmp(name, de.name) == 0){
    80003d76:	85da                	mv	a1,s6
    80003d78:	8556                	mv	a0,s5
    80003d7a:	f73ff0ef          	jal	80003cec <namecmp>
    80003d7e:	f979                	bnez	a0,80003d54 <dirlookup+0x52>
      if(poff)
    80003d80:	000b8463          	beqz	s7,80003d88 <dirlookup+0x86>
        *poff = off;
    80003d84:	009ba023          	sw	s1,0(s7)
      return iget(dp->dev, inum);
    80003d88:	fa045583          	lhu	a1,-96(s0)
    80003d8c:	00092503          	lw	a0,0(s2)
    80003d90:	ed6ff0ef          	jal	80003466 <iget>
    80003d94:	a011                	j	80003d98 <dirlookup+0x96>
  return 0;
    80003d96:	4501                	li	a0,0
}
    80003d98:	60e6                	ld	ra,88(sp)
    80003d9a:	6446                	ld	s0,80(sp)
    80003d9c:	64a6                	ld	s1,72(sp)
    80003d9e:	6906                	ld	s2,64(sp)
    80003da0:	79e2                	ld	s3,56(sp)
    80003da2:	7a42                	ld	s4,48(sp)
    80003da4:	7aa2                	ld	s5,40(sp)
    80003da6:	7b02                	ld	s6,32(sp)
    80003da8:	6be2                	ld	s7,24(sp)
    80003daa:	6125                	addi	sp,sp,96
    80003dac:	8082                	ret

0000000080003dae <namex>:
// If parent != 0, return the inode for the parent and copy the final
// path element into name, which must have room for DIRSIZ bytes.
// Must be called inside a transaction since it calls iput().
static struct inode*
namex(char *path, int nameiparent, char *name)
{
    80003dae:	711d                	addi	sp,sp,-96
    80003db0:	ec86                	sd	ra,88(sp)
    80003db2:	e8a2                	sd	s0,80(sp)
    80003db4:	e4a6                	sd	s1,72(sp)
    80003db6:	e0ca                	sd	s2,64(sp)
    80003db8:	fc4e                	sd	s3,56(sp)
    80003dba:	f852                	sd	s4,48(sp)
    80003dbc:	f456                	sd	s5,40(sp)
    80003dbe:	f05a                	sd	s6,32(sp)
    80003dc0:	ec5e                	sd	s7,24(sp)
    80003dc2:	e862                	sd	s8,16(sp)
    80003dc4:	e466                	sd	s9,8(sp)
    80003dc6:	e06a                	sd	s10,0(sp)
    80003dc8:	1080                	addi	s0,sp,96
    80003dca:	84aa                	mv	s1,a0
    80003dcc:	8b2e                	mv	s6,a1
    80003dce:	8ab2                	mv	s5,a2
  struct inode *ip, *next;

  if(*path == '/')
    80003dd0:	00054703          	lbu	a4,0(a0)
    80003dd4:	02f00793          	li	a5,47
    80003dd8:	00f70f63          	beq	a4,a5,80003df6 <namex+0x48>
    ip = iget(ROOTDEV, ROOTINO);
  else
    ip = idup(myproc()->cwd);
    80003ddc:	d55fd0ef          	jal	80001b30 <myproc>
    80003de0:	15053503          	ld	a0,336(a0)
    80003de4:	8bfff0ef          	jal	800036a2 <idup>
    80003de8:	8a2a                	mv	s4,a0
  while(*path == '/')
    80003dea:	02f00993          	li	s3,47
  if(len >= DIRSIZ)
    80003dee:	4c35                	li	s8,13
    memmove(name, s, DIRSIZ);
    80003df0:	4cb9                	li	s9,14

  while((path = skipelem(path, name)) != 0){
    ilock(ip);
    if(ip->type != T_DIR){
    80003df2:	4b85                	li	s7,1
    80003df4:	a879                	j	80003e92 <namex+0xe4>
    ip = iget(ROOTDEV, ROOTINO);
    80003df6:	4585                	li	a1,1
    80003df8:	852e                	mv	a0,a1
    80003dfa:	e6cff0ef          	jal	80003466 <iget>
    80003dfe:	8a2a                	mv	s4,a0
    80003e00:	b7ed                	j	80003dea <namex+0x3c>
      iunlockput(ip);
    80003e02:	8552                	mv	a0,s4
    80003e04:	b6fff0ef          	jal	80003972 <iunlockput>
      return 0;
    80003e08:	4a01                	li	s4,0
  if(nameiparent){
    iput(ip);
    return 0;
  }
  return ip;
}
    80003e0a:	8552                	mv	a0,s4
    80003e0c:	60e6                	ld	ra,88(sp)
    80003e0e:	6446                	ld	s0,80(sp)
    80003e10:	64a6                	ld	s1,72(sp)
    80003e12:	6906                	ld	s2,64(sp)
    80003e14:	79e2                	ld	s3,56(sp)
    80003e16:	7a42                	ld	s4,48(sp)
    80003e18:	7aa2                	ld	s5,40(sp)
    80003e1a:	7b02                	ld	s6,32(sp)
    80003e1c:	6be2                	ld	s7,24(sp)
    80003e1e:	6c42                	ld	s8,16(sp)
    80003e20:	6ca2                	ld	s9,8(sp)
    80003e22:	6d02                	ld	s10,0(sp)
    80003e24:	6125                	addi	sp,sp,96
    80003e26:	8082                	ret
      iunlock(ip);
    80003e28:	8552                	mv	a0,s4
    80003e2a:	95dff0ef          	jal	80003786 <iunlock>
      return ip;
    80003e2e:	bff1                	j	80003e0a <namex+0x5c>
      iunlockput(ip);
    80003e30:	8552                	mv	a0,s4
    80003e32:	b41ff0ef          	jal	80003972 <iunlockput>
      return 0;
    80003e36:	8a4a                	mv	s4,s2
    80003e38:	bfc9                	j	80003e0a <namex+0x5c>
  len = path - s;
    80003e3a:	40990633          	sub	a2,s2,s1
    80003e3e:	00060d1b          	sext.w	s10,a2
  if(len >= DIRSIZ)
    80003e42:	09ac5463          	bge	s8,s10,80003eca <namex+0x11c>
    memmove(name, s, DIRSIZ);
    80003e46:	8666                	mv	a2,s9
    80003e48:	85a6                	mv	a1,s1
    80003e4a:	8556                	mv	a0,s5
    80003e4c:	900fd0ef          	jal	80000f4c <memmove>
    80003e50:	84ca                	mv	s1,s2
  while(*path == '/')
    80003e52:	0004c783          	lbu	a5,0(s1)
    80003e56:	01379763          	bne	a5,s3,80003e64 <namex+0xb6>
    path++;
    80003e5a:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003e5c:	0004c783          	lbu	a5,0(s1)
    80003e60:	ff378de3          	beq	a5,s3,80003e5a <namex+0xac>
    ilock(ip);
    80003e64:	8552                	mv	a0,s4
    80003e66:	873ff0ef          	jal	800036d8 <ilock>
    if(ip->type != T_DIR){
    80003e6a:	044a1783          	lh	a5,68(s4)
    80003e6e:	f9779ae3          	bne	a5,s7,80003e02 <namex+0x54>
    if(nameiparent && *path == '\0'){
    80003e72:	000b0563          	beqz	s6,80003e7c <namex+0xce>
    80003e76:	0004c783          	lbu	a5,0(s1)
    80003e7a:	d7dd                	beqz	a5,80003e28 <namex+0x7a>
    if((next = dirlookup(ip, name, 0)) == 0){
    80003e7c:	4601                	li	a2,0
    80003e7e:	85d6                	mv	a1,s5
    80003e80:	8552                	mv	a0,s4
    80003e82:	e81ff0ef          	jal	80003d02 <dirlookup>
    80003e86:	892a                	mv	s2,a0
    80003e88:	d545                	beqz	a0,80003e30 <namex+0x82>
    iunlockput(ip);
    80003e8a:	8552                	mv	a0,s4
    80003e8c:	ae7ff0ef          	jal	80003972 <iunlockput>
    ip = next;
    80003e90:	8a4a                	mv	s4,s2
  while(*path == '/')
    80003e92:	0004c783          	lbu	a5,0(s1)
    80003e96:	01379763          	bne	a5,s3,80003ea4 <namex+0xf6>
    path++;
    80003e9a:	0485                	addi	s1,s1,1
  while(*path == '/')
    80003e9c:	0004c783          	lbu	a5,0(s1)
    80003ea0:	ff378de3          	beq	a5,s3,80003e9a <namex+0xec>
  if(*path == 0)
    80003ea4:	cf8d                	beqz	a5,80003ede <namex+0x130>
  while(*path != '/' && *path != 0)
    80003ea6:	0004c783          	lbu	a5,0(s1)
    80003eaa:	fd178713          	addi	a4,a5,-47
    80003eae:	cb19                	beqz	a4,80003ec4 <namex+0x116>
    80003eb0:	cb91                	beqz	a5,80003ec4 <namex+0x116>
    80003eb2:	8926                	mv	s2,s1
    path++;
    80003eb4:	0905                	addi	s2,s2,1
  while(*path != '/' && *path != 0)
    80003eb6:	00094783          	lbu	a5,0(s2)
    80003eba:	fd178713          	addi	a4,a5,-47
    80003ebe:	df35                	beqz	a4,80003e3a <namex+0x8c>
    80003ec0:	fbf5                	bnez	a5,80003eb4 <namex+0x106>
    80003ec2:	bfa5                	j	80003e3a <namex+0x8c>
    80003ec4:	8926                	mv	s2,s1
  len = path - s;
    80003ec6:	4d01                	li	s10,0
    80003ec8:	4601                	li	a2,0
    memmove(name, s, len);
    80003eca:	2601                	sext.w	a2,a2
    80003ecc:	85a6                	mv	a1,s1
    80003ece:	8556                	mv	a0,s5
    80003ed0:	87cfd0ef          	jal	80000f4c <memmove>
    name[len] = 0;
    80003ed4:	9d56                	add	s10,s10,s5
    80003ed6:	000d0023          	sb	zero,0(s10) # fffffffffffff000 <end+0xffffffff7fd9fe98>
    80003eda:	84ca                	mv	s1,s2
    80003edc:	bf9d                	j	80003e52 <namex+0xa4>
  if(nameiparent){
    80003ede:	f20b06e3          	beqz	s6,80003e0a <namex+0x5c>
    iput(ip);
    80003ee2:	8552                	mv	a0,s4
    80003ee4:	a05ff0ef          	jal	800038e8 <iput>
    return 0;
    80003ee8:	4a01                	li	s4,0
    80003eea:	b705                	j	80003e0a <namex+0x5c>

0000000080003eec <dirlink>:
{
    80003eec:	715d                	addi	sp,sp,-80
    80003eee:	e486                	sd	ra,72(sp)
    80003ef0:	e0a2                	sd	s0,64(sp)
    80003ef2:	f84a                	sd	s2,48(sp)
    80003ef4:	ec56                	sd	s5,24(sp)
    80003ef6:	e85a                	sd	s6,16(sp)
    80003ef8:	0880                	addi	s0,sp,80
    80003efa:	892a                	mv	s2,a0
    80003efc:	8aae                	mv	s5,a1
    80003efe:	8b32                	mv	s6,a2
  if((ip = dirlookup(dp, name, 0)) != 0){
    80003f00:	4601                	li	a2,0
    80003f02:	e01ff0ef          	jal	80003d02 <dirlookup>
    80003f06:	ed1d                	bnez	a0,80003f44 <dirlink+0x58>
    80003f08:	fc26                	sd	s1,56(sp)
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003f0a:	04c92483          	lw	s1,76(s2)
    80003f0e:	c4b9                	beqz	s1,80003f5c <dirlink+0x70>
    80003f10:	f44e                	sd	s3,40(sp)
    80003f12:	f052                	sd	s4,32(sp)
    80003f14:	4481                	li	s1,0
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003f16:	fb040a13          	addi	s4,s0,-80
    80003f1a:	49c1                	li	s3,16
    80003f1c:	874e                	mv	a4,s3
    80003f1e:	86a6                	mv	a3,s1
    80003f20:	8652                	mv	a2,s4
    80003f22:	4581                	li	a1,0
    80003f24:	854a                	mv	a0,s2
    80003f26:	bd3ff0ef          	jal	80003af8 <readi>
    80003f2a:	03351163          	bne	a0,s3,80003f4c <dirlink+0x60>
    if(de.inum == 0)
    80003f2e:	fb045783          	lhu	a5,-80(s0)
    80003f32:	c39d                	beqz	a5,80003f58 <dirlink+0x6c>
  for(off = 0; off < dp->size; off += sizeof(de)){
    80003f34:	24c1                	addiw	s1,s1,16
    80003f36:	04c92783          	lw	a5,76(s2)
    80003f3a:	fef4e1e3          	bltu	s1,a5,80003f1c <dirlink+0x30>
    80003f3e:	79a2                	ld	s3,40(sp)
    80003f40:	7a02                	ld	s4,32(sp)
    80003f42:	a829                	j	80003f5c <dirlink+0x70>
    iput(ip);
    80003f44:	9a5ff0ef          	jal	800038e8 <iput>
    return -1;
    80003f48:	557d                	li	a0,-1
    80003f4a:	a83d                	j	80003f88 <dirlink+0x9c>
      panic("dirlink read");
    80003f4c:	00004517          	auipc	a0,0x4
    80003f50:	60c50513          	addi	a0,a0,1548 # 80008558 <etext+0x558>
    80003f54:	8d1fc0ef          	jal	80000824 <panic>
    80003f58:	79a2                	ld	s3,40(sp)
    80003f5a:	7a02                	ld	s4,32(sp)
  strncpy(de.name, name, DIRSIZ);
    80003f5c:	4639                	li	a2,14
    80003f5e:	85d6                	mv	a1,s5
    80003f60:	fb240513          	addi	a0,s0,-78
    80003f64:	896fd0ef          	jal	80000ffa <strncpy>
  de.inum = inum;
    80003f68:	fb641823          	sh	s6,-80(s0)
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80003f6c:	4741                	li	a4,16
    80003f6e:	86a6                	mv	a3,s1
    80003f70:	fb040613          	addi	a2,s0,-80
    80003f74:	4581                	li	a1,0
    80003f76:	854a                	mv	a0,s2
    80003f78:	c73ff0ef          	jal	80003bea <writei>
    80003f7c:	1541                	addi	a0,a0,-16
    80003f7e:	00a03533          	snez	a0,a0
    80003f82:	40a0053b          	negw	a0,a0
    80003f86:	74e2                	ld	s1,56(sp)
}
    80003f88:	60a6                	ld	ra,72(sp)
    80003f8a:	6406                	ld	s0,64(sp)
    80003f8c:	7942                	ld	s2,48(sp)
    80003f8e:	6ae2                	ld	s5,24(sp)
    80003f90:	6b42                	ld	s6,16(sp)
    80003f92:	6161                	addi	sp,sp,80
    80003f94:	8082                	ret

0000000080003f96 <namei>:

struct inode*
namei(char *path)
{
    80003f96:	1101                	addi	sp,sp,-32
    80003f98:	ec06                	sd	ra,24(sp)
    80003f9a:	e822                	sd	s0,16(sp)
    80003f9c:	1000                	addi	s0,sp,32
  char name[DIRSIZ];
  return namex(path, 0, name);
    80003f9e:	fe040613          	addi	a2,s0,-32
    80003fa2:	4581                	li	a1,0
    80003fa4:	e0bff0ef          	jal	80003dae <namex>
}
    80003fa8:	60e2                	ld	ra,24(sp)
    80003faa:	6442                	ld	s0,16(sp)
    80003fac:	6105                	addi	sp,sp,32
    80003fae:	8082                	ret

0000000080003fb0 <nameiparent>:

struct inode*
nameiparent(char *path, char *name)
{
    80003fb0:	1141                	addi	sp,sp,-16
    80003fb2:	e406                	sd	ra,8(sp)
    80003fb4:	e022                	sd	s0,0(sp)
    80003fb6:	0800                	addi	s0,sp,16
    80003fb8:	862e                	mv	a2,a1
  return namex(path, 1, name);
    80003fba:	4585                	li	a1,1
    80003fbc:	df3ff0ef          	jal	80003dae <namex>
    80003fc0:	60a2                	ld	ra,8(sp)
    80003fc2:	6402                	ld	s0,0(sp)
    80003fc4:	0141                	addi	sp,sp,16
    80003fc6:	8082                	ret

0000000080003fc8 <write_head>:
// Write in-memory log header to disk.
// This is the true point at which the
// current transaction commits.
static void
write_head(void)
{
    80003fc8:	1101                	addi	sp,sp,-32
    80003fca:	ec06                	sd	ra,24(sp)
    80003fcc:	e822                	sd	s0,16(sp)
    80003fce:	e426                	sd	s1,8(sp)
    80003fd0:	e04a                	sd	s2,0(sp)
    80003fd2:	1000                	addi	s0,sp,32
  struct buf *buf = bread(log.dev, log.start);
    80003fd4:	0023d917          	auipc	s2,0x23d
    80003fd8:	a9490913          	addi	s2,s2,-1388 # 80240a68 <log>
    80003fdc:	01892583          	lw	a1,24(s2)
    80003fe0:	02492503          	lw	a0,36(s2)
    80003fe4:	f9bfe0ef          	jal	80002f7e <bread>
    80003fe8:	84aa                	mv	s1,a0
  struct logheader *hb = (struct logheader *) (buf->data);
  int i;
  hb->n = log.lh.n;
    80003fea:	02892603          	lw	a2,40(s2)
    80003fee:	cd30                	sw	a2,88(a0)
  for (i = 0; i < log.lh.n; i++) {
    80003ff0:	00c05f63          	blez	a2,8000400e <write_head+0x46>
    80003ff4:	0023d717          	auipc	a4,0x23d
    80003ff8:	aa070713          	addi	a4,a4,-1376 # 80240a94 <log+0x2c>
    80003ffc:	87aa                	mv	a5,a0
    80003ffe:	060a                	slli	a2,a2,0x2
    80004000:	962a                	add	a2,a2,a0
    hb->block[i] = log.lh.block[i];
    80004002:	4314                	lw	a3,0(a4)
    80004004:	cff4                	sw	a3,92(a5)
  for (i = 0; i < log.lh.n; i++) {
    80004006:	0711                	addi	a4,a4,4
    80004008:	0791                	addi	a5,a5,4
    8000400a:	fec79ce3          	bne	a5,a2,80004002 <write_head+0x3a>
  }
  bwrite(buf);
    8000400e:	8526                	mv	a0,s1
    80004010:	844ff0ef          	jal	80003054 <bwrite>
  brelse(buf);
    80004014:	8526                	mv	a0,s1
    80004016:	870ff0ef          	jal	80003086 <brelse>
}
    8000401a:	60e2                	ld	ra,24(sp)
    8000401c:	6442                	ld	s0,16(sp)
    8000401e:	64a2                	ld	s1,8(sp)
    80004020:	6902                	ld	s2,0(sp)
    80004022:	6105                	addi	sp,sp,32
    80004024:	8082                	ret

0000000080004026 <install_trans>:
  for (tail = 0; tail < log.lh.n; tail++) {
    80004026:	0023d797          	auipc	a5,0x23d
    8000402a:	a6a7a783          	lw	a5,-1430(a5) # 80240a90 <log+0x28>
    8000402e:	0cf05163          	blez	a5,800040f0 <install_trans+0xca>
{
    80004032:	715d                	addi	sp,sp,-80
    80004034:	e486                	sd	ra,72(sp)
    80004036:	e0a2                	sd	s0,64(sp)
    80004038:	fc26                	sd	s1,56(sp)
    8000403a:	f84a                	sd	s2,48(sp)
    8000403c:	f44e                	sd	s3,40(sp)
    8000403e:	f052                	sd	s4,32(sp)
    80004040:	ec56                	sd	s5,24(sp)
    80004042:	e85a                	sd	s6,16(sp)
    80004044:	e45e                	sd	s7,8(sp)
    80004046:	e062                	sd	s8,0(sp)
    80004048:	0880                	addi	s0,sp,80
    8000404a:	8b2a                	mv	s6,a0
    8000404c:	0023da97          	auipc	s5,0x23d
    80004050:	a48a8a93          	addi	s5,s5,-1464 # 80240a94 <log+0x2c>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004054:	4981                	li	s3,0
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    80004056:	00004c17          	auipc	s8,0x4
    8000405a:	512c0c13          	addi	s8,s8,1298 # 80008568 <etext+0x568>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    8000405e:	0023da17          	auipc	s4,0x23d
    80004062:	a0aa0a13          	addi	s4,s4,-1526 # 80240a68 <log>
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    80004066:	40000b93          	li	s7,1024
    8000406a:	a025                	j	80004092 <install_trans+0x6c>
      printf("recovering tail %d dst %d\n", tail, log.lh.block[tail]);
    8000406c:	000aa603          	lw	a2,0(s5)
    80004070:	85ce                	mv	a1,s3
    80004072:	8562                	mv	a0,s8
    80004074:	c86fc0ef          	jal	800004fa <printf>
    80004078:	a839                	j	80004096 <install_trans+0x70>
    brelse(lbuf);
    8000407a:	854a                	mv	a0,s2
    8000407c:	80aff0ef          	jal	80003086 <brelse>
    brelse(dbuf);
    80004080:	8526                	mv	a0,s1
    80004082:	804ff0ef          	jal	80003086 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    80004086:	2985                	addiw	s3,s3,1
    80004088:	0a91                	addi	s5,s5,4
    8000408a:	028a2783          	lw	a5,40(s4)
    8000408e:	04f9d563          	bge	s3,a5,800040d8 <install_trans+0xb2>
    if(recovering) {
    80004092:	fc0b1de3          	bnez	s6,8000406c <install_trans+0x46>
    struct buf *lbuf = bread(log.dev, log.start+tail+1); // read log block
    80004096:	018a2583          	lw	a1,24(s4)
    8000409a:	013585bb          	addw	a1,a1,s3
    8000409e:	2585                	addiw	a1,a1,1
    800040a0:	024a2503          	lw	a0,36(s4)
    800040a4:	edbfe0ef          	jal	80002f7e <bread>
    800040a8:	892a                	mv	s2,a0
    struct buf *dbuf = bread(log.dev, log.lh.block[tail]); // read dst
    800040aa:	000aa583          	lw	a1,0(s5)
    800040ae:	024a2503          	lw	a0,36(s4)
    800040b2:	ecdfe0ef          	jal	80002f7e <bread>
    800040b6:	84aa                	mv	s1,a0
    memmove(dbuf->data, lbuf->data, BSIZE);  // copy block to dst
    800040b8:	865e                	mv	a2,s7
    800040ba:	05890593          	addi	a1,s2,88
    800040be:	05850513          	addi	a0,a0,88
    800040c2:	e8bfc0ef          	jal	80000f4c <memmove>
    bwrite(dbuf);  // write dst to disk
    800040c6:	8526                	mv	a0,s1
    800040c8:	f8dfe0ef          	jal	80003054 <bwrite>
    if(recovering == 0)
    800040cc:	fa0b17e3          	bnez	s6,8000407a <install_trans+0x54>
      bunpin(dbuf);
    800040d0:	8526                	mv	a0,s1
    800040d2:	86cff0ef          	jal	8000313e <bunpin>
    800040d6:	b755                	j	8000407a <install_trans+0x54>
}
    800040d8:	60a6                	ld	ra,72(sp)
    800040da:	6406                	ld	s0,64(sp)
    800040dc:	74e2                	ld	s1,56(sp)
    800040de:	7942                	ld	s2,48(sp)
    800040e0:	79a2                	ld	s3,40(sp)
    800040e2:	7a02                	ld	s4,32(sp)
    800040e4:	6ae2                	ld	s5,24(sp)
    800040e6:	6b42                	ld	s6,16(sp)
    800040e8:	6ba2                	ld	s7,8(sp)
    800040ea:	6c02                	ld	s8,0(sp)
    800040ec:	6161                	addi	sp,sp,80
    800040ee:	8082                	ret
    800040f0:	8082                	ret

00000000800040f2 <initlog>:
{
    800040f2:	7179                	addi	sp,sp,-48
    800040f4:	f406                	sd	ra,40(sp)
    800040f6:	f022                	sd	s0,32(sp)
    800040f8:	ec26                	sd	s1,24(sp)
    800040fa:	e84a                	sd	s2,16(sp)
    800040fc:	e44e                	sd	s3,8(sp)
    800040fe:	1800                	addi	s0,sp,48
    80004100:	84aa                	mv	s1,a0
    80004102:	89ae                	mv	s3,a1
  initlock(&log.lock, "log");
    80004104:	0023d917          	auipc	s2,0x23d
    80004108:	96490913          	addi	s2,s2,-1692 # 80240a68 <log>
    8000410c:	00004597          	auipc	a1,0x4
    80004110:	47c58593          	addi	a1,a1,1148 # 80008588 <etext+0x588>
    80004114:	854a                	mv	a0,s2
    80004116:	c7dfc0ef          	jal	80000d92 <initlock>
  log.start = sb->logstart;
    8000411a:	0149a583          	lw	a1,20(s3)
    8000411e:	00b92c23          	sw	a1,24(s2)
  log.dev = dev;
    80004122:	02992223          	sw	s1,36(s2)
  struct buf *buf = bread(log.dev, log.start);
    80004126:	8526                	mv	a0,s1
    80004128:	e57fe0ef          	jal	80002f7e <bread>
  log.lh.n = lh->n;
    8000412c:	4d30                	lw	a2,88(a0)
    8000412e:	02c92423          	sw	a2,40(s2)
  for (i = 0; i < log.lh.n; i++) {
    80004132:	00c05f63          	blez	a2,80004150 <initlog+0x5e>
    80004136:	87aa                	mv	a5,a0
    80004138:	0023d717          	auipc	a4,0x23d
    8000413c:	95c70713          	addi	a4,a4,-1700 # 80240a94 <log+0x2c>
    80004140:	060a                	slli	a2,a2,0x2
    80004142:	962a                	add	a2,a2,a0
    log.lh.block[i] = lh->block[i];
    80004144:	4ff4                	lw	a3,92(a5)
    80004146:	c314                	sw	a3,0(a4)
  for (i = 0; i < log.lh.n; i++) {
    80004148:	0791                	addi	a5,a5,4
    8000414a:	0711                	addi	a4,a4,4
    8000414c:	fec79ce3          	bne	a5,a2,80004144 <initlog+0x52>
  brelse(buf);
    80004150:	f37fe0ef          	jal	80003086 <brelse>

static void
recover_from_log(void)
{
  read_head();
  install_trans(1); // if committed, copy from log to disk
    80004154:	4505                	li	a0,1
    80004156:	ed1ff0ef          	jal	80004026 <install_trans>
  log.lh.n = 0;
    8000415a:	0023d797          	auipc	a5,0x23d
    8000415e:	9207ab23          	sw	zero,-1738(a5) # 80240a90 <log+0x28>
  write_head(); // clear the log
    80004162:	e67ff0ef          	jal	80003fc8 <write_head>
}
    80004166:	70a2                	ld	ra,40(sp)
    80004168:	7402                	ld	s0,32(sp)
    8000416a:	64e2                	ld	s1,24(sp)
    8000416c:	6942                	ld	s2,16(sp)
    8000416e:	69a2                	ld	s3,8(sp)
    80004170:	6145                	addi	sp,sp,48
    80004172:	8082                	ret

0000000080004174 <begin_op>:
}

// called at the start of each FS system call.
void
begin_op(void)
{
    80004174:	1101                	addi	sp,sp,-32
    80004176:	ec06                	sd	ra,24(sp)
    80004178:	e822                	sd	s0,16(sp)
    8000417a:	e426                	sd	s1,8(sp)
    8000417c:	e04a                	sd	s2,0(sp)
    8000417e:	1000                	addi	s0,sp,32
  acquire(&log.lock);
    80004180:	0023d517          	auipc	a0,0x23d
    80004184:	8e850513          	addi	a0,a0,-1816 # 80240a68 <log>
    80004188:	c95fc0ef          	jal	80000e1c <acquire>
  while(1){
    if(log.committing){
    8000418c:	0023d497          	auipc	s1,0x23d
    80004190:	8dc48493          	addi	s1,s1,-1828 # 80240a68 <log>
      sleep(&log, &log.lock);
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    80004194:	4979                	li	s2,30
    80004196:	a029                	j	800041a0 <begin_op+0x2c>
      sleep(&log, &log.lock);
    80004198:	85a6                	mv	a1,s1
    8000419a:	8526                	mv	a0,s1
    8000419c:	f93fd0ef          	jal	8000212e <sleep>
    if(log.committing){
    800041a0:	509c                	lw	a5,32(s1)
    800041a2:	fbfd                	bnez	a5,80004198 <begin_op+0x24>
    } else if(log.lh.n + (log.outstanding+1)*MAXOPBLOCKS > LOGBLOCKS){
    800041a4:	4cd8                	lw	a4,28(s1)
    800041a6:	2705                	addiw	a4,a4,1
    800041a8:	0027179b          	slliw	a5,a4,0x2
    800041ac:	9fb9                	addw	a5,a5,a4
    800041ae:	0017979b          	slliw	a5,a5,0x1
    800041b2:	5494                	lw	a3,40(s1)
    800041b4:	9fb5                	addw	a5,a5,a3
    800041b6:	00f95763          	bge	s2,a5,800041c4 <begin_op+0x50>
      // this op might exhaust log space; wait for commit.
      sleep(&log, &log.lock);
    800041ba:	85a6                	mv	a1,s1
    800041bc:	8526                	mv	a0,s1
    800041be:	f71fd0ef          	jal	8000212e <sleep>
    800041c2:	bff9                	j	800041a0 <begin_op+0x2c>
    } else {
      log.outstanding += 1;
    800041c4:	0023d797          	auipc	a5,0x23d
    800041c8:	8ce7a023          	sw	a4,-1856(a5) # 80240a84 <log+0x1c>
      release(&log.lock);
    800041cc:	0023d517          	auipc	a0,0x23d
    800041d0:	89c50513          	addi	a0,a0,-1892 # 80240a68 <log>
    800041d4:	cddfc0ef          	jal	80000eb0 <release>
      break;
    }
  }
}
    800041d8:	60e2                	ld	ra,24(sp)
    800041da:	6442                	ld	s0,16(sp)
    800041dc:	64a2                	ld	s1,8(sp)
    800041de:	6902                	ld	s2,0(sp)
    800041e0:	6105                	addi	sp,sp,32
    800041e2:	8082                	ret

00000000800041e4 <end_op>:

// called at the end of each FS system call.
// commits if this was the last outstanding operation.
void
end_op(void)
{
    800041e4:	7139                	addi	sp,sp,-64
    800041e6:	fc06                	sd	ra,56(sp)
    800041e8:	f822                	sd	s0,48(sp)
    800041ea:	f426                	sd	s1,40(sp)
    800041ec:	f04a                	sd	s2,32(sp)
    800041ee:	0080                	addi	s0,sp,64
  int do_commit = 0;

  acquire(&log.lock);
    800041f0:	0023d497          	auipc	s1,0x23d
    800041f4:	87848493          	addi	s1,s1,-1928 # 80240a68 <log>
    800041f8:	8526                	mv	a0,s1
    800041fa:	c23fc0ef          	jal	80000e1c <acquire>
  log.outstanding -= 1;
    800041fe:	4cdc                	lw	a5,28(s1)
    80004200:	37fd                	addiw	a5,a5,-1
    80004202:	893e                	mv	s2,a5
    80004204:	ccdc                	sw	a5,28(s1)
  if(log.committing)
    80004206:	509c                	lw	a5,32(s1)
    80004208:	e7b1                	bnez	a5,80004254 <end_op+0x70>
    panic("log.committing");
  if(log.outstanding == 0){
    8000420a:	04091e63          	bnez	s2,80004266 <end_op+0x82>
    do_commit = 1;
    log.committing = 1;
    8000420e:	0023d497          	auipc	s1,0x23d
    80004212:	85a48493          	addi	s1,s1,-1958 # 80240a68 <log>
    80004216:	4785                	li	a5,1
    80004218:	d09c                	sw	a5,32(s1)
    // begin_op() may be waiting for log space,
    // and decrementing log.outstanding has decreased
    // the amount of reserved space.
    wakeup(&log);
  }
  release(&log.lock);
    8000421a:	8526                	mv	a0,s1
    8000421c:	c95fc0ef          	jal	80000eb0 <release>
}

static void
commit()
{
  if (log.lh.n > 0) {
    80004220:	549c                	lw	a5,40(s1)
    80004222:	06f04463          	bgtz	a5,8000428a <end_op+0xa6>
    acquire(&log.lock);
    80004226:	0023d517          	auipc	a0,0x23d
    8000422a:	84250513          	addi	a0,a0,-1982 # 80240a68 <log>
    8000422e:	beffc0ef          	jal	80000e1c <acquire>
    log.committing = 0;
    80004232:	0023d797          	auipc	a5,0x23d
    80004236:	8407ab23          	sw	zero,-1962(a5) # 80240a88 <log+0x20>
    wakeup(&log);
    8000423a:	0023d517          	auipc	a0,0x23d
    8000423e:	82e50513          	addi	a0,a0,-2002 # 80240a68 <log>
    80004242:	f39fd0ef          	jal	8000217a <wakeup>
    release(&log.lock);
    80004246:	0023d517          	auipc	a0,0x23d
    8000424a:	82250513          	addi	a0,a0,-2014 # 80240a68 <log>
    8000424e:	c63fc0ef          	jal	80000eb0 <release>
}
    80004252:	a035                	j	8000427e <end_op+0x9a>
    80004254:	ec4e                	sd	s3,24(sp)
    80004256:	e852                	sd	s4,16(sp)
    80004258:	e456                	sd	s5,8(sp)
    panic("log.committing");
    8000425a:	00004517          	auipc	a0,0x4
    8000425e:	33650513          	addi	a0,a0,822 # 80008590 <etext+0x590>
    80004262:	dc2fc0ef          	jal	80000824 <panic>
    wakeup(&log);
    80004266:	0023d517          	auipc	a0,0x23d
    8000426a:	80250513          	addi	a0,a0,-2046 # 80240a68 <log>
    8000426e:	f0dfd0ef          	jal	8000217a <wakeup>
  release(&log.lock);
    80004272:	0023c517          	auipc	a0,0x23c
    80004276:	7f650513          	addi	a0,a0,2038 # 80240a68 <log>
    8000427a:	c37fc0ef          	jal	80000eb0 <release>
}
    8000427e:	70e2                	ld	ra,56(sp)
    80004280:	7442                	ld	s0,48(sp)
    80004282:	74a2                	ld	s1,40(sp)
    80004284:	7902                	ld	s2,32(sp)
    80004286:	6121                	addi	sp,sp,64
    80004288:	8082                	ret
    8000428a:	ec4e                	sd	s3,24(sp)
    8000428c:	e852                	sd	s4,16(sp)
    8000428e:	e456                	sd	s5,8(sp)
  for (tail = 0; tail < log.lh.n; tail++) {
    80004290:	0023da97          	auipc	s5,0x23d
    80004294:	804a8a93          	addi	s5,s5,-2044 # 80240a94 <log+0x2c>
    struct buf *to = bread(log.dev, log.start+tail+1); // log block
    80004298:	0023ca17          	auipc	s4,0x23c
    8000429c:	7d0a0a13          	addi	s4,s4,2000 # 80240a68 <log>
    800042a0:	018a2583          	lw	a1,24(s4)
    800042a4:	012585bb          	addw	a1,a1,s2
    800042a8:	2585                	addiw	a1,a1,1
    800042aa:	024a2503          	lw	a0,36(s4)
    800042ae:	cd1fe0ef          	jal	80002f7e <bread>
    800042b2:	84aa                	mv	s1,a0
    struct buf *from = bread(log.dev, log.lh.block[tail]); // cache block
    800042b4:	000aa583          	lw	a1,0(s5)
    800042b8:	024a2503          	lw	a0,36(s4)
    800042bc:	cc3fe0ef          	jal	80002f7e <bread>
    800042c0:	89aa                	mv	s3,a0
    memmove(to->data, from->data, BSIZE);
    800042c2:	40000613          	li	a2,1024
    800042c6:	05850593          	addi	a1,a0,88
    800042ca:	05848513          	addi	a0,s1,88
    800042ce:	c7ffc0ef          	jal	80000f4c <memmove>
    bwrite(to);  // write the log
    800042d2:	8526                	mv	a0,s1
    800042d4:	d81fe0ef          	jal	80003054 <bwrite>
    brelse(from);
    800042d8:	854e                	mv	a0,s3
    800042da:	dadfe0ef          	jal	80003086 <brelse>
    brelse(to);
    800042de:	8526                	mv	a0,s1
    800042e0:	da7fe0ef          	jal	80003086 <brelse>
  for (tail = 0; tail < log.lh.n; tail++) {
    800042e4:	2905                	addiw	s2,s2,1
    800042e6:	0a91                	addi	s5,s5,4
    800042e8:	028a2783          	lw	a5,40(s4)
    800042ec:	faf94ae3          	blt	s2,a5,800042a0 <end_op+0xbc>
    write_log();     // Write modified blocks from cache to log
    write_head();    // Write header to disk -- the real commit
    800042f0:	cd9ff0ef          	jal	80003fc8 <write_head>
    install_trans(0); // Now install writes to home locations
    800042f4:	4501                	li	a0,0
    800042f6:	d31ff0ef          	jal	80004026 <install_trans>
    log.lh.n = 0;
    800042fa:	0023c797          	auipc	a5,0x23c
    800042fe:	7807ab23          	sw	zero,1942(a5) # 80240a90 <log+0x28>
    write_head();    // Erase the transaction from the log
    80004302:	cc7ff0ef          	jal	80003fc8 <write_head>
    80004306:	69e2                	ld	s3,24(sp)
    80004308:	6a42                	ld	s4,16(sp)
    8000430a:	6aa2                	ld	s5,8(sp)
    8000430c:	bf29                	j	80004226 <end_op+0x42>

000000008000430e <log_write>:
//   modify bp->data[]
//   log_write(bp)
//   brelse(bp)
void
log_write(struct buf *b)
{
    8000430e:	1101                	addi	sp,sp,-32
    80004310:	ec06                	sd	ra,24(sp)
    80004312:	e822                	sd	s0,16(sp)
    80004314:	e426                	sd	s1,8(sp)
    80004316:	1000                	addi	s0,sp,32
    80004318:	84aa                	mv	s1,a0
  int i;

  acquire(&log.lock);
    8000431a:	0023c517          	auipc	a0,0x23c
    8000431e:	74e50513          	addi	a0,a0,1870 # 80240a68 <log>
    80004322:	afbfc0ef          	jal	80000e1c <acquire>
  if (log.lh.n >= LOGBLOCKS)
    80004326:	0023c617          	auipc	a2,0x23c
    8000432a:	76a62603          	lw	a2,1898(a2) # 80240a90 <log+0x28>
    8000432e:	47f5                	li	a5,29
    80004330:	04c7cd63          	blt	a5,a2,8000438a <log_write+0x7c>
    panic("too big a transaction");
  if (log.outstanding < 1)
    80004334:	0023c797          	auipc	a5,0x23c
    80004338:	7507a783          	lw	a5,1872(a5) # 80240a84 <log+0x1c>
    8000433c:	04f05d63          	blez	a5,80004396 <log_write+0x88>
    panic("log_write outside of trans");

  for (i = 0; i < log.lh.n; i++) {
    80004340:	4781                	li	a5,0
    80004342:	06c05063          	blez	a2,800043a2 <log_write+0x94>
    if (log.lh.block[i] == b->blockno)   // log absorption
    80004346:	44cc                	lw	a1,12(s1)
    80004348:	0023c717          	auipc	a4,0x23c
    8000434c:	74c70713          	addi	a4,a4,1868 # 80240a94 <log+0x2c>
  for (i = 0; i < log.lh.n; i++) {
    80004350:	4781                	li	a5,0
    if (log.lh.block[i] == b->blockno)   // log absorption
    80004352:	4314                	lw	a3,0(a4)
    80004354:	04b68763          	beq	a3,a1,800043a2 <log_write+0x94>
  for (i = 0; i < log.lh.n; i++) {
    80004358:	2785                	addiw	a5,a5,1
    8000435a:	0711                	addi	a4,a4,4
    8000435c:	fef61be3          	bne	a2,a5,80004352 <log_write+0x44>
      break;
  }
  log.lh.block[i] = b->blockno;
    80004360:	060a                	slli	a2,a2,0x2
    80004362:	02060613          	addi	a2,a2,32
    80004366:	0023c797          	auipc	a5,0x23c
    8000436a:	70278793          	addi	a5,a5,1794 # 80240a68 <log>
    8000436e:	97b2                	add	a5,a5,a2
    80004370:	44d8                	lw	a4,12(s1)
    80004372:	c7d8                	sw	a4,12(a5)
  if (i == log.lh.n) {  // Add new block to log?
    bpin(b);
    80004374:	8526                	mv	a0,s1
    80004376:	d95fe0ef          	jal	8000310a <bpin>
    log.lh.n++;
    8000437a:	0023c717          	auipc	a4,0x23c
    8000437e:	6ee70713          	addi	a4,a4,1774 # 80240a68 <log>
    80004382:	571c                	lw	a5,40(a4)
    80004384:	2785                	addiw	a5,a5,1
    80004386:	d71c                	sw	a5,40(a4)
    80004388:	a815                	j	800043bc <log_write+0xae>
    panic("too big a transaction");
    8000438a:	00004517          	auipc	a0,0x4
    8000438e:	21650513          	addi	a0,a0,534 # 800085a0 <etext+0x5a0>
    80004392:	c92fc0ef          	jal	80000824 <panic>
    panic("log_write outside of trans");
    80004396:	00004517          	auipc	a0,0x4
    8000439a:	22250513          	addi	a0,a0,546 # 800085b8 <etext+0x5b8>
    8000439e:	c86fc0ef          	jal	80000824 <panic>
  log.lh.block[i] = b->blockno;
    800043a2:	00279693          	slli	a3,a5,0x2
    800043a6:	02068693          	addi	a3,a3,32
    800043aa:	0023c717          	auipc	a4,0x23c
    800043ae:	6be70713          	addi	a4,a4,1726 # 80240a68 <log>
    800043b2:	9736                	add	a4,a4,a3
    800043b4:	44d4                	lw	a3,12(s1)
    800043b6:	c754                	sw	a3,12(a4)
  if (i == log.lh.n) {  // Add new block to log?
    800043b8:	faf60ee3          	beq	a2,a5,80004374 <log_write+0x66>
  }
  release(&log.lock);
    800043bc:	0023c517          	auipc	a0,0x23c
    800043c0:	6ac50513          	addi	a0,a0,1708 # 80240a68 <log>
    800043c4:	aedfc0ef          	jal	80000eb0 <release>
}
    800043c8:	60e2                	ld	ra,24(sp)
    800043ca:	6442                	ld	s0,16(sp)
    800043cc:	64a2                	ld	s1,8(sp)
    800043ce:	6105                	addi	sp,sp,32
    800043d0:	8082                	ret

00000000800043d2 <initsleeplock>:
#include "proc.h"
#include "sleeplock.h"

void
initsleeplock(struct sleeplock *lk, char *name)
{
    800043d2:	1101                	addi	sp,sp,-32
    800043d4:	ec06                	sd	ra,24(sp)
    800043d6:	e822                	sd	s0,16(sp)
    800043d8:	e426                	sd	s1,8(sp)
    800043da:	e04a                	sd	s2,0(sp)
    800043dc:	1000                	addi	s0,sp,32
    800043de:	84aa                	mv	s1,a0
    800043e0:	892e                	mv	s2,a1
  initlock(&lk->lk, "sleep lock");
    800043e2:	00004597          	auipc	a1,0x4
    800043e6:	1f658593          	addi	a1,a1,502 # 800085d8 <etext+0x5d8>
    800043ea:	0521                	addi	a0,a0,8
    800043ec:	9a7fc0ef          	jal	80000d92 <initlock>
  lk->name = name;
    800043f0:	0324b023          	sd	s2,32(s1)
  lk->locked = 0;
    800043f4:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    800043f8:	0204a423          	sw	zero,40(s1)
}
    800043fc:	60e2                	ld	ra,24(sp)
    800043fe:	6442                	ld	s0,16(sp)
    80004400:	64a2                	ld	s1,8(sp)
    80004402:	6902                	ld	s2,0(sp)
    80004404:	6105                	addi	sp,sp,32
    80004406:	8082                	ret

0000000080004408 <acquiresleep>:

void
acquiresleep(struct sleeplock *lk)
{
    80004408:	1101                	addi	sp,sp,-32
    8000440a:	ec06                	sd	ra,24(sp)
    8000440c:	e822                	sd	s0,16(sp)
    8000440e:	e426                	sd	s1,8(sp)
    80004410:	e04a                	sd	s2,0(sp)
    80004412:	1000                	addi	s0,sp,32
    80004414:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    80004416:	00850913          	addi	s2,a0,8
    8000441a:	854a                	mv	a0,s2
    8000441c:	a01fc0ef          	jal	80000e1c <acquire>
  while (lk->locked) {
    80004420:	409c                	lw	a5,0(s1)
    80004422:	c799                	beqz	a5,80004430 <acquiresleep+0x28>
    sleep(lk, &lk->lk);
    80004424:	85ca                	mv	a1,s2
    80004426:	8526                	mv	a0,s1
    80004428:	d07fd0ef          	jal	8000212e <sleep>
  while (lk->locked) {
    8000442c:	409c                	lw	a5,0(s1)
    8000442e:	fbfd                	bnez	a5,80004424 <acquiresleep+0x1c>
  }
  lk->locked = 1;
    80004430:	4785                	li	a5,1
    80004432:	c09c                	sw	a5,0(s1)
  lk->pid = myproc()->pid;
    80004434:	efcfd0ef          	jal	80001b30 <myproc>
    80004438:	591c                	lw	a5,48(a0)
    8000443a:	d49c                	sw	a5,40(s1)
  release(&lk->lk);
    8000443c:	854a                	mv	a0,s2
    8000443e:	a73fc0ef          	jal	80000eb0 <release>
}
    80004442:	60e2                	ld	ra,24(sp)
    80004444:	6442                	ld	s0,16(sp)
    80004446:	64a2                	ld	s1,8(sp)
    80004448:	6902                	ld	s2,0(sp)
    8000444a:	6105                	addi	sp,sp,32
    8000444c:	8082                	ret

000000008000444e <releasesleep>:

void
releasesleep(struct sleeplock *lk)
{
    8000444e:	1101                	addi	sp,sp,-32
    80004450:	ec06                	sd	ra,24(sp)
    80004452:	e822                	sd	s0,16(sp)
    80004454:	e426                	sd	s1,8(sp)
    80004456:	e04a                	sd	s2,0(sp)
    80004458:	1000                	addi	s0,sp,32
    8000445a:	84aa                	mv	s1,a0
  acquire(&lk->lk);
    8000445c:	00850913          	addi	s2,a0,8
    80004460:	854a                	mv	a0,s2
    80004462:	9bbfc0ef          	jal	80000e1c <acquire>
  lk->locked = 0;
    80004466:	0004a023          	sw	zero,0(s1)
  lk->pid = 0;
    8000446a:	0204a423          	sw	zero,40(s1)
  wakeup(lk);
    8000446e:	8526                	mv	a0,s1
    80004470:	d0bfd0ef          	jal	8000217a <wakeup>
  release(&lk->lk);
    80004474:	854a                	mv	a0,s2
    80004476:	a3bfc0ef          	jal	80000eb0 <release>
}
    8000447a:	60e2                	ld	ra,24(sp)
    8000447c:	6442                	ld	s0,16(sp)
    8000447e:	64a2                	ld	s1,8(sp)
    80004480:	6902                	ld	s2,0(sp)
    80004482:	6105                	addi	sp,sp,32
    80004484:	8082                	ret

0000000080004486 <holdingsleep>:

int
holdingsleep(struct sleeplock *lk)
{
    80004486:	7179                	addi	sp,sp,-48
    80004488:	f406                	sd	ra,40(sp)
    8000448a:	f022                	sd	s0,32(sp)
    8000448c:	ec26                	sd	s1,24(sp)
    8000448e:	e84a                	sd	s2,16(sp)
    80004490:	1800                	addi	s0,sp,48
    80004492:	84aa                	mv	s1,a0
  int r;
  
  acquire(&lk->lk);
    80004494:	00850913          	addi	s2,a0,8
    80004498:	854a                	mv	a0,s2
    8000449a:	983fc0ef          	jal	80000e1c <acquire>
  r = lk->locked && (lk->pid == myproc()->pid);
    8000449e:	409c                	lw	a5,0(s1)
    800044a0:	ef81                	bnez	a5,800044b8 <holdingsleep+0x32>
    800044a2:	4481                	li	s1,0
  release(&lk->lk);
    800044a4:	854a                	mv	a0,s2
    800044a6:	a0bfc0ef          	jal	80000eb0 <release>
  return r;
}
    800044aa:	8526                	mv	a0,s1
    800044ac:	70a2                	ld	ra,40(sp)
    800044ae:	7402                	ld	s0,32(sp)
    800044b0:	64e2                	ld	s1,24(sp)
    800044b2:	6942                	ld	s2,16(sp)
    800044b4:	6145                	addi	sp,sp,48
    800044b6:	8082                	ret
    800044b8:	e44e                	sd	s3,8(sp)
  r = lk->locked && (lk->pid == myproc()->pid);
    800044ba:	0284a983          	lw	s3,40(s1)
    800044be:	e72fd0ef          	jal	80001b30 <myproc>
    800044c2:	5904                	lw	s1,48(a0)
    800044c4:	413484b3          	sub	s1,s1,s3
    800044c8:	0014b493          	seqz	s1,s1
    800044cc:	69a2                	ld	s3,8(sp)
    800044ce:	bfd9                	j	800044a4 <holdingsleep+0x1e>

00000000800044d0 <fileinit>:
  struct file file[NFILE];
} ftable;

void
fileinit(void)
{
    800044d0:	1141                	addi	sp,sp,-16
    800044d2:	e406                	sd	ra,8(sp)
    800044d4:	e022                	sd	s0,0(sp)
    800044d6:	0800                	addi	s0,sp,16
  initlock(&ftable.lock, "ftable");
    800044d8:	00004597          	auipc	a1,0x4
    800044dc:	11058593          	addi	a1,a1,272 # 800085e8 <etext+0x5e8>
    800044e0:	0023c517          	auipc	a0,0x23c
    800044e4:	6d050513          	addi	a0,a0,1744 # 80240bb0 <ftable>
    800044e8:	8abfc0ef          	jal	80000d92 <initlock>
}
    800044ec:	60a2                	ld	ra,8(sp)
    800044ee:	6402                	ld	s0,0(sp)
    800044f0:	0141                	addi	sp,sp,16
    800044f2:	8082                	ret

00000000800044f4 <filealloc>:

// Allocate a file structure.
struct file*
filealloc(void)
{
    800044f4:	1101                	addi	sp,sp,-32
    800044f6:	ec06                	sd	ra,24(sp)
    800044f8:	e822                	sd	s0,16(sp)
    800044fa:	e426                	sd	s1,8(sp)
    800044fc:	1000                	addi	s0,sp,32
  struct file *f;

  acquire(&ftable.lock);
    800044fe:	0023c517          	auipc	a0,0x23c
    80004502:	6b250513          	addi	a0,a0,1714 # 80240bb0 <ftable>
    80004506:	917fc0ef          	jal	80000e1c <acquire>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    8000450a:	0023c497          	auipc	s1,0x23c
    8000450e:	6be48493          	addi	s1,s1,1726 # 80240bc8 <ftable+0x18>
    80004512:	0023d717          	auipc	a4,0x23d
    80004516:	65670713          	addi	a4,a4,1622 # 80241b68 <gt>
    if(f->ref == 0){
    8000451a:	40dc                	lw	a5,4(s1)
    8000451c:	cf89                	beqz	a5,80004536 <filealloc+0x42>
  for(f = ftable.file; f < ftable.file + NFILE; f++){
    8000451e:	02848493          	addi	s1,s1,40
    80004522:	fee49ce3          	bne	s1,a4,8000451a <filealloc+0x26>
      f->ref = 1;
      release(&ftable.lock);
      return f;
    }
  }
  release(&ftable.lock);
    80004526:	0023c517          	auipc	a0,0x23c
    8000452a:	68a50513          	addi	a0,a0,1674 # 80240bb0 <ftable>
    8000452e:	983fc0ef          	jal	80000eb0 <release>
  return 0;
    80004532:	4481                	li	s1,0
    80004534:	a809                	j	80004546 <filealloc+0x52>
      f->ref = 1;
    80004536:	4785                	li	a5,1
    80004538:	c0dc                	sw	a5,4(s1)
      release(&ftable.lock);
    8000453a:	0023c517          	auipc	a0,0x23c
    8000453e:	67650513          	addi	a0,a0,1654 # 80240bb0 <ftable>
    80004542:	96ffc0ef          	jal	80000eb0 <release>
}
    80004546:	8526                	mv	a0,s1
    80004548:	60e2                	ld	ra,24(sp)
    8000454a:	6442                	ld	s0,16(sp)
    8000454c:	64a2                	ld	s1,8(sp)
    8000454e:	6105                	addi	sp,sp,32
    80004550:	8082                	ret

0000000080004552 <filedup>:

// Increment ref count for file f.
struct file*
filedup(struct file *f)
{
    80004552:	1101                	addi	sp,sp,-32
    80004554:	ec06                	sd	ra,24(sp)
    80004556:	e822                	sd	s0,16(sp)
    80004558:	e426                	sd	s1,8(sp)
    8000455a:	1000                	addi	s0,sp,32
    8000455c:	84aa                	mv	s1,a0
  acquire(&ftable.lock);
    8000455e:	0023c517          	auipc	a0,0x23c
    80004562:	65250513          	addi	a0,a0,1618 # 80240bb0 <ftable>
    80004566:	8b7fc0ef          	jal	80000e1c <acquire>
  if(f->ref < 1)
    8000456a:	40dc                	lw	a5,4(s1)
    8000456c:	02f05063          	blez	a5,8000458c <filedup+0x3a>
    panic("filedup");
  f->ref++;
    80004570:	2785                	addiw	a5,a5,1
    80004572:	c0dc                	sw	a5,4(s1)
  release(&ftable.lock);
    80004574:	0023c517          	auipc	a0,0x23c
    80004578:	63c50513          	addi	a0,a0,1596 # 80240bb0 <ftable>
    8000457c:	935fc0ef          	jal	80000eb0 <release>
  return f;
}
    80004580:	8526                	mv	a0,s1
    80004582:	60e2                	ld	ra,24(sp)
    80004584:	6442                	ld	s0,16(sp)
    80004586:	64a2                	ld	s1,8(sp)
    80004588:	6105                	addi	sp,sp,32
    8000458a:	8082                	ret
    panic("filedup");
    8000458c:	00004517          	auipc	a0,0x4
    80004590:	06450513          	addi	a0,a0,100 # 800085f0 <etext+0x5f0>
    80004594:	a90fc0ef          	jal	80000824 <panic>

0000000080004598 <fileclose>:

// Close file f.  (Decrement ref count, close when reaches 0.)
void
fileclose(struct file *f)
{
    80004598:	7139                	addi	sp,sp,-64
    8000459a:	fc06                	sd	ra,56(sp)
    8000459c:	f822                	sd	s0,48(sp)
    8000459e:	f426                	sd	s1,40(sp)
    800045a0:	0080                	addi	s0,sp,64
    800045a2:	84aa                	mv	s1,a0
  struct file ff;

  acquire(&ftable.lock);
    800045a4:	0023c517          	auipc	a0,0x23c
    800045a8:	60c50513          	addi	a0,a0,1548 # 80240bb0 <ftable>
    800045ac:	871fc0ef          	jal	80000e1c <acquire>
  if(f->ref < 1)
    800045b0:	40dc                	lw	a5,4(s1)
    800045b2:	04f05a63          	blez	a5,80004606 <fileclose+0x6e>
    panic("fileclose");
  if(--f->ref > 0){
    800045b6:	37fd                	addiw	a5,a5,-1
    800045b8:	c0dc                	sw	a5,4(s1)
    800045ba:	06f04063          	bgtz	a5,8000461a <fileclose+0x82>
    800045be:	f04a                	sd	s2,32(sp)
    800045c0:	ec4e                	sd	s3,24(sp)
    800045c2:	e852                	sd	s4,16(sp)
    800045c4:	e456                	sd	s5,8(sp)
    release(&ftable.lock);
    return;
  }
  ff = *f;
    800045c6:	0004a903          	lw	s2,0(s1)
    800045ca:	0094c783          	lbu	a5,9(s1)
    800045ce:	89be                	mv	s3,a5
    800045d0:	689c                	ld	a5,16(s1)
    800045d2:	8a3e                	mv	s4,a5
    800045d4:	6c9c                	ld	a5,24(s1)
    800045d6:	8abe                	mv	s5,a5
  f->ref = 0;
    800045d8:	0004a223          	sw	zero,4(s1)
  f->type = FD_NONE;
    800045dc:	0004a023          	sw	zero,0(s1)
  release(&ftable.lock);
    800045e0:	0023c517          	auipc	a0,0x23c
    800045e4:	5d050513          	addi	a0,a0,1488 # 80240bb0 <ftable>
    800045e8:	8c9fc0ef          	jal	80000eb0 <release>

  if(ff.type == FD_PIPE){
    800045ec:	4785                	li	a5,1
    800045ee:	04f90163          	beq	s2,a5,80004630 <fileclose+0x98>
    pipeclose(ff.pipe, ff.writable);
  } else if(ff.type == FD_INODE || ff.type == FD_DEVICE){
    800045f2:	ffe9079b          	addiw	a5,s2,-2
    800045f6:	4705                	li	a4,1
    800045f8:	04f77563          	bgeu	a4,a5,80004642 <fileclose+0xaa>
    800045fc:	7902                	ld	s2,32(sp)
    800045fe:	69e2                	ld	s3,24(sp)
    80004600:	6a42                	ld	s4,16(sp)
    80004602:	6aa2                	ld	s5,8(sp)
    80004604:	a00d                	j	80004626 <fileclose+0x8e>
    80004606:	f04a                	sd	s2,32(sp)
    80004608:	ec4e                	sd	s3,24(sp)
    8000460a:	e852                	sd	s4,16(sp)
    8000460c:	e456                	sd	s5,8(sp)
    panic("fileclose");
    8000460e:	00004517          	auipc	a0,0x4
    80004612:	fea50513          	addi	a0,a0,-22 # 800085f8 <etext+0x5f8>
    80004616:	a0efc0ef          	jal	80000824 <panic>
    release(&ftable.lock);
    8000461a:	0023c517          	auipc	a0,0x23c
    8000461e:	59650513          	addi	a0,a0,1430 # 80240bb0 <ftable>
    80004622:	88ffc0ef          	jal	80000eb0 <release>
    begin_op();
    iput(ff.ip);
    end_op();
  }
}
    80004626:	70e2                	ld	ra,56(sp)
    80004628:	7442                	ld	s0,48(sp)
    8000462a:	74a2                	ld	s1,40(sp)
    8000462c:	6121                	addi	sp,sp,64
    8000462e:	8082                	ret
    pipeclose(ff.pipe, ff.writable);
    80004630:	85ce                	mv	a1,s3
    80004632:	8552                	mv	a0,s4
    80004634:	348000ef          	jal	8000497c <pipeclose>
    80004638:	7902                	ld	s2,32(sp)
    8000463a:	69e2                	ld	s3,24(sp)
    8000463c:	6a42                	ld	s4,16(sp)
    8000463e:	6aa2                	ld	s5,8(sp)
    80004640:	b7dd                	j	80004626 <fileclose+0x8e>
    begin_op();
    80004642:	b33ff0ef          	jal	80004174 <begin_op>
    iput(ff.ip);
    80004646:	8556                	mv	a0,s5
    80004648:	aa0ff0ef          	jal	800038e8 <iput>
    end_op();
    8000464c:	b99ff0ef          	jal	800041e4 <end_op>
    80004650:	7902                	ld	s2,32(sp)
    80004652:	69e2                	ld	s3,24(sp)
    80004654:	6a42                	ld	s4,16(sp)
    80004656:	6aa2                	ld	s5,8(sp)
    80004658:	b7f9                	j	80004626 <fileclose+0x8e>

000000008000465a <filestat>:

// Get metadata about file f.
// addr is a user virtual address, pointing to a struct stat.
int
filestat(struct file *f, uint64 addr)
{
    8000465a:	715d                	addi	sp,sp,-80
    8000465c:	e486                	sd	ra,72(sp)
    8000465e:	e0a2                	sd	s0,64(sp)
    80004660:	fc26                	sd	s1,56(sp)
    80004662:	f052                	sd	s4,32(sp)
    80004664:	0880                	addi	s0,sp,80
    80004666:	84aa                	mv	s1,a0
    80004668:	8a2e                	mv	s4,a1
  struct proc *p = myproc();
    8000466a:	cc6fd0ef          	jal	80001b30 <myproc>
  struct stat st;
  
  if(f->type == FD_INODE || f->type == FD_DEVICE){
    8000466e:	409c                	lw	a5,0(s1)
    80004670:	37f9                	addiw	a5,a5,-2
    80004672:	4705                	li	a4,1
    80004674:	04f76263          	bltu	a4,a5,800046b8 <filestat+0x5e>
    80004678:	f84a                	sd	s2,48(sp)
    8000467a:	f44e                	sd	s3,40(sp)
    8000467c:	89aa                	mv	s3,a0
    ilock(f->ip);
    8000467e:	6c88                	ld	a0,24(s1)
    80004680:	858ff0ef          	jal	800036d8 <ilock>
    stati(f->ip, &st);
    80004684:	fb840913          	addi	s2,s0,-72
    80004688:	85ca                	mv	a1,s2
    8000468a:	6c88                	ld	a0,24(s1)
    8000468c:	c3eff0ef          	jal	80003aca <stati>
    iunlock(f->ip);
    80004690:	6c88                	ld	a0,24(s1)
    80004692:	8f4ff0ef          	jal	80003786 <iunlock>
    if(copyout(p->pagetable, addr, (char *)&st, sizeof(st)) < 0)
    80004696:	46e1                	li	a3,24
    80004698:	864a                	mv	a2,s2
    8000469a:	85d2                	mv	a1,s4
    8000469c:	0509b503          	ld	a0,80(s3)
    800046a0:	9b6fd0ef          	jal	80001856 <copyout>
    800046a4:	41f5551b          	sraiw	a0,a0,0x1f
    800046a8:	7942                	ld	s2,48(sp)
    800046aa:	79a2                	ld	s3,40(sp)
      return -1;
    return 0;
  }
  return -1;
}
    800046ac:	60a6                	ld	ra,72(sp)
    800046ae:	6406                	ld	s0,64(sp)
    800046b0:	74e2                	ld	s1,56(sp)
    800046b2:	7a02                	ld	s4,32(sp)
    800046b4:	6161                	addi	sp,sp,80
    800046b6:	8082                	ret
  return -1;
    800046b8:	557d                	li	a0,-1
    800046ba:	bfcd                	j	800046ac <filestat+0x52>

00000000800046bc <fileread>:

// Read from file f.
// addr is a user virtual address.
int
fileread(struct file *f, uint64 addr, int n)
{
    800046bc:	7179                	addi	sp,sp,-48
    800046be:	f406                	sd	ra,40(sp)
    800046c0:	f022                	sd	s0,32(sp)
    800046c2:	e84a                	sd	s2,16(sp)
    800046c4:	1800                	addi	s0,sp,48
  int r = 0;

  if(f->readable == 0)
    800046c6:	00854783          	lbu	a5,8(a0)
    800046ca:	cfd1                	beqz	a5,80004766 <fileread+0xaa>
    800046cc:	ec26                	sd	s1,24(sp)
    800046ce:	e44e                	sd	s3,8(sp)
    800046d0:	84aa                	mv	s1,a0
    800046d2:	892e                	mv	s2,a1
    800046d4:	89b2                	mv	s3,a2
    return -1;

  if(f->type == FD_PIPE){
    800046d6:	411c                	lw	a5,0(a0)
    800046d8:	4705                	li	a4,1
    800046da:	04e78363          	beq	a5,a4,80004720 <fileread+0x64>
    r = piperead(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800046de:	470d                	li	a4,3
    800046e0:	04e78763          	beq	a5,a4,8000472e <fileread+0x72>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
      return -1;
    r = devsw[f->major].read(1, addr, n);
  } else if(f->type == FD_INODE){
    800046e4:	4709                	li	a4,2
    800046e6:	06e79a63          	bne	a5,a4,8000475a <fileread+0x9e>
    ilock(f->ip);
    800046ea:	6d08                	ld	a0,24(a0)
    800046ec:	fedfe0ef          	jal	800036d8 <ilock>
    if((r = readi(f->ip, 1, addr, f->off, n)) > 0)
    800046f0:	874e                	mv	a4,s3
    800046f2:	5094                	lw	a3,32(s1)
    800046f4:	864a                	mv	a2,s2
    800046f6:	4585                	li	a1,1
    800046f8:	6c88                	ld	a0,24(s1)
    800046fa:	bfeff0ef          	jal	80003af8 <readi>
    800046fe:	892a                	mv	s2,a0
    80004700:	00a05563          	blez	a0,8000470a <fileread+0x4e>
      f->off += r;
    80004704:	509c                	lw	a5,32(s1)
    80004706:	9fa9                	addw	a5,a5,a0
    80004708:	d09c                	sw	a5,32(s1)
    iunlock(f->ip);
    8000470a:	6c88                	ld	a0,24(s1)
    8000470c:	87aff0ef          	jal	80003786 <iunlock>
    80004710:	64e2                	ld	s1,24(sp)
    80004712:	69a2                	ld	s3,8(sp)
  } else {
    panic("fileread");
  }

  return r;
}
    80004714:	854a                	mv	a0,s2
    80004716:	70a2                	ld	ra,40(sp)
    80004718:	7402                	ld	s0,32(sp)
    8000471a:	6942                	ld	s2,16(sp)
    8000471c:	6145                	addi	sp,sp,48
    8000471e:	8082                	ret
    r = piperead(f->pipe, addr, n);
    80004720:	6908                	ld	a0,16(a0)
    80004722:	3b0000ef          	jal	80004ad2 <piperead>
    80004726:	892a                	mv	s2,a0
    80004728:	64e2                	ld	s1,24(sp)
    8000472a:	69a2                	ld	s3,8(sp)
    8000472c:	b7e5                	j	80004714 <fileread+0x58>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].read)
    8000472e:	02451783          	lh	a5,36(a0)
    80004732:	03079693          	slli	a3,a5,0x30
    80004736:	92c1                	srli	a3,a3,0x30
    80004738:	4725                	li	a4,9
    8000473a:	02d76963          	bltu	a4,a3,8000476c <fileread+0xb0>
    8000473e:	0792                	slli	a5,a5,0x4
    80004740:	0023c717          	auipc	a4,0x23c
    80004744:	3d070713          	addi	a4,a4,976 # 80240b10 <devsw>
    80004748:	97ba                	add	a5,a5,a4
    8000474a:	639c                	ld	a5,0(a5)
    8000474c:	c78d                	beqz	a5,80004776 <fileread+0xba>
    r = devsw[f->major].read(1, addr, n);
    8000474e:	4505                	li	a0,1
    80004750:	9782                	jalr	a5
    80004752:	892a                	mv	s2,a0
    80004754:	64e2                	ld	s1,24(sp)
    80004756:	69a2                	ld	s3,8(sp)
    80004758:	bf75                	j	80004714 <fileread+0x58>
    panic("fileread");
    8000475a:	00004517          	auipc	a0,0x4
    8000475e:	eae50513          	addi	a0,a0,-338 # 80008608 <etext+0x608>
    80004762:	8c2fc0ef          	jal	80000824 <panic>
    return -1;
    80004766:	57fd                	li	a5,-1
    80004768:	893e                	mv	s2,a5
    8000476a:	b76d                	j	80004714 <fileread+0x58>
      return -1;
    8000476c:	57fd                	li	a5,-1
    8000476e:	893e                	mv	s2,a5
    80004770:	64e2                	ld	s1,24(sp)
    80004772:	69a2                	ld	s3,8(sp)
    80004774:	b745                	j	80004714 <fileread+0x58>
    80004776:	57fd                	li	a5,-1
    80004778:	893e                	mv	s2,a5
    8000477a:	64e2                	ld	s1,24(sp)
    8000477c:	69a2                	ld	s3,8(sp)
    8000477e:	bf59                	j	80004714 <fileread+0x58>

0000000080004780 <filewrite>:
int
filewrite(struct file *f, uint64 addr, int n)
{
  int r, ret = 0;

  if(f->writable == 0)
    80004780:	00954783          	lbu	a5,9(a0)
    80004784:	10078f63          	beqz	a5,800048a2 <filewrite+0x122>
{
    80004788:	711d                	addi	sp,sp,-96
    8000478a:	ec86                	sd	ra,88(sp)
    8000478c:	e8a2                	sd	s0,80(sp)
    8000478e:	e0ca                	sd	s2,64(sp)
    80004790:	f456                	sd	s5,40(sp)
    80004792:	f05a                	sd	s6,32(sp)
    80004794:	1080                	addi	s0,sp,96
    80004796:	892a                	mv	s2,a0
    80004798:	8b2e                	mv	s6,a1
    8000479a:	8ab2                	mv	s5,a2
    return -1;

  if(f->type == FD_PIPE){
    8000479c:	411c                	lw	a5,0(a0)
    8000479e:	4705                	li	a4,1
    800047a0:	02e78a63          	beq	a5,a4,800047d4 <filewrite+0x54>
    ret = pipewrite(f->pipe, addr, n);
  } else if(f->type == FD_DEVICE){
    800047a4:	470d                	li	a4,3
    800047a6:	02e78b63          	beq	a5,a4,800047dc <filewrite+0x5c>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
      return -1;
    ret = devsw[f->major].write(1, addr, n);
  } else if(f->type == FD_INODE){
    800047aa:	4709                	li	a4,2
    800047ac:	0ce79f63          	bne	a5,a4,8000488a <filewrite+0x10a>
    800047b0:	f852                	sd	s4,48(sp)
    // the maximum log transaction size, including
    // i-node, indirect block, allocation blocks,
    // and 2 blocks of slop for non-aligned writes.
    int max = ((MAXOPBLOCKS-1-1-2) / 2) * BSIZE;
    int i = 0;
    while(i < n){
    800047b2:	0ac05a63          	blez	a2,80004866 <filewrite+0xe6>
    800047b6:	e4a6                	sd	s1,72(sp)
    800047b8:	fc4e                	sd	s3,56(sp)
    800047ba:	ec5e                	sd	s7,24(sp)
    800047bc:	e862                	sd	s8,16(sp)
    800047be:	e466                	sd	s9,8(sp)
    int i = 0;
    800047c0:	4a01                	li	s4,0
      int n1 = n - i;
      if(n1 > max)
    800047c2:	6b85                	lui	s7,0x1
    800047c4:	c00b8b93          	addi	s7,s7,-1024 # c00 <_entry-0x7ffff400>
    800047c8:	6785                	lui	a5,0x1
    800047ca:	c007879b          	addiw	a5,a5,-1024 # c00 <_entry-0x7ffff400>
    800047ce:	8cbe                	mv	s9,a5
        n1 = max;

      begin_op();
      ilock(f->ip);
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    800047d0:	4c05                	li	s8,1
    800047d2:	a8ad                	j	8000484c <filewrite+0xcc>
    ret = pipewrite(f->pipe, addr, n);
    800047d4:	6908                	ld	a0,16(a0)
    800047d6:	204000ef          	jal	800049da <pipewrite>
    800047da:	a04d                	j	8000487c <filewrite+0xfc>
    if(f->major < 0 || f->major >= NDEV || !devsw[f->major].write)
    800047dc:	02451783          	lh	a5,36(a0)
    800047e0:	03079693          	slli	a3,a5,0x30
    800047e4:	92c1                	srli	a3,a3,0x30
    800047e6:	4725                	li	a4,9
    800047e8:	0ad76f63          	bltu	a4,a3,800048a6 <filewrite+0x126>
    800047ec:	0792                	slli	a5,a5,0x4
    800047ee:	0023c717          	auipc	a4,0x23c
    800047f2:	32270713          	addi	a4,a4,802 # 80240b10 <devsw>
    800047f6:	97ba                	add	a5,a5,a4
    800047f8:	679c                	ld	a5,8(a5)
    800047fa:	cbc5                	beqz	a5,800048aa <filewrite+0x12a>
    ret = devsw[f->major].write(1, addr, n);
    800047fc:	4505                	li	a0,1
    800047fe:	9782                	jalr	a5
    80004800:	a8b5                	j	8000487c <filewrite+0xfc>
      if(n1 > max)
    80004802:	2981                	sext.w	s3,s3
      begin_op();
    80004804:	971ff0ef          	jal	80004174 <begin_op>
      ilock(f->ip);
    80004808:	01893503          	ld	a0,24(s2)
    8000480c:	ecdfe0ef          	jal	800036d8 <ilock>
      if ((r = writei(f->ip, 1, addr + i, f->off, n1)) > 0)
    80004810:	874e                	mv	a4,s3
    80004812:	02092683          	lw	a3,32(s2)
    80004816:	016a0633          	add	a2,s4,s6
    8000481a:	85e2                	mv	a1,s8
    8000481c:	01893503          	ld	a0,24(s2)
    80004820:	bcaff0ef          	jal	80003bea <writei>
    80004824:	84aa                	mv	s1,a0
    80004826:	00a05763          	blez	a0,80004834 <filewrite+0xb4>
        f->off += r;
    8000482a:	02092783          	lw	a5,32(s2)
    8000482e:	9fa9                	addw	a5,a5,a0
    80004830:	02f92023          	sw	a5,32(s2)
      iunlock(f->ip);
    80004834:	01893503          	ld	a0,24(s2)
    80004838:	f4ffe0ef          	jal	80003786 <iunlock>
      end_op();
    8000483c:	9a9ff0ef          	jal	800041e4 <end_op>

      if(r != n1){
    80004840:	02999563          	bne	s3,s1,8000486a <filewrite+0xea>
        // error from writei
        break;
      }
      i += r;
    80004844:	01448a3b          	addw	s4,s1,s4
    while(i < n){
    80004848:	015a5963          	bge	s4,s5,8000485a <filewrite+0xda>
      int n1 = n - i;
    8000484c:	414a87bb          	subw	a5,s5,s4
    80004850:	89be                	mv	s3,a5
      if(n1 > max)
    80004852:	fafbd8e3          	bge	s7,a5,80004802 <filewrite+0x82>
    80004856:	89e6                	mv	s3,s9
    80004858:	b76d                	j	80004802 <filewrite+0x82>
    8000485a:	64a6                	ld	s1,72(sp)
    8000485c:	79e2                	ld	s3,56(sp)
    8000485e:	6be2                	ld	s7,24(sp)
    80004860:	6c42                	ld	s8,16(sp)
    80004862:	6ca2                	ld	s9,8(sp)
    80004864:	a801                	j	80004874 <filewrite+0xf4>
    int i = 0;
    80004866:	4a01                	li	s4,0
    80004868:	a031                	j	80004874 <filewrite+0xf4>
    8000486a:	64a6                	ld	s1,72(sp)
    8000486c:	79e2                	ld	s3,56(sp)
    8000486e:	6be2                	ld	s7,24(sp)
    80004870:	6c42                	ld	s8,16(sp)
    80004872:	6ca2                	ld	s9,8(sp)
    }
    ret = (i == n ? n : -1);
    80004874:	034a9d63          	bne	s5,s4,800048ae <filewrite+0x12e>
    80004878:	8556                	mv	a0,s5
    8000487a:	7a42                	ld	s4,48(sp)
  } else {
    panic("filewrite");
  }

  return ret;
}
    8000487c:	60e6                	ld	ra,88(sp)
    8000487e:	6446                	ld	s0,80(sp)
    80004880:	6906                	ld	s2,64(sp)
    80004882:	7aa2                	ld	s5,40(sp)
    80004884:	7b02                	ld	s6,32(sp)
    80004886:	6125                	addi	sp,sp,96
    80004888:	8082                	ret
    8000488a:	e4a6                	sd	s1,72(sp)
    8000488c:	fc4e                	sd	s3,56(sp)
    8000488e:	f852                	sd	s4,48(sp)
    80004890:	ec5e                	sd	s7,24(sp)
    80004892:	e862                	sd	s8,16(sp)
    80004894:	e466                	sd	s9,8(sp)
    panic("filewrite");
    80004896:	00004517          	auipc	a0,0x4
    8000489a:	d8250513          	addi	a0,a0,-638 # 80008618 <etext+0x618>
    8000489e:	f87fb0ef          	jal	80000824 <panic>
    return -1;
    800048a2:	557d                	li	a0,-1
}
    800048a4:	8082                	ret
      return -1;
    800048a6:	557d                	li	a0,-1
    800048a8:	bfd1                	j	8000487c <filewrite+0xfc>
    800048aa:	557d                	li	a0,-1
    800048ac:	bfc1                	j	8000487c <filewrite+0xfc>
    ret = (i == n ? n : -1);
    800048ae:	557d                	li	a0,-1
    800048b0:	7a42                	ld	s4,48(sp)
    800048b2:	b7e9                	j	8000487c <filewrite+0xfc>

00000000800048b4 <pipealloc>:
  int writeopen;  // write fd is still open
};

int
pipealloc(struct file **f0, struct file **f1)
{
    800048b4:	7179                	addi	sp,sp,-48
    800048b6:	f406                	sd	ra,40(sp)
    800048b8:	f022                	sd	s0,32(sp)
    800048ba:	ec26                	sd	s1,24(sp)
    800048bc:	e052                	sd	s4,0(sp)
    800048be:	1800                	addi	s0,sp,48
    800048c0:	84aa                	mv	s1,a0
    800048c2:	8a2e                	mv	s4,a1
  struct pipe *pi;

  pi = 0;
  *f0 = *f1 = 0;
    800048c4:	0005b023          	sd	zero,0(a1)
    800048c8:	00053023          	sd	zero,0(a0)
  if((*f0 = filealloc()) == 0 || (*f1 = filealloc()) == 0)
    800048cc:	c29ff0ef          	jal	800044f4 <filealloc>
    800048d0:	e088                	sd	a0,0(s1)
    800048d2:	c549                	beqz	a0,8000495c <pipealloc+0xa8>
    800048d4:	c21ff0ef          	jal	800044f4 <filealloc>
    800048d8:	00aa3023          	sd	a0,0(s4)
    800048dc:	cd25                	beqz	a0,80004954 <pipealloc+0xa0>
    800048de:	e84a                	sd	s2,16(sp)
    goto bad;
  if((pi = (struct pipe*)kalloc()) == 0)
    800048e0:	c2cfc0ef          	jal	80000d0c <kalloc>
    800048e4:	892a                	mv	s2,a0
    800048e6:	c12d                	beqz	a0,80004948 <pipealloc+0x94>
    800048e8:	e44e                	sd	s3,8(sp)
    goto bad;
  pi->readopen = 1;
    800048ea:	4985                	li	s3,1
    800048ec:	23352023          	sw	s3,544(a0)
  pi->writeopen = 1;
    800048f0:	23352223          	sw	s3,548(a0)
  pi->nwrite = 0;
    800048f4:	20052e23          	sw	zero,540(a0)
  pi->nread = 0;
    800048f8:	20052c23          	sw	zero,536(a0)
  initlock(&pi->lock, "pipe");
    800048fc:	00004597          	auipc	a1,0x4
    80004900:	d2c58593          	addi	a1,a1,-724 # 80008628 <etext+0x628>
    80004904:	c8efc0ef          	jal	80000d92 <initlock>
  (*f0)->type = FD_PIPE;
    80004908:	609c                	ld	a5,0(s1)
    8000490a:	0137a023          	sw	s3,0(a5)
  (*f0)->readable = 1;
    8000490e:	609c                	ld	a5,0(s1)
    80004910:	01378423          	sb	s3,8(a5)
  (*f0)->writable = 0;
    80004914:	609c                	ld	a5,0(s1)
    80004916:	000784a3          	sb	zero,9(a5)
  (*f0)->pipe = pi;
    8000491a:	609c                	ld	a5,0(s1)
    8000491c:	0127b823          	sd	s2,16(a5)
  (*f1)->type = FD_PIPE;
    80004920:	000a3783          	ld	a5,0(s4)
    80004924:	0137a023          	sw	s3,0(a5)
  (*f1)->readable = 0;
    80004928:	000a3783          	ld	a5,0(s4)
    8000492c:	00078423          	sb	zero,8(a5)
  (*f1)->writable = 1;
    80004930:	000a3783          	ld	a5,0(s4)
    80004934:	013784a3          	sb	s3,9(a5)
  (*f1)->pipe = pi;
    80004938:	000a3783          	ld	a5,0(s4)
    8000493c:	0127b823          	sd	s2,16(a5)
  return 0;
    80004940:	4501                	li	a0,0
    80004942:	6942                	ld	s2,16(sp)
    80004944:	69a2                	ld	s3,8(sp)
    80004946:	a01d                	j	8000496c <pipealloc+0xb8>

 bad:
  if(pi)
    kfree((char*)pi);
  if(*f0)
    80004948:	6088                	ld	a0,0(s1)
    8000494a:	c119                	beqz	a0,80004950 <pipealloc+0x9c>
    8000494c:	6942                	ld	s2,16(sp)
    8000494e:	a029                	j	80004958 <pipealloc+0xa4>
    80004950:	6942                	ld	s2,16(sp)
    80004952:	a029                	j	8000495c <pipealloc+0xa8>
    80004954:	6088                	ld	a0,0(s1)
    80004956:	c10d                	beqz	a0,80004978 <pipealloc+0xc4>
    fileclose(*f0);
    80004958:	c41ff0ef          	jal	80004598 <fileclose>
  if(*f1)
    8000495c:	000a3783          	ld	a5,0(s4)
    fileclose(*f1);
  return -1;
    80004960:	557d                	li	a0,-1
  if(*f1)
    80004962:	c789                	beqz	a5,8000496c <pipealloc+0xb8>
    fileclose(*f1);
    80004964:	853e                	mv	a0,a5
    80004966:	c33ff0ef          	jal	80004598 <fileclose>
  return -1;
    8000496a:	557d                	li	a0,-1
}
    8000496c:	70a2                	ld	ra,40(sp)
    8000496e:	7402                	ld	s0,32(sp)
    80004970:	64e2                	ld	s1,24(sp)
    80004972:	6a02                	ld	s4,0(sp)
    80004974:	6145                	addi	sp,sp,48
    80004976:	8082                	ret
  return -1;
    80004978:	557d                	li	a0,-1
    8000497a:	bfcd                	j	8000496c <pipealloc+0xb8>

000000008000497c <pipeclose>:

void
pipeclose(struct pipe *pi, int writable)
{
    8000497c:	1101                	addi	sp,sp,-32
    8000497e:	ec06                	sd	ra,24(sp)
    80004980:	e822                	sd	s0,16(sp)
    80004982:	e426                	sd	s1,8(sp)
    80004984:	e04a                	sd	s2,0(sp)
    80004986:	1000                	addi	s0,sp,32
    80004988:	84aa                	mv	s1,a0
    8000498a:	892e                	mv	s2,a1
  acquire(&pi->lock);
    8000498c:	c90fc0ef          	jal	80000e1c <acquire>
  if(writable){
    80004990:	02090763          	beqz	s2,800049be <pipeclose+0x42>
    pi->writeopen = 0;
    80004994:	2204a223          	sw	zero,548(s1)
    wakeup(&pi->nread);
    80004998:	21848513          	addi	a0,s1,536
    8000499c:	fdefd0ef          	jal	8000217a <wakeup>
  } else {
    pi->readopen = 0;
    wakeup(&pi->nwrite);
  }
  if(pi->readopen == 0 && pi->writeopen == 0){
    800049a0:	2204a783          	lw	a5,544(s1)
    800049a4:	e781                	bnez	a5,800049ac <pipeclose+0x30>
    800049a6:	2244a783          	lw	a5,548(s1)
    800049aa:	c38d                	beqz	a5,800049cc <pipeclose+0x50>
    release(&pi->lock);
    kfree((char*)pi);
  } else
    release(&pi->lock);
    800049ac:	8526                	mv	a0,s1
    800049ae:	d02fc0ef          	jal	80000eb0 <release>
}
    800049b2:	60e2                	ld	ra,24(sp)
    800049b4:	6442                	ld	s0,16(sp)
    800049b6:	64a2                	ld	s1,8(sp)
    800049b8:	6902                	ld	s2,0(sp)
    800049ba:	6105                	addi	sp,sp,32
    800049bc:	8082                	ret
    pi->readopen = 0;
    800049be:	2204a023          	sw	zero,544(s1)
    wakeup(&pi->nwrite);
    800049c2:	21c48513          	addi	a0,s1,540
    800049c6:	fb4fd0ef          	jal	8000217a <wakeup>
    800049ca:	bfd9                	j	800049a0 <pipeclose+0x24>
    release(&pi->lock);
    800049cc:	8526                	mv	a0,s1
    800049ce:	ce2fc0ef          	jal	80000eb0 <release>
    kfree((char*)pi);
    800049d2:	8526                	mv	a0,s1
    800049d4:	a08fc0ef          	jal	80000bdc <kfree>
    800049d8:	bfe9                	j	800049b2 <pipeclose+0x36>

00000000800049da <pipewrite>:

int
pipewrite(struct pipe *pi, uint64 addr, int n)
{
    800049da:	7159                	addi	sp,sp,-112
    800049dc:	f486                	sd	ra,104(sp)
    800049de:	f0a2                	sd	s0,96(sp)
    800049e0:	eca6                	sd	s1,88(sp)
    800049e2:	e8ca                	sd	s2,80(sp)
    800049e4:	e4ce                	sd	s3,72(sp)
    800049e6:	e0d2                	sd	s4,64(sp)
    800049e8:	fc56                	sd	s5,56(sp)
    800049ea:	1880                	addi	s0,sp,112
    800049ec:	84aa                	mv	s1,a0
    800049ee:	8aae                	mv	s5,a1
    800049f0:	8a32                	mv	s4,a2
  int i = 0;
  struct proc *pr = myproc();
    800049f2:	93efd0ef          	jal	80001b30 <myproc>
    800049f6:	89aa                	mv	s3,a0

  acquire(&pi->lock);
    800049f8:	8526                	mv	a0,s1
    800049fa:	c22fc0ef          	jal	80000e1c <acquire>
  while(i < n){
    800049fe:	0d405263          	blez	s4,80004ac2 <pipewrite+0xe8>
    80004a02:	f85a                	sd	s6,48(sp)
    80004a04:	f45e                	sd	s7,40(sp)
    80004a06:	f062                	sd	s8,32(sp)
    80004a08:	ec66                	sd	s9,24(sp)
    80004a0a:	e86a                	sd	s10,16(sp)
  int i = 0;
    80004a0c:	4901                	li	s2,0
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
      wakeup(&pi->nread);
      sleep(&pi->nwrite, &pi->lock);
    } else {
      char ch;
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004a0e:	f9f40c13          	addi	s8,s0,-97
    80004a12:	4b85                	li	s7,1
    80004a14:	5b7d                	li	s6,-1
      wakeup(&pi->nread);
    80004a16:	21848d13          	addi	s10,s1,536
      sleep(&pi->nwrite, &pi->lock);
    80004a1a:	21c48c93          	addi	s9,s1,540
    80004a1e:	a82d                	j	80004a58 <pipewrite+0x7e>
      release(&pi->lock);
    80004a20:	8526                	mv	a0,s1
    80004a22:	c8efc0ef          	jal	80000eb0 <release>
      return -1;
    80004a26:	597d                	li	s2,-1
    80004a28:	7b42                	ld	s6,48(sp)
    80004a2a:	7ba2                	ld	s7,40(sp)
    80004a2c:	7c02                	ld	s8,32(sp)
    80004a2e:	6ce2                	ld	s9,24(sp)
    80004a30:	6d42                	ld	s10,16(sp)
  }
  wakeup(&pi->nread);
  release(&pi->lock);

  return i;
}
    80004a32:	854a                	mv	a0,s2
    80004a34:	70a6                	ld	ra,104(sp)
    80004a36:	7406                	ld	s0,96(sp)
    80004a38:	64e6                	ld	s1,88(sp)
    80004a3a:	6946                	ld	s2,80(sp)
    80004a3c:	69a6                	ld	s3,72(sp)
    80004a3e:	6a06                	ld	s4,64(sp)
    80004a40:	7ae2                	ld	s5,56(sp)
    80004a42:	6165                	addi	sp,sp,112
    80004a44:	8082                	ret
      wakeup(&pi->nread);
    80004a46:	856a                	mv	a0,s10
    80004a48:	f32fd0ef          	jal	8000217a <wakeup>
      sleep(&pi->nwrite, &pi->lock);
    80004a4c:	85a6                	mv	a1,s1
    80004a4e:	8566                	mv	a0,s9
    80004a50:	edefd0ef          	jal	8000212e <sleep>
  while(i < n){
    80004a54:	05495a63          	bge	s2,s4,80004aa8 <pipewrite+0xce>
    if(pi->readopen == 0 || killed(pr)){
    80004a58:	2204a783          	lw	a5,544(s1)
    80004a5c:	d3f1                	beqz	a5,80004a20 <pipewrite+0x46>
    80004a5e:	854e                	mv	a0,s3
    80004a60:	90bfd0ef          	jal	8000236a <killed>
    80004a64:	fd55                	bnez	a0,80004a20 <pipewrite+0x46>
    if(pi->nwrite == pi->nread + PIPESIZE){ //DOC: pipewrite-full
    80004a66:	2184a783          	lw	a5,536(s1)
    80004a6a:	21c4a703          	lw	a4,540(s1)
    80004a6e:	2007879b          	addiw	a5,a5,512
    80004a72:	fcf70ae3          	beq	a4,a5,80004a46 <pipewrite+0x6c>
      if(copyin(pr->pagetable, &ch, addr + i, 1) == -1)
    80004a76:	86de                	mv	a3,s7
    80004a78:	01590633          	add	a2,s2,s5
    80004a7c:	85e2                	mv	a1,s8
    80004a7e:	0509b503          	ld	a0,80(s3)
    80004a82:	e93fc0ef          	jal	80001914 <copyin>
    80004a86:	05650063          	beq	a0,s6,80004ac6 <pipewrite+0xec>
      pi->data[pi->nwrite++ % PIPESIZE] = ch;
    80004a8a:	21c4a783          	lw	a5,540(s1)
    80004a8e:	0017871b          	addiw	a4,a5,1
    80004a92:	20e4ae23          	sw	a4,540(s1)
    80004a96:	1ff7f793          	andi	a5,a5,511
    80004a9a:	97a6                	add	a5,a5,s1
    80004a9c:	f9f44703          	lbu	a4,-97(s0)
    80004aa0:	00e78c23          	sb	a4,24(a5)
      i++;
    80004aa4:	2905                	addiw	s2,s2,1
    80004aa6:	b77d                	j	80004a54 <pipewrite+0x7a>
    80004aa8:	7b42                	ld	s6,48(sp)
    80004aaa:	7ba2                	ld	s7,40(sp)
    80004aac:	7c02                	ld	s8,32(sp)
    80004aae:	6ce2                	ld	s9,24(sp)
    80004ab0:	6d42                	ld	s10,16(sp)
  wakeup(&pi->nread);
    80004ab2:	21848513          	addi	a0,s1,536
    80004ab6:	ec4fd0ef          	jal	8000217a <wakeup>
  release(&pi->lock);
    80004aba:	8526                	mv	a0,s1
    80004abc:	bf4fc0ef          	jal	80000eb0 <release>
  return i;
    80004ac0:	bf8d                	j	80004a32 <pipewrite+0x58>
  int i = 0;
    80004ac2:	4901                	li	s2,0
    80004ac4:	b7fd                	j	80004ab2 <pipewrite+0xd8>
    80004ac6:	7b42                	ld	s6,48(sp)
    80004ac8:	7ba2                	ld	s7,40(sp)
    80004aca:	7c02                	ld	s8,32(sp)
    80004acc:	6ce2                	ld	s9,24(sp)
    80004ace:	6d42                	ld	s10,16(sp)
    80004ad0:	b7cd                	j	80004ab2 <pipewrite+0xd8>

0000000080004ad2 <piperead>:

int
piperead(struct pipe *pi, uint64 addr, int n)
{
    80004ad2:	711d                	addi	sp,sp,-96
    80004ad4:	ec86                	sd	ra,88(sp)
    80004ad6:	e8a2                	sd	s0,80(sp)
    80004ad8:	e4a6                	sd	s1,72(sp)
    80004ada:	e0ca                	sd	s2,64(sp)
    80004adc:	fc4e                	sd	s3,56(sp)
    80004ade:	f852                	sd	s4,48(sp)
    80004ae0:	f456                	sd	s5,40(sp)
    80004ae2:	1080                	addi	s0,sp,96
    80004ae4:	84aa                	mv	s1,a0
    80004ae6:	892e                	mv	s2,a1
    80004ae8:	8ab2                	mv	s5,a2
  int i;
  struct proc *pr = myproc();
    80004aea:	846fd0ef          	jal	80001b30 <myproc>
    80004aee:	8a2a                	mv	s4,a0
  char ch;

  acquire(&pi->lock);
    80004af0:	8526                	mv	a0,s1
    80004af2:	b2afc0ef          	jal	80000e1c <acquire>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004af6:	2184a703          	lw	a4,536(s1)
    80004afa:	21c4a783          	lw	a5,540(s1)
    if(killed(pr)){
      release(&pi->lock);
      return -1;
    }
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004afe:	21848993          	addi	s3,s1,536
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004b02:	02f71763          	bne	a4,a5,80004b30 <piperead+0x5e>
    80004b06:	2244a783          	lw	a5,548(s1)
    80004b0a:	cf85                	beqz	a5,80004b42 <piperead+0x70>
    if(killed(pr)){
    80004b0c:	8552                	mv	a0,s4
    80004b0e:	85dfd0ef          	jal	8000236a <killed>
    80004b12:	e11d                	bnez	a0,80004b38 <piperead+0x66>
    sleep(&pi->nread, &pi->lock); //DOC: piperead-sleep
    80004b14:	85a6                	mv	a1,s1
    80004b16:	854e                	mv	a0,s3
    80004b18:	e16fd0ef          	jal	8000212e <sleep>
  while(pi->nread == pi->nwrite && pi->writeopen){  //DOC: pipe-empty
    80004b1c:	2184a703          	lw	a4,536(s1)
    80004b20:	21c4a783          	lw	a5,540(s1)
    80004b24:	fef701e3          	beq	a4,a5,80004b06 <piperead+0x34>
    80004b28:	f05a                	sd	s6,32(sp)
    80004b2a:	ec5e                	sd	s7,24(sp)
    80004b2c:	e862                	sd	s8,16(sp)
    80004b2e:	a829                	j	80004b48 <piperead+0x76>
    80004b30:	f05a                	sd	s6,32(sp)
    80004b32:	ec5e                	sd	s7,24(sp)
    80004b34:	e862                	sd	s8,16(sp)
    80004b36:	a809                	j	80004b48 <piperead+0x76>
      release(&pi->lock);
    80004b38:	8526                	mv	a0,s1
    80004b3a:	b76fc0ef          	jal	80000eb0 <release>
      return -1;
    80004b3e:	59fd                	li	s3,-1
    80004b40:	a09d                	j	80004ba6 <piperead+0xd4>
    80004b42:	f05a                	sd	s6,32(sp)
    80004b44:	ec5e                	sd	s7,24(sp)
    80004b46:	e862                	sd	s8,16(sp)
  }
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004b48:	4981                	li	s3,0
    if(pi->nread == pi->nwrite)
      break;
    ch = pi->data[pi->nread++ % PIPESIZE];
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004b4a:	faf40c13          	addi	s8,s0,-81
    80004b4e:	4b85                	li	s7,1
    80004b50:	5b7d                	li	s6,-1
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004b52:	05505063          	blez	s5,80004b92 <piperead+0xc0>
    if(pi->nread == pi->nwrite)
    80004b56:	2184a783          	lw	a5,536(s1)
    80004b5a:	21c4a703          	lw	a4,540(s1)
    80004b5e:	02f70a63          	beq	a4,a5,80004b92 <piperead+0xc0>
    ch = pi->data[pi->nread++ % PIPESIZE];
    80004b62:	0017871b          	addiw	a4,a5,1
    80004b66:	20e4ac23          	sw	a4,536(s1)
    80004b6a:	1ff7f793          	andi	a5,a5,511
    80004b6e:	97a6                	add	a5,a5,s1
    80004b70:	0187c783          	lbu	a5,24(a5)
    80004b74:	faf407a3          	sb	a5,-81(s0)
    if(copyout(pr->pagetable, addr + i, &ch, 1) == -1)
    80004b78:	86de                	mv	a3,s7
    80004b7a:	8662                	mv	a2,s8
    80004b7c:	85ca                	mv	a1,s2
    80004b7e:	050a3503          	ld	a0,80(s4)
    80004b82:	cd5fc0ef          	jal	80001856 <copyout>
    80004b86:	01650663          	beq	a0,s6,80004b92 <piperead+0xc0>
  for(i = 0; i < n; i++){  //DOC: piperead-copy
    80004b8a:	2985                	addiw	s3,s3,1
    80004b8c:	0905                	addi	s2,s2,1
    80004b8e:	fd3a94e3          	bne	s5,s3,80004b56 <piperead+0x84>
      break;
  }
  wakeup(&pi->nwrite);  //DOC: piperead-wakeup
    80004b92:	21c48513          	addi	a0,s1,540
    80004b96:	de4fd0ef          	jal	8000217a <wakeup>
  release(&pi->lock);
    80004b9a:	8526                	mv	a0,s1
    80004b9c:	b14fc0ef          	jal	80000eb0 <release>
    80004ba0:	7b02                	ld	s6,32(sp)
    80004ba2:	6be2                	ld	s7,24(sp)
    80004ba4:	6c42                	ld	s8,16(sp)
  return i;
}
    80004ba6:	854e                	mv	a0,s3
    80004ba8:	60e6                	ld	ra,88(sp)
    80004baa:	6446                	ld	s0,80(sp)
    80004bac:	64a6                	ld	s1,72(sp)
    80004bae:	6906                	ld	s2,64(sp)
    80004bb0:	79e2                	ld	s3,56(sp)
    80004bb2:	7a42                	ld	s4,48(sp)
    80004bb4:	7aa2                	ld	s5,40(sp)
    80004bb6:	6125                	addi	sp,sp,96
    80004bb8:	8082                	ret

0000000080004bba <flags2perm>:

static int loadseg(pde_t *, uint64, struct inode *, uint, uint);

// map ELF permissions to PTE permission bits.
int flags2perm(int flags)
{
    80004bba:	1141                	addi	sp,sp,-16
    80004bbc:	e406                	sd	ra,8(sp)
    80004bbe:	e022                	sd	s0,0(sp)
    80004bc0:	0800                	addi	s0,sp,16
    80004bc2:	87aa                	mv	a5,a0
    int perm = 0;
    if(flags & 0x1)
    80004bc4:	0035151b          	slliw	a0,a0,0x3
    80004bc8:	8921                	andi	a0,a0,8
      perm = PTE_X;
    if(flags & 0x2)
    80004bca:	8b89                	andi	a5,a5,2
    80004bcc:	c399                	beqz	a5,80004bd2 <flags2perm+0x18>
      perm |= PTE_W;
    80004bce:	00456513          	ori	a0,a0,4
    return perm;
}
    80004bd2:	60a2                	ld	ra,8(sp)
    80004bd4:	6402                	ld	s0,0(sp)
    80004bd6:	0141                	addi	sp,sp,16
    80004bd8:	8082                	ret

0000000080004bda <kexec>:
//
// the implementation of the exec() system call
//
int
kexec(char *path, char **argv)
{
    80004bda:	de010113          	addi	sp,sp,-544
    80004bde:	20113c23          	sd	ra,536(sp)
    80004be2:	20813823          	sd	s0,528(sp)
    80004be6:	20913423          	sd	s1,520(sp)
    80004bea:	21213023          	sd	s2,512(sp)
    80004bee:	1400                	addi	s0,sp,544
    80004bf0:	892a                	mv	s2,a0
    80004bf2:	dea43823          	sd	a0,-528(s0)
    80004bf6:	e0b43023          	sd	a1,-512(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
  struct elfhdr elf;
  struct inode *ip;
  struct proghdr ph;
  pagetable_t pagetable = 0, oldpagetable;
  struct proc *p = myproc();
    80004bfa:	f37fc0ef          	jal	80001b30 <myproc>
    80004bfe:	84aa                	mv	s1,a0

  begin_op();
    80004c00:	d74ff0ef          	jal	80004174 <begin_op>

  // Open the executable file.
  if((ip = namei(path)) == 0){
    80004c04:	854a                	mv	a0,s2
    80004c06:	b90ff0ef          	jal	80003f96 <namei>
    80004c0a:	cd21                	beqz	a0,80004c62 <kexec+0x88>
    80004c0c:	fbd2                	sd	s4,496(sp)
    80004c0e:	8a2a                	mv	s4,a0
    end_op();
    return -1;
  }
  ilock(ip);
    80004c10:	ac9fe0ef          	jal	800036d8 <ilock>

  // Read the ELF header.
  if(readi(ip, 0, (uint64)&elf, 0, sizeof(elf)) != sizeof(elf))
    80004c14:	04000713          	li	a4,64
    80004c18:	4681                	li	a3,0
    80004c1a:	e5040613          	addi	a2,s0,-432
    80004c1e:	4581                	li	a1,0
    80004c20:	8552                	mv	a0,s4
    80004c22:	ed7fe0ef          	jal	80003af8 <readi>
    80004c26:	04000793          	li	a5,64
    80004c2a:	00f51a63          	bne	a0,a5,80004c3e <kexec+0x64>
    goto bad;

  // Is this really an ELF file?
  if(elf.magic != ELF_MAGIC)
    80004c2e:	e5042703          	lw	a4,-432(s0)
    80004c32:	464c47b7          	lui	a5,0x464c4
    80004c36:	57f78793          	addi	a5,a5,1407 # 464c457f <_entry-0x39b3ba81>
    80004c3a:	02f70863          	beq	a4,a5,80004c6a <kexec+0x90>

 bad:
  if(pagetable)
    proc_freepagetable(pagetable, sz);
  if(ip){
    iunlockput(ip);
    80004c3e:	8552                	mv	a0,s4
    80004c40:	d33fe0ef          	jal	80003972 <iunlockput>
    end_op();
    80004c44:	da0ff0ef          	jal	800041e4 <end_op>
  }
  return -1;
    80004c48:	557d                	li	a0,-1
    80004c4a:	7a5e                	ld	s4,496(sp)
}
    80004c4c:	21813083          	ld	ra,536(sp)
    80004c50:	21013403          	ld	s0,528(sp)
    80004c54:	20813483          	ld	s1,520(sp)
    80004c58:	20013903          	ld	s2,512(sp)
    80004c5c:	22010113          	addi	sp,sp,544
    80004c60:	8082                	ret
    end_op();
    80004c62:	d82ff0ef          	jal	800041e4 <end_op>
    return -1;
    80004c66:	557d                	li	a0,-1
    80004c68:	b7d5                	j	80004c4c <kexec+0x72>
    80004c6a:	f3da                	sd	s6,480(sp)
  if((pagetable = proc_pagetable(p)) == 0)
    80004c6c:	8526                	mv	a0,s1
    80004c6e:	fcdfc0ef          	jal	80001c3a <proc_pagetable>
    80004c72:	8b2a                	mv	s6,a0
    80004c74:	26050f63          	beqz	a0,80004ef2 <kexec+0x318>
    80004c78:	ffce                	sd	s3,504(sp)
    80004c7a:	f7d6                	sd	s5,488(sp)
    80004c7c:	efde                	sd	s7,472(sp)
    80004c7e:	ebe2                	sd	s8,464(sp)
    80004c80:	e7e6                	sd	s9,456(sp)
    80004c82:	e3ea                	sd	s10,448(sp)
    80004c84:	ff6e                	sd	s11,440(sp)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004c86:	e8845783          	lhu	a5,-376(s0)
    80004c8a:	0e078963          	beqz	a5,80004d7c <kexec+0x1a2>
    80004c8e:	e7042683          	lw	a3,-400(s0)
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004c92:	4901                	li	s2,0
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004c94:	4d01                	li	s10,0
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004c96:	03800d93          	li	s11,56
    if(ph.vaddr % PGSIZE != 0)
    80004c9a:	6c85                	lui	s9,0x1
    80004c9c:	fffc8793          	addi	a5,s9,-1 # fff <_entry-0x7ffff001>
    80004ca0:	def43423          	sd	a5,-536(s0)

  for(i = 0; i < sz; i += PGSIZE){
    pa = walkaddr(pagetable, va + i);
    if(pa == 0)
      panic("loadseg: address should exist");
    if(sz - i < PGSIZE)
    80004ca4:	6a85                	lui	s5,0x1
    80004ca6:	a085                	j	80004d06 <kexec+0x12c>
      panic("loadseg: address should exist");
    80004ca8:	00004517          	auipc	a0,0x4
    80004cac:	98850513          	addi	a0,a0,-1656 # 80008630 <etext+0x630>
    80004cb0:	b75fb0ef          	jal	80000824 <panic>
    if(sz - i < PGSIZE)
    80004cb4:	2901                	sext.w	s2,s2
      n = sz - i;
    else
      n = PGSIZE;
    if(readi(ip, 0, (uint64)pa, offset+i, n) != n)
    80004cb6:	874a                	mv	a4,s2
    80004cb8:	009b86bb          	addw	a3,s7,s1
    80004cbc:	4581                	li	a1,0
    80004cbe:	8552                	mv	a0,s4
    80004cc0:	e39fe0ef          	jal	80003af8 <readi>
    80004cc4:	22a91b63          	bne	s2,a0,80004efa <kexec+0x320>
  for(i = 0; i < sz; i += PGSIZE){
    80004cc8:	009a84bb          	addw	s1,s5,s1
    80004ccc:	0334f263          	bgeu	s1,s3,80004cf0 <kexec+0x116>
    pa = walkaddr(pagetable, va + i);
    80004cd0:	02049593          	slli	a1,s1,0x20
    80004cd4:	9181                	srli	a1,a1,0x20
    80004cd6:	95e2                	add	a1,a1,s8
    80004cd8:	855a                	mv	a0,s6
    80004cda:	d48fc0ef          	jal	80001222 <walkaddr>
    80004cde:	862a                	mv	a2,a0
    if(pa == 0)
    80004ce0:	d561                	beqz	a0,80004ca8 <kexec+0xce>
    if(sz - i < PGSIZE)
    80004ce2:	409987bb          	subw	a5,s3,s1
    80004ce6:	893e                	mv	s2,a5
    80004ce8:	fcfcf6e3          	bgeu	s9,a5,80004cb4 <kexec+0xda>
    80004cec:	8956                	mv	s2,s5
    80004cee:	b7d9                	j	80004cb4 <kexec+0xda>
    sz = sz1;
    80004cf0:	df843903          	ld	s2,-520(s0)
  for(i=0, off=elf.phoff; i<elf.phnum; i++, off+=sizeof(ph)){
    80004cf4:	2d05                	addiw	s10,s10,1
    80004cf6:	e0843783          	ld	a5,-504(s0)
    80004cfa:	0387869b          	addiw	a3,a5,56
    80004cfe:	e8845783          	lhu	a5,-376(s0)
    80004d02:	06fd5e63          	bge	s10,a5,80004d7e <kexec+0x1a4>
    if(readi(ip, 0, (uint64)&ph, off, sizeof(ph)) != sizeof(ph))
    80004d06:	e0d43423          	sd	a3,-504(s0)
    80004d0a:	876e                	mv	a4,s11
    80004d0c:	e1840613          	addi	a2,s0,-488
    80004d10:	4581                	li	a1,0
    80004d12:	8552                	mv	a0,s4
    80004d14:	de5fe0ef          	jal	80003af8 <readi>
    80004d18:	1db51f63          	bne	a0,s11,80004ef6 <kexec+0x31c>
    if(ph.type != ELF_PROG_LOAD)
    80004d1c:	e1842783          	lw	a5,-488(s0)
    80004d20:	4705                	li	a4,1
    80004d22:	fce799e3          	bne	a5,a4,80004cf4 <kexec+0x11a>
    if(ph.memsz < ph.filesz)
    80004d26:	e4043483          	ld	s1,-448(s0)
    80004d2a:	e3843783          	ld	a5,-456(s0)
    80004d2e:	1ef4e463          	bltu	s1,a5,80004f16 <kexec+0x33c>
    if(ph.vaddr + ph.memsz < ph.vaddr)
    80004d32:	e2843783          	ld	a5,-472(s0)
    80004d36:	94be                	add	s1,s1,a5
    80004d38:	1ef4e263          	bltu	s1,a5,80004f1c <kexec+0x342>
    if(ph.vaddr % PGSIZE != 0)
    80004d3c:	de843703          	ld	a4,-536(s0)
    80004d40:	8ff9                	and	a5,a5,a4
    80004d42:	1e079063          	bnez	a5,80004f22 <kexec+0x348>
    if((sz1 = uvmalloc(pagetable, sz, ph.vaddr + ph.memsz, flags2perm(ph.flags))) == 0)
    80004d46:	e1c42503          	lw	a0,-484(s0)
    80004d4a:	e71ff0ef          	jal	80004bba <flags2perm>
    80004d4e:	86aa                	mv	a3,a0
    80004d50:	8626                	mv	a2,s1
    80004d52:	85ca                	mv	a1,s2
    80004d54:	855a                	mv	a0,s6
    80004d56:	fa2fc0ef          	jal	800014f8 <uvmalloc>
    80004d5a:	dea43c23          	sd	a0,-520(s0)
    80004d5e:	1c050563          	beqz	a0,80004f28 <kexec+0x34e>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004d62:	e3842983          	lw	s3,-456(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004d66:	00098863          	beqz	s3,80004d76 <kexec+0x19c>
    if(loadseg(pagetable, ph.vaddr, ip, ph.off, ph.filesz) < 0)
    80004d6a:	e2843c03          	ld	s8,-472(s0)
    80004d6e:	e2042b83          	lw	s7,-480(s0)
  for(i = 0; i < sz; i += PGSIZE){
    80004d72:	4481                	li	s1,0
    80004d74:	bfb1                	j	80004cd0 <kexec+0xf6>
    sz = sz1;
    80004d76:	df843903          	ld	s2,-520(s0)
    80004d7a:	bfad                	j	80004cf4 <kexec+0x11a>
  uint64 argc, sz = 0, sp, ustack[MAXARG], stackbase;
    80004d7c:	4901                	li	s2,0
  iunlockput(ip);
    80004d7e:	8552                	mv	a0,s4
    80004d80:	bf3fe0ef          	jal	80003972 <iunlockput>
  end_op();
    80004d84:	c60ff0ef          	jal	800041e4 <end_op>
  p = myproc();
    80004d88:	da9fc0ef          	jal	80001b30 <myproc>
    80004d8c:	8aaa                	mv	s5,a0
  uint64 oldsz = p->sz;
    80004d8e:	04853d03          	ld	s10,72(a0)
  sz = PGROUNDUP(sz);
    80004d92:	6985                	lui	s3,0x1
    80004d94:	19fd                	addi	s3,s3,-1 # fff <_entry-0x7ffff001>
    80004d96:	99ca                	add	s3,s3,s2
    80004d98:	77fd                	lui	a5,0xfffff
    80004d9a:	00f9f9b3          	and	s3,s3,a5
  if((sz1 = uvmalloc(pagetable, sz, sz + (USERSTACK+1)*PGSIZE, PTE_W)) == 0)
    80004d9e:	4691                	li	a3,4
    80004da0:	6609                	lui	a2,0x2
    80004da2:	964e                	add	a2,a2,s3
    80004da4:	85ce                	mv	a1,s3
    80004da6:	855a                	mv	a0,s6
    80004da8:	f50fc0ef          	jal	800014f8 <uvmalloc>
    80004dac:	8a2a                	mv	s4,a0
    80004dae:	e105                	bnez	a0,80004dce <kexec+0x1f4>
    proc_freepagetable(pagetable, sz);
    80004db0:	85ce                	mv	a1,s3
    80004db2:	855a                	mv	a0,s6
    80004db4:	f0bfc0ef          	jal	80001cbe <proc_freepagetable>
  return -1;
    80004db8:	557d                	li	a0,-1
    80004dba:	79fe                	ld	s3,504(sp)
    80004dbc:	7a5e                	ld	s4,496(sp)
    80004dbe:	7abe                	ld	s5,488(sp)
    80004dc0:	7b1e                	ld	s6,480(sp)
    80004dc2:	6bfe                	ld	s7,472(sp)
    80004dc4:	6c5e                	ld	s8,464(sp)
    80004dc6:	6cbe                	ld	s9,456(sp)
    80004dc8:	6d1e                	ld	s10,448(sp)
    80004dca:	7dfa                	ld	s11,440(sp)
    80004dcc:	b541                	j	80004c4c <kexec+0x72>
  uvmclear(pagetable, sz-(USERSTACK+1)*PGSIZE);
    80004dce:	75f9                	lui	a1,0xffffe
    80004dd0:	95aa                	add	a1,a1,a0
    80004dd2:	855a                	mv	a0,s6
    80004dd4:	8fdfc0ef          	jal	800016d0 <uvmclear>
  stackbase = sp - USERSTACK*PGSIZE;
    80004dd8:	800a0b93          	addi	s7,s4,-2048
    80004ddc:	800b8b93          	addi	s7,s7,-2048
  for(argc = 0; argv[argc]; argc++) {
    80004de0:	e0043783          	ld	a5,-512(s0)
    80004de4:	6388                	ld	a0,0(a5)
  sp = sz;
    80004de6:	8952                	mv	s2,s4
  for(argc = 0; argv[argc]; argc++) {
    80004de8:	4481                	li	s1,0
    ustack[argc] = sp;
    80004dea:	e9040c93          	addi	s9,s0,-368
    if(argc >= MAXARG)
    80004dee:	02000c13          	li	s8,32
  for(argc = 0; argv[argc]; argc++) {
    80004df2:	cd21                	beqz	a0,80004e4a <kexec+0x270>
    sp -= strlen(argv[argc]) + 1;
    80004df4:	a82fc0ef          	jal	80001076 <strlen>
    80004df8:	0015079b          	addiw	a5,a0,1
    80004dfc:	40f907b3          	sub	a5,s2,a5
    sp -= sp % 16; // riscv sp must be 16-byte aligned
    80004e00:	ff07f913          	andi	s2,a5,-16
    if(sp < stackbase)
    80004e04:	13796563          	bltu	s2,s7,80004f2e <kexec+0x354>
    if(copyout(pagetable, sp, argv[argc], strlen(argv[argc]) + 1) < 0)
    80004e08:	e0043d83          	ld	s11,-512(s0)
    80004e0c:	000db983          	ld	s3,0(s11)
    80004e10:	854e                	mv	a0,s3
    80004e12:	a64fc0ef          	jal	80001076 <strlen>
    80004e16:	0015069b          	addiw	a3,a0,1
    80004e1a:	864e                	mv	a2,s3
    80004e1c:	85ca                	mv	a1,s2
    80004e1e:	855a                	mv	a0,s6
    80004e20:	a37fc0ef          	jal	80001856 <copyout>
    80004e24:	10054763          	bltz	a0,80004f32 <kexec+0x358>
    ustack[argc] = sp;
    80004e28:	00349793          	slli	a5,s1,0x3
    80004e2c:	97e6                	add	a5,a5,s9
    80004e2e:	0127b023          	sd	s2,0(a5) # fffffffffffff000 <end+0xffffffff7fd9fe98>
  for(argc = 0; argv[argc]; argc++) {
    80004e32:	0485                	addi	s1,s1,1
    80004e34:	008d8793          	addi	a5,s11,8
    80004e38:	e0f43023          	sd	a5,-512(s0)
    80004e3c:	008db503          	ld	a0,8(s11)
    80004e40:	c509                	beqz	a0,80004e4a <kexec+0x270>
    if(argc >= MAXARG)
    80004e42:	fb8499e3          	bne	s1,s8,80004df4 <kexec+0x21a>
  sz = sz1;
    80004e46:	89d2                	mv	s3,s4
    80004e48:	b7a5                	j	80004db0 <kexec+0x1d6>
  ustack[argc] = 0;
    80004e4a:	00349793          	slli	a5,s1,0x3
    80004e4e:	f9078793          	addi	a5,a5,-112
    80004e52:	97a2                	add	a5,a5,s0
    80004e54:	f007b023          	sd	zero,-256(a5)
  sp -= (argc+1) * sizeof(uint64);
    80004e58:	00349693          	slli	a3,s1,0x3
    80004e5c:	06a1                	addi	a3,a3,8
    80004e5e:	40d90933          	sub	s2,s2,a3
  sp -= sp % 16;
    80004e62:	ff097913          	andi	s2,s2,-16
  sz = sz1;
    80004e66:	89d2                	mv	s3,s4
  if(sp < stackbase)
    80004e68:	f57964e3          	bltu	s2,s7,80004db0 <kexec+0x1d6>
  if(copyout(pagetable, sp, (char *)ustack, (argc+1)*sizeof(uint64)) < 0)
    80004e6c:	e9040613          	addi	a2,s0,-368
    80004e70:	85ca                	mv	a1,s2
    80004e72:	855a                	mv	a0,s6
    80004e74:	9e3fc0ef          	jal	80001856 <copyout>
    80004e78:	f2054ce3          	bltz	a0,80004db0 <kexec+0x1d6>
  p->trapframe->a1 = sp;
    80004e7c:	058ab783          	ld	a5,88(s5) # 1058 <_entry-0x7fffefa8>
    80004e80:	0727bc23          	sd	s2,120(a5)
  for(last=s=path; *s; s++)
    80004e84:	df043783          	ld	a5,-528(s0)
    80004e88:	0007c703          	lbu	a4,0(a5)
    80004e8c:	cf11                	beqz	a4,80004ea8 <kexec+0x2ce>
    80004e8e:	0785                	addi	a5,a5,1
    if(*s == '/')
    80004e90:	02f00693          	li	a3,47
    80004e94:	a029                	j	80004e9e <kexec+0x2c4>
  for(last=s=path; *s; s++)
    80004e96:	0785                	addi	a5,a5,1
    80004e98:	fff7c703          	lbu	a4,-1(a5)
    80004e9c:	c711                	beqz	a4,80004ea8 <kexec+0x2ce>
    if(*s == '/')
    80004e9e:	fed71ce3          	bne	a4,a3,80004e96 <kexec+0x2bc>
      last = s+1;
    80004ea2:	def43823          	sd	a5,-528(s0)
    80004ea6:	bfc5                	j	80004e96 <kexec+0x2bc>
  safestrcpy(p->name, last, sizeof(p->name));
    80004ea8:	4641                	li	a2,16
    80004eaa:	df043583          	ld	a1,-528(s0)
    80004eae:	158a8513          	addi	a0,s5,344
    80004eb2:	98efc0ef          	jal	80001040 <safestrcpy>
  oldpagetable = p->pagetable;
    80004eb6:	050ab503          	ld	a0,80(s5)
  p->pagetable = pagetable;
    80004eba:	056ab823          	sd	s6,80(s5)
  p->sz = sz;
    80004ebe:	054ab423          	sd	s4,72(s5)
  p->trapframe->epc = elf.entry;  // initial program counter = main
    80004ec2:	058ab783          	ld	a5,88(s5)
    80004ec6:	e6843703          	ld	a4,-408(s0)
    80004eca:	ef98                	sd	a4,24(a5)
  p->trapframe->sp = sp; // initial stack pointer
    80004ecc:	058ab783          	ld	a5,88(s5)
    80004ed0:	0327b823          	sd	s2,48(a5)
  proc_freepagetable(oldpagetable, oldsz);
    80004ed4:	85ea                	mv	a1,s10
    80004ed6:	de9fc0ef          	jal	80001cbe <proc_freepagetable>
  return argc; // this ends up in a0, the first argument to main(argc, argv)
    80004eda:	0004851b          	sext.w	a0,s1
    80004ede:	79fe                	ld	s3,504(sp)
    80004ee0:	7a5e                	ld	s4,496(sp)
    80004ee2:	7abe                	ld	s5,488(sp)
    80004ee4:	7b1e                	ld	s6,480(sp)
    80004ee6:	6bfe                	ld	s7,472(sp)
    80004ee8:	6c5e                	ld	s8,464(sp)
    80004eea:	6cbe                	ld	s9,456(sp)
    80004eec:	6d1e                	ld	s10,448(sp)
    80004eee:	7dfa                	ld	s11,440(sp)
    80004ef0:	bbb1                	j	80004c4c <kexec+0x72>
    80004ef2:	7b1e                	ld	s6,480(sp)
    80004ef4:	b3a9                	j	80004c3e <kexec+0x64>
    80004ef6:	df243c23          	sd	s2,-520(s0)
    proc_freepagetable(pagetable, sz);
    80004efa:	df843583          	ld	a1,-520(s0)
    80004efe:	855a                	mv	a0,s6
    80004f00:	dbffc0ef          	jal	80001cbe <proc_freepagetable>
  if(ip){
    80004f04:	79fe                	ld	s3,504(sp)
    80004f06:	7abe                	ld	s5,488(sp)
    80004f08:	7b1e                	ld	s6,480(sp)
    80004f0a:	6bfe                	ld	s7,472(sp)
    80004f0c:	6c5e                	ld	s8,464(sp)
    80004f0e:	6cbe                	ld	s9,456(sp)
    80004f10:	6d1e                	ld	s10,448(sp)
    80004f12:	7dfa                	ld	s11,440(sp)
    80004f14:	b32d                	j	80004c3e <kexec+0x64>
    80004f16:	df243c23          	sd	s2,-520(s0)
    80004f1a:	b7c5                	j	80004efa <kexec+0x320>
    80004f1c:	df243c23          	sd	s2,-520(s0)
    80004f20:	bfe9                	j	80004efa <kexec+0x320>
    80004f22:	df243c23          	sd	s2,-520(s0)
    80004f26:	bfd1                	j	80004efa <kexec+0x320>
    80004f28:	df243c23          	sd	s2,-520(s0)
    80004f2c:	b7f9                	j	80004efa <kexec+0x320>
  sz = sz1;
    80004f2e:	89d2                	mv	s3,s4
    80004f30:	b541                	j	80004db0 <kexec+0x1d6>
    80004f32:	89d2                	mv	s3,s4
    80004f34:	bdb5                	j	80004db0 <kexec+0x1d6>

0000000080004f36 <argfd>:

// Fetch the nth word-sized system call argument as a file descriptor
// and return both the descriptor and the corresponding struct file.
static int
argfd(int n, int *pfd, struct file **pf)
{
    80004f36:	7179                	addi	sp,sp,-48
    80004f38:	f406                	sd	ra,40(sp)
    80004f3a:	f022                	sd	s0,32(sp)
    80004f3c:	ec26                	sd	s1,24(sp)
    80004f3e:	e84a                	sd	s2,16(sp)
    80004f40:	1800                	addi	s0,sp,48
    80004f42:	892e                	mv	s2,a1
    80004f44:	84b2                	mv	s1,a2
  int fd;
  struct file *f;

  argint(n, &fd);
    80004f46:	fdc40593          	addi	a1,s0,-36
    80004f4a:	be1fd0ef          	jal	80002b2a <argint>
  if(fd < 0 || fd >= NOFILE || (f=myproc()->ofile[fd]) == 0)
    80004f4e:	fdc42703          	lw	a4,-36(s0)
    80004f52:	47bd                	li	a5,15
    80004f54:	02e7ea63          	bltu	a5,a4,80004f88 <argfd+0x52>
    80004f58:	bd9fc0ef          	jal	80001b30 <myproc>
    80004f5c:	fdc42703          	lw	a4,-36(s0)
    80004f60:	00371793          	slli	a5,a4,0x3
    80004f64:	0d078793          	addi	a5,a5,208
    80004f68:	953e                	add	a0,a0,a5
    80004f6a:	611c                	ld	a5,0(a0)
    80004f6c:	c385                	beqz	a5,80004f8c <argfd+0x56>
    return -1;
  if(pfd)
    80004f6e:	00090463          	beqz	s2,80004f76 <argfd+0x40>
    *pfd = fd;
    80004f72:	00e92023          	sw	a4,0(s2)
  if(pf)
    *pf = f;
  return 0;
    80004f76:	4501                	li	a0,0
  if(pf)
    80004f78:	c091                	beqz	s1,80004f7c <argfd+0x46>
    *pf = f;
    80004f7a:	e09c                	sd	a5,0(s1)
}
    80004f7c:	70a2                	ld	ra,40(sp)
    80004f7e:	7402                	ld	s0,32(sp)
    80004f80:	64e2                	ld	s1,24(sp)
    80004f82:	6942                	ld	s2,16(sp)
    80004f84:	6145                	addi	sp,sp,48
    80004f86:	8082                	ret
    return -1;
    80004f88:	557d                	li	a0,-1
    80004f8a:	bfcd                	j	80004f7c <argfd+0x46>
    80004f8c:	557d                	li	a0,-1
    80004f8e:	b7fd                	j	80004f7c <argfd+0x46>

0000000080004f90 <fdalloc>:

// Allocate a file descriptor for the given file.
// Takes over file reference from caller on success.
static int
fdalloc(struct file *f)
{
    80004f90:	1101                	addi	sp,sp,-32
    80004f92:	ec06                	sd	ra,24(sp)
    80004f94:	e822                	sd	s0,16(sp)
    80004f96:	e426                	sd	s1,8(sp)
    80004f98:	1000                	addi	s0,sp,32
    80004f9a:	84aa                	mv	s1,a0
  int fd;
  struct proc *p = myproc();
    80004f9c:	b95fc0ef          	jal	80001b30 <myproc>
    80004fa0:	862a                	mv	a2,a0

  for(fd = 0; fd < NOFILE; fd++){
    80004fa2:	0d050793          	addi	a5,a0,208
    80004fa6:	4501                	li	a0,0
    80004fa8:	46c1                	li	a3,16
    if(p->ofile[fd] == 0){
    80004faa:	6398                	ld	a4,0(a5)
    80004fac:	cb19                	beqz	a4,80004fc2 <fdalloc+0x32>
  for(fd = 0; fd < NOFILE; fd++){
    80004fae:	2505                	addiw	a0,a0,1
    80004fb0:	07a1                	addi	a5,a5,8
    80004fb2:	fed51ce3          	bne	a0,a3,80004faa <fdalloc+0x1a>
      p->ofile[fd] = f;
      return fd;
    }
  }
  return -1;
    80004fb6:	557d                	li	a0,-1
}
    80004fb8:	60e2                	ld	ra,24(sp)
    80004fba:	6442                	ld	s0,16(sp)
    80004fbc:	64a2                	ld	s1,8(sp)
    80004fbe:	6105                	addi	sp,sp,32
    80004fc0:	8082                	ret
      p->ofile[fd] = f;
    80004fc2:	00351793          	slli	a5,a0,0x3
    80004fc6:	0d078793          	addi	a5,a5,208
    80004fca:	963e                	add	a2,a2,a5
    80004fcc:	e204                	sd	s1,0(a2)
      return fd;
    80004fce:	b7ed                	j	80004fb8 <fdalloc+0x28>

0000000080004fd0 <create>:
  return -1;
}

static struct inode*
create(char *path, short type, short major, short minor)
{
    80004fd0:	715d                	addi	sp,sp,-80
    80004fd2:	e486                	sd	ra,72(sp)
    80004fd4:	e0a2                	sd	s0,64(sp)
    80004fd6:	fc26                	sd	s1,56(sp)
    80004fd8:	f84a                	sd	s2,48(sp)
    80004fda:	f44e                	sd	s3,40(sp)
    80004fdc:	f052                	sd	s4,32(sp)
    80004fde:	ec56                	sd	s5,24(sp)
    80004fe0:	e85a                	sd	s6,16(sp)
    80004fe2:	0880                	addi	s0,sp,80
    80004fe4:	892e                	mv	s2,a1
    80004fe6:	8a2e                	mv	s4,a1
    80004fe8:	8ab2                	mv	s5,a2
    80004fea:	8b36                	mv	s6,a3
  struct inode *ip, *dp;
  char name[DIRSIZ];

  if((dp = nameiparent(path, name)) == 0)
    80004fec:	fb040593          	addi	a1,s0,-80
    80004ff0:	fc1fe0ef          	jal	80003fb0 <nameiparent>
    80004ff4:	84aa                	mv	s1,a0
    80004ff6:	10050763          	beqz	a0,80005104 <create+0x134>
    return 0;

  ilock(dp);
    80004ffa:	edefe0ef          	jal	800036d8 <ilock>

  if((ip = dirlookup(dp, name, 0)) != 0){
    80004ffe:	4601                	li	a2,0
    80005000:	fb040593          	addi	a1,s0,-80
    80005004:	8526                	mv	a0,s1
    80005006:	cfdfe0ef          	jal	80003d02 <dirlookup>
    8000500a:	89aa                	mv	s3,a0
    8000500c:	c131                	beqz	a0,80005050 <create+0x80>
    iunlockput(dp);
    8000500e:	8526                	mv	a0,s1
    80005010:	963fe0ef          	jal	80003972 <iunlockput>
    ilock(ip);
    80005014:	854e                	mv	a0,s3
    80005016:	ec2fe0ef          	jal	800036d8 <ilock>
    if(type == T_FILE && (ip->type == T_FILE || ip->type == T_DEVICE))
    8000501a:	4789                	li	a5,2
    8000501c:	02f91563          	bne	s2,a5,80005046 <create+0x76>
    80005020:	0449d783          	lhu	a5,68(s3)
    80005024:	37f9                	addiw	a5,a5,-2
    80005026:	17c2                	slli	a5,a5,0x30
    80005028:	93c1                	srli	a5,a5,0x30
    8000502a:	4705                	li	a4,1
    8000502c:	00f76d63          	bltu	a4,a5,80005046 <create+0x76>
  ip->nlink = 0;
  iupdate(ip);
  iunlockput(ip);
  iunlockput(dp);
  return 0;
}
    80005030:	854e                	mv	a0,s3
    80005032:	60a6                	ld	ra,72(sp)
    80005034:	6406                	ld	s0,64(sp)
    80005036:	74e2                	ld	s1,56(sp)
    80005038:	7942                	ld	s2,48(sp)
    8000503a:	79a2                	ld	s3,40(sp)
    8000503c:	7a02                	ld	s4,32(sp)
    8000503e:	6ae2                	ld	s5,24(sp)
    80005040:	6b42                	ld	s6,16(sp)
    80005042:	6161                	addi	sp,sp,80
    80005044:	8082                	ret
    iunlockput(ip);
    80005046:	854e                	mv	a0,s3
    80005048:	92bfe0ef          	jal	80003972 <iunlockput>
    return 0;
    8000504c:	4981                	li	s3,0
    8000504e:	b7cd                	j	80005030 <create+0x60>
  if((ip = ialloc(dp->dev, type)) == 0){
    80005050:	85ca                	mv	a1,s2
    80005052:	4088                	lw	a0,0(s1)
    80005054:	d14fe0ef          	jal	80003568 <ialloc>
    80005058:	892a                	mv	s2,a0
    8000505a:	cd15                	beqz	a0,80005096 <create+0xc6>
  ilock(ip);
    8000505c:	e7cfe0ef          	jal	800036d8 <ilock>
  ip->major = major;
    80005060:	05591323          	sh	s5,70(s2)
  ip->minor = minor;
    80005064:	05691423          	sh	s6,72(s2)
  ip->nlink = 1;
    80005068:	4785                	li	a5,1
    8000506a:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    8000506e:	854a                	mv	a0,s2
    80005070:	db4fe0ef          	jal	80003624 <iupdate>
  if(type == T_DIR){  // Create . and .. entries.
    80005074:	4705                	li	a4,1
    80005076:	02ea0463          	beq	s4,a4,8000509e <create+0xce>
  if(dirlink(dp, name, ip->inum) < 0)
    8000507a:	00492603          	lw	a2,4(s2)
    8000507e:	fb040593          	addi	a1,s0,-80
    80005082:	8526                	mv	a0,s1
    80005084:	e69fe0ef          	jal	80003eec <dirlink>
    80005088:	06054263          	bltz	a0,800050ec <create+0x11c>
  iunlockput(dp);
    8000508c:	8526                	mv	a0,s1
    8000508e:	8e5fe0ef          	jal	80003972 <iunlockput>
  return ip;
    80005092:	89ca                	mv	s3,s2
    80005094:	bf71                	j	80005030 <create+0x60>
    iunlockput(dp);
    80005096:	8526                	mv	a0,s1
    80005098:	8dbfe0ef          	jal	80003972 <iunlockput>
    return 0;
    8000509c:	bf51                	j	80005030 <create+0x60>
    if(dirlink(ip, ".", ip->inum) < 0 || dirlink(ip, "..", dp->inum) < 0)
    8000509e:	00492603          	lw	a2,4(s2)
    800050a2:	00003597          	auipc	a1,0x3
    800050a6:	5ae58593          	addi	a1,a1,1454 # 80008650 <etext+0x650>
    800050aa:	854a                	mv	a0,s2
    800050ac:	e41fe0ef          	jal	80003eec <dirlink>
    800050b0:	02054e63          	bltz	a0,800050ec <create+0x11c>
    800050b4:	40d0                	lw	a2,4(s1)
    800050b6:	00003597          	auipc	a1,0x3
    800050ba:	5a258593          	addi	a1,a1,1442 # 80008658 <etext+0x658>
    800050be:	854a                	mv	a0,s2
    800050c0:	e2dfe0ef          	jal	80003eec <dirlink>
    800050c4:	02054463          	bltz	a0,800050ec <create+0x11c>
  if(dirlink(dp, name, ip->inum) < 0)
    800050c8:	00492603          	lw	a2,4(s2)
    800050cc:	fb040593          	addi	a1,s0,-80
    800050d0:	8526                	mv	a0,s1
    800050d2:	e1bfe0ef          	jal	80003eec <dirlink>
    800050d6:	00054b63          	bltz	a0,800050ec <create+0x11c>
    dp->nlink++;  // for ".."
    800050da:	04a4d783          	lhu	a5,74(s1)
    800050de:	2785                	addiw	a5,a5,1
    800050e0:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800050e4:	8526                	mv	a0,s1
    800050e6:	d3efe0ef          	jal	80003624 <iupdate>
    800050ea:	b74d                	j	8000508c <create+0xbc>
  ip->nlink = 0;
    800050ec:	04091523          	sh	zero,74(s2)
  iupdate(ip);
    800050f0:	854a                	mv	a0,s2
    800050f2:	d32fe0ef          	jal	80003624 <iupdate>
  iunlockput(ip);
    800050f6:	854a                	mv	a0,s2
    800050f8:	87bfe0ef          	jal	80003972 <iunlockput>
  iunlockput(dp);
    800050fc:	8526                	mv	a0,s1
    800050fe:	875fe0ef          	jal	80003972 <iunlockput>
  return 0;
    80005102:	b73d                	j	80005030 <create+0x60>
    return 0;
    80005104:	89aa                	mv	s3,a0
    80005106:	b72d                	j	80005030 <create+0x60>

0000000080005108 <sys_dup>:
{
    80005108:	7179                	addi	sp,sp,-48
    8000510a:	f406                	sd	ra,40(sp)
    8000510c:	f022                	sd	s0,32(sp)
    8000510e:	1800                	addi	s0,sp,48
  if(argfd(0, 0, &f) < 0)
    80005110:	fd840613          	addi	a2,s0,-40
    80005114:	4581                	li	a1,0
    80005116:	4501                	li	a0,0
    80005118:	e1fff0ef          	jal	80004f36 <argfd>
    return -1;
    8000511c:	57fd                	li	a5,-1
  if(argfd(0, 0, &f) < 0)
    8000511e:	02054363          	bltz	a0,80005144 <sys_dup+0x3c>
    80005122:	ec26                	sd	s1,24(sp)
    80005124:	e84a                	sd	s2,16(sp)
  if((fd=fdalloc(f)) < 0)
    80005126:	fd843483          	ld	s1,-40(s0)
    8000512a:	8526                	mv	a0,s1
    8000512c:	e65ff0ef          	jal	80004f90 <fdalloc>
    80005130:	892a                	mv	s2,a0
    return -1;
    80005132:	57fd                	li	a5,-1
  if((fd=fdalloc(f)) < 0)
    80005134:	00054d63          	bltz	a0,8000514e <sys_dup+0x46>
  filedup(f);
    80005138:	8526                	mv	a0,s1
    8000513a:	c18ff0ef          	jal	80004552 <filedup>
  return fd;
    8000513e:	87ca                	mv	a5,s2
    80005140:	64e2                	ld	s1,24(sp)
    80005142:	6942                	ld	s2,16(sp)
}
    80005144:	853e                	mv	a0,a5
    80005146:	70a2                	ld	ra,40(sp)
    80005148:	7402                	ld	s0,32(sp)
    8000514a:	6145                	addi	sp,sp,48
    8000514c:	8082                	ret
    8000514e:	64e2                	ld	s1,24(sp)
    80005150:	6942                	ld	s2,16(sp)
    80005152:	bfcd                	j	80005144 <sys_dup+0x3c>

0000000080005154 <sys_read>:
{
    80005154:	7179                	addi	sp,sp,-48
    80005156:	f406                	sd	ra,40(sp)
    80005158:	f022                	sd	s0,32(sp)
    8000515a:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    8000515c:	fd840593          	addi	a1,s0,-40
    80005160:	4505                	li	a0,1
    80005162:	9e5fd0ef          	jal	80002b46 <argaddr>
  argint(2, &n);
    80005166:	fe440593          	addi	a1,s0,-28
    8000516a:	4509                	li	a0,2
    8000516c:	9bffd0ef          	jal	80002b2a <argint>
  if(argfd(0, 0, &f) < 0)
    80005170:	fe840613          	addi	a2,s0,-24
    80005174:	4581                	li	a1,0
    80005176:	4501                	li	a0,0
    80005178:	dbfff0ef          	jal	80004f36 <argfd>
    8000517c:	87aa                	mv	a5,a0
    return -1;
    8000517e:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    80005180:	0007ca63          	bltz	a5,80005194 <sys_read+0x40>
  return fileread(f, p, n);
    80005184:	fe442603          	lw	a2,-28(s0)
    80005188:	fd843583          	ld	a1,-40(s0)
    8000518c:	fe843503          	ld	a0,-24(s0)
    80005190:	d2cff0ef          	jal	800046bc <fileread>
}
    80005194:	70a2                	ld	ra,40(sp)
    80005196:	7402                	ld	s0,32(sp)
    80005198:	6145                	addi	sp,sp,48
    8000519a:	8082                	ret

000000008000519c <sys_write>:
{
    8000519c:	7179                	addi	sp,sp,-48
    8000519e:	f406                	sd	ra,40(sp)
    800051a0:	f022                	sd	s0,32(sp)
    800051a2:	1800                	addi	s0,sp,48
  argaddr(1, &p);
    800051a4:	fd840593          	addi	a1,s0,-40
    800051a8:	4505                	li	a0,1
    800051aa:	99dfd0ef          	jal	80002b46 <argaddr>
  argint(2, &n);
    800051ae:	fe440593          	addi	a1,s0,-28
    800051b2:	4509                	li	a0,2
    800051b4:	977fd0ef          	jal	80002b2a <argint>
  if(argfd(0, 0, &f) < 0)
    800051b8:	fe840613          	addi	a2,s0,-24
    800051bc:	4581                	li	a1,0
    800051be:	4501                	li	a0,0
    800051c0:	d77ff0ef          	jal	80004f36 <argfd>
    800051c4:	87aa                	mv	a5,a0
    return -1;
    800051c6:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    800051c8:	0007ca63          	bltz	a5,800051dc <sys_write+0x40>
  return filewrite(f, p, n);
    800051cc:	fe442603          	lw	a2,-28(s0)
    800051d0:	fd843583          	ld	a1,-40(s0)
    800051d4:	fe843503          	ld	a0,-24(s0)
    800051d8:	da8ff0ef          	jal	80004780 <filewrite>
}
    800051dc:	70a2                	ld	ra,40(sp)
    800051de:	7402                	ld	s0,32(sp)
    800051e0:	6145                	addi	sp,sp,48
    800051e2:	8082                	ret

00000000800051e4 <sys_close>:
{
    800051e4:	1101                	addi	sp,sp,-32
    800051e6:	ec06                	sd	ra,24(sp)
    800051e8:	e822                	sd	s0,16(sp)
    800051ea:	1000                	addi	s0,sp,32
  if(argfd(0, &fd, &f) < 0)
    800051ec:	fe040613          	addi	a2,s0,-32
    800051f0:	fec40593          	addi	a1,s0,-20
    800051f4:	4501                	li	a0,0
    800051f6:	d41ff0ef          	jal	80004f36 <argfd>
    return -1;
    800051fa:	57fd                	li	a5,-1
  if(argfd(0, &fd, &f) < 0)
    800051fc:	02054163          	bltz	a0,8000521e <sys_close+0x3a>
  myproc()->ofile[fd] = 0;
    80005200:	931fc0ef          	jal	80001b30 <myproc>
    80005204:	fec42783          	lw	a5,-20(s0)
    80005208:	078e                	slli	a5,a5,0x3
    8000520a:	0d078793          	addi	a5,a5,208
    8000520e:	953e                	add	a0,a0,a5
    80005210:	00053023          	sd	zero,0(a0)
  fileclose(f);
    80005214:	fe043503          	ld	a0,-32(s0)
    80005218:	b80ff0ef          	jal	80004598 <fileclose>
  return 0;
    8000521c:	4781                	li	a5,0
}
    8000521e:	853e                	mv	a0,a5
    80005220:	60e2                	ld	ra,24(sp)
    80005222:	6442                	ld	s0,16(sp)
    80005224:	6105                	addi	sp,sp,32
    80005226:	8082                	ret

0000000080005228 <sys_fstat>:
{
    80005228:	1101                	addi	sp,sp,-32
    8000522a:	ec06                	sd	ra,24(sp)
    8000522c:	e822                	sd	s0,16(sp)
    8000522e:	1000                	addi	s0,sp,32
  argaddr(1, &st);
    80005230:	fe040593          	addi	a1,s0,-32
    80005234:	4505                	li	a0,1
    80005236:	911fd0ef          	jal	80002b46 <argaddr>
  if(argfd(0, 0, &f) < 0)
    8000523a:	fe840613          	addi	a2,s0,-24
    8000523e:	4581                	li	a1,0
    80005240:	4501                	li	a0,0
    80005242:	cf5ff0ef          	jal	80004f36 <argfd>
    80005246:	87aa                	mv	a5,a0
    return -1;
    80005248:	557d                	li	a0,-1
  if(argfd(0, 0, &f) < 0)
    8000524a:	0007c863          	bltz	a5,8000525a <sys_fstat+0x32>
  return filestat(f, st);
    8000524e:	fe043583          	ld	a1,-32(s0)
    80005252:	fe843503          	ld	a0,-24(s0)
    80005256:	c04ff0ef          	jal	8000465a <filestat>
}
    8000525a:	60e2                	ld	ra,24(sp)
    8000525c:	6442                	ld	s0,16(sp)
    8000525e:	6105                	addi	sp,sp,32
    80005260:	8082                	ret

0000000080005262 <sys_link>:
{
    80005262:	7169                	addi	sp,sp,-304
    80005264:	f606                	sd	ra,296(sp)
    80005266:	f222                	sd	s0,288(sp)
    80005268:	1a00                	addi	s0,sp,304
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000526a:	08000613          	li	a2,128
    8000526e:	ed040593          	addi	a1,s0,-304
    80005272:	4501                	li	a0,0
    80005274:	8effd0ef          	jal	80002b62 <argstr>
    return -1;
    80005278:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000527a:	0c054e63          	bltz	a0,80005356 <sys_link+0xf4>
    8000527e:	08000613          	li	a2,128
    80005282:	f5040593          	addi	a1,s0,-176
    80005286:	4505                	li	a0,1
    80005288:	8dbfd0ef          	jal	80002b62 <argstr>
    return -1;
    8000528c:	57fd                	li	a5,-1
  if(argstr(0, old, MAXPATH) < 0 || argstr(1, new, MAXPATH) < 0)
    8000528e:	0c054463          	bltz	a0,80005356 <sys_link+0xf4>
    80005292:	ee26                	sd	s1,280(sp)
  begin_op();
    80005294:	ee1fe0ef          	jal	80004174 <begin_op>
  if((ip = namei(old)) == 0){
    80005298:	ed040513          	addi	a0,s0,-304
    8000529c:	cfbfe0ef          	jal	80003f96 <namei>
    800052a0:	84aa                	mv	s1,a0
    800052a2:	c53d                	beqz	a0,80005310 <sys_link+0xae>
  ilock(ip);
    800052a4:	c34fe0ef          	jal	800036d8 <ilock>
  if(ip->type == T_DIR){
    800052a8:	04449703          	lh	a4,68(s1)
    800052ac:	4785                	li	a5,1
    800052ae:	06f70663          	beq	a4,a5,8000531a <sys_link+0xb8>
    800052b2:	ea4a                	sd	s2,272(sp)
  ip->nlink++;
    800052b4:	04a4d783          	lhu	a5,74(s1)
    800052b8:	2785                	addiw	a5,a5,1
    800052ba:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    800052be:	8526                	mv	a0,s1
    800052c0:	b64fe0ef          	jal	80003624 <iupdate>
  iunlock(ip);
    800052c4:	8526                	mv	a0,s1
    800052c6:	cc0fe0ef          	jal	80003786 <iunlock>
  if((dp = nameiparent(new, name)) == 0)
    800052ca:	fd040593          	addi	a1,s0,-48
    800052ce:	f5040513          	addi	a0,s0,-176
    800052d2:	cdffe0ef          	jal	80003fb0 <nameiparent>
    800052d6:	892a                	mv	s2,a0
    800052d8:	cd21                	beqz	a0,80005330 <sys_link+0xce>
  ilock(dp);
    800052da:	bfefe0ef          	jal	800036d8 <ilock>
  if(dp->dev != ip->dev || dirlink(dp, name, ip->inum) < 0){
    800052de:	854a                	mv	a0,s2
    800052e0:	00092703          	lw	a4,0(s2)
    800052e4:	409c                	lw	a5,0(s1)
    800052e6:	04f71263          	bne	a4,a5,8000532a <sys_link+0xc8>
    800052ea:	40d0                	lw	a2,4(s1)
    800052ec:	fd040593          	addi	a1,s0,-48
    800052f0:	bfdfe0ef          	jal	80003eec <dirlink>
    800052f4:	02054b63          	bltz	a0,8000532a <sys_link+0xc8>
  iunlockput(dp);
    800052f8:	854a                	mv	a0,s2
    800052fa:	e78fe0ef          	jal	80003972 <iunlockput>
  iput(ip);
    800052fe:	8526                	mv	a0,s1
    80005300:	de8fe0ef          	jal	800038e8 <iput>
  end_op();
    80005304:	ee1fe0ef          	jal	800041e4 <end_op>
  return 0;
    80005308:	4781                	li	a5,0
    8000530a:	64f2                	ld	s1,280(sp)
    8000530c:	6952                	ld	s2,272(sp)
    8000530e:	a0a1                	j	80005356 <sys_link+0xf4>
    end_op();
    80005310:	ed5fe0ef          	jal	800041e4 <end_op>
    return -1;
    80005314:	57fd                	li	a5,-1
    80005316:	64f2                	ld	s1,280(sp)
    80005318:	a83d                	j	80005356 <sys_link+0xf4>
    iunlockput(ip);
    8000531a:	8526                	mv	a0,s1
    8000531c:	e56fe0ef          	jal	80003972 <iunlockput>
    end_op();
    80005320:	ec5fe0ef          	jal	800041e4 <end_op>
    return -1;
    80005324:	57fd                	li	a5,-1
    80005326:	64f2                	ld	s1,280(sp)
    80005328:	a03d                	j	80005356 <sys_link+0xf4>
    iunlockput(dp);
    8000532a:	854a                	mv	a0,s2
    8000532c:	e46fe0ef          	jal	80003972 <iunlockput>
  ilock(ip);
    80005330:	8526                	mv	a0,s1
    80005332:	ba6fe0ef          	jal	800036d8 <ilock>
  ip->nlink--;
    80005336:	04a4d783          	lhu	a5,74(s1)
    8000533a:	37fd                	addiw	a5,a5,-1
    8000533c:	04f49523          	sh	a5,74(s1)
  iupdate(ip);
    80005340:	8526                	mv	a0,s1
    80005342:	ae2fe0ef          	jal	80003624 <iupdate>
  iunlockput(ip);
    80005346:	8526                	mv	a0,s1
    80005348:	e2afe0ef          	jal	80003972 <iunlockput>
  end_op();
    8000534c:	e99fe0ef          	jal	800041e4 <end_op>
  return -1;
    80005350:	57fd                	li	a5,-1
    80005352:	64f2                	ld	s1,280(sp)
    80005354:	6952                	ld	s2,272(sp)
}
    80005356:	853e                	mv	a0,a5
    80005358:	70b2                	ld	ra,296(sp)
    8000535a:	7412                	ld	s0,288(sp)
    8000535c:	6155                	addi	sp,sp,304
    8000535e:	8082                	ret

0000000080005360 <sys_unlink>:
{
    80005360:	7151                	addi	sp,sp,-240
    80005362:	f586                	sd	ra,232(sp)
    80005364:	f1a2                	sd	s0,224(sp)
    80005366:	1980                	addi	s0,sp,240
  if(argstr(0, path, MAXPATH) < 0)
    80005368:	08000613          	li	a2,128
    8000536c:	f3040593          	addi	a1,s0,-208
    80005370:	4501                	li	a0,0
    80005372:	ff0fd0ef          	jal	80002b62 <argstr>
    80005376:	14054d63          	bltz	a0,800054d0 <sys_unlink+0x170>
    8000537a:	eda6                	sd	s1,216(sp)
  begin_op();
    8000537c:	df9fe0ef          	jal	80004174 <begin_op>
  if((dp = nameiparent(path, name)) == 0){
    80005380:	fb040593          	addi	a1,s0,-80
    80005384:	f3040513          	addi	a0,s0,-208
    80005388:	c29fe0ef          	jal	80003fb0 <nameiparent>
    8000538c:	84aa                	mv	s1,a0
    8000538e:	c955                	beqz	a0,80005442 <sys_unlink+0xe2>
  ilock(dp);
    80005390:	b48fe0ef          	jal	800036d8 <ilock>
  if(namecmp(name, ".") == 0 || namecmp(name, "..") == 0)
    80005394:	00003597          	auipc	a1,0x3
    80005398:	2bc58593          	addi	a1,a1,700 # 80008650 <etext+0x650>
    8000539c:	fb040513          	addi	a0,s0,-80
    800053a0:	94dfe0ef          	jal	80003cec <namecmp>
    800053a4:	10050b63          	beqz	a0,800054ba <sys_unlink+0x15a>
    800053a8:	00003597          	auipc	a1,0x3
    800053ac:	2b058593          	addi	a1,a1,688 # 80008658 <etext+0x658>
    800053b0:	fb040513          	addi	a0,s0,-80
    800053b4:	939fe0ef          	jal	80003cec <namecmp>
    800053b8:	10050163          	beqz	a0,800054ba <sys_unlink+0x15a>
    800053bc:	e9ca                	sd	s2,208(sp)
  if((ip = dirlookup(dp, name, &off)) == 0)
    800053be:	f2c40613          	addi	a2,s0,-212
    800053c2:	fb040593          	addi	a1,s0,-80
    800053c6:	8526                	mv	a0,s1
    800053c8:	93bfe0ef          	jal	80003d02 <dirlookup>
    800053cc:	892a                	mv	s2,a0
    800053ce:	0e050563          	beqz	a0,800054b8 <sys_unlink+0x158>
    800053d2:	e5ce                	sd	s3,200(sp)
  ilock(ip);
    800053d4:	b04fe0ef          	jal	800036d8 <ilock>
  if(ip->nlink < 1)
    800053d8:	04a91783          	lh	a5,74(s2)
    800053dc:	06f05863          	blez	a5,8000544c <sys_unlink+0xec>
  if(ip->type == T_DIR && !isdirempty(ip)){
    800053e0:	04491703          	lh	a4,68(s2)
    800053e4:	4785                	li	a5,1
    800053e6:	06f70963          	beq	a4,a5,80005458 <sys_unlink+0xf8>
  memset(&de, 0, sizeof(de));
    800053ea:	fc040993          	addi	s3,s0,-64
    800053ee:	4641                	li	a2,16
    800053f0:	4581                	li	a1,0
    800053f2:	854e                	mv	a0,s3
    800053f4:	af9fb0ef          	jal	80000eec <memset>
  if(writei(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    800053f8:	4741                	li	a4,16
    800053fa:	f2c42683          	lw	a3,-212(s0)
    800053fe:	864e                	mv	a2,s3
    80005400:	4581                	li	a1,0
    80005402:	8526                	mv	a0,s1
    80005404:	fe6fe0ef          	jal	80003bea <writei>
    80005408:	47c1                	li	a5,16
    8000540a:	08f51863          	bne	a0,a5,8000549a <sys_unlink+0x13a>
  if(ip->type == T_DIR){
    8000540e:	04491703          	lh	a4,68(s2)
    80005412:	4785                	li	a5,1
    80005414:	08f70963          	beq	a4,a5,800054a6 <sys_unlink+0x146>
  iunlockput(dp);
    80005418:	8526                	mv	a0,s1
    8000541a:	d58fe0ef          	jal	80003972 <iunlockput>
  ip->nlink--;
    8000541e:	04a95783          	lhu	a5,74(s2)
    80005422:	37fd                	addiw	a5,a5,-1
    80005424:	04f91523          	sh	a5,74(s2)
  iupdate(ip);
    80005428:	854a                	mv	a0,s2
    8000542a:	9fafe0ef          	jal	80003624 <iupdate>
  iunlockput(ip);
    8000542e:	854a                	mv	a0,s2
    80005430:	d42fe0ef          	jal	80003972 <iunlockput>
  end_op();
    80005434:	db1fe0ef          	jal	800041e4 <end_op>
  return 0;
    80005438:	4501                	li	a0,0
    8000543a:	64ee                	ld	s1,216(sp)
    8000543c:	694e                	ld	s2,208(sp)
    8000543e:	69ae                	ld	s3,200(sp)
    80005440:	a061                	j	800054c8 <sys_unlink+0x168>
    end_op();
    80005442:	da3fe0ef          	jal	800041e4 <end_op>
    return -1;
    80005446:	557d                	li	a0,-1
    80005448:	64ee                	ld	s1,216(sp)
    8000544a:	a8bd                	j	800054c8 <sys_unlink+0x168>
    panic("unlink: nlink < 1");
    8000544c:	00003517          	auipc	a0,0x3
    80005450:	21450513          	addi	a0,a0,532 # 80008660 <etext+0x660>
    80005454:	bd0fb0ef          	jal	80000824 <panic>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005458:	04c92703          	lw	a4,76(s2)
    8000545c:	02000793          	li	a5,32
    80005460:	f8e7f5e3          	bgeu	a5,a4,800053ea <sys_unlink+0x8a>
    80005464:	89be                	mv	s3,a5
    if(readi(dp, 0, (uint64)&de, off, sizeof(de)) != sizeof(de))
    80005466:	4741                	li	a4,16
    80005468:	86ce                	mv	a3,s3
    8000546a:	f1840613          	addi	a2,s0,-232
    8000546e:	4581                	li	a1,0
    80005470:	854a                	mv	a0,s2
    80005472:	e86fe0ef          	jal	80003af8 <readi>
    80005476:	47c1                	li	a5,16
    80005478:	00f51b63          	bne	a0,a5,8000548e <sys_unlink+0x12e>
    if(de.inum != 0)
    8000547c:	f1845783          	lhu	a5,-232(s0)
    80005480:	ebb1                	bnez	a5,800054d4 <sys_unlink+0x174>
  for(off=2*sizeof(de); off<dp->size; off+=sizeof(de)){
    80005482:	29c1                	addiw	s3,s3,16
    80005484:	04c92783          	lw	a5,76(s2)
    80005488:	fcf9efe3          	bltu	s3,a5,80005466 <sys_unlink+0x106>
    8000548c:	bfb9                	j	800053ea <sys_unlink+0x8a>
      panic("isdirempty: readi");
    8000548e:	00003517          	auipc	a0,0x3
    80005492:	1ea50513          	addi	a0,a0,490 # 80008678 <etext+0x678>
    80005496:	b8efb0ef          	jal	80000824 <panic>
    panic("unlink: writei");
    8000549a:	00003517          	auipc	a0,0x3
    8000549e:	1f650513          	addi	a0,a0,502 # 80008690 <etext+0x690>
    800054a2:	b82fb0ef          	jal	80000824 <panic>
    dp->nlink--;
    800054a6:	04a4d783          	lhu	a5,74(s1)
    800054aa:	37fd                	addiw	a5,a5,-1
    800054ac:	04f49523          	sh	a5,74(s1)
    iupdate(dp);
    800054b0:	8526                	mv	a0,s1
    800054b2:	972fe0ef          	jal	80003624 <iupdate>
    800054b6:	b78d                	j	80005418 <sys_unlink+0xb8>
    800054b8:	694e                	ld	s2,208(sp)
  iunlockput(dp);
    800054ba:	8526                	mv	a0,s1
    800054bc:	cb6fe0ef          	jal	80003972 <iunlockput>
  end_op();
    800054c0:	d25fe0ef          	jal	800041e4 <end_op>
  return -1;
    800054c4:	557d                	li	a0,-1
    800054c6:	64ee                	ld	s1,216(sp)
}
    800054c8:	70ae                	ld	ra,232(sp)
    800054ca:	740e                	ld	s0,224(sp)
    800054cc:	616d                	addi	sp,sp,240
    800054ce:	8082                	ret
    return -1;
    800054d0:	557d                	li	a0,-1
    800054d2:	bfdd                	j	800054c8 <sys_unlink+0x168>
    iunlockput(ip);
    800054d4:	854a                	mv	a0,s2
    800054d6:	c9cfe0ef          	jal	80003972 <iunlockput>
    goto bad;
    800054da:	694e                	ld	s2,208(sp)
    800054dc:	69ae                	ld	s3,200(sp)
    800054de:	bff1                	j	800054ba <sys_unlink+0x15a>

00000000800054e0 <sys_open>:

uint64
sys_open(void)
{
    800054e0:	7131                	addi	sp,sp,-192
    800054e2:	fd06                	sd	ra,184(sp)
    800054e4:	f922                	sd	s0,176(sp)
    800054e6:	0180                	addi	s0,sp,192
  int fd, omode;
  struct file *f;
  struct inode *ip;
  int n;

  argint(1, &omode);
    800054e8:	f4c40593          	addi	a1,s0,-180
    800054ec:	4505                	li	a0,1
    800054ee:	e3cfd0ef          	jal	80002b2a <argint>
  if((n = argstr(0, path, MAXPATH)) < 0)
    800054f2:	08000613          	li	a2,128
    800054f6:	f5040593          	addi	a1,s0,-176
    800054fa:	4501                	li	a0,0
    800054fc:	e66fd0ef          	jal	80002b62 <argstr>
    80005500:	87aa                	mv	a5,a0
    return -1;
    80005502:	557d                	li	a0,-1
  if((n = argstr(0, path, MAXPATH)) < 0)
    80005504:	0a07c363          	bltz	a5,800055aa <sys_open+0xca>
    80005508:	f526                	sd	s1,168(sp)

  begin_op();
    8000550a:	c6bfe0ef          	jal	80004174 <begin_op>

  if(omode & O_CREATE){
    8000550e:	f4c42783          	lw	a5,-180(s0)
    80005512:	2007f793          	andi	a5,a5,512
    80005516:	c3dd                	beqz	a5,800055bc <sys_open+0xdc>
    ip = create(path, T_FILE, 0, 0);
    80005518:	4681                	li	a3,0
    8000551a:	4601                	li	a2,0
    8000551c:	4589                	li	a1,2
    8000551e:	f5040513          	addi	a0,s0,-176
    80005522:	aafff0ef          	jal	80004fd0 <create>
    80005526:	84aa                	mv	s1,a0
    if(ip == 0){
    80005528:	c549                	beqz	a0,800055b2 <sys_open+0xd2>
      end_op();
      return -1;
    }
  }

  if(ip->type == T_DEVICE && (ip->major < 0 || ip->major >= NDEV)){
    8000552a:	04449703          	lh	a4,68(s1)
    8000552e:	478d                	li	a5,3
    80005530:	00f71763          	bne	a4,a5,8000553e <sys_open+0x5e>
    80005534:	0464d703          	lhu	a4,70(s1)
    80005538:	47a5                	li	a5,9
    8000553a:	0ae7ee63          	bltu	a5,a4,800055f6 <sys_open+0x116>
    8000553e:	f14a                	sd	s2,160(sp)
    iunlockput(ip);
    end_op();
    return -1;
  }

  if((f = filealloc()) == 0 || (fd = fdalloc(f)) < 0){
    80005540:	fb5fe0ef          	jal	800044f4 <filealloc>
    80005544:	892a                	mv	s2,a0
    80005546:	c561                	beqz	a0,8000560e <sys_open+0x12e>
    80005548:	ed4e                	sd	s3,152(sp)
    8000554a:	a47ff0ef          	jal	80004f90 <fdalloc>
    8000554e:	89aa                	mv	s3,a0
    80005550:	0a054b63          	bltz	a0,80005606 <sys_open+0x126>
    iunlockput(ip);
    end_op();
    return -1;
  }

  if(ip->type == T_DEVICE){
    80005554:	04449703          	lh	a4,68(s1)
    80005558:	478d                	li	a5,3
    8000555a:	0cf70363          	beq	a4,a5,80005620 <sys_open+0x140>
    f->type = FD_DEVICE;
    f->major = ip->major;
  } else {
    f->type = FD_INODE;
    8000555e:	4789                	li	a5,2
    80005560:	00f92023          	sw	a5,0(s2)
    f->off = 0;
    80005564:	02092023          	sw	zero,32(s2)
  }
  f->ip = ip;
    80005568:	00993c23          	sd	s1,24(s2)
  f->readable = !(omode & O_WRONLY);
    8000556c:	f4c42783          	lw	a5,-180(s0)
    80005570:	0017f713          	andi	a4,a5,1
    80005574:	00174713          	xori	a4,a4,1
    80005578:	00e90423          	sb	a4,8(s2)
  f->writable = (omode & O_WRONLY) || (omode & O_RDWR);
    8000557c:	0037f713          	andi	a4,a5,3
    80005580:	00e03733          	snez	a4,a4
    80005584:	00e904a3          	sb	a4,9(s2)

  if((omode & O_TRUNC) && ip->type == T_FILE){
    80005588:	4007f793          	andi	a5,a5,1024
    8000558c:	c791                	beqz	a5,80005598 <sys_open+0xb8>
    8000558e:	04449703          	lh	a4,68(s1)
    80005592:	4789                	li	a5,2
    80005594:	08f70d63          	beq	a4,a5,8000562e <sys_open+0x14e>
    itrunc(ip);
  }

  iunlock(ip);
    80005598:	8526                	mv	a0,s1
    8000559a:	9ecfe0ef          	jal	80003786 <iunlock>
  end_op();
    8000559e:	c47fe0ef          	jal	800041e4 <end_op>

  return fd;
    800055a2:	854e                	mv	a0,s3
    800055a4:	74aa                	ld	s1,168(sp)
    800055a6:	790a                	ld	s2,160(sp)
    800055a8:	69ea                	ld	s3,152(sp)
}
    800055aa:	70ea                	ld	ra,184(sp)
    800055ac:	744a                	ld	s0,176(sp)
    800055ae:	6129                	addi	sp,sp,192
    800055b0:	8082                	ret
      end_op();
    800055b2:	c33fe0ef          	jal	800041e4 <end_op>
      return -1;
    800055b6:	557d                	li	a0,-1
    800055b8:	74aa                	ld	s1,168(sp)
    800055ba:	bfc5                	j	800055aa <sys_open+0xca>
    if((ip = namei(path)) == 0){
    800055bc:	f5040513          	addi	a0,s0,-176
    800055c0:	9d7fe0ef          	jal	80003f96 <namei>
    800055c4:	84aa                	mv	s1,a0
    800055c6:	c11d                	beqz	a0,800055ec <sys_open+0x10c>
    ilock(ip);
    800055c8:	910fe0ef          	jal	800036d8 <ilock>
    if(ip->type == T_DIR && omode != O_RDONLY){
    800055cc:	04449703          	lh	a4,68(s1)
    800055d0:	4785                	li	a5,1
    800055d2:	f4f71ce3          	bne	a4,a5,8000552a <sys_open+0x4a>
    800055d6:	f4c42783          	lw	a5,-180(s0)
    800055da:	d3b5                	beqz	a5,8000553e <sys_open+0x5e>
      iunlockput(ip);
    800055dc:	8526                	mv	a0,s1
    800055de:	b94fe0ef          	jal	80003972 <iunlockput>
      end_op();
    800055e2:	c03fe0ef          	jal	800041e4 <end_op>
      return -1;
    800055e6:	557d                	li	a0,-1
    800055e8:	74aa                	ld	s1,168(sp)
    800055ea:	b7c1                	j	800055aa <sys_open+0xca>
      end_op();
    800055ec:	bf9fe0ef          	jal	800041e4 <end_op>
      return -1;
    800055f0:	557d                	li	a0,-1
    800055f2:	74aa                	ld	s1,168(sp)
    800055f4:	bf5d                	j	800055aa <sys_open+0xca>
    iunlockput(ip);
    800055f6:	8526                	mv	a0,s1
    800055f8:	b7afe0ef          	jal	80003972 <iunlockput>
    end_op();
    800055fc:	be9fe0ef          	jal	800041e4 <end_op>
    return -1;
    80005600:	557d                	li	a0,-1
    80005602:	74aa                	ld	s1,168(sp)
    80005604:	b75d                	j	800055aa <sys_open+0xca>
      fileclose(f);
    80005606:	854a                	mv	a0,s2
    80005608:	f91fe0ef          	jal	80004598 <fileclose>
    8000560c:	69ea                	ld	s3,152(sp)
    iunlockput(ip);
    8000560e:	8526                	mv	a0,s1
    80005610:	b62fe0ef          	jal	80003972 <iunlockput>
    end_op();
    80005614:	bd1fe0ef          	jal	800041e4 <end_op>
    return -1;
    80005618:	557d                	li	a0,-1
    8000561a:	74aa                	ld	s1,168(sp)
    8000561c:	790a                	ld	s2,160(sp)
    8000561e:	b771                	j	800055aa <sys_open+0xca>
    f->type = FD_DEVICE;
    80005620:	00e92023          	sw	a4,0(s2)
    f->major = ip->major;
    80005624:	04649783          	lh	a5,70(s1)
    80005628:	02f91223          	sh	a5,36(s2)
    8000562c:	bf35                	j	80005568 <sys_open+0x88>
    itrunc(ip);
    8000562e:	8526                	mv	a0,s1
    80005630:	996fe0ef          	jal	800037c6 <itrunc>
    80005634:	b795                	j	80005598 <sys_open+0xb8>

0000000080005636 <sys_mkdir>:

uint64
sys_mkdir(void)
{
    80005636:	7175                	addi	sp,sp,-144
    80005638:	e506                	sd	ra,136(sp)
    8000563a:	e122                	sd	s0,128(sp)
    8000563c:	0900                	addi	s0,sp,144
  char path[MAXPATH];
  struct inode *ip;

  begin_op();
    8000563e:	b37fe0ef          	jal	80004174 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = create(path, T_DIR, 0, 0)) == 0){
    80005642:	08000613          	li	a2,128
    80005646:	f7040593          	addi	a1,s0,-144
    8000564a:	4501                	li	a0,0
    8000564c:	d16fd0ef          	jal	80002b62 <argstr>
    80005650:	02054363          	bltz	a0,80005676 <sys_mkdir+0x40>
    80005654:	4681                	li	a3,0
    80005656:	4601                	li	a2,0
    80005658:	4585                	li	a1,1
    8000565a:	f7040513          	addi	a0,s0,-144
    8000565e:	973ff0ef          	jal	80004fd0 <create>
    80005662:	c911                	beqz	a0,80005676 <sys_mkdir+0x40>
    end_op();
    return -1;
  }
  iunlockput(ip);
    80005664:	b0efe0ef          	jal	80003972 <iunlockput>
  end_op();
    80005668:	b7dfe0ef          	jal	800041e4 <end_op>
  return 0;
    8000566c:	4501                	li	a0,0
}
    8000566e:	60aa                	ld	ra,136(sp)
    80005670:	640a                	ld	s0,128(sp)
    80005672:	6149                	addi	sp,sp,144
    80005674:	8082                	ret
    end_op();
    80005676:	b6ffe0ef          	jal	800041e4 <end_op>
    return -1;
    8000567a:	557d                	li	a0,-1
    8000567c:	bfcd                	j	8000566e <sys_mkdir+0x38>

000000008000567e <sys_mknod>:

uint64
sys_mknod(void)
{
    8000567e:	7135                	addi	sp,sp,-160
    80005680:	ed06                	sd	ra,152(sp)
    80005682:	e922                	sd	s0,144(sp)
    80005684:	1100                	addi	s0,sp,160
  struct inode *ip;
  char path[MAXPATH];
  int major, minor;

  begin_op();
    80005686:	aeffe0ef          	jal	80004174 <begin_op>
  argint(1, &major);
    8000568a:	f6c40593          	addi	a1,s0,-148
    8000568e:	4505                	li	a0,1
    80005690:	c9afd0ef          	jal	80002b2a <argint>
  argint(2, &minor);
    80005694:	f6840593          	addi	a1,s0,-152
    80005698:	4509                	li	a0,2
    8000569a:	c90fd0ef          	jal	80002b2a <argint>
  if((argstr(0, path, MAXPATH)) < 0 ||
    8000569e:	08000613          	li	a2,128
    800056a2:	f7040593          	addi	a1,s0,-144
    800056a6:	4501                	li	a0,0
    800056a8:	cbafd0ef          	jal	80002b62 <argstr>
    800056ac:	02054563          	bltz	a0,800056d6 <sys_mknod+0x58>
     (ip = create(path, T_DEVICE, major, minor)) == 0){
    800056b0:	f6841683          	lh	a3,-152(s0)
    800056b4:	f6c41603          	lh	a2,-148(s0)
    800056b8:	458d                	li	a1,3
    800056ba:	f7040513          	addi	a0,s0,-144
    800056be:	913ff0ef          	jal	80004fd0 <create>
  if((argstr(0, path, MAXPATH)) < 0 ||
    800056c2:	c911                	beqz	a0,800056d6 <sys_mknod+0x58>
    end_op();
    return -1;
  }
  iunlockput(ip);
    800056c4:	aaefe0ef          	jal	80003972 <iunlockput>
  end_op();
    800056c8:	b1dfe0ef          	jal	800041e4 <end_op>
  return 0;
    800056cc:	4501                	li	a0,0
}
    800056ce:	60ea                	ld	ra,152(sp)
    800056d0:	644a                	ld	s0,144(sp)
    800056d2:	610d                	addi	sp,sp,160
    800056d4:	8082                	ret
    end_op();
    800056d6:	b0ffe0ef          	jal	800041e4 <end_op>
    return -1;
    800056da:	557d                	li	a0,-1
    800056dc:	bfcd                	j	800056ce <sys_mknod+0x50>

00000000800056de <sys_chdir>:

uint64
sys_chdir(void)
{
    800056de:	7135                	addi	sp,sp,-160
    800056e0:	ed06                	sd	ra,152(sp)
    800056e2:	e922                	sd	s0,144(sp)
    800056e4:	e14a                	sd	s2,128(sp)
    800056e6:	1100                	addi	s0,sp,160
  char path[MAXPATH];
  struct inode *ip;
  struct proc *p = myproc();
    800056e8:	c48fc0ef          	jal	80001b30 <myproc>
    800056ec:	892a                	mv	s2,a0
  
  begin_op();
    800056ee:	a87fe0ef          	jal	80004174 <begin_op>
  if(argstr(0, path, MAXPATH) < 0 || (ip = namei(path)) == 0){
    800056f2:	08000613          	li	a2,128
    800056f6:	f6040593          	addi	a1,s0,-160
    800056fa:	4501                	li	a0,0
    800056fc:	c66fd0ef          	jal	80002b62 <argstr>
    80005700:	04054363          	bltz	a0,80005746 <sys_chdir+0x68>
    80005704:	e526                	sd	s1,136(sp)
    80005706:	f6040513          	addi	a0,s0,-160
    8000570a:	88dfe0ef          	jal	80003f96 <namei>
    8000570e:	84aa                	mv	s1,a0
    80005710:	c915                	beqz	a0,80005744 <sys_chdir+0x66>
    end_op();
    return -1;
  }
  ilock(ip);
    80005712:	fc7fd0ef          	jal	800036d8 <ilock>
  if(ip->type != T_DIR){
    80005716:	04449703          	lh	a4,68(s1)
    8000571a:	4785                	li	a5,1
    8000571c:	02f71963          	bne	a4,a5,8000574e <sys_chdir+0x70>
    iunlockput(ip);
    end_op();
    return -1;
  }
  iunlock(ip);
    80005720:	8526                	mv	a0,s1
    80005722:	864fe0ef          	jal	80003786 <iunlock>
  iput(p->cwd);
    80005726:	15093503          	ld	a0,336(s2)
    8000572a:	9befe0ef          	jal	800038e8 <iput>
  end_op();
    8000572e:	ab7fe0ef          	jal	800041e4 <end_op>
  p->cwd = ip;
    80005732:	14993823          	sd	s1,336(s2)
  return 0;
    80005736:	4501                	li	a0,0
    80005738:	64aa                	ld	s1,136(sp)
}
    8000573a:	60ea                	ld	ra,152(sp)
    8000573c:	644a                	ld	s0,144(sp)
    8000573e:	690a                	ld	s2,128(sp)
    80005740:	610d                	addi	sp,sp,160
    80005742:	8082                	ret
    80005744:	64aa                	ld	s1,136(sp)
    end_op();
    80005746:	a9ffe0ef          	jal	800041e4 <end_op>
    return -1;
    8000574a:	557d                	li	a0,-1
    8000574c:	b7fd                	j	8000573a <sys_chdir+0x5c>
    iunlockput(ip);
    8000574e:	8526                	mv	a0,s1
    80005750:	a22fe0ef          	jal	80003972 <iunlockput>
    end_op();
    80005754:	a91fe0ef          	jal	800041e4 <end_op>
    return -1;
    80005758:	557d                	li	a0,-1
    8000575a:	64aa                	ld	s1,136(sp)
    8000575c:	bff9                	j	8000573a <sys_chdir+0x5c>

000000008000575e <sys_exec>:

uint64
sys_exec(void)
{
    8000575e:	7105                	addi	sp,sp,-480
    80005760:	ef86                	sd	ra,472(sp)
    80005762:	eba2                	sd	s0,464(sp)
    80005764:	1380                	addi	s0,sp,480
  char path[MAXPATH], *argv[MAXARG];
  int i;
  uint64 uargv, uarg;

  argaddr(1, &uargv);
    80005766:	e2840593          	addi	a1,s0,-472
    8000576a:	4505                	li	a0,1
    8000576c:	bdafd0ef          	jal	80002b46 <argaddr>
  if(argstr(0, path, MAXPATH) < 0) {
    80005770:	08000613          	li	a2,128
    80005774:	f3040593          	addi	a1,s0,-208
    80005778:	4501                	li	a0,0
    8000577a:	be8fd0ef          	jal	80002b62 <argstr>
    8000577e:	87aa                	mv	a5,a0
    return -1;
    80005780:	557d                	li	a0,-1
  if(argstr(0, path, MAXPATH) < 0) {
    80005782:	0e07c063          	bltz	a5,80005862 <sys_exec+0x104>
    80005786:	e7a6                	sd	s1,456(sp)
    80005788:	e3ca                	sd	s2,448(sp)
    8000578a:	ff4e                	sd	s3,440(sp)
    8000578c:	fb52                	sd	s4,432(sp)
    8000578e:	f756                	sd	s5,424(sp)
    80005790:	f35a                	sd	s6,416(sp)
    80005792:	ef5e                	sd	s7,408(sp)
  }
  memset(argv, 0, sizeof(argv));
    80005794:	e3040a13          	addi	s4,s0,-464
    80005798:	10000613          	li	a2,256
    8000579c:	4581                	li	a1,0
    8000579e:	8552                	mv	a0,s4
    800057a0:	f4cfb0ef          	jal	80000eec <memset>
  for(i=0;; i++){
    if(i >= NELEM(argv)){
    800057a4:	84d2                	mv	s1,s4
  memset(argv, 0, sizeof(argv));
    800057a6:	89d2                	mv	s3,s4
    800057a8:	4901                	li	s2,0
      goto bad;
    }
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800057aa:	e2040a93          	addi	s5,s0,-480
      break;
    }
    argv[i] = kalloc();
    if(argv[i] == 0)
      goto bad;
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800057ae:	6b05                	lui	s6,0x1
    if(i >= NELEM(argv)){
    800057b0:	02000b93          	li	s7,32
    if(fetchaddr(uargv+sizeof(uint64)*i, (uint64*)&uarg) < 0){
    800057b4:	00391513          	slli	a0,s2,0x3
    800057b8:	85d6                	mv	a1,s5
    800057ba:	e2843783          	ld	a5,-472(s0)
    800057be:	953e                	add	a0,a0,a5
    800057c0:	ae0fd0ef          	jal	80002aa0 <fetchaddr>
    800057c4:	02054663          	bltz	a0,800057f0 <sys_exec+0x92>
    if(uarg == 0){
    800057c8:	e2043783          	ld	a5,-480(s0)
    800057cc:	c7a1                	beqz	a5,80005814 <sys_exec+0xb6>
    argv[i] = kalloc();
    800057ce:	d3efb0ef          	jal	80000d0c <kalloc>
    800057d2:	85aa                	mv	a1,a0
    800057d4:	00a9b023          	sd	a0,0(s3)
    if(argv[i] == 0)
    800057d8:	cd01                	beqz	a0,800057f0 <sys_exec+0x92>
    if(fetchstr(uarg, argv[i], PGSIZE) < 0)
    800057da:	865a                	mv	a2,s6
    800057dc:	e2043503          	ld	a0,-480(s0)
    800057e0:	b0afd0ef          	jal	80002aea <fetchstr>
    800057e4:	00054663          	bltz	a0,800057f0 <sys_exec+0x92>
    if(i >= NELEM(argv)){
    800057e8:	0905                	addi	s2,s2,1
    800057ea:	09a1                	addi	s3,s3,8
    800057ec:	fd7914e3          	bne	s2,s7,800057b4 <sys_exec+0x56>
    kfree(argv[i]);

  return ret;

 bad:
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800057f0:	100a0a13          	addi	s4,s4,256
    800057f4:	6088                	ld	a0,0(s1)
    800057f6:	cd31                	beqz	a0,80005852 <sys_exec+0xf4>
    kfree(argv[i]);
    800057f8:	be4fb0ef          	jal	80000bdc <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    800057fc:	04a1                	addi	s1,s1,8
    800057fe:	ff449be3          	bne	s1,s4,800057f4 <sys_exec+0x96>
  return -1;
    80005802:	557d                	li	a0,-1
    80005804:	64be                	ld	s1,456(sp)
    80005806:	691e                	ld	s2,448(sp)
    80005808:	79fa                	ld	s3,440(sp)
    8000580a:	7a5a                	ld	s4,432(sp)
    8000580c:	7aba                	ld	s5,424(sp)
    8000580e:	7b1a                	ld	s6,416(sp)
    80005810:	6bfa                	ld	s7,408(sp)
    80005812:	a881                	j	80005862 <sys_exec+0x104>
      argv[i] = 0;
    80005814:	0009079b          	sext.w	a5,s2
    80005818:	e3040593          	addi	a1,s0,-464
    8000581c:	078e                	slli	a5,a5,0x3
    8000581e:	97ae                	add	a5,a5,a1
    80005820:	0007b023          	sd	zero,0(a5)
  int ret = kexec(path, argv);
    80005824:	f3040513          	addi	a0,s0,-208
    80005828:	bb2ff0ef          	jal	80004bda <kexec>
    8000582c:	892a                	mv	s2,a0
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000582e:	100a0a13          	addi	s4,s4,256
    80005832:	6088                	ld	a0,0(s1)
    80005834:	c511                	beqz	a0,80005840 <sys_exec+0xe2>
    kfree(argv[i]);
    80005836:	ba6fb0ef          	jal	80000bdc <kfree>
  for(i = 0; i < NELEM(argv) && argv[i] != 0; i++)
    8000583a:	04a1                	addi	s1,s1,8
    8000583c:	ff449be3          	bne	s1,s4,80005832 <sys_exec+0xd4>
  return ret;
    80005840:	854a                	mv	a0,s2
    80005842:	64be                	ld	s1,456(sp)
    80005844:	691e                	ld	s2,448(sp)
    80005846:	79fa                	ld	s3,440(sp)
    80005848:	7a5a                	ld	s4,432(sp)
    8000584a:	7aba                	ld	s5,424(sp)
    8000584c:	7b1a                	ld	s6,416(sp)
    8000584e:	6bfa                	ld	s7,408(sp)
    80005850:	a809                	j	80005862 <sys_exec+0x104>
  return -1;
    80005852:	557d                	li	a0,-1
    80005854:	64be                	ld	s1,456(sp)
    80005856:	691e                	ld	s2,448(sp)
    80005858:	79fa                	ld	s3,440(sp)
    8000585a:	7a5a                	ld	s4,432(sp)
    8000585c:	7aba                	ld	s5,424(sp)
    8000585e:	7b1a                	ld	s6,416(sp)
    80005860:	6bfa                	ld	s7,408(sp)
}
    80005862:	60fe                	ld	ra,472(sp)
    80005864:	645e                	ld	s0,464(sp)
    80005866:	613d                	addi	sp,sp,480
    80005868:	8082                	ret

000000008000586a <sys_pipe>:

uint64
sys_pipe(void)
{
    8000586a:	7139                	addi	sp,sp,-64
    8000586c:	fc06                	sd	ra,56(sp)
    8000586e:	f822                	sd	s0,48(sp)
    80005870:	f426                	sd	s1,40(sp)
    80005872:	0080                	addi	s0,sp,64
  uint64 fdarray; // user pointer to array of two integers
  struct file *rf, *wf;
  int fd0, fd1;
  struct proc *p = myproc();
    80005874:	abcfc0ef          	jal	80001b30 <myproc>
    80005878:	84aa                	mv	s1,a0

  argaddr(0, &fdarray);
    8000587a:	fd840593          	addi	a1,s0,-40
    8000587e:	4501                	li	a0,0
    80005880:	ac6fd0ef          	jal	80002b46 <argaddr>
  if(pipealloc(&rf, &wf) < 0)
    80005884:	fc840593          	addi	a1,s0,-56
    80005888:	fd040513          	addi	a0,s0,-48
    8000588c:	828ff0ef          	jal	800048b4 <pipealloc>
    return -1;
    80005890:	57fd                	li	a5,-1
  if(pipealloc(&rf, &wf) < 0)
    80005892:	0a054763          	bltz	a0,80005940 <sys_pipe+0xd6>
  fd0 = -1;
    80005896:	fcf42223          	sw	a5,-60(s0)
  if((fd0 = fdalloc(rf)) < 0 || (fd1 = fdalloc(wf)) < 0){
    8000589a:	fd043503          	ld	a0,-48(s0)
    8000589e:	ef2ff0ef          	jal	80004f90 <fdalloc>
    800058a2:	fca42223          	sw	a0,-60(s0)
    800058a6:	08054463          	bltz	a0,8000592e <sys_pipe+0xc4>
    800058aa:	fc843503          	ld	a0,-56(s0)
    800058ae:	ee2ff0ef          	jal	80004f90 <fdalloc>
    800058b2:	fca42023          	sw	a0,-64(s0)
    800058b6:	06054263          	bltz	a0,8000591a <sys_pipe+0xb0>
      p->ofile[fd0] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800058ba:	4691                	li	a3,4
    800058bc:	fc440613          	addi	a2,s0,-60
    800058c0:	fd843583          	ld	a1,-40(s0)
    800058c4:	68a8                	ld	a0,80(s1)
    800058c6:	f91fb0ef          	jal	80001856 <copyout>
    800058ca:	00054e63          	bltz	a0,800058e6 <sys_pipe+0x7c>
     copyout(p->pagetable, fdarray+sizeof(fd0), (char *)&fd1, sizeof(fd1)) < 0){
    800058ce:	4691                	li	a3,4
    800058d0:	fc040613          	addi	a2,s0,-64
    800058d4:	fd843583          	ld	a1,-40(s0)
    800058d8:	95b6                	add	a1,a1,a3
    800058da:	68a8                	ld	a0,80(s1)
    800058dc:	f7bfb0ef          	jal	80001856 <copyout>
    p->ofile[fd1] = 0;
    fileclose(rf);
    fileclose(wf);
    return -1;
  }
  return 0;
    800058e0:	4781                	li	a5,0
  if(copyout(p->pagetable, fdarray, (char*)&fd0, sizeof(fd0)) < 0 ||
    800058e2:	04055f63          	bgez	a0,80005940 <sys_pipe+0xd6>
    p->ofile[fd0] = 0;
    800058e6:	fc442783          	lw	a5,-60(s0)
    800058ea:	078e                	slli	a5,a5,0x3
    800058ec:	0d078793          	addi	a5,a5,208
    800058f0:	97a6                	add	a5,a5,s1
    800058f2:	0007b023          	sd	zero,0(a5)
    p->ofile[fd1] = 0;
    800058f6:	fc042783          	lw	a5,-64(s0)
    800058fa:	078e                	slli	a5,a5,0x3
    800058fc:	0d078793          	addi	a5,a5,208
    80005900:	97a6                	add	a5,a5,s1
    80005902:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    80005906:	fd043503          	ld	a0,-48(s0)
    8000590a:	c8ffe0ef          	jal	80004598 <fileclose>
    fileclose(wf);
    8000590e:	fc843503          	ld	a0,-56(s0)
    80005912:	c87fe0ef          	jal	80004598 <fileclose>
    return -1;
    80005916:	57fd                	li	a5,-1
    80005918:	a025                	j	80005940 <sys_pipe+0xd6>
    if(fd0 >= 0)
    8000591a:	fc442783          	lw	a5,-60(s0)
    8000591e:	0007c863          	bltz	a5,8000592e <sys_pipe+0xc4>
      p->ofile[fd0] = 0;
    80005922:	078e                	slli	a5,a5,0x3
    80005924:	0d078793          	addi	a5,a5,208
    80005928:	97a6                	add	a5,a5,s1
    8000592a:	0007b023          	sd	zero,0(a5)
    fileclose(rf);
    8000592e:	fd043503          	ld	a0,-48(s0)
    80005932:	c67fe0ef          	jal	80004598 <fileclose>
    fileclose(wf);
    80005936:	fc843503          	ld	a0,-56(s0)
    8000593a:	c5ffe0ef          	jal	80004598 <fileclose>
    return -1;
    8000593e:	57fd                	li	a5,-1
}
    80005940:	853e                	mv	a0,a5
    80005942:	70e2                	ld	ra,56(sp)
    80005944:	7442                	ld	s0,48(sp)
    80005946:	74a2                	ld	s1,40(sp)
    80005948:	6121                	addi	sp,sp,64
    8000594a:	8082                	ret
    8000594c:	0000                	unimp
	...

0000000080005950 <kernelvec>:
.globl kerneltrap
.globl kernelvec
.align 4
kernelvec:
        # make room to save registers.
        addi sp, sp, -256
    80005950:	7111                	addi	sp,sp,-256

        # save caller-saved registers.
        sd ra, 0(sp)
    80005952:	e006                	sd	ra,0(sp)
        # sd sp, 8(sp)
        sd gp, 16(sp)
    80005954:	e80e                	sd	gp,16(sp)
        sd tp, 24(sp)
    80005956:	ec12                	sd	tp,24(sp)
        sd t0, 32(sp)
    80005958:	f016                	sd	t0,32(sp)
        sd t1, 40(sp)
    8000595a:	f41a                	sd	t1,40(sp)
        sd t2, 48(sp)
    8000595c:	f81e                	sd	t2,48(sp)
        sd a0, 72(sp)
    8000595e:	e4aa                	sd	a0,72(sp)
        sd a1, 80(sp)
    80005960:	e8ae                	sd	a1,80(sp)
        sd a2, 88(sp)
    80005962:	ecb2                	sd	a2,88(sp)
        sd a3, 96(sp)
    80005964:	f0b6                	sd	a3,96(sp)
        sd a4, 104(sp)
    80005966:	f4ba                	sd	a4,104(sp)
        sd a5, 112(sp)
    80005968:	f8be                	sd	a5,112(sp)
        sd a6, 120(sp)
    8000596a:	fcc2                	sd	a6,120(sp)
        sd a7, 128(sp)
    8000596c:	e146                	sd	a7,128(sp)
        sd t3, 216(sp)
    8000596e:	edf2                	sd	t3,216(sp)
        sd t4, 224(sp)
    80005970:	f1f6                	sd	t4,224(sp)
        sd t5, 232(sp)
    80005972:	f5fa                	sd	t5,232(sp)
        sd t6, 240(sp)
    80005974:	f9fe                	sd	t6,240(sp)

        # call the C trap handler in trap.c
        call kerneltrap
    80005976:	838fd0ef          	jal	800029ae <kerneltrap>

        # restore registers.
        ld ra, 0(sp)
    8000597a:	6082                	ld	ra,0(sp)
        # ld sp, 8(sp)
        ld gp, 16(sp)
    8000597c:	61c2                	ld	gp,16(sp)
        # not tp (contains hartid), in case we moved CPUs
        ld t0, 32(sp)
    8000597e:	7282                	ld	t0,32(sp)
        ld t1, 40(sp)
    80005980:	7322                	ld	t1,40(sp)
        ld t2, 48(sp)
    80005982:	73c2                	ld	t2,48(sp)
        ld a0, 72(sp)
    80005984:	6526                	ld	a0,72(sp)
        ld a1, 80(sp)
    80005986:	65c6                	ld	a1,80(sp)
        ld a2, 88(sp)
    80005988:	6666                	ld	a2,88(sp)
        ld a3, 96(sp)
    8000598a:	7686                	ld	a3,96(sp)
        ld a4, 104(sp)
    8000598c:	7726                	ld	a4,104(sp)
        ld a5, 112(sp)
    8000598e:	77c6                	ld	a5,112(sp)
        ld a6, 120(sp)
    80005990:	7866                	ld	a6,120(sp)
        ld a7, 128(sp)
    80005992:	688a                	ld	a7,128(sp)
        ld t3, 216(sp)
    80005994:	6e6e                	ld	t3,216(sp)
        ld t4, 224(sp)
    80005996:	7e8e                	ld	t4,224(sp)
        ld t5, 232(sp)
    80005998:	7f2e                	ld	t5,232(sp)
        ld t6, 240(sp)
    8000599a:	7fce                	ld	t6,240(sp)

        addi sp, sp, 256
    8000599c:	6111                	addi	sp,sp,256

        # return to whatever we were doing in the kernel.
        sret
    8000599e:	10200073          	sret
    800059a2:	00000013          	nop
    800059a6:	00000013          	nop
    800059aa:	00000013          	nop

00000000800059ae <plicinit>:
// the riscv Platform Level Interrupt Controller (PLIC).
//

void
plicinit(void)
{
    800059ae:	1141                	addi	sp,sp,-16
    800059b0:	e406                	sd	ra,8(sp)
    800059b2:	e022                	sd	s0,0(sp)
    800059b4:	0800                	addi	s0,sp,16
  // set desired IRQ priorities non-zero (otherwise disabled).
  *(uint32*)(PLIC + UART0_IRQ*4) = 1;
    800059b6:	0c000737          	lui	a4,0xc000
    800059ba:	4785                	li	a5,1
    800059bc:	d71c                	sw	a5,40(a4)
  *(uint32*)(PLIC + VIRTIO0_IRQ*4) = 1;
    800059be:	c35c                	sw	a5,4(a4)
}
    800059c0:	60a2                	ld	ra,8(sp)
    800059c2:	6402                	ld	s0,0(sp)
    800059c4:	0141                	addi	sp,sp,16
    800059c6:	8082                	ret

00000000800059c8 <plicinithart>:

void
plicinithart(void)
{
    800059c8:	1141                	addi	sp,sp,-16
    800059ca:	e406                	sd	ra,8(sp)
    800059cc:	e022                	sd	s0,0(sp)
    800059ce:	0800                	addi	s0,sp,16
  int hart = cpuid();
    800059d0:	92cfc0ef          	jal	80001afc <cpuid>
  
  // set enable bits for this hart's S-mode
  // for the uart and virtio disk.
  *(uint32*)PLIC_SENABLE(hart) = (1 << UART0_IRQ) | (1 << VIRTIO0_IRQ);
    800059d4:	0085171b          	slliw	a4,a0,0x8
    800059d8:	0c0027b7          	lui	a5,0xc002
    800059dc:	97ba                	add	a5,a5,a4
    800059de:	40200713          	li	a4,1026
    800059e2:	08e7a023          	sw	a4,128(a5) # c002080 <_entry-0x73ffdf80>

  // set this hart's S-mode priority threshold to 0.
  *(uint32*)PLIC_SPRIORITY(hart) = 0;
    800059e6:	00d5151b          	slliw	a0,a0,0xd
    800059ea:	0c2017b7          	lui	a5,0xc201
    800059ee:	97aa                	add	a5,a5,a0
    800059f0:	0007a023          	sw	zero,0(a5) # c201000 <_entry-0x73dff000>
}
    800059f4:	60a2                	ld	ra,8(sp)
    800059f6:	6402                	ld	s0,0(sp)
    800059f8:	0141                	addi	sp,sp,16
    800059fa:	8082                	ret

00000000800059fc <plic_claim>:

// ask the PLIC what interrupt we should serve.
int
plic_claim(void)
{
    800059fc:	1141                	addi	sp,sp,-16
    800059fe:	e406                	sd	ra,8(sp)
    80005a00:	e022                	sd	s0,0(sp)
    80005a02:	0800                	addi	s0,sp,16
  int hart = cpuid();
    80005a04:	8f8fc0ef          	jal	80001afc <cpuid>
  int irq = *(uint32*)PLIC_SCLAIM(hart);
    80005a08:	00d5151b          	slliw	a0,a0,0xd
    80005a0c:	0c2017b7          	lui	a5,0xc201
    80005a10:	97aa                	add	a5,a5,a0
  return irq;
}
    80005a12:	43c8                	lw	a0,4(a5)
    80005a14:	60a2                	ld	ra,8(sp)
    80005a16:	6402                	ld	s0,0(sp)
    80005a18:	0141                	addi	sp,sp,16
    80005a1a:	8082                	ret

0000000080005a1c <plic_complete>:

// tell the PLIC we've served this IRQ.
void
plic_complete(int irq)
{
    80005a1c:	1101                	addi	sp,sp,-32
    80005a1e:	ec06                	sd	ra,24(sp)
    80005a20:	e822                	sd	s0,16(sp)
    80005a22:	e426                	sd	s1,8(sp)
    80005a24:	1000                	addi	s0,sp,32
    80005a26:	84aa                	mv	s1,a0
  int hart = cpuid();
    80005a28:	8d4fc0ef          	jal	80001afc <cpuid>
  *(uint32*)PLIC_SCLAIM(hart) = irq;
    80005a2c:	00d5179b          	slliw	a5,a0,0xd
    80005a30:	0c201737          	lui	a4,0xc201
    80005a34:	97ba                	add	a5,a5,a4
    80005a36:	c3c4                	sw	s1,4(a5)
}
    80005a38:	60e2                	ld	ra,24(sp)
    80005a3a:	6442                	ld	s0,16(sp)
    80005a3c:	64a2                	ld	s1,8(sp)
    80005a3e:	6105                	addi	sp,sp,32
    80005a40:	8082                	ret

0000000080005a42 <shm_init>:
#include "shm.h"

#define physical_pages 1000
struct mem_reg gt[physical_pages];

void shm_init(){
    80005a42:	7179                	addi	sp,sp,-48
    80005a44:	f406                	sd	ra,40(sp)
    80005a46:	f022                	sd	s0,32(sp)
    80005a48:	ec26                	sd	s1,24(sp)
    80005a4a:	e84a                	sd	s2,16(sp)
    80005a4c:	e44e                	sd	s3,8(sp)
    80005a4e:	1800                	addi	s0,sp,48
    for(int i=0;i<physical_pages;i++){
    80005a50:	0023c497          	auipc	s1,0x23c
    80005a54:	12848493          	addi	s1,s1,296 # 80241b78 <gt+0x10>
    80005a58:	00246997          	auipc	s3,0x246
    80005a5c:	d6098993          	addi	s3,s3,-672 # 8024b7b8 <array_of_mb+0x10>
        gt[i].no_of_process=0;
        gt[i].pa=NULL;
        initlock(&gt[i].lock,"key_lock");
    80005a60:	00003917          	auipc	s2,0x3
    80005a64:	c4090913          	addi	s2,s2,-960 # 800086a0 <etext+0x6a0>
        gt[i].no_of_process=0;
    80005a68:	fe04ac23          	sw	zero,-8(s1)
        gt[i].pa=NULL;
    80005a6c:	fe04b823          	sd	zero,-16(s1)
        initlock(&gt[i].lock,"key_lock");
    80005a70:	85ca                	mv	a1,s2
    80005a72:	8526                	mv	a0,s1
    80005a74:	b1efb0ef          	jal	80000d92 <initlock>
    for(int i=0;i<physical_pages;i++){
    80005a78:	02848493          	addi	s1,s1,40
    80005a7c:	ff3496e3          	bne	s1,s3,80005a68 <shm_init+0x26>
    }
}
    80005a80:	70a2                	ld	ra,40(sp)
    80005a82:	7402                	ld	s0,32(sp)
    80005a84:	64e2                	ld	s1,24(sp)
    80005a86:	6942                	ld	s2,16(sp)
    80005a88:	69a2                	ld	s3,8(sp)
    80005a8a:	6145                	addi	sp,sp,48
    80005a8c:	8082                	ret

0000000080005a8e <shm_create>:
int shm_create(int key){
    80005a8e:	1101                	addi	sp,sp,-32
    80005a90:	ec06                	sd	ra,24(sp)
    80005a92:	e822                	sd	s0,16(sp)
    80005a94:	e426                	sd	s1,8(sp)
    80005a96:	1000                	addi	s0,sp,32
    80005a98:	84aa                	mv	s1,a0
    if(gt[key].pa!=NULL){
    80005a9a:	00251793          	slli	a5,a0,0x2
    80005a9e:	97aa                	add	a5,a5,a0
    80005aa0:	078e                	slli	a5,a5,0x3
    80005aa2:	0023c717          	auipc	a4,0x23c
    80005aa6:	0c670713          	addi	a4,a4,198 # 80241b68 <gt>
    80005aaa:	97ba                	add	a5,a5,a4
    80005aac:	639c                	ld	a5,0(a5)
    80005aae:	c799                	beqz	a5,80005abc <shm_create+0x2e>
    if(gt[key].pa==0){
        return -1;
    }
    memset(gt[key].pa,0,PGSIZE);
    return key;
}
    80005ab0:	8526                	mv	a0,s1
    80005ab2:	60e2                	ld	ra,24(sp)
    80005ab4:	6442                	ld	s0,16(sp)
    80005ab6:	64a2                	ld	s1,8(sp)
    80005ab8:	6105                	addi	sp,sp,32
    80005aba:	8082                	ret
    gt[key].pa=kalloc();
    80005abc:	a50fb0ef          	jal	80000d0c <kalloc>
    80005ac0:	00249793          	slli	a5,s1,0x2
    80005ac4:	97a6                	add	a5,a5,s1
    80005ac6:	078e                	slli	a5,a5,0x3
    80005ac8:	0023c717          	auipc	a4,0x23c
    80005acc:	0a070713          	addi	a4,a4,160 # 80241b68 <gt>
    80005ad0:	97ba                	add	a5,a5,a4
    80005ad2:	e388                	sd	a0,0(a5)
    if(gt[key].pa==0){
    80005ad4:	c511                	beqz	a0,80005ae0 <shm_create+0x52>
    memset(gt[key].pa,0,PGSIZE);
    80005ad6:	6605                	lui	a2,0x1
    80005ad8:	4581                	li	a1,0
    80005ada:	c12fb0ef          	jal	80000eec <memset>
    return key;
    80005ade:	bfc9                	j	80005ab0 <shm_create+0x22>
        return -1;
    80005ae0:	54fd                	li	s1,-1
    80005ae2:	b7f9                	j	80005ab0 <shm_create+0x22>

0000000080005ae4 <shm_get>:

void *shm_get(int key){
    80005ae4:	7179                	addi	sp,sp,-48
    80005ae6:	f406                	sd	ra,40(sp)
    80005ae8:	f022                	sd	s0,32(sp)
    80005aea:	ec26                	sd	s1,24(sp)
    80005aec:	e84a                	sd	s2,16(sp)
    80005aee:	1800                	addi	s0,sp,48
    80005af0:	84aa                	mv	s1,a0
 uint64 shared_va = 0x40000000-((key+1)*PGSIZE);
 acquire(&gt[key].lock);
    80005af2:	00251913          	slli	s2,a0,0x2
    80005af6:	992a                	add	s2,s2,a0
    80005af8:	090e                	slli	s2,s2,0x3
    80005afa:	0941                	addi	s2,s2,16
    80005afc:	0023c797          	auipc	a5,0x23c
    80005b00:	06c78793          	addi	a5,a5,108 # 80241b68 <gt>
    80005b04:	993e                	add	s2,s2,a5
    80005b06:	854a                	mv	a0,s2
    80005b08:	b14fb0ef          	jal	80000e1c <acquire>
if(shm_create(key)==-1){
    80005b0c:	8526                	mv	a0,s1
    80005b0e:	f81ff0ef          	jal	80005a8e <shm_create>
    80005b12:	57fd                	li	a5,-1
    80005b14:	06f50663          	beq	a0,a5,80005b80 <shm_get+0x9c>
    80005b18:	e44e                	sd	s3,8(sp)
 uint64 shared_va = 0x40000000-((key+1)*PGSIZE);
    80005b1a:	00040537          	lui	a0,0x40
    80005b1e:	357d                	addiw	a0,a0,-1 # 3ffff <_entry-0x7ffc0001>
    80005b20:	9d05                	subw	a0,a0,s1
    80005b22:	00c5199b          	slliw	s3,a0,0xc
    release(&gt[key].lock);
    return NULL;
}
if( mappages(myproc()->pagetable,shared_va,PGSIZE,(uint64)gt[key].pa,PTE_W | PTE_R | PTE_U)==-1)printf("mapping failed");
    80005b26:	80afc0ef          	jal	80001b30 <myproc>
    80005b2a:	00249793          	slli	a5,s1,0x2
    80005b2e:	97a6                	add	a5,a5,s1
    80005b30:	078e                	slli	a5,a5,0x3
    80005b32:	0023c717          	auipc	a4,0x23c
    80005b36:	03670713          	addi	a4,a4,54 # 80241b68 <gt>
    80005b3a:	97ba                	add	a5,a5,a4
    80005b3c:	4759                	li	a4,22
    80005b3e:	6394                	ld	a3,0(a5)
    80005b40:	6605                	lui	a2,0x1
    80005b42:	85ce                	mv	a1,s3
    80005b44:	6928                	ld	a0,80(a0)
    80005b46:	f16fb0ef          	jal	8000125c <mappages>
    80005b4a:	57fd                	li	a5,-1
    80005b4c:	02f50f63          	beq	a0,a5,80005b8a <shm_get+0xa6>
 gt[key].no_of_process++;
    80005b50:	0023c697          	auipc	a3,0x23c
    80005b54:	01868693          	addi	a3,a3,24 # 80241b68 <gt>
    80005b58:	00249793          	slli	a5,s1,0x2
    80005b5c:	00978733          	add	a4,a5,s1
    80005b60:	070e                	slli	a4,a4,0x3
    80005b62:	9736                	add	a4,a4,a3
    80005b64:	471c                	lw	a5,8(a4)
    80005b66:	2785                	addiw	a5,a5,1
    80005b68:	c71c                	sw	a5,8(a4)
 release(&gt[key].lock);
    80005b6a:	854a                	mv	a0,s2
    80005b6c:	b44fb0ef          	jal	80000eb0 <release>
 return (void*)shared_va;
    80005b70:	854e                	mv	a0,s3
    80005b72:	69a2                	ld	s3,8(sp)
}
    80005b74:	70a2                	ld	ra,40(sp)
    80005b76:	7402                	ld	s0,32(sp)
    80005b78:	64e2                	ld	s1,24(sp)
    80005b7a:	6942                	ld	s2,16(sp)
    80005b7c:	6145                	addi	sp,sp,48
    80005b7e:	8082                	ret
    release(&gt[key].lock);
    80005b80:	854a                	mv	a0,s2
    80005b82:	b2efb0ef          	jal	80000eb0 <release>
    return NULL;
    80005b86:	4501                	li	a0,0
    80005b88:	b7f5                	j	80005b74 <shm_get+0x90>
if( mappages(myproc()->pagetable,shared_va,PGSIZE,(uint64)gt[key].pa,PTE_W | PTE_R | PTE_U)==-1)printf("mapping failed");
    80005b8a:	00003517          	auipc	a0,0x3
    80005b8e:	b2650513          	addi	a0,a0,-1242 # 800086b0 <etext+0x6b0>
    80005b92:	969fa0ef          	jal	800004fa <printf>
    80005b96:	bf6d                	j	80005b50 <shm_get+0x6c>

0000000080005b98 <shm_close>:

int shm_close(int key){
    80005b98:	7179                	addi	sp,sp,-48
    80005b9a:	f406                	sd	ra,40(sp)
    80005b9c:	f022                	sd	s0,32(sp)
    80005b9e:	ec26                	sd	s1,24(sp)
    80005ba0:	e84a                	sd	s2,16(sp)
    80005ba2:	e44e                	sd	s3,8(sp)
    80005ba4:	e052                	sd	s4,0(sp)
    80005ba6:	1800                	addi	s0,sp,48
    80005ba8:	84aa                	mv	s1,a0
    acquire(&gt[key].lock);
    80005baa:	00251913          	slli	s2,a0,0x2
    80005bae:	00a909b3          	add	s3,s2,a0
    80005bb2:	098e                	slli	s3,s3,0x3
    80005bb4:	09c1                	addi	s3,s3,16
    80005bb6:	0023ca17          	auipc	s4,0x23c
    80005bba:	fb2a0a13          	addi	s4,s4,-78 # 80241b68 <gt>
    80005bbe:	99d2                	add	s3,s3,s4
    80005bc0:	854e                	mv	a0,s3
    80005bc2:	a5afb0ef          	jal	80000e1c <acquire>
    if(gt[key].no_of_process==0){
    80005bc6:	9926                	add	s2,s2,s1
    80005bc8:	090e                	slli	s2,s2,0x3
    80005bca:	9a4a                	add	s4,s4,s2
    80005bcc:	008a2783          	lw	a5,8(s4)
    80005bd0:	cba1                	beqz	a5,80005c20 <shm_close+0x88>
        release(&gt[key].lock);
        return 1;
    }
    if(gt[key].no_of_process>1){
    80005bd2:	4705                	li	a4,1
    80005bd4:	04f75a63          	bge	a4,a5,80005c28 <shm_close+0x90>
        gt[key].no_of_process--;
    80005bd8:	00249713          	slli	a4,s1,0x2
    80005bdc:	9726                	add	a4,a4,s1
    80005bde:	070e                	slli	a4,a4,0x3
    80005be0:	0023c697          	auipc	a3,0x23c
    80005be4:	f8868693          	addi	a3,a3,-120 # 80241b68 <gt>
    80005be8:	9736                	add	a4,a4,a3
    80005bea:	37fd                	addiw	a5,a5,-1
    80005bec:	c71c                	sw	a5,8(a4)
        uvmunmap(myproc()->pagetable, 0x40000000-((key+1)*PGSIZE), 1, 0);
    80005bee:	f43fb0ef          	jal	80001b30 <myproc>
    80005bf2:	000405b7          	lui	a1,0x40
    80005bf6:	35fd                	addiw	a1,a1,-1 # 3ffff <_entry-0x7ffc0001>
    80005bf8:	9d85                	subw	a1,a1,s1
    80005bfa:	4681                	li	a3,0
    80005bfc:	4605                	li	a2,1
    80005bfe:	00c5959b          	slliw	a1,a1,0xc
    80005c02:	6928                	ld	a0,80(a0)
    80005c04:	827fb0ef          	jal	8000142a <uvmunmap>
        release(&gt[key].lock);
    80005c08:	854e                	mv	a0,s3
    80005c0a:	aa6fb0ef          	jal	80000eb0 <release>
        uvmunmap(myproc()->pagetable, 0x40000000-((key+1)*PGSIZE), 1, 1);
        gt[key].pa=NULL;
        release(&gt[key].lock);
        return 1;
    }
    80005c0e:	4505                	li	a0,1
    80005c10:	70a2                	ld	ra,40(sp)
    80005c12:	7402                	ld	s0,32(sp)
    80005c14:	64e2                	ld	s1,24(sp)
    80005c16:	6942                	ld	s2,16(sp)
    80005c18:	69a2                	ld	s3,8(sp)
    80005c1a:	6a02                	ld	s4,0(sp)
    80005c1c:	6145                	addi	sp,sp,48
    80005c1e:	8082                	ret
        release(&gt[key].lock);
    80005c20:	854e                	mv	a0,s3
    80005c22:	a8efb0ef          	jal	80000eb0 <release>
        return 1;
    80005c26:	b7e5                	j	80005c0e <shm_close+0x76>
        gt[key].no_of_process--;
    80005c28:	0023ca17          	auipc	s4,0x23c
    80005c2c:	f40a0a13          	addi	s4,s4,-192 # 80241b68 <gt>
    80005c30:	00249913          	slli	s2,s1,0x2
    80005c34:	00990733          	add	a4,s2,s1
    80005c38:	070e                	slli	a4,a4,0x3
    80005c3a:	9752                	add	a4,a4,s4
    80005c3c:	37fd                	addiw	a5,a5,-1
    80005c3e:	c71c                	sw	a5,8(a4)
        uvmunmap(myproc()->pagetable, 0x40000000-((key+1)*PGSIZE), 1, 1);
    80005c40:	ef1fb0ef          	jal	80001b30 <myproc>
    80005c44:	000405b7          	lui	a1,0x40
    80005c48:	35fd                	addiw	a1,a1,-1 # 3ffff <_entry-0x7ffc0001>
    80005c4a:	9d85                	subw	a1,a1,s1
    80005c4c:	4685                	li	a3,1
    80005c4e:	8636                	mv	a2,a3
    80005c50:	00c5959b          	slliw	a1,a1,0xc
    80005c54:	6928                	ld	a0,80(a0)
    80005c56:	fd4fb0ef          	jal	8000142a <uvmunmap>
        gt[key].pa=NULL;
    80005c5a:	9926                	add	s2,s2,s1
    80005c5c:	090e                	slli	s2,s2,0x3
    80005c5e:	9a4a                	add	s4,s4,s2
    80005c60:	000a3023          	sd	zero,0(s4)
        release(&gt[key].lock);
    80005c64:	854e                	mv	a0,s3
    80005c66:	a4afb0ef          	jal	80000eb0 <release>
        return 1;
    80005c6a:	b755                	j	80005c0e <shm_close+0x76>

0000000080005c6c <enqueue>:


#define size 10
#define max_mboxes 1000
struct mbox array_of_mb[max_mboxes];
int enqueue(int value,struct mbox *buffer){
    80005c6c:	1141                	addi	sp,sp,-16
    80005c6e:	e406                	sd	ra,8(sp)
    80005c70:	e022                	sd	s0,0(sp)
    80005c72:	0800                	addi	s0,sp,16

    if(buffer->length==size){
    80005c74:	5990                	lw	a2,48(a1)
    80005c76:	47a9                	li	a5,10
    80005c78:	04f60663          	beq	a2,a5,80005cc4 <enqueue+0x58>
        return -1;
    }
    if(buffer->front==-1)buffer->front =0;
    80005c7c:	5598                	lw	a4,40(a1)
    80005c7e:	57fd                	li	a5,-1
    80005c80:	02f70f63          	beq	a4,a5,80005cbe <enqueue+0x52>
    buffer->rear = (buffer->rear+1)%size;
    80005c84:	55dc                	lw	a5,44(a1)
    80005c86:	2785                	addiw	a5,a5,1
    80005c88:	66666737          	lui	a4,0x66666
    80005c8c:	66770713          	addi	a4,a4,1639 # 66666667 <_entry-0x19999999>
    80005c90:	02e78733          	mul	a4,a5,a4
    80005c94:	9709                	srai	a4,a4,0x22
    80005c96:	41f7d69b          	sraiw	a3,a5,0x1f
    80005c9a:	9f15                	subw	a4,a4,a3
    80005c9c:	0027169b          	slliw	a3,a4,0x2
    80005ca0:	9f35                	addw	a4,a4,a3
    80005ca2:	0017171b          	slliw	a4,a4,0x1
    80005ca6:	9f99                	subw	a5,a5,a4
    80005ca8:	d5dc                	sw	a5,44(a1)
    buffer->queue[buffer->rear]=value;
    80005caa:	078a                	slli	a5,a5,0x2
    80005cac:	97ae                	add	a5,a5,a1
    80005cae:	c388                	sw	a0,0(a5)
    buffer->length++;
    80005cb0:	2605                	addiw	a2,a2,1 # 1001 <_entry-0x7fffefff>
    80005cb2:	d990                	sw	a2,48(a1)
    return 0;
    80005cb4:	4501                	li	a0,0
}
    80005cb6:	60a2                	ld	ra,8(sp)
    80005cb8:	6402                	ld	s0,0(sp)
    80005cba:	0141                	addi	sp,sp,16
    80005cbc:	8082                	ret
    if(buffer->front==-1)buffer->front =0;
    80005cbe:	0205a423          	sw	zero,40(a1)
    80005cc2:	b7c9                	j	80005c84 <enqueue+0x18>
        return -1;
    80005cc4:	557d                	li	a0,-1
    80005cc6:	bfc5                	j	80005cb6 <enqueue+0x4a>

0000000080005cc8 <dequeue>:
int dequeue(struct mbox* buffer){
    80005cc8:	1141                	addi	sp,sp,-16
    80005cca:	e406                	sd	ra,8(sp)
    80005ccc:	e022                	sd	s0,0(sp)
    80005cce:	0800                	addi	s0,sp,16
    int val;
    if(buffer->length==0)return -1;
    80005cd0:	5910                	lw	a2,48(a0)
    80005cd2:	ca21                	beqz	a2,80005d22 <dequeue+0x5a>
    80005cd4:	872a                	mv	a4,a0
    if(buffer->front==buffer->rear){
    80005cd6:	551c                	lw	a5,40(a0)
    80005cd8:	5554                	lw	a3,44(a0)
    80005cda:	02f68e63          	beq	a3,a5,80005d16 <dequeue+0x4e>
        val=buffer->queue[buffer->front];
        buffer->rear=-1;
        buffer->front=-1;
    }
    else{
        val=buffer->queue[buffer->front];
    80005cde:	00279693          	slli	a3,a5,0x2
    80005ce2:	96aa                	add	a3,a3,a0
    80005ce4:	4288                	lw	a0,0(a3)
        buffer->front=(buffer->front+1)%size;
    80005ce6:	2785                	addiw	a5,a5,1
    80005ce8:	666666b7          	lui	a3,0x66666
    80005cec:	66768693          	addi	a3,a3,1639 # 66666667 <_entry-0x19999999>
    80005cf0:	02d786b3          	mul	a3,a5,a3
    80005cf4:	9689                	srai	a3,a3,0x22
    80005cf6:	41f7d59b          	sraiw	a1,a5,0x1f
    80005cfa:	9e8d                	subw	a3,a3,a1
    80005cfc:	0026959b          	slliw	a1,a3,0x2
    80005d00:	9ead                	addw	a3,a3,a1
    80005d02:	0016969b          	slliw	a3,a3,0x1
    80005d06:	9f95                	subw	a5,a5,a3
        buffer->front=-1;
    80005d08:	d71c                	sw	a5,40(a4)
    }
    buffer->length--;
    80005d0a:	367d                	addiw	a2,a2,-1
    80005d0c:	db10                	sw	a2,48(a4)
    return val;
}
    80005d0e:	60a2                	ld	ra,8(sp)
    80005d10:	6402                	ld	s0,0(sp)
    80005d12:	0141                	addi	sp,sp,16
    80005d14:	8082                	ret
        val=buffer->queue[buffer->front];
    80005d16:	078a                	slli	a5,a5,0x2
    80005d18:	97aa                	add	a5,a5,a0
    80005d1a:	4388                	lw	a0,0(a5)
        buffer->rear=-1;
    80005d1c:	57fd                	li	a5,-1
    80005d1e:	d75c                	sw	a5,44(a4)
        buffer->front=-1;
    80005d20:	b7e5                	j	80005d08 <dequeue+0x40>
    if(buffer->length==0)return -1;
    80005d22:	557d                	li	a0,-1
    80005d24:	b7ed                	j	80005d0e <dequeue+0x46>

0000000080005d26 <mbox_init>:

void mbox_init(){
    80005d26:	7179                	addi	sp,sp,-48
    80005d28:	f406                	sd	ra,40(sp)
    80005d2a:	f022                	sd	s0,32(sp)
    80005d2c:	ec26                	sd	s1,24(sp)
    80005d2e:	e84a                	sd	s2,16(sp)
    80005d30:	e44e                	sd	s3,8(sp)
    80005d32:	e052                	sd	s4,0(sp)
    80005d34:	1800                	addi	s0,sp,48
    for(int i=0;i<max_mboxes;i++){
    80005d36:	00246497          	auipc	s1,0x246
    80005d3a:	aaa48493          	addi	s1,s1,-1366 # 8024b7e0 <array_of_mb+0x38>
    80005d3e:	00259a17          	auipc	s4,0x259
    80005d42:	322a0a13          	addi	s4,s4,802 # 8025f060 <disk+0x38>
        array_of_mb[i].front=-1;
    80005d46:	597d                	li	s2,-1
        array_of_mb[i].rear=-1;
        array_of_mb[i].length=0;
        array_of_mb[i].valid=0;
        initlock(&array_of_mb[i].lock,"buffer_lock");
    80005d48:	00003997          	auipc	s3,0x3
    80005d4c:	97898993          	addi	s3,s3,-1672 # 800086c0 <etext+0x6c0>
        array_of_mb[i].front=-1;
    80005d50:	ff24a823          	sw	s2,-16(s1)
        array_of_mb[i].rear=-1;
    80005d54:	ff24aa23          	sw	s2,-12(s1)
        array_of_mb[i].length=0;
    80005d58:	fe04ac23          	sw	zero,-8(s1)
        array_of_mb[i].valid=0;
    80005d5c:	fe04ae23          	sw	zero,-4(s1)
        initlock(&array_of_mb[i].lock,"buffer_lock");
    80005d60:	85ce                	mv	a1,s3
    80005d62:	8526                	mv	a0,s1
    80005d64:	82efb0ef          	jal	80000d92 <initlock>
    for(int i=0;i<max_mboxes;i++){
    80005d68:	05048493          	addi	s1,s1,80
    80005d6c:	ff4492e3          	bne	s1,s4,80005d50 <mbox_init+0x2a>
    }
}
    80005d70:	70a2                	ld	ra,40(sp)
    80005d72:	7402                	ld	s0,32(sp)
    80005d74:	64e2                	ld	s1,24(sp)
    80005d76:	6942                	ld	s2,16(sp)
    80005d78:	69a2                	ld	s3,8(sp)
    80005d7a:	6a02                	ld	s4,0(sp)
    80005d7c:	6145                	addi	sp,sp,48
    80005d7e:	8082                	ret

0000000080005d80 <mbox_create>:

int mbox_create(int key){
    80005d80:	1141                	addi	sp,sp,-16
    80005d82:	e406                	sd	ra,8(sp)
    80005d84:	e022                	sd	s0,0(sp)
    80005d86:	0800                	addi	s0,sp,16
    80005d88:	87aa                	mv	a5,a0
    if(array_of_mb[key].valid)return -1;
    80005d8a:	00251713          	slli	a4,a0,0x2
    80005d8e:	972a                	add	a4,a4,a0
    80005d90:	0712                	slli	a4,a4,0x4
    80005d92:	00246697          	auipc	a3,0x246
    80005d96:	a1668693          	addi	a3,a3,-1514 # 8024b7a8 <array_of_mb>
    80005d9a:	9736                	add	a4,a4,a3
    80005d9c:	5b48                	lw	a0,52(a4)
    80005d9e:	ed01                	bnez	a0,80005db6 <mbox_create+0x36>
    else array_of_mb[key].valid=1;
    80005da0:	00279713          	slli	a4,a5,0x2
    80005da4:	97ba                	add	a5,a5,a4
    80005da6:	0792                	slli	a5,a5,0x4
    80005da8:	97b6                	add	a5,a5,a3
    80005daa:	4705                	li	a4,1
    80005dac:	dbd8                	sw	a4,52(a5)
    return 0;
}
    80005dae:	60a2                	ld	ra,8(sp)
    80005db0:	6402                	ld	s0,0(sp)
    80005db2:	0141                	addi	sp,sp,16
    80005db4:	8082                	ret
    if(array_of_mb[key].valid)return -1;
    80005db6:	557d                	li	a0,-1
    80005db8:	bfdd                	j	80005dae <mbox_create+0x2e>

0000000080005dba <mbox_send>:

int mbox_send(int mbox_id,int msg){
    80005dba:	7139                	addi	sp,sp,-64
    80005dbc:	fc06                	sd	ra,56(sp)
    80005dbe:	f822                	sd	s0,48(sp)
    80005dc0:	f426                	sd	s1,40(sp)
    80005dc2:	f04a                	sd	s2,32(sp)
    80005dc4:	ec4e                	sd	s3,24(sp)
    80005dc6:	e852                	sd	s4,16(sp)
    80005dc8:	e456                	sd	s5,8(sp)
    80005dca:	0080                	addi	s0,sp,64
    80005dcc:	8aaa                	mv	s5,a0
    80005dce:	89ae                	mv	s3,a1
    acquire(&array_of_mb[mbox_id].lock);
    80005dd0:	00251493          	slli	s1,a0,0x2
    80005dd4:	94aa                	add	s1,s1,a0
    80005dd6:	0492                	slli	s1,s1,0x4
    80005dd8:	03848913          	addi	s2,s1,56
    80005ddc:	00246a17          	auipc	s4,0x246
    80005de0:	9cca0a13          	addi	s4,s4,-1588 # 8024b7a8 <array_of_mb>
    80005de4:	9952                	add	s2,s2,s4
    80005de6:	854a                	mv	a0,s2
    80005de8:	834fb0ef          	jal	80000e1c <acquire>
    while(enqueue(msg,&array_of_mb[mbox_id])==-1){
    80005dec:	94d2                	add	s1,s1,s4
    80005dee:	5a7d                	li	s4,-1
    80005df0:	a801                	j	80005e00 <mbox_send+0x46>
        wakeup(&array_of_mb[mbox_id]);
    80005df2:	8526                	mv	a0,s1
    80005df4:	b86fc0ef          	jal	8000217a <wakeup>
        sleep(&array_of_mb[mbox_id],&array_of_mb[mbox_id].lock);
    80005df8:	85ca                	mv	a1,s2
    80005dfa:	8526                	mv	a0,s1
    80005dfc:	b32fc0ef          	jal	8000212e <sleep>
    while(enqueue(msg,&array_of_mb[mbox_id])==-1){
    80005e00:	85a6                	mv	a1,s1
    80005e02:	854e                	mv	a0,s3
    80005e04:	e69ff0ef          	jal	80005c6c <enqueue>
    80005e08:	ff4505e3          	beq	a0,s4,80005df2 <mbox_send+0x38>
    }
    printf("sent %d in mailbox with id: %d\n",msg,mbox_id);
    80005e0c:	8656                	mv	a2,s5
    80005e0e:	85ce                	mv	a1,s3
    80005e10:	00003517          	auipc	a0,0x3
    80005e14:	8c050513          	addi	a0,a0,-1856 # 800086d0 <etext+0x6d0>
    80005e18:	ee2fa0ef          	jal	800004fa <printf>
    wakeup(&array_of_mb[mbox_id]);
    80005e1c:	8526                	mv	a0,s1
    80005e1e:	b5cfc0ef          	jal	8000217a <wakeup>
    release(&array_of_mb[mbox_id].lock);
    80005e22:	854a                	mv	a0,s2
    80005e24:	88cfb0ef          	jal	80000eb0 <release>
    return 0;
}
    80005e28:	4501                	li	a0,0
    80005e2a:	70e2                	ld	ra,56(sp)
    80005e2c:	7442                	ld	s0,48(sp)
    80005e2e:	74a2                	ld	s1,40(sp)
    80005e30:	7902                	ld	s2,32(sp)
    80005e32:	69e2                	ld	s3,24(sp)
    80005e34:	6a42                	ld	s4,16(sp)
    80005e36:	6aa2                	ld	s5,8(sp)
    80005e38:	6121                	addi	sp,sp,64
    80005e3a:	8082                	ret

0000000080005e3c <mbox_recv>:

int mbox_recv(int mbox_id,int *msg){
    80005e3c:	7139                	addi	sp,sp,-64
    80005e3e:	fc06                	sd	ra,56(sp)
    80005e40:	f822                	sd	s0,48(sp)
    80005e42:	f426                	sd	s1,40(sp)
    80005e44:	f04a                	sd	s2,32(sp)
    80005e46:	ec4e                	sd	s3,24(sp)
    80005e48:	e852                	sd	s4,16(sp)
    80005e4a:	e456                	sd	s5,8(sp)
    80005e4c:	0080                	addi	s0,sp,64
    80005e4e:	8a2a                	mv	s4,a0
    80005e50:	8aae                	mv	s5,a1
    acquire(&array_of_mb[mbox_id].lock);
    80005e52:	00251493          	slli	s1,a0,0x2
    80005e56:	94aa                	add	s1,s1,a0
    80005e58:	0492                	slli	s1,s1,0x4
    80005e5a:	03848913          	addi	s2,s1,56
    80005e5e:	00246997          	auipc	s3,0x246
    80005e62:	94a98993          	addi	s3,s3,-1718 # 8024b7a8 <array_of_mb>
    80005e66:	994e                	add	s2,s2,s3
    80005e68:	854a                	mv	a0,s2
    80005e6a:	fb3fa0ef          	jal	80000e1c <acquire>
    int temp;
    while((temp=dequeue(&array_of_mb[mbox_id]))==-1){
    80005e6e:	94ce                	add	s1,s1,s3
    80005e70:	59fd                	li	s3,-1
    80005e72:	a801                	j	80005e82 <mbox_recv+0x46>
        wakeup(&array_of_mb[mbox_id]);
    80005e74:	8526                	mv	a0,s1
    80005e76:	b04fc0ef          	jal	8000217a <wakeup>
        sleep(&array_of_mb[mbox_id],&array_of_mb[mbox_id].lock);
    80005e7a:	85ca                	mv	a1,s2
    80005e7c:	8526                	mv	a0,s1
    80005e7e:	ab0fc0ef          	jal	8000212e <sleep>
    while((temp=dequeue(&array_of_mb[mbox_id]))==-1){
    80005e82:	8526                	mv	a0,s1
    80005e84:	e45ff0ef          	jal	80005cc8 <dequeue>
    80005e88:	ff3506e3          	beq	a0,s3,80005e74 <mbox_recv+0x38>
    }
    *msg=temp;
    80005e8c:	00aaa023          	sw	a0,0(s5)
    printf("receieved %d in mailbox with id: %d\n",*msg,mbox_id);
    80005e90:	8652                	mv	a2,s4
    80005e92:	85aa                	mv	a1,a0
    80005e94:	00003517          	auipc	a0,0x3
    80005e98:	85c50513          	addi	a0,a0,-1956 # 800086f0 <etext+0x6f0>
    80005e9c:	e5efa0ef          	jal	800004fa <printf>
    wakeup(&array_of_mb[mbox_id]);  
    80005ea0:	8526                	mv	a0,s1
    80005ea2:	ad8fc0ef          	jal	8000217a <wakeup>
    release(&array_of_mb[mbox_id].lock);
    80005ea6:	854a                	mv	a0,s2
    80005ea8:	808fb0ef          	jal	80000eb0 <release>
    return 0;
    80005eac:	4501                	li	a0,0
    80005eae:	70e2                	ld	ra,56(sp)
    80005eb0:	7442                	ld	s0,48(sp)
    80005eb2:	74a2                	ld	s1,40(sp)
    80005eb4:	7902                	ld	s2,32(sp)
    80005eb6:	69e2                	ld	s3,24(sp)
    80005eb8:	6a42                	ld	s4,16(sp)
    80005eba:	6aa2                	ld	s5,8(sp)
    80005ebc:	6121                	addi	sp,sp,64
    80005ebe:	8082                	ret

0000000080005ec0 <free_desc>:
}

// mark a descriptor as free.
static void
free_desc(int i)
{
    80005ec0:	1141                	addi	sp,sp,-16
    80005ec2:	e406                	sd	ra,8(sp)
    80005ec4:	e022                	sd	s0,0(sp)
    80005ec6:	0800                	addi	s0,sp,16
  if(i >= NUM)
    80005ec8:	479d                	li	a5,7
    80005eca:	04a7ca63          	blt	a5,a0,80005f1e <free_desc+0x5e>
    panic("free_desc 1");
  if(disk.free[i])
    80005ece:	00259797          	auipc	a5,0x259
    80005ed2:	15a78793          	addi	a5,a5,346 # 8025f028 <disk>
    80005ed6:	97aa                	add	a5,a5,a0
    80005ed8:	0187c783          	lbu	a5,24(a5)
    80005edc:	e7b9                	bnez	a5,80005f2a <free_desc+0x6a>
    panic("free_desc 2");
  disk.desc[i].addr = 0;
    80005ede:	00451693          	slli	a3,a0,0x4
    80005ee2:	00259797          	auipc	a5,0x259
    80005ee6:	14678793          	addi	a5,a5,326 # 8025f028 <disk>
    80005eea:	6398                	ld	a4,0(a5)
    80005eec:	9736                	add	a4,a4,a3
    80005eee:	00073023          	sd	zero,0(a4)
  disk.desc[i].len = 0;
    80005ef2:	6398                	ld	a4,0(a5)
    80005ef4:	9736                	add	a4,a4,a3
    80005ef6:	00072423          	sw	zero,8(a4)
  disk.desc[i].flags = 0;
    80005efa:	00071623          	sh	zero,12(a4)
  disk.desc[i].next = 0;
    80005efe:	00071723          	sh	zero,14(a4)
  disk.free[i] = 1;
    80005f02:	97aa                	add	a5,a5,a0
    80005f04:	4705                	li	a4,1
    80005f06:	00e78c23          	sb	a4,24(a5)
  wakeup(&disk.free[0]);
    80005f0a:	00259517          	auipc	a0,0x259
    80005f0e:	13650513          	addi	a0,a0,310 # 8025f040 <disk+0x18>
    80005f12:	a68fc0ef          	jal	8000217a <wakeup>
}
    80005f16:	60a2                	ld	ra,8(sp)
    80005f18:	6402                	ld	s0,0(sp)
    80005f1a:	0141                	addi	sp,sp,16
    80005f1c:	8082                	ret
    panic("free_desc 1");
    80005f1e:	00002517          	auipc	a0,0x2
    80005f22:	7fa50513          	addi	a0,a0,2042 # 80008718 <etext+0x718>
    80005f26:	8fffa0ef          	jal	80000824 <panic>
    panic("free_desc 2");
    80005f2a:	00002517          	auipc	a0,0x2
    80005f2e:	7fe50513          	addi	a0,a0,2046 # 80008728 <etext+0x728>
    80005f32:	8f3fa0ef          	jal	80000824 <panic>

0000000080005f36 <virtio_disk_init>:
{
    80005f36:	1101                	addi	sp,sp,-32
    80005f38:	ec06                	sd	ra,24(sp)
    80005f3a:	e822                	sd	s0,16(sp)
    80005f3c:	e426                	sd	s1,8(sp)
    80005f3e:	e04a                	sd	s2,0(sp)
    80005f40:	1000                	addi	s0,sp,32
  initlock(&disk.vdisk_lock, "virtio_disk");
    80005f42:	00002597          	auipc	a1,0x2
    80005f46:	7f658593          	addi	a1,a1,2038 # 80008738 <etext+0x738>
    80005f4a:	00259517          	auipc	a0,0x259
    80005f4e:	20650513          	addi	a0,a0,518 # 8025f150 <disk+0x128>
    80005f52:	e41fa0ef          	jal	80000d92 <initlock>
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005f56:	100017b7          	lui	a5,0x10001
    80005f5a:	4398                	lw	a4,0(a5)
    80005f5c:	2701                	sext.w	a4,a4
    80005f5e:	747277b7          	lui	a5,0x74727
    80005f62:	97678793          	addi	a5,a5,-1674 # 74726976 <_entry-0xb8d968a>
    80005f66:	14f71863          	bne	a4,a5,800060b6 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005f6a:	100017b7          	lui	a5,0x10001
    80005f6e:	43dc                	lw	a5,4(a5)
    80005f70:	2781                	sext.w	a5,a5
  if(*R(VIRTIO_MMIO_MAGIC_VALUE) != 0x74726976 ||
    80005f72:	4709                	li	a4,2
    80005f74:	14e79163          	bne	a5,a4,800060b6 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005f78:	100017b7          	lui	a5,0x10001
    80005f7c:	479c                	lw	a5,8(a5)
    80005f7e:	2781                	sext.w	a5,a5
     *R(VIRTIO_MMIO_VERSION) != 2 ||
    80005f80:	12e79b63          	bne	a5,a4,800060b6 <virtio_disk_init+0x180>
     *R(VIRTIO_MMIO_VENDOR_ID) != 0x554d4551){
    80005f84:	100017b7          	lui	a5,0x10001
    80005f88:	47d8                	lw	a4,12(a5)
    80005f8a:	2701                	sext.w	a4,a4
     *R(VIRTIO_MMIO_DEVICE_ID) != 2 ||
    80005f8c:	554d47b7          	lui	a5,0x554d4
    80005f90:	55178793          	addi	a5,a5,1361 # 554d4551 <_entry-0x2ab2baaf>
    80005f94:	12f71163          	bne	a4,a5,800060b6 <virtio_disk_init+0x180>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005f98:	100017b7          	lui	a5,0x10001
    80005f9c:	0607a823          	sw	zero,112(a5) # 10001070 <_entry-0x6fffef90>
  *R(VIRTIO_MMIO_STATUS) = status;
    80005fa0:	4705                	li	a4,1
    80005fa2:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005fa4:	470d                	li	a4,3
    80005fa6:	dbb8                	sw	a4,112(a5)
  uint64 features = *R(VIRTIO_MMIO_DEVICE_FEATURES);
    80005fa8:	10001737          	lui	a4,0x10001
    80005fac:	4b18                	lw	a4,16(a4)
  features &= ~(1 << VIRTIO_RING_F_INDIRECT_DESC);
    80005fae:	c7ffe6b7          	lui	a3,0xc7ffe
    80005fb2:	75f68693          	addi	a3,a3,1887 # ffffffffc7ffe75f <end+0xffffffff47d9f5f7>
  *R(VIRTIO_MMIO_DRIVER_FEATURES) = features;
    80005fb6:	8f75                	and	a4,a4,a3
    80005fb8:	100016b7          	lui	a3,0x10001
    80005fbc:	d298                	sw	a4,32(a3)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005fbe:	472d                	li	a4,11
    80005fc0:	dbb8                	sw	a4,112(a5)
  *R(VIRTIO_MMIO_STATUS) = status;
    80005fc2:	07078793          	addi	a5,a5,112
  status = *R(VIRTIO_MMIO_STATUS);
    80005fc6:	439c                	lw	a5,0(a5)
    80005fc8:	0007891b          	sext.w	s2,a5
  if(!(status & VIRTIO_CONFIG_S_FEATURES_OK))
    80005fcc:	8ba1                	andi	a5,a5,8
    80005fce:	0e078a63          	beqz	a5,800060c2 <virtio_disk_init+0x18c>
  *R(VIRTIO_MMIO_QUEUE_SEL) = 0;
    80005fd2:	100017b7          	lui	a5,0x10001
    80005fd6:	0207a823          	sw	zero,48(a5) # 10001030 <_entry-0x6fffefd0>
  if(*R(VIRTIO_MMIO_QUEUE_READY))
    80005fda:	43fc                	lw	a5,68(a5)
    80005fdc:	2781                	sext.w	a5,a5
    80005fde:	0e079863          	bnez	a5,800060ce <virtio_disk_init+0x198>
  uint32 max = *R(VIRTIO_MMIO_QUEUE_NUM_MAX);
    80005fe2:	100017b7          	lui	a5,0x10001
    80005fe6:	5bdc                	lw	a5,52(a5)
    80005fe8:	2781                	sext.w	a5,a5
  if(max == 0)
    80005fea:	0e078863          	beqz	a5,800060da <virtio_disk_init+0x1a4>
  if(max < NUM)
    80005fee:	471d                	li	a4,7
    80005ff0:	0ef77b63          	bgeu	a4,a5,800060e6 <virtio_disk_init+0x1b0>
  disk.desc = kalloc();
    80005ff4:	d19fa0ef          	jal	80000d0c <kalloc>
    80005ff8:	00259497          	auipc	s1,0x259
    80005ffc:	03048493          	addi	s1,s1,48 # 8025f028 <disk>
    80006000:	e088                	sd	a0,0(s1)
  disk.avail = kalloc();
    80006002:	d0bfa0ef          	jal	80000d0c <kalloc>
    80006006:	e488                	sd	a0,8(s1)
  disk.used = kalloc();
    80006008:	d05fa0ef          	jal	80000d0c <kalloc>
    8000600c:	87aa                	mv	a5,a0
    8000600e:	e888                	sd	a0,16(s1)
  if(!disk.desc || !disk.avail || !disk.used)
    80006010:	6088                	ld	a0,0(s1)
    80006012:	0e050063          	beqz	a0,800060f2 <virtio_disk_init+0x1bc>
    80006016:	00259717          	auipc	a4,0x259
    8000601a:	01a73703          	ld	a4,26(a4) # 8025f030 <disk+0x8>
    8000601e:	cb71                	beqz	a4,800060f2 <virtio_disk_init+0x1bc>
    80006020:	cbe9                	beqz	a5,800060f2 <virtio_disk_init+0x1bc>
  memset(disk.desc, 0, PGSIZE);
    80006022:	6605                	lui	a2,0x1
    80006024:	4581                	li	a1,0
    80006026:	ec7fa0ef          	jal	80000eec <memset>
  memset(disk.avail, 0, PGSIZE);
    8000602a:	00259497          	auipc	s1,0x259
    8000602e:	ffe48493          	addi	s1,s1,-2 # 8025f028 <disk>
    80006032:	6605                	lui	a2,0x1
    80006034:	4581                	li	a1,0
    80006036:	6488                	ld	a0,8(s1)
    80006038:	eb5fa0ef          	jal	80000eec <memset>
  memset(disk.used, 0, PGSIZE);
    8000603c:	6605                	lui	a2,0x1
    8000603e:	4581                	li	a1,0
    80006040:	6888                	ld	a0,16(s1)
    80006042:	eabfa0ef          	jal	80000eec <memset>
  *R(VIRTIO_MMIO_QUEUE_NUM) = NUM;
    80006046:	100017b7          	lui	a5,0x10001
    8000604a:	4721                	li	a4,8
    8000604c:	df98                	sw	a4,56(a5)
  *R(VIRTIO_MMIO_QUEUE_DESC_LOW) = (uint64)disk.desc;
    8000604e:	4098                	lw	a4,0(s1)
    80006050:	08e7a023          	sw	a4,128(a5) # 10001080 <_entry-0x6fffef80>
  *R(VIRTIO_MMIO_QUEUE_DESC_HIGH) = (uint64)disk.desc >> 32;
    80006054:	40d8                	lw	a4,4(s1)
    80006056:	08e7a223          	sw	a4,132(a5)
  *R(VIRTIO_MMIO_DRIVER_DESC_LOW) = (uint64)disk.avail;
    8000605a:	649c                	ld	a5,8(s1)
    8000605c:	0007869b          	sext.w	a3,a5
    80006060:	10001737          	lui	a4,0x10001
    80006064:	08d72823          	sw	a3,144(a4) # 10001090 <_entry-0x6fffef70>
  *R(VIRTIO_MMIO_DRIVER_DESC_HIGH) = (uint64)disk.avail >> 32;
    80006068:	9781                	srai	a5,a5,0x20
    8000606a:	08f72a23          	sw	a5,148(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_LOW) = (uint64)disk.used;
    8000606e:	689c                	ld	a5,16(s1)
    80006070:	0007869b          	sext.w	a3,a5
    80006074:	0ad72023          	sw	a3,160(a4)
  *R(VIRTIO_MMIO_DEVICE_DESC_HIGH) = (uint64)disk.used >> 32;
    80006078:	9781                	srai	a5,a5,0x20
    8000607a:	0af72223          	sw	a5,164(a4)
  *R(VIRTIO_MMIO_QUEUE_READY) = 0x1;
    8000607e:	4785                	li	a5,1
    80006080:	c37c                	sw	a5,68(a4)
    disk.free[i] = 1;
    80006082:	00f48c23          	sb	a5,24(s1)
    80006086:	00f48ca3          	sb	a5,25(s1)
    8000608a:	00f48d23          	sb	a5,26(s1)
    8000608e:	00f48da3          	sb	a5,27(s1)
    80006092:	00f48e23          	sb	a5,28(s1)
    80006096:	00f48ea3          	sb	a5,29(s1)
    8000609a:	00f48f23          	sb	a5,30(s1)
    8000609e:	00f48fa3          	sb	a5,31(s1)
  status |= VIRTIO_CONFIG_S_DRIVER_OK;
    800060a2:	00496913          	ori	s2,s2,4
  *R(VIRTIO_MMIO_STATUS) = status;
    800060a6:	07272823          	sw	s2,112(a4)
}
    800060aa:	60e2                	ld	ra,24(sp)
    800060ac:	6442                	ld	s0,16(sp)
    800060ae:	64a2                	ld	s1,8(sp)
    800060b0:	6902                	ld	s2,0(sp)
    800060b2:	6105                	addi	sp,sp,32
    800060b4:	8082                	ret
    panic("could not find virtio disk");
    800060b6:	00002517          	auipc	a0,0x2
    800060ba:	69250513          	addi	a0,a0,1682 # 80008748 <etext+0x748>
    800060be:	f66fa0ef          	jal	80000824 <panic>
    panic("virtio disk FEATURES_OK unset");
    800060c2:	00002517          	auipc	a0,0x2
    800060c6:	6a650513          	addi	a0,a0,1702 # 80008768 <etext+0x768>
    800060ca:	f5afa0ef          	jal	80000824 <panic>
    panic("virtio disk should not be ready");
    800060ce:	00002517          	auipc	a0,0x2
    800060d2:	6ba50513          	addi	a0,a0,1722 # 80008788 <etext+0x788>
    800060d6:	f4efa0ef          	jal	80000824 <panic>
    panic("virtio disk has no queue 0");
    800060da:	00002517          	auipc	a0,0x2
    800060de:	6ce50513          	addi	a0,a0,1742 # 800087a8 <etext+0x7a8>
    800060e2:	f42fa0ef          	jal	80000824 <panic>
    panic("virtio disk max queue too short");
    800060e6:	00002517          	auipc	a0,0x2
    800060ea:	6e250513          	addi	a0,a0,1762 # 800087c8 <etext+0x7c8>
    800060ee:	f36fa0ef          	jal	80000824 <panic>
    panic("virtio disk kalloc");
    800060f2:	00002517          	auipc	a0,0x2
    800060f6:	6f650513          	addi	a0,a0,1782 # 800087e8 <etext+0x7e8>
    800060fa:	f2afa0ef          	jal	80000824 <panic>

00000000800060fe <virtio_disk_rw>:
  return 0;
}

void
virtio_disk_rw(struct buf *b, int write)
{
    800060fe:	711d                	addi	sp,sp,-96
    80006100:	ec86                	sd	ra,88(sp)
    80006102:	e8a2                	sd	s0,80(sp)
    80006104:	e4a6                	sd	s1,72(sp)
    80006106:	e0ca                	sd	s2,64(sp)
    80006108:	fc4e                	sd	s3,56(sp)
    8000610a:	f852                	sd	s4,48(sp)
    8000610c:	f456                	sd	s5,40(sp)
    8000610e:	f05a                	sd	s6,32(sp)
    80006110:	ec5e                	sd	s7,24(sp)
    80006112:	e862                	sd	s8,16(sp)
    80006114:	1080                	addi	s0,sp,96
    80006116:	89aa                	mv	s3,a0
    80006118:	8b2e                	mv	s6,a1
  uint64 sector = b->blockno * (BSIZE / 512);
    8000611a:	00c52b83          	lw	s7,12(a0)
    8000611e:	001b9b9b          	slliw	s7,s7,0x1
    80006122:	1b82                	slli	s7,s7,0x20
    80006124:	020bdb93          	srli	s7,s7,0x20

  acquire(&disk.vdisk_lock);
    80006128:	00259517          	auipc	a0,0x259
    8000612c:	02850513          	addi	a0,a0,40 # 8025f150 <disk+0x128>
    80006130:	cedfa0ef          	jal	80000e1c <acquire>
  for(int i = 0; i < NUM; i++){
    80006134:	44a1                	li	s1,8
      disk.free[i] = 0;
    80006136:	00259a97          	auipc	s5,0x259
    8000613a:	ef2a8a93          	addi	s5,s5,-270 # 8025f028 <disk>
  for(int i = 0; i < 3; i++){
    8000613e:	4a0d                	li	s4,3
    idx[i] = alloc_desc();
    80006140:	5c7d                	li	s8,-1
    80006142:	a095                	j	800061a6 <virtio_disk_rw+0xa8>
      disk.free[i] = 0;
    80006144:	00fa8733          	add	a4,s5,a5
    80006148:	00070c23          	sb	zero,24(a4)
    idx[i] = alloc_desc();
    8000614c:	c19c                	sw	a5,0(a1)
    if(idx[i] < 0){
    8000614e:	0207c563          	bltz	a5,80006178 <virtio_disk_rw+0x7a>
  for(int i = 0; i < 3; i++){
    80006152:	2905                	addiw	s2,s2,1
    80006154:	0611                	addi	a2,a2,4 # 1004 <_entry-0x7fffeffc>
    80006156:	05490c63          	beq	s2,s4,800061ae <virtio_disk_rw+0xb0>
    idx[i] = alloc_desc();
    8000615a:	85b2                	mv	a1,a2
  for(int i = 0; i < NUM; i++){
    8000615c:	00259717          	auipc	a4,0x259
    80006160:	ecc70713          	addi	a4,a4,-308 # 8025f028 <disk>
    80006164:	4781                	li	a5,0
    if(disk.free[i]){
    80006166:	01874683          	lbu	a3,24(a4)
    8000616a:	fee9                	bnez	a3,80006144 <virtio_disk_rw+0x46>
  for(int i = 0; i < NUM; i++){
    8000616c:	2785                	addiw	a5,a5,1
    8000616e:	0705                	addi	a4,a4,1
    80006170:	fe979be3          	bne	a5,s1,80006166 <virtio_disk_rw+0x68>
    idx[i] = alloc_desc();
    80006174:	0185a023          	sw	s8,0(a1)
      for(int j = 0; j < i; j++)
    80006178:	01205d63          	blez	s2,80006192 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    8000617c:	fa042503          	lw	a0,-96(s0)
    80006180:	d41ff0ef          	jal	80005ec0 <free_desc>
      for(int j = 0; j < i; j++)
    80006184:	4785                	li	a5,1
    80006186:	0127d663          	bge	a5,s2,80006192 <virtio_disk_rw+0x94>
        free_desc(idx[j]);
    8000618a:	fa442503          	lw	a0,-92(s0)
    8000618e:	d33ff0ef          	jal	80005ec0 <free_desc>
  int idx[3];
  while(1){
    if(alloc3_desc(idx) == 0) {
      break;
    }
    sleep(&disk.free[0], &disk.vdisk_lock);
    80006192:	00259597          	auipc	a1,0x259
    80006196:	fbe58593          	addi	a1,a1,-66 # 8025f150 <disk+0x128>
    8000619a:	00259517          	auipc	a0,0x259
    8000619e:	ea650513          	addi	a0,a0,-346 # 8025f040 <disk+0x18>
    800061a2:	f8dfb0ef          	jal	8000212e <sleep>
  for(int i = 0; i < 3; i++){
    800061a6:	fa040613          	addi	a2,s0,-96
    800061aa:	4901                	li	s2,0
    800061ac:	b77d                	j	8000615a <virtio_disk_rw+0x5c>
  }

  // format the three descriptors.
  // qemu's virtio-blk.c reads them.

  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800061ae:	fa042503          	lw	a0,-96(s0)
    800061b2:	00451693          	slli	a3,a0,0x4

  if(write)
    800061b6:	00259797          	auipc	a5,0x259
    800061ba:	e7278793          	addi	a5,a5,-398 # 8025f028 <disk>
    800061be:	00451713          	slli	a4,a0,0x4
    800061c2:	0a070713          	addi	a4,a4,160
    800061c6:	973e                	add	a4,a4,a5
    800061c8:	01603633          	snez	a2,s6
    800061cc:	c710                	sw	a2,8(a4)
    buf0->type = VIRTIO_BLK_T_OUT; // write the disk
  else
    buf0->type = VIRTIO_BLK_T_IN; // read the disk
  buf0->reserved = 0;
    800061ce:	00072623          	sw	zero,12(a4)
  buf0->sector = sector;
    800061d2:	01773823          	sd	s7,16(a4)

  disk.desc[idx[0]].addr = (uint64) buf0;
    800061d6:	6398                	ld	a4,0(a5)
    800061d8:	9736                	add	a4,a4,a3
  struct virtio_blk_req *buf0 = &disk.ops[idx[0]];
    800061da:	0a868613          	addi	a2,a3,168 # 100010a8 <_entry-0x6fffef58>
    800061de:	963e                	add	a2,a2,a5
  disk.desc[idx[0]].addr = (uint64) buf0;
    800061e0:	e310                	sd	a2,0(a4)
  disk.desc[idx[0]].len = sizeof(struct virtio_blk_req);
    800061e2:	6390                	ld	a2,0(a5)
    800061e4:	00d60833          	add	a6,a2,a3
    800061e8:	4741                	li	a4,16
    800061ea:	00e82423          	sw	a4,8(a6)
  disk.desc[idx[0]].flags = VRING_DESC_F_NEXT;
    800061ee:	4585                	li	a1,1
    800061f0:	00b81623          	sh	a1,12(a6)
  disk.desc[idx[0]].next = idx[1];
    800061f4:	fa442703          	lw	a4,-92(s0)
    800061f8:	00e81723          	sh	a4,14(a6)

  disk.desc[idx[1]].addr = (uint64) b->data;
    800061fc:	0712                	slli	a4,a4,0x4
    800061fe:	963a                	add	a2,a2,a4
    80006200:	05898813          	addi	a6,s3,88
    80006204:	01063023          	sd	a6,0(a2)
  disk.desc[idx[1]].len = BSIZE;
    80006208:	0007b883          	ld	a7,0(a5)
    8000620c:	9746                	add	a4,a4,a7
    8000620e:	40000613          	li	a2,1024
    80006212:	c710                	sw	a2,8(a4)
  if(write)
    80006214:	001b3613          	seqz	a2,s6
    80006218:	0016161b          	slliw	a2,a2,0x1
    disk.desc[idx[1]].flags = 0; // device reads b->data
  else
    disk.desc[idx[1]].flags = VRING_DESC_F_WRITE; // device writes b->data
  disk.desc[idx[1]].flags |= VRING_DESC_F_NEXT;
    8000621c:	8e4d                	or	a2,a2,a1
    8000621e:	00c71623          	sh	a2,12(a4)
  disk.desc[idx[1]].next = idx[2];
    80006222:	fa842603          	lw	a2,-88(s0)
    80006226:	00c71723          	sh	a2,14(a4)

  disk.info[idx[0]].status = 0xff; // device writes 0 on success
    8000622a:	00451813          	slli	a6,a0,0x4
    8000622e:	02080813          	addi	a6,a6,32
    80006232:	983e                	add	a6,a6,a5
    80006234:	577d                	li	a4,-1
    80006236:	00e80823          	sb	a4,16(a6)
  disk.desc[idx[2]].addr = (uint64) &disk.info[idx[0]].status;
    8000623a:	0612                	slli	a2,a2,0x4
    8000623c:	98b2                	add	a7,a7,a2
    8000623e:	03068713          	addi	a4,a3,48
    80006242:	973e                	add	a4,a4,a5
    80006244:	00e8b023          	sd	a4,0(a7)
  disk.desc[idx[2]].len = 1;
    80006248:	6398                	ld	a4,0(a5)
    8000624a:	9732                	add	a4,a4,a2
    8000624c:	c70c                	sw	a1,8(a4)
  disk.desc[idx[2]].flags = VRING_DESC_F_WRITE; // device writes the status
    8000624e:	4689                	li	a3,2
    80006250:	00d71623          	sh	a3,12(a4)
  disk.desc[idx[2]].next = 0;
    80006254:	00071723          	sh	zero,14(a4)

  // record struct buf for virtio_disk_intr().
  b->disk = 1;
    80006258:	00b9a223          	sw	a1,4(s3)
  disk.info[idx[0]].b = b;
    8000625c:	01383423          	sd	s3,8(a6)

  // tell the device the first index in our chain of descriptors.
  disk.avail->ring[disk.avail->idx % NUM] = idx[0];
    80006260:	6794                	ld	a3,8(a5)
    80006262:	0026d703          	lhu	a4,2(a3)
    80006266:	8b1d                	andi	a4,a4,7
    80006268:	0706                	slli	a4,a4,0x1
    8000626a:	96ba                	add	a3,a3,a4
    8000626c:	00a69223          	sh	a0,4(a3)

  __sync_synchronize();
    80006270:	0330000f          	fence	rw,rw

  // tell the device another avail ring entry is available.
  disk.avail->idx += 1; // not % NUM ...
    80006274:	6798                	ld	a4,8(a5)
    80006276:	00275783          	lhu	a5,2(a4)
    8000627a:	2785                	addiw	a5,a5,1
    8000627c:	00f71123          	sh	a5,2(a4)

  __sync_synchronize();
    80006280:	0330000f          	fence	rw,rw

  *R(VIRTIO_MMIO_QUEUE_NOTIFY) = 0; // value is queue number
    80006284:	100017b7          	lui	a5,0x10001
    80006288:	0407a823          	sw	zero,80(a5) # 10001050 <_entry-0x6fffefb0>

  // Wait for virtio_disk_intr() to say request has finished.
  while(b->disk == 1) {
    8000628c:	0049a783          	lw	a5,4(s3)
    sleep(b, &disk.vdisk_lock);
    80006290:	00259917          	auipc	s2,0x259
    80006294:	ec090913          	addi	s2,s2,-320 # 8025f150 <disk+0x128>
  while(b->disk == 1) {
    80006298:	84ae                	mv	s1,a1
    8000629a:	00b79a63          	bne	a5,a1,800062ae <virtio_disk_rw+0x1b0>
    sleep(b, &disk.vdisk_lock);
    8000629e:	85ca                	mv	a1,s2
    800062a0:	854e                	mv	a0,s3
    800062a2:	e8dfb0ef          	jal	8000212e <sleep>
  while(b->disk == 1) {
    800062a6:	0049a783          	lw	a5,4(s3)
    800062aa:	fe978ae3          	beq	a5,s1,8000629e <virtio_disk_rw+0x1a0>
  }

  disk.info[idx[0]].b = 0;
    800062ae:	fa042903          	lw	s2,-96(s0)
    800062b2:	00491713          	slli	a4,s2,0x4
    800062b6:	02070713          	addi	a4,a4,32
    800062ba:	00259797          	auipc	a5,0x259
    800062be:	d6e78793          	addi	a5,a5,-658 # 8025f028 <disk>
    800062c2:	97ba                	add	a5,a5,a4
    800062c4:	0007b423          	sd	zero,8(a5)
    int flag = disk.desc[i].flags;
    800062c8:	00259997          	auipc	s3,0x259
    800062cc:	d6098993          	addi	s3,s3,-672 # 8025f028 <disk>
    800062d0:	00491713          	slli	a4,s2,0x4
    800062d4:	0009b783          	ld	a5,0(s3)
    800062d8:	97ba                	add	a5,a5,a4
    800062da:	00c7d483          	lhu	s1,12(a5)
    int nxt = disk.desc[i].next;
    800062de:	854a                	mv	a0,s2
    800062e0:	00e7d903          	lhu	s2,14(a5)
    free_desc(i);
    800062e4:	bddff0ef          	jal	80005ec0 <free_desc>
    if(flag & VRING_DESC_F_NEXT)
    800062e8:	8885                	andi	s1,s1,1
    800062ea:	f0fd                	bnez	s1,800062d0 <virtio_disk_rw+0x1d2>
  free_chain(idx[0]);

  release(&disk.vdisk_lock);
    800062ec:	00259517          	auipc	a0,0x259
    800062f0:	e6450513          	addi	a0,a0,-412 # 8025f150 <disk+0x128>
    800062f4:	bbdfa0ef          	jal	80000eb0 <release>
}
    800062f8:	60e6                	ld	ra,88(sp)
    800062fa:	6446                	ld	s0,80(sp)
    800062fc:	64a6                	ld	s1,72(sp)
    800062fe:	6906                	ld	s2,64(sp)
    80006300:	79e2                	ld	s3,56(sp)
    80006302:	7a42                	ld	s4,48(sp)
    80006304:	7aa2                	ld	s5,40(sp)
    80006306:	7b02                	ld	s6,32(sp)
    80006308:	6be2                	ld	s7,24(sp)
    8000630a:	6c42                	ld	s8,16(sp)
    8000630c:	6125                	addi	sp,sp,96
    8000630e:	8082                	ret

0000000080006310 <virtio_disk_intr>:

void
virtio_disk_intr()
{
    80006310:	1101                	addi	sp,sp,-32
    80006312:	ec06                	sd	ra,24(sp)
    80006314:	e822                	sd	s0,16(sp)
    80006316:	e426                	sd	s1,8(sp)
    80006318:	1000                	addi	s0,sp,32
  acquire(&disk.vdisk_lock);
    8000631a:	00259497          	auipc	s1,0x259
    8000631e:	d0e48493          	addi	s1,s1,-754 # 8025f028 <disk>
    80006322:	00259517          	auipc	a0,0x259
    80006326:	e2e50513          	addi	a0,a0,-466 # 8025f150 <disk+0x128>
    8000632a:	af3fa0ef          	jal	80000e1c <acquire>
  // we've seen this interrupt, which the following line does.
  // this may race with the device writing new entries to
  // the "used" ring, in which case we may process the new
  // completion entries in this interrupt, and have nothing to do
  // in the next interrupt, which is harmless.
  *R(VIRTIO_MMIO_INTERRUPT_ACK) = *R(VIRTIO_MMIO_INTERRUPT_STATUS) & 0x3;
    8000632e:	100017b7          	lui	a5,0x10001
    80006332:	53bc                	lw	a5,96(a5)
    80006334:	8b8d                	andi	a5,a5,3
    80006336:	10001737          	lui	a4,0x10001
    8000633a:	d37c                	sw	a5,100(a4)

  __sync_synchronize();
    8000633c:	0330000f          	fence	rw,rw

  // the device increments disk.used->idx when it
  // adds an entry to the used ring.

  while(disk.used_idx != disk.used->idx){
    80006340:	689c                	ld	a5,16(s1)
    80006342:	0204d703          	lhu	a4,32(s1)
    80006346:	0027d783          	lhu	a5,2(a5) # 10001002 <_entry-0x6fffeffe>
    8000634a:	04f70863          	beq	a4,a5,8000639a <virtio_disk_intr+0x8a>
    __sync_synchronize();
    8000634e:	0330000f          	fence	rw,rw
    int id = disk.used->ring[disk.used_idx % NUM].id;
    80006352:	6898                	ld	a4,16(s1)
    80006354:	0204d783          	lhu	a5,32(s1)
    80006358:	8b9d                	andi	a5,a5,7
    8000635a:	078e                	slli	a5,a5,0x3
    8000635c:	97ba                	add	a5,a5,a4
    8000635e:	43dc                	lw	a5,4(a5)

    if(disk.info[id].status != 0)
    80006360:	00479713          	slli	a4,a5,0x4
    80006364:	02070713          	addi	a4,a4,32 # 10001020 <_entry-0x6fffefe0>
    80006368:	9726                	add	a4,a4,s1
    8000636a:	01074703          	lbu	a4,16(a4)
    8000636e:	e329                	bnez	a4,800063b0 <virtio_disk_intr+0xa0>
      panic("virtio_disk_intr status");

    struct buf *b = disk.info[id].b;
    80006370:	0792                	slli	a5,a5,0x4
    80006372:	02078793          	addi	a5,a5,32
    80006376:	97a6                	add	a5,a5,s1
    80006378:	6788                	ld	a0,8(a5)
    b->disk = 0;   // disk is done with buf
    8000637a:	00052223          	sw	zero,4(a0)
    wakeup(b);
    8000637e:	dfdfb0ef          	jal	8000217a <wakeup>

    disk.used_idx += 1;
    80006382:	0204d783          	lhu	a5,32(s1)
    80006386:	2785                	addiw	a5,a5,1
    80006388:	17c2                	slli	a5,a5,0x30
    8000638a:	93c1                	srli	a5,a5,0x30
    8000638c:	02f49023          	sh	a5,32(s1)
  while(disk.used_idx != disk.used->idx){
    80006390:	6898                	ld	a4,16(s1)
    80006392:	00275703          	lhu	a4,2(a4)
    80006396:	faf71ce3          	bne	a4,a5,8000634e <virtio_disk_intr+0x3e>
  }

  release(&disk.vdisk_lock);
    8000639a:	00259517          	auipc	a0,0x259
    8000639e:	db650513          	addi	a0,a0,-586 # 8025f150 <disk+0x128>
    800063a2:	b0ffa0ef          	jal	80000eb0 <release>
}
    800063a6:	60e2                	ld	ra,24(sp)
    800063a8:	6442                	ld	s0,16(sp)
    800063aa:	64a2                	ld	s1,8(sp)
    800063ac:	6105                	addi	sp,sp,32
    800063ae:	8082                	ret
      panic("virtio_disk_intr status");
    800063b0:	00002517          	auipc	a0,0x2
    800063b4:	45050513          	addi	a0,a0,1104 # 80008800 <etext+0x800>
    800063b8:	c6cfa0ef          	jal	80000824 <panic>
	...

0000000080007000 <_trampoline>:
    80007000:	14051073          	csrw	sscratch,a0
    80007004:	02000537          	lui	a0,0x2000
    80007008:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    8000700a:	0536                	slli	a0,a0,0xd
    8000700c:	02153423          	sd	ra,40(a0)
    80007010:	02253823          	sd	sp,48(a0)
    80007014:	02353c23          	sd	gp,56(a0)
    80007018:	04453023          	sd	tp,64(a0)
    8000701c:	04553423          	sd	t0,72(a0)
    80007020:	04653823          	sd	t1,80(a0)
    80007024:	04753c23          	sd	t2,88(a0)
    80007028:	f120                	sd	s0,96(a0)
    8000702a:	f524                	sd	s1,104(a0)
    8000702c:	fd2c                	sd	a1,120(a0)
    8000702e:	e150                	sd	a2,128(a0)
    80007030:	e554                	sd	a3,136(a0)
    80007032:	e958                	sd	a4,144(a0)
    80007034:	ed5c                	sd	a5,152(a0)
    80007036:	0b053023          	sd	a6,160(a0)
    8000703a:	0b153423          	sd	a7,168(a0)
    8000703e:	0b253823          	sd	s2,176(a0)
    80007042:	0b353c23          	sd	s3,184(a0)
    80007046:	0d453023          	sd	s4,192(a0)
    8000704a:	0d553423          	sd	s5,200(a0)
    8000704e:	0d653823          	sd	s6,208(a0)
    80007052:	0d753c23          	sd	s7,216(a0)
    80007056:	0f853023          	sd	s8,224(a0)
    8000705a:	0f953423          	sd	s9,232(a0)
    8000705e:	0fa53823          	sd	s10,240(a0)
    80007062:	0fb53c23          	sd	s11,248(a0)
    80007066:	11c53023          	sd	t3,256(a0)
    8000706a:	11d53423          	sd	t4,264(a0)
    8000706e:	11e53823          	sd	t5,272(a0)
    80007072:	11f53c23          	sd	t6,280(a0)
    80007076:	140022f3          	csrr	t0,sscratch
    8000707a:	06553823          	sd	t0,112(a0)
    8000707e:	00853103          	ld	sp,8(a0)
    80007082:	02053203          	ld	tp,32(a0)
    80007086:	01053283          	ld	t0,16(a0)
    8000708a:	00053303          	ld	t1,0(a0)
    8000708e:	12000073          	sfence.vma
    80007092:	18031073          	csrw	satp,t1
    80007096:	12000073          	sfence.vma
    8000709a:	9282                	jalr	t0

000000008000709c <userret>:
    8000709c:	12000073          	sfence.vma
    800070a0:	18051073          	csrw	satp,a0
    800070a4:	12000073          	sfence.vma
    800070a8:	02000537          	lui	a0,0x2000
    800070ac:	357d                	addiw	a0,a0,-1 # 1ffffff <_entry-0x7e000001>
    800070ae:	0536                	slli	a0,a0,0xd
    800070b0:	02853083          	ld	ra,40(a0)
    800070b4:	03053103          	ld	sp,48(a0)
    800070b8:	03853183          	ld	gp,56(a0)
    800070bc:	04053203          	ld	tp,64(a0)
    800070c0:	04853283          	ld	t0,72(a0)
    800070c4:	05053303          	ld	t1,80(a0)
    800070c8:	05853383          	ld	t2,88(a0)
    800070cc:	7120                	ld	s0,96(a0)
    800070ce:	7524                	ld	s1,104(a0)
    800070d0:	7d2c                	ld	a1,120(a0)
    800070d2:	6150                	ld	a2,128(a0)
    800070d4:	6554                	ld	a3,136(a0)
    800070d6:	6958                	ld	a4,144(a0)
    800070d8:	6d5c                	ld	a5,152(a0)
    800070da:	0a053803          	ld	a6,160(a0)
    800070de:	0a853883          	ld	a7,168(a0)
    800070e2:	0b053903          	ld	s2,176(a0)
    800070e6:	0b853983          	ld	s3,184(a0)
    800070ea:	0c053a03          	ld	s4,192(a0)
    800070ee:	0c853a83          	ld	s5,200(a0)
    800070f2:	0d053b03          	ld	s6,208(a0)
    800070f6:	0d853b83          	ld	s7,216(a0)
    800070fa:	0e053c03          	ld	s8,224(a0)
    800070fe:	0e853c83          	ld	s9,232(a0)
    80007102:	0f053d03          	ld	s10,240(a0)
    80007106:	0f853d83          	ld	s11,248(a0)
    8000710a:	10053e03          	ld	t3,256(a0)
    8000710e:	10853e83          	ld	t4,264(a0)
    80007112:	11053f03          	ld	t5,272(a0)
    80007116:	11853f83          	ld	t6,280(a0)
    8000711a:	7928                	ld	a0,112(a0)
    8000711c:	10200073          	sret
	...
