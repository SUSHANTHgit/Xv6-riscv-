kernel/main.o: kernel/main.c kernel/types.h kernel/param.h \
 kernel/memlayout.h kernel/riscv.h kernel/defs.h kernel/shm.h \
 kernel/spinlock.h kernel/mbox.h
