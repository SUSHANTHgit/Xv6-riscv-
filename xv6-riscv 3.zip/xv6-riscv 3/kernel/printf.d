kernel/printf.o: kernel/printf.c \
 /opt/homebrew/Cellar/riscv-gnu-toolchain/main/lib/gcc/riscv64-unknown-elf/15.1.0/include/stdarg.h \
 kernel/types.h kernel/param.h kernel/spinlock.h kernel/sleeplock.h \
 kernel/fs.h kernel/file.h kernel/memlayout.h kernel/riscv.h \
 kernel/defs.h kernel/proc.h kernel/constumprint.h
