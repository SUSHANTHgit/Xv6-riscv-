
user/_bigfile:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <write_bigfile>:
#define FILENAME "bigfile"
#define BLOCK_SIZE 1024  // Block size in xv6
#define NUM_BLOCKS 3000  // Number of blocks to write (exceeds single-indirect limit)
#define FILE_SIZE (BLOCK_SIZE * NUM_BLOCKS)

void write_bigfile() {
   0:	b9010113          	addi	sp,sp,-1136
   4:	46113423          	sd	ra,1128(sp)
   8:	46813023          	sd	s0,1120(sp)
   c:	44913c23          	sd	s1,1112(sp)
  10:	45213823          	sd	s2,1104(sp)
  14:	45313423          	sd	s3,1096(sp)
  18:	45413023          	sd	s4,1088(sp)
  1c:	43513c23          	sd	s5,1080(sp)
  20:	43613823          	sd	s6,1072(sp)
  24:	43713423          	sd	s7,1064(sp)
  28:	43813023          	sd	s8,1056(sp)
  2c:	41913c23          	sd	s9,1048(sp)
  30:	41a13823          	sd	s10,1040(sp)
  34:	41b13423          	sd	s11,1032(sp)
  38:	47010413          	addi	s0,sp,1136
  int fd = open(FILENAME, O_CREATE | O_WRONLY);
  3c:	20100593          	li	a1,513
  40:	00001517          	auipc	a0,0x1
  44:	bb050513          	addi	a0,a0,-1104 # bf0 <malloc+0xfa>
  48:	5b2000ef          	jal	5fa <open>
  if (fd < 0) {
  4c:	04054a63          	bltz	a0,a0 <write_bigfile+0xa0>
  50:	8aaa                	mv	s5,a0
    printf("bigfile: failed to create file %s\n", FILENAME);
    exit(1);
  }

  printf("bigfile: writing %d blocks (%d bytes) to %s...\n", NUM_BLOCKS, FILE_SIZE, FILENAME);
  52:	00001697          	auipc	a3,0x1
  56:	b9e68693          	addi	a3,a3,-1122 # bf0 <malloc+0xfa>
  5a:	002ee637          	lui	a2,0x2ee
  5e:	6585                	lui	a1,0x1
  60:	bb858593          	addi	a1,a1,-1096 # bb8 <malloc+0xc2>
  64:	00001517          	auipc	a0,0x1
  68:	bbc50513          	addi	a0,a0,-1092 # c20 <malloc+0x12a>
  6c:	1d3000ef          	jal	a3e <printf>

  char buffer[BLOCK_SIZE];
  for (int i = 0; i < NUM_BLOCKS; i++) {
  70:	b9040c13          	addi	s8,s0,-1136
  74:	418004bb          	negw	s1,s8
  78:	4981                	li	s3,0
  7a:	400c0913          	addi	s2,s8,1024
    for (int j = 0; j < BLOCK_SIZE; j++) {
      buffer[j] = (i + j) % 256;
    }

    // Write the buffer to the file
    if (write(fd, buffer, BLOCK_SIZE) != BLOCK_SIZE) {
  7e:	8d62                	mv	s10,s8
  80:	40000a13          	li	s4,1024
      close(fd);
      exit(1);
    }

    // Print progress every 500 blocks
    if (i % 500 == 0) {
  84:	10625bb7          	lui	s7,0x10625
  88:	dd3b8b93          	addi	s7,s7,-557 # 10624dd3 <base+0x10623dc3>
  8c:	1f400c93          	li	s9,500
      printf("bigfile: written %d/%d blocks\n", i, NUM_BLOCKS);
  90:	6b05                	lui	s6,0x1
  92:	bb8b0b13          	addi	s6,s6,-1096 # bb8 <malloc+0xc2>
  96:	00001d97          	auipc	s11,0x1
  9a:	be2d8d93          	addi	s11,s11,-1054 # c78 <malloc+0x182>
  9e:	a83d                	j	dc <write_bigfile+0xdc>
    printf("bigfile: failed to create file %s\n", FILENAME);
  a0:	00001597          	auipc	a1,0x1
  a4:	b5058593          	addi	a1,a1,-1200 # bf0 <malloc+0xfa>
  a8:	00001517          	auipc	a0,0x1
  ac:	b5050513          	addi	a0,a0,-1200 # bf8 <malloc+0x102>
  b0:	18f000ef          	jal	a3e <printf>
    exit(1);
  b4:	4505                	li	a0,1
  b6:	504000ef          	jal	5ba <exit>
      printf("bigfile: write failed at block %d\n", i);
  ba:	85ce                	mv	a1,s3
  bc:	00001517          	auipc	a0,0x1
  c0:	b9450513          	addi	a0,a0,-1132 # c50 <malloc+0x15a>
  c4:	17b000ef          	jal	a3e <printf>
      close(fd);
  c8:	8556                	mv	a0,s5
  ca:	518000ef          	jal	5e2 <close>
      exit(1);
  ce:	4505                	li	a0,1
  d0:	4ea000ef          	jal	5ba <exit>
  for (int i = 0; i < NUM_BLOCKS; i++) {
  d4:	2985                	addiw	s3,s3,1
  d6:	2485                	addiw	s1,s1,1
  d8:	05698263          	beq	s3,s6,11c <write_bigfile+0x11c>
void write_bigfile() {
  dc:	87e2                	mv	a5,s8
      buffer[j] = (i + j) % 256;
  de:	0097873b          	addw	a4,a5,s1
  e2:	00e78023          	sb	a4,0(a5)
    for (int j = 0; j < BLOCK_SIZE; j++) {
  e6:	0785                	addi	a5,a5,1
  e8:	ff279be3          	bne	a5,s2,de <write_bigfile+0xde>
    if (write(fd, buffer, BLOCK_SIZE) != BLOCK_SIZE) {
  ec:	8652                	mv	a2,s4
  ee:	85ea                	mv	a1,s10
  f0:	8556                	mv	a0,s5
  f2:	4e8000ef          	jal	5da <write>
  f6:	fd4512e3          	bne	a0,s4,ba <write_bigfile+0xba>
    if (i % 500 == 0) {
  fa:	037987b3          	mul	a5,s3,s7
  fe:	9795                	srai	a5,a5,0x25
 100:	41f9d71b          	sraiw	a4,s3,0x1f
 104:	9f99                	subw	a5,a5,a4
 106:	02fc87bb          	mulw	a5,s9,a5
 10a:	40f987bb          	subw	a5,s3,a5
 10e:	f3f9                	bnez	a5,d4 <write_bigfile+0xd4>
      printf("bigfile: written %d/%d blocks\n", i, NUM_BLOCKS);
 110:	865a                	mv	a2,s6
 112:	85ce                	mv	a1,s3
 114:	856e                	mv	a0,s11
 116:	129000ef          	jal	a3e <printf>
 11a:	bf6d                	j	d4 <write_bigfile+0xd4>
    }
  }

  printf("bigfile: successfully wrote %d blocks\n", NUM_BLOCKS);
 11c:	6585                	lui	a1,0x1
 11e:	bb858593          	addi	a1,a1,-1096 # bb8 <malloc+0xc2>
 122:	00001517          	auipc	a0,0x1
 126:	b7650513          	addi	a0,a0,-1162 # c98 <malloc+0x1a2>
 12a:	115000ef          	jal	a3e <printf>
  close(fd);
 12e:	8556                	mv	a0,s5
 130:	4b2000ef          	jal	5e2 <close>
}
 134:	46813083          	ld	ra,1128(sp)
 138:	46013403          	ld	s0,1120(sp)
 13c:	45813483          	ld	s1,1112(sp)
 140:	45013903          	ld	s2,1104(sp)
 144:	44813983          	ld	s3,1096(sp)
 148:	44013a03          	ld	s4,1088(sp)
 14c:	43813a83          	ld	s5,1080(sp)
 150:	43013b03          	ld	s6,1072(sp)
 154:	42813b83          	ld	s7,1064(sp)
 158:	42013c03          	ld	s8,1056(sp)
 15c:	41813c83          	ld	s9,1048(sp)
 160:	41013d03          	ld	s10,1040(sp)
 164:	40813d83          	ld	s11,1032(sp)
 168:	47010113          	addi	sp,sp,1136
 16c:	8082                	ret

000000000000016e <verify_bigfile>:

void verify_bigfile() {
 16e:	7119                	addi	sp,sp,-128
 170:	fc86                	sd	ra,120(sp)
 172:	f8a2                	sd	s0,112(sp)
 174:	f4a6                	sd	s1,104(sp)
 176:	f0ca                	sd	s2,96(sp)
 178:	ecce                	sd	s3,88(sp)
 17a:	e8d2                	sd	s4,80(sp)
 17c:	e4d6                	sd	s5,72(sp)
 17e:	e0da                	sd	s6,64(sp)
 180:	fc5e                	sd	s7,56(sp)
 182:	f862                	sd	s8,48(sp)
 184:	f466                	sd	s9,40(sp)
 186:	f06a                	sd	s10,32(sp)
 188:	ec6e                	sd	s11,24(sp)
 18a:	0100                	addi	s0,sp,128
 18c:	81010113          	addi	sp,sp,-2032
  int fd = open(FILENAME, O_RDONLY);
 190:	4581                	li	a1,0
 192:	00001517          	auipc	a0,0x1
 196:	a5e50513          	addi	a0,a0,-1442 # bf0 <malloc+0xfa>
 19a:	460000ef          	jal	5fa <open>
  if (fd < 0) {
 19e:	04054a63          	bltz	a0,1f2 <verify_bigfile+0x84>
 1a2:	8b2a                	mv	s6,a0
    printf("bigfile: failed to open file %s for reading\n", FILENAME);
    exit(1);
  }

  printf("bigfile: verifying %d blocks (%d bytes) in %s...\n", NUM_BLOCKS, FILE_SIZE, FILENAME);
 1a4:	00001697          	auipc	a3,0x1
 1a8:	a4c68693          	addi	a3,a3,-1460 # bf0 <malloc+0xfa>
 1ac:	002ee637          	lui	a2,0x2ee
 1b0:	6585                	lui	a1,0x1
 1b2:	bb858593          	addi	a1,a1,-1096 # bb8 <malloc+0xc2>
 1b6:	00001517          	auipc	a0,0x1
 1ba:	b3a50513          	addi	a0,a0,-1222 # cf0 <malloc+0x1fa>
 1be:	081000ef          	jal	a3e <printf>

  char buffer[BLOCK_SIZE];
  char expected[BLOCK_SIZE];
  for (int i = 0; i < NUM_BLOCKS; i++) {
 1c2:	80040c93          	addi	s9,s0,-2048
 1c6:	f90c8c93          	addi	s9,s9,-112
 1ca:	419004bb          	negw	s1,s9
 1ce:	4981                	li	s3,0
 1d0:	400c8913          	addi	s2,s9,1024
    for (int j = 0; j < BLOCK_SIZE; j++) {
      expected[j] = (i + j) % 256;
    }

    // Read a block from the file
    if (read(fd, buffer, BLOCK_SIZE) != BLOCK_SIZE) {
 1d4:	b9040a93          	addi	s5,s0,-1136
 1d8:	40000a13          	li	s4,1024
      close(fd);
      exit(1);
    }

    // Verify the block's contents
    if (memcmp(buffer, expected, BLOCK_SIZE) != 0) {
 1dc:	8de6                	mv	s11,s9
      close(fd);
      exit(1);
    }

    // Print progress every 500 blocks
    if (i % 500 == 0) {
 1de:	10625c37          	lui	s8,0x10625
 1e2:	dd3c0c13          	addi	s8,s8,-557 # 10624dd3 <base+0x10623dc3>
 1e6:	1f400d13          	li	s10,500
      printf("bigfile: verified %d/%d blocks\n", i, NUM_BLOCKS);
 1ea:	6b85                	lui	s7,0x1
 1ec:	bb8b8b93          	addi	s7,s7,-1096 # bb8 <malloc+0xc2>
 1f0:	a8a1                	j	248 <verify_bigfile+0xda>
    printf("bigfile: failed to open file %s for reading\n", FILENAME);
 1f2:	00001597          	auipc	a1,0x1
 1f6:	9fe58593          	addi	a1,a1,-1538 # bf0 <malloc+0xfa>
 1fa:	00001517          	auipc	a0,0x1
 1fe:	ac650513          	addi	a0,a0,-1338 # cc0 <malloc+0x1ca>
 202:	03d000ef          	jal	a3e <printf>
    exit(1);
 206:	4505                	li	a0,1
 208:	3b2000ef          	jal	5ba <exit>
      printf("bigfile: read failed at block %d\n", i);
 20c:	85ce                	mv	a1,s3
 20e:	00001517          	auipc	a0,0x1
 212:	b1a50513          	addi	a0,a0,-1254 # d28 <malloc+0x232>
 216:	029000ef          	jal	a3e <printf>
      close(fd);
 21a:	855a                	mv	a0,s6
 21c:	3c6000ef          	jal	5e2 <close>
      exit(1);
 220:	4505                	li	a0,1
 222:	398000ef          	jal	5ba <exit>
      printf("bigfile: data mismatch at block %d\n", i);
 226:	85ce                	mv	a1,s3
 228:	00001517          	auipc	a0,0x1
 22c:	b2850513          	addi	a0,a0,-1240 # d50 <malloc+0x25a>
 230:	00f000ef          	jal	a3e <printf>
      close(fd);
 234:	855a                	mv	a0,s6
 236:	3ac000ef          	jal	5e2 <close>
      exit(1);
 23a:	4505                	li	a0,1
 23c:	37e000ef          	jal	5ba <exit>
  for (int i = 0; i < NUM_BLOCKS; i++) {
 240:	2985                	addiw	s3,s3,1
 242:	2485                	addiw	s1,s1,1
 244:	05798b63          	beq	s3,s7,29a <verify_bigfile+0x12c>
void verify_bigfile() {
 248:	87e6                	mv	a5,s9
      expected[j] = (i + j) % 256;
 24a:	0097873b          	addw	a4,a5,s1
 24e:	00e78023          	sb	a4,0(a5)
    for (int j = 0; j < BLOCK_SIZE; j++) {
 252:	0785                	addi	a5,a5,1
 254:	ff279be3          	bne	a5,s2,24a <verify_bigfile+0xdc>
    if (read(fd, buffer, BLOCK_SIZE) != BLOCK_SIZE) {
 258:	8652                	mv	a2,s4
 25a:	85d6                	mv	a1,s5
 25c:	855a                	mv	a0,s6
 25e:	374000ef          	jal	5d2 <read>
 262:	fb4515e3          	bne	a0,s4,20c <verify_bigfile+0x9e>
    if (memcmp(buffer, expected, BLOCK_SIZE) != 0) {
 266:	8652                	mv	a2,s4
 268:	85ee                	mv	a1,s11
 26a:	8556                	mv	a0,s5
 26c:	2cc000ef          	jal	538 <memcmp>
 270:	f95d                	bnez	a0,226 <verify_bigfile+0xb8>
    if (i % 500 == 0) {
 272:	038987b3          	mul	a5,s3,s8
 276:	9795                	srai	a5,a5,0x25
 278:	41f9d71b          	sraiw	a4,s3,0x1f
 27c:	9f99                	subw	a5,a5,a4
 27e:	02fd07bb          	mulw	a5,s10,a5
 282:	40f987bb          	subw	a5,s3,a5
 286:	ffcd                	bnez	a5,240 <verify_bigfile+0xd2>
      printf("bigfile: verified %d/%d blocks\n", i, NUM_BLOCKS);
 288:	865e                	mv	a2,s7
 28a:	85ce                	mv	a1,s3
 28c:	00001517          	auipc	a0,0x1
 290:	aec50513          	addi	a0,a0,-1300 # d78 <malloc+0x282>
 294:	7aa000ef          	jal	a3e <printf>
 298:	b765                	j	240 <verify_bigfile+0xd2>
    }
  }

  printf("bigfile: successfully verified %d blocks\n", NUM_BLOCKS);
 29a:	6585                	lui	a1,0x1
 29c:	bb858593          	addi	a1,a1,-1096 # bb8 <malloc+0xc2>
 2a0:	00001517          	auipc	a0,0x1
 2a4:	af850513          	addi	a0,a0,-1288 # d98 <malloc+0x2a2>
 2a8:	796000ef          	jal	a3e <printf>
  close(fd);
 2ac:	855a                	mv	a0,s6
 2ae:	334000ef          	jal	5e2 <close>
}
 2b2:	7f010113          	addi	sp,sp,2032
 2b6:	70e6                	ld	ra,120(sp)
 2b8:	7446                	ld	s0,112(sp)
 2ba:	74a6                	ld	s1,104(sp)
 2bc:	7906                	ld	s2,96(sp)
 2be:	69e6                	ld	s3,88(sp)
 2c0:	6a46                	ld	s4,80(sp)
 2c2:	6aa6                	ld	s5,72(sp)
 2c4:	6b06                	ld	s6,64(sp)
 2c6:	7be2                	ld	s7,56(sp)
 2c8:	7c42                	ld	s8,48(sp)
 2ca:	7ca2                	ld	s9,40(sp)
 2cc:	7d02                	ld	s10,32(sp)
 2ce:	6de2                	ld	s11,24(sp)
 2d0:	6109                	addi	sp,sp,128
 2d2:	8082                	ret

00000000000002d4 <main>:

int main(void) {
 2d4:	1141                	addi	sp,sp,-16
 2d6:	e406                	sd	ra,8(sp)
 2d8:	e022                	sd	s0,0(sp)
 2da:	0800                	addi	s0,sp,16
  printf("bigfile: starting test\n");
 2dc:	00001517          	auipc	a0,0x1
 2e0:	aec50513          	addi	a0,a0,-1300 # dc8 <malloc+0x2d2>
 2e4:	75a000ef          	jal	a3e <printf>

  // Step 1: Write a large file
  write_bigfile();
 2e8:	d19ff0ef          	jal	0 <write_bigfile>

  // Step 2: Verify the file's contents
  verify_bigfile();
 2ec:	e83ff0ef          	jal	16e <verify_bigfile>

  printf("bigfile: test completed successfully\n");
 2f0:	00001517          	auipc	a0,0x1
 2f4:	af050513          	addi	a0,a0,-1296 # de0 <malloc+0x2ea>
 2f8:	746000ef          	jal	a3e <printf>
  exit(0);
 2fc:	4501                	li	a0,0
 2fe:	2bc000ef          	jal	5ba <exit>

0000000000000302 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 302:	1141                	addi	sp,sp,-16
 304:	e406                	sd	ra,8(sp)
 306:	e022                	sd	s0,0(sp)
 308:	0800                	addi	s0,sp,16
  extern int main();
  main();
 30a:	fcbff0ef          	jal	2d4 <main>
  exit(0);
 30e:	4501                	li	a0,0
 310:	2aa000ef          	jal	5ba <exit>

0000000000000314 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 314:	1141                	addi	sp,sp,-16
 316:	e406                	sd	ra,8(sp)
 318:	e022                	sd	s0,0(sp)
 31a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 31c:	87aa                	mv	a5,a0
 31e:	0585                	addi	a1,a1,1
 320:	0785                	addi	a5,a5,1
 322:	fff5c703          	lbu	a4,-1(a1)
 326:	fee78fa3          	sb	a4,-1(a5)
 32a:	fb75                	bnez	a4,31e <strcpy+0xa>
    ;
  return os;
}
 32c:	60a2                	ld	ra,8(sp)
 32e:	6402                	ld	s0,0(sp)
 330:	0141                	addi	sp,sp,16
 332:	8082                	ret

0000000000000334 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 334:	1141                	addi	sp,sp,-16
 336:	e406                	sd	ra,8(sp)
 338:	e022                	sd	s0,0(sp)
 33a:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 33c:	00054783          	lbu	a5,0(a0)
 340:	cb91                	beqz	a5,354 <strcmp+0x20>
 342:	0005c703          	lbu	a4,0(a1)
 346:	00f71763          	bne	a4,a5,354 <strcmp+0x20>
    p++, q++;
 34a:	0505                	addi	a0,a0,1
 34c:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 34e:	00054783          	lbu	a5,0(a0)
 352:	fbe5                	bnez	a5,342 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 354:	0005c503          	lbu	a0,0(a1)
}
 358:	40a7853b          	subw	a0,a5,a0
 35c:	60a2                	ld	ra,8(sp)
 35e:	6402                	ld	s0,0(sp)
 360:	0141                	addi	sp,sp,16
 362:	8082                	ret

0000000000000364 <strlen>:

uint
strlen(const char *s)
{
 364:	1141                	addi	sp,sp,-16
 366:	e406                	sd	ra,8(sp)
 368:	e022                	sd	s0,0(sp)
 36a:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 36c:	00054783          	lbu	a5,0(a0)
 370:	cf91                	beqz	a5,38c <strlen+0x28>
 372:	00150793          	addi	a5,a0,1
 376:	86be                	mv	a3,a5
 378:	0785                	addi	a5,a5,1
 37a:	fff7c703          	lbu	a4,-1(a5)
 37e:	ff65                	bnez	a4,376 <strlen+0x12>
 380:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 384:	60a2                	ld	ra,8(sp)
 386:	6402                	ld	s0,0(sp)
 388:	0141                	addi	sp,sp,16
 38a:	8082                	ret
  for(n = 0; s[n]; n++)
 38c:	4501                	li	a0,0
 38e:	bfdd                	j	384 <strlen+0x20>

0000000000000390 <memset>:

void*
memset(void *dst, int c, uint n)
{
 390:	1141                	addi	sp,sp,-16
 392:	e406                	sd	ra,8(sp)
 394:	e022                	sd	s0,0(sp)
 396:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 398:	ca19                	beqz	a2,3ae <memset+0x1e>
 39a:	87aa                	mv	a5,a0
 39c:	1602                	slli	a2,a2,0x20
 39e:	9201                	srli	a2,a2,0x20
 3a0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 3a4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 3a8:	0785                	addi	a5,a5,1
 3aa:	fee79de3          	bne	a5,a4,3a4 <memset+0x14>
  }
  return dst;
}
 3ae:	60a2                	ld	ra,8(sp)
 3b0:	6402                	ld	s0,0(sp)
 3b2:	0141                	addi	sp,sp,16
 3b4:	8082                	ret

00000000000003b6 <strchr>:

char*
strchr(const char *s, char c)
{
 3b6:	1141                	addi	sp,sp,-16
 3b8:	e406                	sd	ra,8(sp)
 3ba:	e022                	sd	s0,0(sp)
 3bc:	0800                	addi	s0,sp,16
  for(; *s; s++)
 3be:	00054783          	lbu	a5,0(a0)
 3c2:	cf81                	beqz	a5,3da <strchr+0x24>
    if(*s == c)
 3c4:	00f58763          	beq	a1,a5,3d2 <strchr+0x1c>
  for(; *s; s++)
 3c8:	0505                	addi	a0,a0,1
 3ca:	00054783          	lbu	a5,0(a0)
 3ce:	fbfd                	bnez	a5,3c4 <strchr+0xe>
      return (char*)s;
  return 0;
 3d0:	4501                	li	a0,0
}
 3d2:	60a2                	ld	ra,8(sp)
 3d4:	6402                	ld	s0,0(sp)
 3d6:	0141                	addi	sp,sp,16
 3d8:	8082                	ret
  return 0;
 3da:	4501                	li	a0,0
 3dc:	bfdd                	j	3d2 <strchr+0x1c>

00000000000003de <gets>:

char*
gets(char *buf, int max)
{
 3de:	711d                	addi	sp,sp,-96
 3e0:	ec86                	sd	ra,88(sp)
 3e2:	e8a2                	sd	s0,80(sp)
 3e4:	e4a6                	sd	s1,72(sp)
 3e6:	e0ca                	sd	s2,64(sp)
 3e8:	fc4e                	sd	s3,56(sp)
 3ea:	f852                	sd	s4,48(sp)
 3ec:	f456                	sd	s5,40(sp)
 3ee:	f05a                	sd	s6,32(sp)
 3f0:	ec5e                	sd	s7,24(sp)
 3f2:	e862                	sd	s8,16(sp)
 3f4:	1080                	addi	s0,sp,96
 3f6:	8baa                	mv	s7,a0
 3f8:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 3fa:	892a                	mv	s2,a0
 3fc:	4481                	li	s1,0
    cc = read(0, &c, 1);
 3fe:	faf40b13          	addi	s6,s0,-81
 402:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 404:	8c26                	mv	s8,s1
 406:	0014899b          	addiw	s3,s1,1
 40a:	84ce                	mv	s1,s3
 40c:	0349d463          	bge	s3,s4,434 <gets+0x56>
    cc = read(0, &c, 1);
 410:	8656                	mv	a2,s5
 412:	85da                	mv	a1,s6
 414:	4501                	li	a0,0
 416:	1bc000ef          	jal	5d2 <read>
    if(cc < 1)
 41a:	00a05d63          	blez	a0,434 <gets+0x56>
      break;
    buf[i++] = c;
 41e:	faf44783          	lbu	a5,-81(s0)
 422:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 426:	0905                	addi	s2,s2,1
 428:	ff678713          	addi	a4,a5,-10
 42c:	c319                	beqz	a4,432 <gets+0x54>
 42e:	17cd                	addi	a5,a5,-13
 430:	fbf1                	bnez	a5,404 <gets+0x26>
    buf[i++] = c;
 432:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 434:	9c5e                	add	s8,s8,s7
 436:	000c0023          	sb	zero,0(s8)
  return buf;
}
 43a:	855e                	mv	a0,s7
 43c:	60e6                	ld	ra,88(sp)
 43e:	6446                	ld	s0,80(sp)
 440:	64a6                	ld	s1,72(sp)
 442:	6906                	ld	s2,64(sp)
 444:	79e2                	ld	s3,56(sp)
 446:	7a42                	ld	s4,48(sp)
 448:	7aa2                	ld	s5,40(sp)
 44a:	7b02                	ld	s6,32(sp)
 44c:	6be2                	ld	s7,24(sp)
 44e:	6c42                	ld	s8,16(sp)
 450:	6125                	addi	sp,sp,96
 452:	8082                	ret

0000000000000454 <stat>:

int
stat(const char *n, struct stat *st)
{
 454:	1101                	addi	sp,sp,-32
 456:	ec06                	sd	ra,24(sp)
 458:	e822                	sd	s0,16(sp)
 45a:	e04a                	sd	s2,0(sp)
 45c:	1000                	addi	s0,sp,32
 45e:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 460:	4581                	li	a1,0
 462:	198000ef          	jal	5fa <open>
  if(fd < 0)
 466:	02054263          	bltz	a0,48a <stat+0x36>
 46a:	e426                	sd	s1,8(sp)
 46c:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 46e:	85ca                	mv	a1,s2
 470:	1a2000ef          	jal	612 <fstat>
 474:	892a                	mv	s2,a0
  close(fd);
 476:	8526                	mv	a0,s1
 478:	16a000ef          	jal	5e2 <close>
  return r;
 47c:	64a2                	ld	s1,8(sp)
}
 47e:	854a                	mv	a0,s2
 480:	60e2                	ld	ra,24(sp)
 482:	6442                	ld	s0,16(sp)
 484:	6902                	ld	s2,0(sp)
 486:	6105                	addi	sp,sp,32
 488:	8082                	ret
    return -1;
 48a:	57fd                	li	a5,-1
 48c:	893e                	mv	s2,a5
 48e:	bfc5                	j	47e <stat+0x2a>

0000000000000490 <atoi>:

int
atoi(const char *s)
{
 490:	1141                	addi	sp,sp,-16
 492:	e406                	sd	ra,8(sp)
 494:	e022                	sd	s0,0(sp)
 496:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 498:	00054683          	lbu	a3,0(a0)
 49c:	fd06879b          	addiw	a5,a3,-48
 4a0:	0ff7f793          	zext.b	a5,a5
 4a4:	4625                	li	a2,9
 4a6:	02f66963          	bltu	a2,a5,4d8 <atoi+0x48>
 4aa:	872a                	mv	a4,a0
  n = 0;
 4ac:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 4ae:	0705                	addi	a4,a4,1
 4b0:	0025179b          	slliw	a5,a0,0x2
 4b4:	9fa9                	addw	a5,a5,a0
 4b6:	0017979b          	slliw	a5,a5,0x1
 4ba:	9fb5                	addw	a5,a5,a3
 4bc:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 4c0:	00074683          	lbu	a3,0(a4)
 4c4:	fd06879b          	addiw	a5,a3,-48
 4c8:	0ff7f793          	zext.b	a5,a5
 4cc:	fef671e3          	bgeu	a2,a5,4ae <atoi+0x1e>
  return n;
}
 4d0:	60a2                	ld	ra,8(sp)
 4d2:	6402                	ld	s0,0(sp)
 4d4:	0141                	addi	sp,sp,16
 4d6:	8082                	ret
  n = 0;
 4d8:	4501                	li	a0,0
 4da:	bfdd                	j	4d0 <atoi+0x40>

00000000000004dc <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 4dc:	1141                	addi	sp,sp,-16
 4de:	e406                	sd	ra,8(sp)
 4e0:	e022                	sd	s0,0(sp)
 4e2:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 4e4:	02b57563          	bgeu	a0,a1,50e <memmove+0x32>
    while(n-- > 0)
 4e8:	00c05f63          	blez	a2,506 <memmove+0x2a>
 4ec:	1602                	slli	a2,a2,0x20
 4ee:	9201                	srli	a2,a2,0x20
 4f0:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 4f4:	872a                	mv	a4,a0
      *dst++ = *src++;
 4f6:	0585                	addi	a1,a1,1
 4f8:	0705                	addi	a4,a4,1
 4fa:	fff5c683          	lbu	a3,-1(a1)
 4fe:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 502:	fee79ae3          	bne	a5,a4,4f6 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 506:	60a2                	ld	ra,8(sp)
 508:	6402                	ld	s0,0(sp)
 50a:	0141                	addi	sp,sp,16
 50c:	8082                	ret
    while(n-- > 0)
 50e:	fec05ce3          	blez	a2,506 <memmove+0x2a>
    dst += n;
 512:	00c50733          	add	a4,a0,a2
    src += n;
 516:	95b2                	add	a1,a1,a2
 518:	fff6079b          	addiw	a5,a2,-1 # 2edfff <base+0x2ecfef>
 51c:	1782                	slli	a5,a5,0x20
 51e:	9381                	srli	a5,a5,0x20
 520:	fff7c793          	not	a5,a5
 524:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 526:	15fd                	addi	a1,a1,-1
 528:	177d                	addi	a4,a4,-1
 52a:	0005c683          	lbu	a3,0(a1)
 52e:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 532:	fef71ae3          	bne	a4,a5,526 <memmove+0x4a>
 536:	bfc1                	j	506 <memmove+0x2a>

0000000000000538 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 538:	1141                	addi	sp,sp,-16
 53a:	e406                	sd	ra,8(sp)
 53c:	e022                	sd	s0,0(sp)
 53e:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 540:	c61d                	beqz	a2,56e <memcmp+0x36>
 542:	1602                	slli	a2,a2,0x20
 544:	9201                	srli	a2,a2,0x20
 546:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 54a:	00054783          	lbu	a5,0(a0)
 54e:	0005c703          	lbu	a4,0(a1)
 552:	00e79863          	bne	a5,a4,562 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 556:	0505                	addi	a0,a0,1
    p2++;
 558:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 55a:	fed518e3          	bne	a0,a3,54a <memcmp+0x12>
  }
  return 0;
 55e:	4501                	li	a0,0
 560:	a019                	j	566 <memcmp+0x2e>
      return *p1 - *p2;
 562:	40e7853b          	subw	a0,a5,a4
}
 566:	60a2                	ld	ra,8(sp)
 568:	6402                	ld	s0,0(sp)
 56a:	0141                	addi	sp,sp,16
 56c:	8082                	ret
  return 0;
 56e:	4501                	li	a0,0
 570:	bfdd                	j	566 <memcmp+0x2e>

0000000000000572 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 572:	1141                	addi	sp,sp,-16
 574:	e406                	sd	ra,8(sp)
 576:	e022                	sd	s0,0(sp)
 578:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 57a:	f63ff0ef          	jal	4dc <memmove>
}
 57e:	60a2                	ld	ra,8(sp)
 580:	6402                	ld	s0,0(sp)
 582:	0141                	addi	sp,sp,16
 584:	8082                	ret

0000000000000586 <sbrk>:

char *
sbrk(int n) {
 586:	1141                	addi	sp,sp,-16
 588:	e406                	sd	ra,8(sp)
 58a:	e022                	sd	s0,0(sp)
 58c:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 58e:	4585                	li	a1,1
 590:	0b2000ef          	jal	642 <sys_sbrk>
}
 594:	60a2                	ld	ra,8(sp)
 596:	6402                	ld	s0,0(sp)
 598:	0141                	addi	sp,sp,16
 59a:	8082                	ret

000000000000059c <sbrklazy>:

char *
sbrklazy(int n) {
 59c:	1141                	addi	sp,sp,-16
 59e:	e406                	sd	ra,8(sp)
 5a0:	e022                	sd	s0,0(sp)
 5a2:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 5a4:	4589                	li	a1,2
 5a6:	09c000ef          	jal	642 <sys_sbrk>
}
 5aa:	60a2                	ld	ra,8(sp)
 5ac:	6402                	ld	s0,0(sp)
 5ae:	0141                	addi	sp,sp,16
 5b0:	8082                	ret

00000000000005b2 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 5b2:	4885                	li	a7,1
 ecall
 5b4:	00000073          	ecall
 ret
 5b8:	8082                	ret

00000000000005ba <exit>:
.global exit
exit:
 li a7, SYS_exit
 5ba:	4889                	li	a7,2
 ecall
 5bc:	00000073          	ecall
 ret
 5c0:	8082                	ret

00000000000005c2 <wait>:
.global wait
wait:
 li a7, SYS_wait
 5c2:	488d                	li	a7,3
 ecall
 5c4:	00000073          	ecall
 ret
 5c8:	8082                	ret

00000000000005ca <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 5ca:	4891                	li	a7,4
 ecall
 5cc:	00000073          	ecall
 ret
 5d0:	8082                	ret

00000000000005d2 <read>:
.global read
read:
 li a7, SYS_read
 5d2:	4895                	li	a7,5
 ecall
 5d4:	00000073          	ecall
 ret
 5d8:	8082                	ret

00000000000005da <write>:
.global write
write:
 li a7, SYS_write
 5da:	48c1                	li	a7,16
 ecall
 5dc:	00000073          	ecall
 ret
 5e0:	8082                	ret

00000000000005e2 <close>:
.global close
close:
 li a7, SYS_close
 5e2:	48d5                	li	a7,21
 ecall
 5e4:	00000073          	ecall
 ret
 5e8:	8082                	ret

00000000000005ea <kill>:
.global kill
kill:
 li a7, SYS_kill
 5ea:	4899                	li	a7,6
 ecall
 5ec:	00000073          	ecall
 ret
 5f0:	8082                	ret

00000000000005f2 <exec>:
.global exec
exec:
 li a7, SYS_exec
 5f2:	489d                	li	a7,7
 ecall
 5f4:	00000073          	ecall
 ret
 5f8:	8082                	ret

00000000000005fa <open>:
.global open
open:
 li a7, SYS_open
 5fa:	48bd                	li	a7,15
 ecall
 5fc:	00000073          	ecall
 ret
 600:	8082                	ret

0000000000000602 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 602:	48c5                	li	a7,17
 ecall
 604:	00000073          	ecall
 ret
 608:	8082                	ret

000000000000060a <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 60a:	48c9                	li	a7,18
 ecall
 60c:	00000073          	ecall
 ret
 610:	8082                	ret

0000000000000612 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 612:	48a1                	li	a7,8
 ecall
 614:	00000073          	ecall
 ret
 618:	8082                	ret

000000000000061a <link>:
.global link
link:
 li a7, SYS_link
 61a:	48cd                	li	a7,19
 ecall
 61c:	00000073          	ecall
 ret
 620:	8082                	ret

0000000000000622 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 622:	48d1                	li	a7,20
 ecall
 624:	00000073          	ecall
 ret
 628:	8082                	ret

000000000000062a <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 62a:	48a5                	li	a7,9
 ecall
 62c:	00000073          	ecall
 ret
 630:	8082                	ret

0000000000000632 <dup>:
.global dup
dup:
 li a7, SYS_dup
 632:	48a9                	li	a7,10
 ecall
 634:	00000073          	ecall
 ret
 638:	8082                	ret

000000000000063a <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 63a:	48ad                	li	a7,11
 ecall
 63c:	00000073          	ecall
 ret
 640:	8082                	ret

0000000000000642 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 642:	48b1                	li	a7,12
 ecall
 644:	00000073          	ecall
 ret
 648:	8082                	ret

000000000000064a <pause>:
.global pause
pause:
 li a7, SYS_pause
 64a:	48b5                	li	a7,13
 ecall
 64c:	00000073          	ecall
 ret
 650:	8082                	ret

0000000000000652 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 652:	48b9                	li	a7,14
 ecall
 654:	00000073          	ecall
 ret
 658:	8082                	ret

000000000000065a <shm_create>:
.global shm_create
shm_create:
 li a7, SYS_shm_create
 65a:	48d9                	li	a7,22
 ecall
 65c:	00000073          	ecall
 ret
 660:	8082                	ret

0000000000000662 <shm_get>:
.global shm_get
shm_get:
 li a7, SYS_shm_get
 662:	48dd                	li	a7,23
 ecall
 664:	00000073          	ecall
 ret
 668:	8082                	ret

000000000000066a <shm_close>:
.global shm_close
shm_close:
 li a7, SYS_shm_close
 66a:	48e1                	li	a7,24
 ecall
 66c:	00000073          	ecall
 ret
 670:	8082                	ret

0000000000000672 <mbox_create>:
.global mbox_create
mbox_create:
 li a7, SYS_mbox_create
 672:	48e5                	li	a7,25
 ecall
 674:	00000073          	ecall
 ret
 678:	8082                	ret

000000000000067a <mbox_send>:
.global mbox_send
mbox_send:
 li a7, SYS_mbox_send
 67a:	48e9                	li	a7,26
 ecall
 67c:	00000073          	ecall
 ret
 680:	8082                	ret

0000000000000682 <mbox_recv>:
.global mbox_recv
mbox_recv:
 li a7, SYS_mbox_recv
 682:	48ed                	li	a7,27
 ecall
 684:	00000073          	ecall
 ret
 688:	8082                	ret

000000000000068a <va2pa>:
.global va2pa
va2pa:
 li a7, SYS_va2pa
 68a:	48f1                	li	a7,28
 ecall
 68c:	00000073          	ecall
 ret
 690:	8082                	ret

0000000000000692 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 692:	1101                	addi	sp,sp,-32
 694:	ec06                	sd	ra,24(sp)
 696:	e822                	sd	s0,16(sp)
 698:	1000                	addi	s0,sp,32
 69a:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 69e:	4605                	li	a2,1
 6a0:	fef40593          	addi	a1,s0,-17
 6a4:	f37ff0ef          	jal	5da <write>
}
 6a8:	60e2                	ld	ra,24(sp)
 6aa:	6442                	ld	s0,16(sp)
 6ac:	6105                	addi	sp,sp,32
 6ae:	8082                	ret

00000000000006b0 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 6b0:	715d                	addi	sp,sp,-80
 6b2:	e486                	sd	ra,72(sp)
 6b4:	e0a2                	sd	s0,64(sp)
 6b6:	f84a                	sd	s2,48(sp)
 6b8:	f44e                	sd	s3,40(sp)
 6ba:	0880                	addi	s0,sp,80
 6bc:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 6be:	cac1                	beqz	a3,74e <printint+0x9e>
 6c0:	0805d763          	bgez	a1,74e <printint+0x9e>
    neg = 1;
    x = -xx;
 6c4:	40b005bb          	negw	a1,a1
    neg = 1;
 6c8:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 6ca:	fb840993          	addi	s3,s0,-72
  neg = 0;
 6ce:	86ce                	mv	a3,s3
  i = 0;
 6d0:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 6d2:	00000817          	auipc	a6,0x0
 6d6:	73e80813          	addi	a6,a6,1854 # e10 <digits>
 6da:	88ba                	mv	a7,a4
 6dc:	0017051b          	addiw	a0,a4,1
 6e0:	872a                	mv	a4,a0
 6e2:	02c5f7bb          	remuw	a5,a1,a2
 6e6:	1782                	slli	a5,a5,0x20
 6e8:	9381                	srli	a5,a5,0x20
 6ea:	97c2                	add	a5,a5,a6
 6ec:	0007c783          	lbu	a5,0(a5)
 6f0:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 6f4:	87ae                	mv	a5,a1
 6f6:	02c5d5bb          	divuw	a1,a1,a2
 6fa:	0685                	addi	a3,a3,1
 6fc:	fcc7ffe3          	bgeu	a5,a2,6da <printint+0x2a>
  if(neg)
 700:	00030c63          	beqz	t1,718 <printint+0x68>
    buf[i++] = '-';
 704:	fd050793          	addi	a5,a0,-48
 708:	00878533          	add	a0,a5,s0
 70c:	02d00793          	li	a5,45
 710:	fef50423          	sb	a5,-24(a0)
 714:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 718:	02e05563          	blez	a4,742 <printint+0x92>
 71c:	fc26                	sd	s1,56(sp)
 71e:	377d                	addiw	a4,a4,-1
 720:	00e984b3          	add	s1,s3,a4
 724:	19fd                	addi	s3,s3,-1
 726:	99ba                	add	s3,s3,a4
 728:	1702                	slli	a4,a4,0x20
 72a:	9301                	srli	a4,a4,0x20
 72c:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 730:	0004c583          	lbu	a1,0(s1)
 734:	854a                	mv	a0,s2
 736:	f5dff0ef          	jal	692 <putc>
  while(--i >= 0)
 73a:	14fd                	addi	s1,s1,-1
 73c:	ff349ae3          	bne	s1,s3,730 <printint+0x80>
 740:	74e2                	ld	s1,56(sp)
}
 742:	60a6                	ld	ra,72(sp)
 744:	6406                	ld	s0,64(sp)
 746:	7942                	ld	s2,48(sp)
 748:	79a2                	ld	s3,40(sp)
 74a:	6161                	addi	sp,sp,80
 74c:	8082                	ret
    x = xx;
 74e:	2581                	sext.w	a1,a1
  neg = 0;
 750:	4301                	li	t1,0
 752:	bfa5                	j	6ca <printint+0x1a>

0000000000000754 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 754:	711d                	addi	sp,sp,-96
 756:	ec86                	sd	ra,88(sp)
 758:	e8a2                	sd	s0,80(sp)
 75a:	e4a6                	sd	s1,72(sp)
 75c:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 75e:	0005c483          	lbu	s1,0(a1)
 762:	22048363          	beqz	s1,988 <vprintf+0x234>
 766:	e0ca                	sd	s2,64(sp)
 768:	fc4e                	sd	s3,56(sp)
 76a:	f852                	sd	s4,48(sp)
 76c:	f456                	sd	s5,40(sp)
 76e:	f05a                	sd	s6,32(sp)
 770:	ec5e                	sd	s7,24(sp)
 772:	e862                	sd	s8,16(sp)
 774:	8b2a                	mv	s6,a0
 776:	8a2e                	mv	s4,a1
 778:	8bb2                	mv	s7,a2
  state = 0;
 77a:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 77c:	4901                	li	s2,0
 77e:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 780:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 784:	06400c13          	li	s8,100
 788:	a00d                	j	7aa <vprintf+0x56>
        putc(fd, c0);
 78a:	85a6                	mv	a1,s1
 78c:	855a                	mv	a0,s6
 78e:	f05ff0ef          	jal	692 <putc>
 792:	a019                	j	798 <vprintf+0x44>
    } else if(state == '%'){
 794:	03598363          	beq	s3,s5,7ba <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 798:	0019079b          	addiw	a5,s2,1
 79c:	893e                	mv	s2,a5
 79e:	873e                	mv	a4,a5
 7a0:	97d2                	add	a5,a5,s4
 7a2:	0007c483          	lbu	s1,0(a5)
 7a6:	1c048a63          	beqz	s1,97a <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 7aa:	0004879b          	sext.w	a5,s1
    if(state == 0){
 7ae:	fe0993e3          	bnez	s3,794 <vprintf+0x40>
      if(c0 == '%'){
 7b2:	fd579ce3          	bne	a5,s5,78a <vprintf+0x36>
        state = '%';
 7b6:	89be                	mv	s3,a5
 7b8:	b7c5                	j	798 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 7ba:	00ea06b3          	add	a3,s4,a4
 7be:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 7c2:	1c060863          	beqz	a2,992 <vprintf+0x23e>
      if(c0 == 'd'){
 7c6:	03878763          	beq	a5,s8,7f4 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 7ca:	f9478693          	addi	a3,a5,-108
 7ce:	0016b693          	seqz	a3,a3
 7d2:	f9c60593          	addi	a1,a2,-100
 7d6:	e99d                	bnez	a1,80c <vprintf+0xb8>
 7d8:	ca95                	beqz	a3,80c <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 7da:	008b8493          	addi	s1,s7,8
 7de:	4685                	li	a3,1
 7e0:	4629                	li	a2,10
 7e2:	000bb583          	ld	a1,0(s7)
 7e6:	855a                	mv	a0,s6
 7e8:	ec9ff0ef          	jal	6b0 <printint>
        i += 1;
 7ec:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 7ee:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 7f0:	4981                	li	s3,0
 7f2:	b75d                	j	798 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 7f4:	008b8493          	addi	s1,s7,8
 7f8:	4685                	li	a3,1
 7fa:	4629                	li	a2,10
 7fc:	000ba583          	lw	a1,0(s7)
 800:	855a                	mv	a0,s6
 802:	eafff0ef          	jal	6b0 <printint>
 806:	8ba6                	mv	s7,s1
      state = 0;
 808:	4981                	li	s3,0
 80a:	b779                	j	798 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 80c:	9752                	add	a4,a4,s4
 80e:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 812:	f9460713          	addi	a4,a2,-108
 816:	00173713          	seqz	a4,a4
 81a:	8f75                	and	a4,a4,a3
 81c:	f9c58513          	addi	a0,a1,-100
 820:	18051363          	bnez	a0,9a6 <vprintf+0x252>
 824:	18070163          	beqz	a4,9a6 <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 828:	008b8493          	addi	s1,s7,8
 82c:	4685                	li	a3,1
 82e:	4629                	li	a2,10
 830:	000bb583          	ld	a1,0(s7)
 834:	855a                	mv	a0,s6
 836:	e7bff0ef          	jal	6b0 <printint>
        i += 2;
 83a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 83c:	8ba6                	mv	s7,s1
      state = 0;
 83e:	4981                	li	s3,0
        i += 2;
 840:	bfa1                	j	798 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 842:	008b8493          	addi	s1,s7,8
 846:	4681                	li	a3,0
 848:	4629                	li	a2,10
 84a:	000be583          	lwu	a1,0(s7)
 84e:	855a                	mv	a0,s6
 850:	e61ff0ef          	jal	6b0 <printint>
 854:	8ba6                	mv	s7,s1
      state = 0;
 856:	4981                	li	s3,0
 858:	b781                	j	798 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 85a:	008b8493          	addi	s1,s7,8
 85e:	4681                	li	a3,0
 860:	4629                	li	a2,10
 862:	000bb583          	ld	a1,0(s7)
 866:	855a                	mv	a0,s6
 868:	e49ff0ef          	jal	6b0 <printint>
        i += 1;
 86c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 86e:	8ba6                	mv	s7,s1
      state = 0;
 870:	4981                	li	s3,0
 872:	b71d                	j	798 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 874:	008b8493          	addi	s1,s7,8
 878:	4681                	li	a3,0
 87a:	4629                	li	a2,10
 87c:	000bb583          	ld	a1,0(s7)
 880:	855a                	mv	a0,s6
 882:	e2fff0ef          	jal	6b0 <printint>
        i += 2;
 886:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 888:	8ba6                	mv	s7,s1
      state = 0;
 88a:	4981                	li	s3,0
        i += 2;
 88c:	b731                	j	798 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 88e:	008b8493          	addi	s1,s7,8
 892:	4681                	li	a3,0
 894:	4641                	li	a2,16
 896:	000be583          	lwu	a1,0(s7)
 89a:	855a                	mv	a0,s6
 89c:	e15ff0ef          	jal	6b0 <printint>
 8a0:	8ba6                	mv	s7,s1
      state = 0;
 8a2:	4981                	li	s3,0
 8a4:	bdd5                	j	798 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 8a6:	008b8493          	addi	s1,s7,8
 8aa:	4681                	li	a3,0
 8ac:	4641                	li	a2,16
 8ae:	000bb583          	ld	a1,0(s7)
 8b2:	855a                	mv	a0,s6
 8b4:	dfdff0ef          	jal	6b0 <printint>
        i += 1;
 8b8:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 8ba:	8ba6                	mv	s7,s1
      state = 0;
 8bc:	4981                	li	s3,0
 8be:	bde9                	j	798 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 8c0:	008b8493          	addi	s1,s7,8
 8c4:	4681                	li	a3,0
 8c6:	4641                	li	a2,16
 8c8:	000bb583          	ld	a1,0(s7)
 8cc:	855a                	mv	a0,s6
 8ce:	de3ff0ef          	jal	6b0 <printint>
        i += 2;
 8d2:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 8d4:	8ba6                	mv	s7,s1
      state = 0;
 8d6:	4981                	li	s3,0
        i += 2;
 8d8:	b5c1                	j	798 <vprintf+0x44>
 8da:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 8dc:	008b8793          	addi	a5,s7,8
 8e0:	8cbe                	mv	s9,a5
 8e2:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 8e6:	03000593          	li	a1,48
 8ea:	855a                	mv	a0,s6
 8ec:	da7ff0ef          	jal	692 <putc>
  putc(fd, 'x');
 8f0:	07800593          	li	a1,120
 8f4:	855a                	mv	a0,s6
 8f6:	d9dff0ef          	jal	692 <putc>
 8fa:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 8fc:	00000b97          	auipc	s7,0x0
 900:	514b8b93          	addi	s7,s7,1300 # e10 <digits>
 904:	03c9d793          	srli	a5,s3,0x3c
 908:	97de                	add	a5,a5,s7
 90a:	0007c583          	lbu	a1,0(a5)
 90e:	855a                	mv	a0,s6
 910:	d83ff0ef          	jal	692 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 914:	0992                	slli	s3,s3,0x4
 916:	34fd                	addiw	s1,s1,-1
 918:	f4f5                	bnez	s1,904 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 91a:	8be6                	mv	s7,s9
      state = 0;
 91c:	4981                	li	s3,0
 91e:	6ca2                	ld	s9,8(sp)
 920:	bda5                	j	798 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 922:	008b8493          	addi	s1,s7,8
 926:	000bc583          	lbu	a1,0(s7)
 92a:	855a                	mv	a0,s6
 92c:	d67ff0ef          	jal	692 <putc>
 930:	8ba6                	mv	s7,s1
      state = 0;
 932:	4981                	li	s3,0
 934:	b595                	j	798 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 936:	008b8993          	addi	s3,s7,8
 93a:	000bb483          	ld	s1,0(s7)
 93e:	cc91                	beqz	s1,95a <vprintf+0x206>
        for(; *s; s++)
 940:	0004c583          	lbu	a1,0(s1)
 944:	c985                	beqz	a1,974 <vprintf+0x220>
          putc(fd, *s);
 946:	855a                	mv	a0,s6
 948:	d4bff0ef          	jal	692 <putc>
        for(; *s; s++)
 94c:	0485                	addi	s1,s1,1
 94e:	0004c583          	lbu	a1,0(s1)
 952:	f9f5                	bnez	a1,946 <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 954:	8bce                	mv	s7,s3
      state = 0;
 956:	4981                	li	s3,0
 958:	b581                	j	798 <vprintf+0x44>
          s = "(null)";
 95a:	00000497          	auipc	s1,0x0
 95e:	4ae48493          	addi	s1,s1,1198 # e08 <malloc+0x312>
        for(; *s; s++)
 962:	02800593          	li	a1,40
 966:	b7c5                	j	946 <vprintf+0x1f2>
        putc(fd, '%');
 968:	85be                	mv	a1,a5
 96a:	855a                	mv	a0,s6
 96c:	d27ff0ef          	jal	692 <putc>
      state = 0;
 970:	4981                	li	s3,0
 972:	b51d                	j	798 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 974:	8bce                	mv	s7,s3
      state = 0;
 976:	4981                	li	s3,0
 978:	b505                	j	798 <vprintf+0x44>
 97a:	6906                	ld	s2,64(sp)
 97c:	79e2                	ld	s3,56(sp)
 97e:	7a42                	ld	s4,48(sp)
 980:	7aa2                	ld	s5,40(sp)
 982:	7b02                	ld	s6,32(sp)
 984:	6be2                	ld	s7,24(sp)
 986:	6c42                	ld	s8,16(sp)
    }
  }
}
 988:	60e6                	ld	ra,88(sp)
 98a:	6446                	ld	s0,80(sp)
 98c:	64a6                	ld	s1,72(sp)
 98e:	6125                	addi	sp,sp,96
 990:	8082                	ret
      if(c0 == 'd'){
 992:	06400713          	li	a4,100
 996:	e4e78fe3          	beq	a5,a4,7f4 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 99a:	f9478693          	addi	a3,a5,-108
 99e:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 9a2:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 9a4:	4701                	li	a4,0
      } else if(c0 == 'u'){
 9a6:	07500513          	li	a0,117
 9aa:	e8a78ce3          	beq	a5,a0,842 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 9ae:	f8b60513          	addi	a0,a2,-117
 9b2:	e119                	bnez	a0,9b8 <vprintf+0x264>
 9b4:	ea0693e3          	bnez	a3,85a <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 9b8:	f8b58513          	addi	a0,a1,-117
 9bc:	e119                	bnez	a0,9c2 <vprintf+0x26e>
 9be:	ea071be3          	bnez	a4,874 <vprintf+0x120>
      } else if(c0 == 'x'){
 9c2:	07800513          	li	a0,120
 9c6:	eca784e3          	beq	a5,a0,88e <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 9ca:	f8860613          	addi	a2,a2,-120
 9ce:	e219                	bnez	a2,9d4 <vprintf+0x280>
 9d0:	ec069be3          	bnez	a3,8a6 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 9d4:	f8858593          	addi	a1,a1,-120
 9d8:	e199                	bnez	a1,9de <vprintf+0x28a>
 9da:	ee0713e3          	bnez	a4,8c0 <vprintf+0x16c>
      } else if(c0 == 'p'){
 9de:	07000713          	li	a4,112
 9e2:	eee78ce3          	beq	a5,a4,8da <vprintf+0x186>
      } else if(c0 == 'c'){
 9e6:	06300713          	li	a4,99
 9ea:	f2e78ce3          	beq	a5,a4,922 <vprintf+0x1ce>
      } else if(c0 == 's'){
 9ee:	07300713          	li	a4,115
 9f2:	f4e782e3          	beq	a5,a4,936 <vprintf+0x1e2>
      } else if(c0 == '%'){
 9f6:	02500713          	li	a4,37
 9fa:	f6e787e3          	beq	a5,a4,968 <vprintf+0x214>
        putc(fd, '%');
 9fe:	02500593          	li	a1,37
 a02:	855a                	mv	a0,s6
 a04:	c8fff0ef          	jal	692 <putc>
        putc(fd, c0);
 a08:	85a6                	mv	a1,s1
 a0a:	855a                	mv	a0,s6
 a0c:	c87ff0ef          	jal	692 <putc>
      state = 0;
 a10:	4981                	li	s3,0
 a12:	b359                	j	798 <vprintf+0x44>

0000000000000a14 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 a14:	715d                	addi	sp,sp,-80
 a16:	ec06                	sd	ra,24(sp)
 a18:	e822                	sd	s0,16(sp)
 a1a:	1000                	addi	s0,sp,32
 a1c:	e010                	sd	a2,0(s0)
 a1e:	e414                	sd	a3,8(s0)
 a20:	e818                	sd	a4,16(s0)
 a22:	ec1c                	sd	a5,24(s0)
 a24:	03043023          	sd	a6,32(s0)
 a28:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 a2c:	8622                	mv	a2,s0
 a2e:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 a32:	d23ff0ef          	jal	754 <vprintf>
}
 a36:	60e2                	ld	ra,24(sp)
 a38:	6442                	ld	s0,16(sp)
 a3a:	6161                	addi	sp,sp,80
 a3c:	8082                	ret

0000000000000a3e <printf>:

void
printf(const char *fmt, ...)
{
 a3e:	711d                	addi	sp,sp,-96
 a40:	ec06                	sd	ra,24(sp)
 a42:	e822                	sd	s0,16(sp)
 a44:	1000                	addi	s0,sp,32
 a46:	e40c                	sd	a1,8(s0)
 a48:	e810                	sd	a2,16(s0)
 a4a:	ec14                	sd	a3,24(s0)
 a4c:	f018                	sd	a4,32(s0)
 a4e:	f41c                	sd	a5,40(s0)
 a50:	03043823          	sd	a6,48(s0)
 a54:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 a58:	00840613          	addi	a2,s0,8
 a5c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 a60:	85aa                	mv	a1,a0
 a62:	4505                	li	a0,1
 a64:	cf1ff0ef          	jal	754 <vprintf>
}
 a68:	60e2                	ld	ra,24(sp)
 a6a:	6442                	ld	s0,16(sp)
 a6c:	6125                	addi	sp,sp,96
 a6e:	8082                	ret

0000000000000a70 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 a70:	1141                	addi	sp,sp,-16
 a72:	e406                	sd	ra,8(sp)
 a74:	e022                	sd	s0,0(sp)
 a76:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 a78:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 a7c:	00000797          	auipc	a5,0x0
 a80:	5847b783          	ld	a5,1412(a5) # 1000 <freep>
 a84:	a039                	j	a92 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 a86:	6398                	ld	a4,0(a5)
 a88:	00e7e463          	bltu	a5,a4,a90 <free+0x20>
 a8c:	00e6ea63          	bltu	a3,a4,aa0 <free+0x30>
{
 a90:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 a92:	fed7fae3          	bgeu	a5,a3,a86 <free+0x16>
 a96:	6398                	ld	a4,0(a5)
 a98:	00e6e463          	bltu	a3,a4,aa0 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 a9c:	fee7eae3          	bltu	a5,a4,a90 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 aa0:	ff852583          	lw	a1,-8(a0)
 aa4:	6390                	ld	a2,0(a5)
 aa6:	02059813          	slli	a6,a1,0x20
 aaa:	01c85713          	srli	a4,a6,0x1c
 aae:	9736                	add	a4,a4,a3
 ab0:	02e60563          	beq	a2,a4,ada <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 ab4:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 ab8:	4790                	lw	a2,8(a5)
 aba:	02061593          	slli	a1,a2,0x20
 abe:	01c5d713          	srli	a4,a1,0x1c
 ac2:	973e                	add	a4,a4,a5
 ac4:	02e68263          	beq	a3,a4,ae8 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 ac8:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 aca:	00000717          	auipc	a4,0x0
 ace:	52f73b23          	sd	a5,1334(a4) # 1000 <freep>
}
 ad2:	60a2                	ld	ra,8(sp)
 ad4:	6402                	ld	s0,0(sp)
 ad6:	0141                	addi	sp,sp,16
 ad8:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 ada:	4618                	lw	a4,8(a2)
 adc:	9f2d                	addw	a4,a4,a1
 ade:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 ae2:	6398                	ld	a4,0(a5)
 ae4:	6310                	ld	a2,0(a4)
 ae6:	b7f9                	j	ab4 <free+0x44>
    p->s.size += bp->s.size;
 ae8:	ff852703          	lw	a4,-8(a0)
 aec:	9f31                	addw	a4,a4,a2
 aee:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 af0:	ff053683          	ld	a3,-16(a0)
 af4:	bfd1                	j	ac8 <free+0x58>

0000000000000af6 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 af6:	7139                	addi	sp,sp,-64
 af8:	fc06                	sd	ra,56(sp)
 afa:	f822                	sd	s0,48(sp)
 afc:	f04a                	sd	s2,32(sp)
 afe:	ec4e                	sd	s3,24(sp)
 b00:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 b02:	02051993          	slli	s3,a0,0x20
 b06:	0209d993          	srli	s3,s3,0x20
 b0a:	09bd                	addi	s3,s3,15
 b0c:	0049d993          	srli	s3,s3,0x4
 b10:	2985                	addiw	s3,s3,1
 b12:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 b14:	00000517          	auipc	a0,0x0
 b18:	4ec53503          	ld	a0,1260(a0) # 1000 <freep>
 b1c:	c905                	beqz	a0,b4c <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 b1e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 b20:	4798                	lw	a4,8(a5)
 b22:	09377663          	bgeu	a4,s3,bae <malloc+0xb8>
 b26:	f426                	sd	s1,40(sp)
 b28:	e852                	sd	s4,16(sp)
 b2a:	e456                	sd	s5,8(sp)
 b2c:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 b2e:	8a4e                	mv	s4,s3
 b30:	6705                	lui	a4,0x1
 b32:	00e9f363          	bgeu	s3,a4,b38 <malloc+0x42>
 b36:	6a05                	lui	s4,0x1
 b38:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 b3c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 b40:	00000497          	auipc	s1,0x0
 b44:	4c048493          	addi	s1,s1,1216 # 1000 <freep>
  if(p == SBRK_ERROR)
 b48:	5afd                	li	s5,-1
 b4a:	a83d                	j	b88 <malloc+0x92>
 b4c:	f426                	sd	s1,40(sp)
 b4e:	e852                	sd	s4,16(sp)
 b50:	e456                	sd	s5,8(sp)
 b52:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 b54:	00000797          	auipc	a5,0x0
 b58:	4bc78793          	addi	a5,a5,1212 # 1010 <base>
 b5c:	00000717          	auipc	a4,0x0
 b60:	4af73223          	sd	a5,1188(a4) # 1000 <freep>
 b64:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 b66:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 b6a:	b7d1                	j	b2e <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 b6c:	6398                	ld	a4,0(a5)
 b6e:	e118                	sd	a4,0(a0)
 b70:	a899                	j	bc6 <malloc+0xd0>
  hp->s.size = nu;
 b72:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 b76:	0541                	addi	a0,a0,16
 b78:	ef9ff0ef          	jal	a70 <free>
  return freep;
 b7c:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 b7e:	c125                	beqz	a0,bde <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 b80:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 b82:	4798                	lw	a4,8(a5)
 b84:	03277163          	bgeu	a4,s2,ba6 <malloc+0xb0>
    if(p == freep)
 b88:	6098                	ld	a4,0(s1)
 b8a:	853e                	mv	a0,a5
 b8c:	fef71ae3          	bne	a4,a5,b80 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 b90:	8552                	mv	a0,s4
 b92:	9f5ff0ef          	jal	586 <sbrk>
  if(p == SBRK_ERROR)
 b96:	fd551ee3          	bne	a0,s5,b72 <malloc+0x7c>
        return 0;
 b9a:	4501                	li	a0,0
 b9c:	74a2                	ld	s1,40(sp)
 b9e:	6a42                	ld	s4,16(sp)
 ba0:	6aa2                	ld	s5,8(sp)
 ba2:	6b02                	ld	s6,0(sp)
 ba4:	a03d                	j	bd2 <malloc+0xdc>
 ba6:	74a2                	ld	s1,40(sp)
 ba8:	6a42                	ld	s4,16(sp)
 baa:	6aa2                	ld	s5,8(sp)
 bac:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 bae:	fae90fe3          	beq	s2,a4,b6c <malloc+0x76>
        p->s.size -= nunits;
 bb2:	4137073b          	subw	a4,a4,s3
 bb6:	c798                	sw	a4,8(a5)
        p += p->s.size;
 bb8:	02071693          	slli	a3,a4,0x20
 bbc:	01c6d713          	srli	a4,a3,0x1c
 bc0:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 bc2:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 bc6:	00000717          	auipc	a4,0x0
 bca:	42a73d23          	sd	a0,1082(a4) # 1000 <freep>
      return (void*)(p + 1);
 bce:	01078513          	addi	a0,a5,16
  }
}
 bd2:	70e2                	ld	ra,56(sp)
 bd4:	7442                	ld	s0,48(sp)
 bd6:	7902                	ld	s2,32(sp)
 bd8:	69e2                	ld	s3,24(sp)
 bda:	6121                	addi	sp,sp,64
 bdc:	8082                	ret
 bde:	74a2                	ld	s1,40(sp)
 be0:	6a42                	ld	s4,16(sp)
 be2:	6aa2                	ld	s5,8(sp)
 be4:	6b02                	ld	s6,0(sp)
 be6:	b7f5                	j	bd2 <malloc+0xdc>
