
user/_cowtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	1800                	addi	s0,sp,48
  char *p = malloc(4096);
   8:	6505                	lui	a0,0x1
   a:	105000ef          	jal	90e <malloc>
  if (p == 0) {
   e:	c551                	beqz	a0,9a <main+0x9a>
  10:	ec26                	sd	s1,24(sp)
  12:	e84a                	sd	s2,16(sp)
  14:	84aa                	mv	s1,a0
    printf("malloc failed\n");
    exit(1);
  }

  p[0] = 'A';
  16:	04100793          	li	a5,65
  1a:	00f50023          	sb	a5,0(a0) # 1000 <freep>
  uint64 pa_parent_before = va2pa((uint64)p);
  1e:	484000ef          	jal	4a2 <va2pa>
  22:	892a                	mv	s2,a0
  printf("parent BEFORE fork: p[0] = %c, va = %p, pa = 0x%p\n",
  24:	86aa                	mv	a3,a0
  26:	8626                	mv	a2,s1
  28:	0004c583          	lbu	a1,0(s1)
  2c:	00001517          	auipc	a0,0x1
  30:	9e450513          	addi	a0,a0,-1564 # a10 <malloc+0x102>
  34:	023000ef          	jal	856 <printf>
         p[0], p, (void*)pa_parent_before);

  int pid = fork();
  38:	392000ef          	jal	3ca <fork>
  if (pid < 0) {
  3c:	06054b63          	bltz	a0,b2 <main+0xb2>
  40:	e44e                	sd	s3,8(sp)
    printf("fork failed\n");
    exit(1);
  } else if (pid == 0) {
  42:	e949                	bnez	a0,d4 <main+0xd4>
    uint64 pa_child_before = va2pa((uint64)p);
  44:	8526                	mv	a0,s1
  46:	45c000ef          	jal	4a2 <va2pa>
  4a:	89aa                	mv	s3,a0
    printf("child BEFORE modifying: p[0] = %c, va = %p, pa = 0x%p\n",
  4c:	86aa                	mv	a3,a0
  4e:	8626                	mv	a2,s1
  50:	0004c583          	lbu	a1,0(s1)
  54:	00001517          	auipc	a0,0x1
  58:	a0450513          	addi	a0,a0,-1532 # a58 <malloc+0x14a>
  5c:	7fa000ef          	jal	856 <printf>
           p[0], p, (void*)pa_child_before);

    p[0] = 'C';  // should trigger COW
  60:	04300793          	li	a5,67
  64:	00f48023          	sb	a5,0(s1)

    uint64 pa_child_after = va2pa((uint64)p);
  68:	8526                	mv	a0,s1
  6a:	438000ef          	jal	4a2 <va2pa>
  6e:	892a                	mv	s2,a0
    printf("child AFTER modifying:  p[0] = %c, va = %p, pa = 0x%p\n",
  70:	86aa                	mv	a3,a0
  72:	8626                	mv	a2,s1
  74:	0004c583          	lbu	a1,0(s1)
  78:	00001517          	auipc	a0,0x1
  7c:	a1850513          	addi	a0,a0,-1512 # a90 <malloc+0x182>
  80:	7d6000ef          	jal	856 <printf>
           p[0], p, (void*)pa_child_after);

    if (pa_child_before != pa_child_after)
  84:	05298163          	beq	s3,s2,c6 <main+0xc6>
      printf("COW SUCCESS: child got new page.\n");
  88:	00001517          	auipc	a0,0x1
  8c:	a4050513          	addi	a0,a0,-1472 # ac8 <malloc+0x1ba>
  90:	7c6000ef          	jal	856 <printf>
    else
      printf("COW FAILED: same physical page after write!\n");

    exit(0);
  94:	4501                	li	a0,0
  96:	33c000ef          	jal	3d2 <exit>
  9a:	ec26                	sd	s1,24(sp)
  9c:	e84a                	sd	s2,16(sp)
  9e:	e44e                	sd	s3,8(sp)
    printf("malloc failed\n");
  a0:	00001517          	auipc	a0,0x1
  a4:	96050513          	addi	a0,a0,-1696 # a00 <malloc+0xf2>
  a8:	7ae000ef          	jal	856 <printf>
    exit(1);
  ac:	4505                	li	a0,1
  ae:	324000ef          	jal	3d2 <exit>
  b2:	e44e                	sd	s3,8(sp)
    printf("fork failed\n");
  b4:	00001517          	auipc	a0,0x1
  b8:	99450513          	addi	a0,a0,-1644 # a48 <malloc+0x13a>
  bc:	79a000ef          	jal	856 <printf>
    exit(1);
  c0:	4505                	li	a0,1
  c2:	310000ef          	jal	3d2 <exit>
      printf("COW FAILED: same physical page after write!\n");
  c6:	00001517          	auipc	a0,0x1
  ca:	a2a50513          	addi	a0,a0,-1494 # af0 <malloc+0x1e2>
  ce:	788000ef          	jal	856 <printf>
  d2:	b7c9                	j	94 <main+0x94>
  } else {
    wait(0);
  d4:	4501                	li	a0,0
  d6:	304000ef          	jal	3da <wait>
    uint64 pa_parent_after = va2pa((uint64)p);
  da:	8526                	mv	a0,s1
  dc:	3c6000ef          	jal	4a2 <va2pa>
  e0:	89aa                	mv	s3,a0
    printf("parent AFTER child exit: p[0] = %c, va = %p, pa = 0x%p\n",
  e2:	86aa                	mv	a3,a0
  e4:	8626                	mv	a2,s1
  e6:	0004c583          	lbu	a1,0(s1)
  ea:	00001517          	auipc	a0,0x1
  ee:	a3650513          	addi	a0,a0,-1482 # b20 <malloc+0x212>
  f2:	764000ef          	jal	856 <printf>
           p[0], p, (void*)pa_parent_after);

    if (pa_parent_before == pa_parent_after)
  f6:	01390b63          	beq	s2,s3,10c <main+0x10c>
      printf("Parent page unchanged.\n");
    else
      printf("Parent page changed (unexpected!).\n");
  fa:	00001517          	auipc	a0,0x1
  fe:	a7650513          	addi	a0,a0,-1418 # b70 <malloc+0x262>
 102:	754000ef          	jal	856 <printf>
  }

  exit(0);
 106:	4501                	li	a0,0
 108:	2ca000ef          	jal	3d2 <exit>
      printf("Parent page unchanged.\n");
 10c:	00001517          	auipc	a0,0x1
 110:	a4c50513          	addi	a0,a0,-1460 # b58 <malloc+0x24a>
 114:	742000ef          	jal	856 <printf>
 118:	b7fd                	j	106 <main+0x106>

000000000000011a <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 11a:	1141                	addi	sp,sp,-16
 11c:	e406                	sd	ra,8(sp)
 11e:	e022                	sd	s0,0(sp)
 120:	0800                	addi	s0,sp,16
  extern int main();
  main();
 122:	edfff0ef          	jal	0 <main>
  exit(0);
 126:	4501                	li	a0,0
 128:	2aa000ef          	jal	3d2 <exit>

000000000000012c <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 12c:	1141                	addi	sp,sp,-16
 12e:	e406                	sd	ra,8(sp)
 130:	e022                	sd	s0,0(sp)
 132:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 134:	87aa                	mv	a5,a0
 136:	0585                	addi	a1,a1,1
 138:	0785                	addi	a5,a5,1
 13a:	fff5c703          	lbu	a4,-1(a1)
 13e:	fee78fa3          	sb	a4,-1(a5)
 142:	fb75                	bnez	a4,136 <strcpy+0xa>
    ;
  return os;
}
 144:	60a2                	ld	ra,8(sp)
 146:	6402                	ld	s0,0(sp)
 148:	0141                	addi	sp,sp,16
 14a:	8082                	ret

000000000000014c <strcmp>:

int
strcmp(const char *p, const char *q)
{
 14c:	1141                	addi	sp,sp,-16
 14e:	e406                	sd	ra,8(sp)
 150:	e022                	sd	s0,0(sp)
 152:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 154:	00054783          	lbu	a5,0(a0)
 158:	cb91                	beqz	a5,16c <strcmp+0x20>
 15a:	0005c703          	lbu	a4,0(a1)
 15e:	00f71763          	bne	a4,a5,16c <strcmp+0x20>
    p++, q++;
 162:	0505                	addi	a0,a0,1
 164:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 166:	00054783          	lbu	a5,0(a0)
 16a:	fbe5                	bnez	a5,15a <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 16c:	0005c503          	lbu	a0,0(a1)
}
 170:	40a7853b          	subw	a0,a5,a0
 174:	60a2                	ld	ra,8(sp)
 176:	6402                	ld	s0,0(sp)
 178:	0141                	addi	sp,sp,16
 17a:	8082                	ret

000000000000017c <strlen>:

uint
strlen(const char *s)
{
 17c:	1141                	addi	sp,sp,-16
 17e:	e406                	sd	ra,8(sp)
 180:	e022                	sd	s0,0(sp)
 182:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 184:	00054783          	lbu	a5,0(a0)
 188:	cf91                	beqz	a5,1a4 <strlen+0x28>
 18a:	00150793          	addi	a5,a0,1
 18e:	86be                	mv	a3,a5
 190:	0785                	addi	a5,a5,1
 192:	fff7c703          	lbu	a4,-1(a5)
 196:	ff65                	bnez	a4,18e <strlen+0x12>
 198:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 19c:	60a2                	ld	ra,8(sp)
 19e:	6402                	ld	s0,0(sp)
 1a0:	0141                	addi	sp,sp,16
 1a2:	8082                	ret
  for(n = 0; s[n]; n++)
 1a4:	4501                	li	a0,0
 1a6:	bfdd                	j	19c <strlen+0x20>

00000000000001a8 <memset>:

void*
memset(void *dst, int c, uint n)
{
 1a8:	1141                	addi	sp,sp,-16
 1aa:	e406                	sd	ra,8(sp)
 1ac:	e022                	sd	s0,0(sp)
 1ae:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 1b0:	ca19                	beqz	a2,1c6 <memset+0x1e>
 1b2:	87aa                	mv	a5,a0
 1b4:	1602                	slli	a2,a2,0x20
 1b6:	9201                	srli	a2,a2,0x20
 1b8:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 1bc:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 1c0:	0785                	addi	a5,a5,1
 1c2:	fee79de3          	bne	a5,a4,1bc <memset+0x14>
  }
  return dst;
}
 1c6:	60a2                	ld	ra,8(sp)
 1c8:	6402                	ld	s0,0(sp)
 1ca:	0141                	addi	sp,sp,16
 1cc:	8082                	ret

00000000000001ce <strchr>:

char*
strchr(const char *s, char c)
{
 1ce:	1141                	addi	sp,sp,-16
 1d0:	e406                	sd	ra,8(sp)
 1d2:	e022                	sd	s0,0(sp)
 1d4:	0800                	addi	s0,sp,16
  for(; *s; s++)
 1d6:	00054783          	lbu	a5,0(a0)
 1da:	cf81                	beqz	a5,1f2 <strchr+0x24>
    if(*s == c)
 1dc:	00f58763          	beq	a1,a5,1ea <strchr+0x1c>
  for(; *s; s++)
 1e0:	0505                	addi	a0,a0,1
 1e2:	00054783          	lbu	a5,0(a0)
 1e6:	fbfd                	bnez	a5,1dc <strchr+0xe>
      return (char*)s;
  return 0;
 1e8:	4501                	li	a0,0
}
 1ea:	60a2                	ld	ra,8(sp)
 1ec:	6402                	ld	s0,0(sp)
 1ee:	0141                	addi	sp,sp,16
 1f0:	8082                	ret
  return 0;
 1f2:	4501                	li	a0,0
 1f4:	bfdd                	j	1ea <strchr+0x1c>

00000000000001f6 <gets>:

char*
gets(char *buf, int max)
{
 1f6:	711d                	addi	sp,sp,-96
 1f8:	ec86                	sd	ra,88(sp)
 1fa:	e8a2                	sd	s0,80(sp)
 1fc:	e4a6                	sd	s1,72(sp)
 1fe:	e0ca                	sd	s2,64(sp)
 200:	fc4e                	sd	s3,56(sp)
 202:	f852                	sd	s4,48(sp)
 204:	f456                	sd	s5,40(sp)
 206:	f05a                	sd	s6,32(sp)
 208:	ec5e                	sd	s7,24(sp)
 20a:	e862                	sd	s8,16(sp)
 20c:	1080                	addi	s0,sp,96
 20e:	8baa                	mv	s7,a0
 210:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 212:	892a                	mv	s2,a0
 214:	4481                	li	s1,0
    cc = read(0, &c, 1);
 216:	faf40b13          	addi	s6,s0,-81
 21a:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 21c:	8c26                	mv	s8,s1
 21e:	0014899b          	addiw	s3,s1,1
 222:	84ce                	mv	s1,s3
 224:	0349d463          	bge	s3,s4,24c <gets+0x56>
    cc = read(0, &c, 1);
 228:	8656                	mv	a2,s5
 22a:	85da                	mv	a1,s6
 22c:	4501                	li	a0,0
 22e:	1bc000ef          	jal	3ea <read>
    if(cc < 1)
 232:	00a05d63          	blez	a0,24c <gets+0x56>
      break;
    buf[i++] = c;
 236:	faf44783          	lbu	a5,-81(s0)
 23a:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 23e:	0905                	addi	s2,s2,1
 240:	ff678713          	addi	a4,a5,-10
 244:	c319                	beqz	a4,24a <gets+0x54>
 246:	17cd                	addi	a5,a5,-13
 248:	fbf1                	bnez	a5,21c <gets+0x26>
    buf[i++] = c;
 24a:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 24c:	9c5e                	add	s8,s8,s7
 24e:	000c0023          	sb	zero,0(s8)
  return buf;
}
 252:	855e                	mv	a0,s7
 254:	60e6                	ld	ra,88(sp)
 256:	6446                	ld	s0,80(sp)
 258:	64a6                	ld	s1,72(sp)
 25a:	6906                	ld	s2,64(sp)
 25c:	79e2                	ld	s3,56(sp)
 25e:	7a42                	ld	s4,48(sp)
 260:	7aa2                	ld	s5,40(sp)
 262:	7b02                	ld	s6,32(sp)
 264:	6be2                	ld	s7,24(sp)
 266:	6c42                	ld	s8,16(sp)
 268:	6125                	addi	sp,sp,96
 26a:	8082                	ret

000000000000026c <stat>:

int
stat(const char *n, struct stat *st)
{
 26c:	1101                	addi	sp,sp,-32
 26e:	ec06                	sd	ra,24(sp)
 270:	e822                	sd	s0,16(sp)
 272:	e04a                	sd	s2,0(sp)
 274:	1000                	addi	s0,sp,32
 276:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 278:	4581                	li	a1,0
 27a:	198000ef          	jal	412 <open>
  if(fd < 0)
 27e:	02054263          	bltz	a0,2a2 <stat+0x36>
 282:	e426                	sd	s1,8(sp)
 284:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 286:	85ca                	mv	a1,s2
 288:	1a2000ef          	jal	42a <fstat>
 28c:	892a                	mv	s2,a0
  close(fd);
 28e:	8526                	mv	a0,s1
 290:	16a000ef          	jal	3fa <close>
  return r;
 294:	64a2                	ld	s1,8(sp)
}
 296:	854a                	mv	a0,s2
 298:	60e2                	ld	ra,24(sp)
 29a:	6442                	ld	s0,16(sp)
 29c:	6902                	ld	s2,0(sp)
 29e:	6105                	addi	sp,sp,32
 2a0:	8082                	ret
    return -1;
 2a2:	57fd                	li	a5,-1
 2a4:	893e                	mv	s2,a5
 2a6:	bfc5                	j	296 <stat+0x2a>

00000000000002a8 <atoi>:

int
atoi(const char *s)
{
 2a8:	1141                	addi	sp,sp,-16
 2aa:	e406                	sd	ra,8(sp)
 2ac:	e022                	sd	s0,0(sp)
 2ae:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 2b0:	00054683          	lbu	a3,0(a0)
 2b4:	fd06879b          	addiw	a5,a3,-48
 2b8:	0ff7f793          	zext.b	a5,a5
 2bc:	4625                	li	a2,9
 2be:	02f66963          	bltu	a2,a5,2f0 <atoi+0x48>
 2c2:	872a                	mv	a4,a0
  n = 0;
 2c4:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 2c6:	0705                	addi	a4,a4,1
 2c8:	0025179b          	slliw	a5,a0,0x2
 2cc:	9fa9                	addw	a5,a5,a0
 2ce:	0017979b          	slliw	a5,a5,0x1
 2d2:	9fb5                	addw	a5,a5,a3
 2d4:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 2d8:	00074683          	lbu	a3,0(a4)
 2dc:	fd06879b          	addiw	a5,a3,-48
 2e0:	0ff7f793          	zext.b	a5,a5
 2e4:	fef671e3          	bgeu	a2,a5,2c6 <atoi+0x1e>
  return n;
}
 2e8:	60a2                	ld	ra,8(sp)
 2ea:	6402                	ld	s0,0(sp)
 2ec:	0141                	addi	sp,sp,16
 2ee:	8082                	ret
  n = 0;
 2f0:	4501                	li	a0,0
 2f2:	bfdd                	j	2e8 <atoi+0x40>

00000000000002f4 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 2f4:	1141                	addi	sp,sp,-16
 2f6:	e406                	sd	ra,8(sp)
 2f8:	e022                	sd	s0,0(sp)
 2fa:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2fc:	02b57563          	bgeu	a0,a1,326 <memmove+0x32>
    while(n-- > 0)
 300:	00c05f63          	blez	a2,31e <memmove+0x2a>
 304:	1602                	slli	a2,a2,0x20
 306:	9201                	srli	a2,a2,0x20
 308:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 30c:	872a                	mv	a4,a0
      *dst++ = *src++;
 30e:	0585                	addi	a1,a1,1
 310:	0705                	addi	a4,a4,1
 312:	fff5c683          	lbu	a3,-1(a1)
 316:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 31a:	fee79ae3          	bne	a5,a4,30e <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 31e:	60a2                	ld	ra,8(sp)
 320:	6402                	ld	s0,0(sp)
 322:	0141                	addi	sp,sp,16
 324:	8082                	ret
    while(n-- > 0)
 326:	fec05ce3          	blez	a2,31e <memmove+0x2a>
    dst += n;
 32a:	00c50733          	add	a4,a0,a2
    src += n;
 32e:	95b2                	add	a1,a1,a2
 330:	fff6079b          	addiw	a5,a2,-1
 334:	1782                	slli	a5,a5,0x20
 336:	9381                	srli	a5,a5,0x20
 338:	fff7c793          	not	a5,a5
 33c:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 33e:	15fd                	addi	a1,a1,-1
 340:	177d                	addi	a4,a4,-1
 342:	0005c683          	lbu	a3,0(a1)
 346:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 34a:	fef71ae3          	bne	a4,a5,33e <memmove+0x4a>
 34e:	bfc1                	j	31e <memmove+0x2a>

0000000000000350 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 350:	1141                	addi	sp,sp,-16
 352:	e406                	sd	ra,8(sp)
 354:	e022                	sd	s0,0(sp)
 356:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 358:	c61d                	beqz	a2,386 <memcmp+0x36>
 35a:	1602                	slli	a2,a2,0x20
 35c:	9201                	srli	a2,a2,0x20
 35e:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 362:	00054783          	lbu	a5,0(a0)
 366:	0005c703          	lbu	a4,0(a1)
 36a:	00e79863          	bne	a5,a4,37a <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 36e:	0505                	addi	a0,a0,1
    p2++;
 370:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 372:	fed518e3          	bne	a0,a3,362 <memcmp+0x12>
  }
  return 0;
 376:	4501                	li	a0,0
 378:	a019                	j	37e <memcmp+0x2e>
      return *p1 - *p2;
 37a:	40e7853b          	subw	a0,a5,a4
}
 37e:	60a2                	ld	ra,8(sp)
 380:	6402                	ld	s0,0(sp)
 382:	0141                	addi	sp,sp,16
 384:	8082                	ret
  return 0;
 386:	4501                	li	a0,0
 388:	bfdd                	j	37e <memcmp+0x2e>

000000000000038a <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 38a:	1141                	addi	sp,sp,-16
 38c:	e406                	sd	ra,8(sp)
 38e:	e022                	sd	s0,0(sp)
 390:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 392:	f63ff0ef          	jal	2f4 <memmove>
}
 396:	60a2                	ld	ra,8(sp)
 398:	6402                	ld	s0,0(sp)
 39a:	0141                	addi	sp,sp,16
 39c:	8082                	ret

000000000000039e <sbrk>:

char *
sbrk(int n) {
 39e:	1141                	addi	sp,sp,-16
 3a0:	e406                	sd	ra,8(sp)
 3a2:	e022                	sd	s0,0(sp)
 3a4:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 3a6:	4585                	li	a1,1
 3a8:	0b2000ef          	jal	45a <sys_sbrk>
}
 3ac:	60a2                	ld	ra,8(sp)
 3ae:	6402                	ld	s0,0(sp)
 3b0:	0141                	addi	sp,sp,16
 3b2:	8082                	ret

00000000000003b4 <sbrklazy>:

char *
sbrklazy(int n) {
 3b4:	1141                	addi	sp,sp,-16
 3b6:	e406                	sd	ra,8(sp)
 3b8:	e022                	sd	s0,0(sp)
 3ba:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 3bc:	4589                	li	a1,2
 3be:	09c000ef          	jal	45a <sys_sbrk>
}
 3c2:	60a2                	ld	ra,8(sp)
 3c4:	6402                	ld	s0,0(sp)
 3c6:	0141                	addi	sp,sp,16
 3c8:	8082                	ret

00000000000003ca <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3ca:	4885                	li	a7,1
 ecall
 3cc:	00000073          	ecall
 ret
 3d0:	8082                	ret

00000000000003d2 <exit>:
.global exit
exit:
 li a7, SYS_exit
 3d2:	4889                	li	a7,2
 ecall
 3d4:	00000073          	ecall
 ret
 3d8:	8082                	ret

00000000000003da <wait>:
.global wait
wait:
 li a7, SYS_wait
 3da:	488d                	li	a7,3
 ecall
 3dc:	00000073          	ecall
 ret
 3e0:	8082                	ret

00000000000003e2 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 3e2:	4891                	li	a7,4
 ecall
 3e4:	00000073          	ecall
 ret
 3e8:	8082                	ret

00000000000003ea <read>:
.global read
read:
 li a7, SYS_read
 3ea:	4895                	li	a7,5
 ecall
 3ec:	00000073          	ecall
 ret
 3f0:	8082                	ret

00000000000003f2 <write>:
.global write
write:
 li a7, SYS_write
 3f2:	48c1                	li	a7,16
 ecall
 3f4:	00000073          	ecall
 ret
 3f8:	8082                	ret

00000000000003fa <close>:
.global close
close:
 li a7, SYS_close
 3fa:	48d5                	li	a7,21
 ecall
 3fc:	00000073          	ecall
 ret
 400:	8082                	ret

0000000000000402 <kill>:
.global kill
kill:
 li a7, SYS_kill
 402:	4899                	li	a7,6
 ecall
 404:	00000073          	ecall
 ret
 408:	8082                	ret

000000000000040a <exec>:
.global exec
exec:
 li a7, SYS_exec
 40a:	489d                	li	a7,7
 ecall
 40c:	00000073          	ecall
 ret
 410:	8082                	ret

0000000000000412 <open>:
.global open
open:
 li a7, SYS_open
 412:	48bd                	li	a7,15
 ecall
 414:	00000073          	ecall
 ret
 418:	8082                	ret

000000000000041a <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 41a:	48c5                	li	a7,17
 ecall
 41c:	00000073          	ecall
 ret
 420:	8082                	ret

0000000000000422 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 422:	48c9                	li	a7,18
 ecall
 424:	00000073          	ecall
 ret
 428:	8082                	ret

000000000000042a <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 42a:	48a1                	li	a7,8
 ecall
 42c:	00000073          	ecall
 ret
 430:	8082                	ret

0000000000000432 <link>:
.global link
link:
 li a7, SYS_link
 432:	48cd                	li	a7,19
 ecall
 434:	00000073          	ecall
 ret
 438:	8082                	ret

000000000000043a <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 43a:	48d1                	li	a7,20
 ecall
 43c:	00000073          	ecall
 ret
 440:	8082                	ret

0000000000000442 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 442:	48a5                	li	a7,9
 ecall
 444:	00000073          	ecall
 ret
 448:	8082                	ret

000000000000044a <dup>:
.global dup
dup:
 li a7, SYS_dup
 44a:	48a9                	li	a7,10
 ecall
 44c:	00000073          	ecall
 ret
 450:	8082                	ret

0000000000000452 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 452:	48ad                	li	a7,11
 ecall
 454:	00000073          	ecall
 ret
 458:	8082                	ret

000000000000045a <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 45a:	48b1                	li	a7,12
 ecall
 45c:	00000073          	ecall
 ret
 460:	8082                	ret

0000000000000462 <pause>:
.global pause
pause:
 li a7, SYS_pause
 462:	48b5                	li	a7,13
 ecall
 464:	00000073          	ecall
 ret
 468:	8082                	ret

000000000000046a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 46a:	48b9                	li	a7,14
 ecall
 46c:	00000073          	ecall
 ret
 470:	8082                	ret

0000000000000472 <shm_create>:
.global shm_create
shm_create:
 li a7, SYS_shm_create
 472:	48d9                	li	a7,22
 ecall
 474:	00000073          	ecall
 ret
 478:	8082                	ret

000000000000047a <shm_get>:
.global shm_get
shm_get:
 li a7, SYS_shm_get
 47a:	48dd                	li	a7,23
 ecall
 47c:	00000073          	ecall
 ret
 480:	8082                	ret

0000000000000482 <shm_close>:
.global shm_close
shm_close:
 li a7, SYS_shm_close
 482:	48e1                	li	a7,24
 ecall
 484:	00000073          	ecall
 ret
 488:	8082                	ret

000000000000048a <mbox_create>:
.global mbox_create
mbox_create:
 li a7, SYS_mbox_create
 48a:	48e5                	li	a7,25
 ecall
 48c:	00000073          	ecall
 ret
 490:	8082                	ret

0000000000000492 <mbox_send>:
.global mbox_send
mbox_send:
 li a7, SYS_mbox_send
 492:	48e9                	li	a7,26
 ecall
 494:	00000073          	ecall
 ret
 498:	8082                	ret

000000000000049a <mbox_recv>:
.global mbox_recv
mbox_recv:
 li a7, SYS_mbox_recv
 49a:	48ed                	li	a7,27
 ecall
 49c:	00000073          	ecall
 ret
 4a0:	8082                	ret

00000000000004a2 <va2pa>:
.global va2pa
va2pa:
 li a7, SYS_va2pa
 4a2:	48f1                	li	a7,28
 ecall
 4a4:	00000073          	ecall
 ret
 4a8:	8082                	ret

00000000000004aa <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 4aa:	1101                	addi	sp,sp,-32
 4ac:	ec06                	sd	ra,24(sp)
 4ae:	e822                	sd	s0,16(sp)
 4b0:	1000                	addi	s0,sp,32
 4b2:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 4b6:	4605                	li	a2,1
 4b8:	fef40593          	addi	a1,s0,-17
 4bc:	f37ff0ef          	jal	3f2 <write>
}
 4c0:	60e2                	ld	ra,24(sp)
 4c2:	6442                	ld	s0,16(sp)
 4c4:	6105                	addi	sp,sp,32
 4c6:	8082                	ret

00000000000004c8 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 4c8:	715d                	addi	sp,sp,-80
 4ca:	e486                	sd	ra,72(sp)
 4cc:	e0a2                	sd	s0,64(sp)
 4ce:	f84a                	sd	s2,48(sp)
 4d0:	f44e                	sd	s3,40(sp)
 4d2:	0880                	addi	s0,sp,80
 4d4:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 4d6:	cac1                	beqz	a3,566 <printint+0x9e>
 4d8:	0805d763          	bgez	a1,566 <printint+0x9e>
    neg = 1;
    x = -xx;
 4dc:	40b005bb          	negw	a1,a1
    neg = 1;
 4e0:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 4e2:	fb840993          	addi	s3,s0,-72
  neg = 0;
 4e6:	86ce                	mv	a3,s3
  i = 0;
 4e8:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 4ea:	00000817          	auipc	a6,0x0
 4ee:	6b680813          	addi	a6,a6,1718 # ba0 <digits>
 4f2:	88ba                	mv	a7,a4
 4f4:	0017051b          	addiw	a0,a4,1
 4f8:	872a                	mv	a4,a0
 4fa:	02c5f7bb          	remuw	a5,a1,a2
 4fe:	1782                	slli	a5,a5,0x20
 500:	9381                	srli	a5,a5,0x20
 502:	97c2                	add	a5,a5,a6
 504:	0007c783          	lbu	a5,0(a5)
 508:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 50c:	87ae                	mv	a5,a1
 50e:	02c5d5bb          	divuw	a1,a1,a2
 512:	0685                	addi	a3,a3,1
 514:	fcc7ffe3          	bgeu	a5,a2,4f2 <printint+0x2a>
  if(neg)
 518:	00030c63          	beqz	t1,530 <printint+0x68>
    buf[i++] = '-';
 51c:	fd050793          	addi	a5,a0,-48
 520:	00878533          	add	a0,a5,s0
 524:	02d00793          	li	a5,45
 528:	fef50423          	sb	a5,-24(a0)
 52c:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 530:	02e05563          	blez	a4,55a <printint+0x92>
 534:	fc26                	sd	s1,56(sp)
 536:	377d                	addiw	a4,a4,-1
 538:	00e984b3          	add	s1,s3,a4
 53c:	19fd                	addi	s3,s3,-1
 53e:	99ba                	add	s3,s3,a4
 540:	1702                	slli	a4,a4,0x20
 542:	9301                	srli	a4,a4,0x20
 544:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 548:	0004c583          	lbu	a1,0(s1)
 54c:	854a                	mv	a0,s2
 54e:	f5dff0ef          	jal	4aa <putc>
  while(--i >= 0)
 552:	14fd                	addi	s1,s1,-1
 554:	ff349ae3          	bne	s1,s3,548 <printint+0x80>
 558:	74e2                	ld	s1,56(sp)
}
 55a:	60a6                	ld	ra,72(sp)
 55c:	6406                	ld	s0,64(sp)
 55e:	7942                	ld	s2,48(sp)
 560:	79a2                	ld	s3,40(sp)
 562:	6161                	addi	sp,sp,80
 564:	8082                	ret
    x = xx;
 566:	2581                	sext.w	a1,a1
  neg = 0;
 568:	4301                	li	t1,0
 56a:	bfa5                	j	4e2 <printint+0x1a>

000000000000056c <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 56c:	711d                	addi	sp,sp,-96
 56e:	ec86                	sd	ra,88(sp)
 570:	e8a2                	sd	s0,80(sp)
 572:	e4a6                	sd	s1,72(sp)
 574:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 576:	0005c483          	lbu	s1,0(a1)
 57a:	22048363          	beqz	s1,7a0 <vprintf+0x234>
 57e:	e0ca                	sd	s2,64(sp)
 580:	fc4e                	sd	s3,56(sp)
 582:	f852                	sd	s4,48(sp)
 584:	f456                	sd	s5,40(sp)
 586:	f05a                	sd	s6,32(sp)
 588:	ec5e                	sd	s7,24(sp)
 58a:	e862                	sd	s8,16(sp)
 58c:	8b2a                	mv	s6,a0
 58e:	8a2e                	mv	s4,a1
 590:	8bb2                	mv	s7,a2
  state = 0;
 592:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 594:	4901                	li	s2,0
 596:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 598:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 59c:	06400c13          	li	s8,100
 5a0:	a00d                	j	5c2 <vprintf+0x56>
        putc(fd, c0);
 5a2:	85a6                	mv	a1,s1
 5a4:	855a                	mv	a0,s6
 5a6:	f05ff0ef          	jal	4aa <putc>
 5aa:	a019                	j	5b0 <vprintf+0x44>
    } else if(state == '%'){
 5ac:	03598363          	beq	s3,s5,5d2 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 5b0:	0019079b          	addiw	a5,s2,1
 5b4:	893e                	mv	s2,a5
 5b6:	873e                	mv	a4,a5
 5b8:	97d2                	add	a5,a5,s4
 5ba:	0007c483          	lbu	s1,0(a5)
 5be:	1c048a63          	beqz	s1,792 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 5c2:	0004879b          	sext.w	a5,s1
    if(state == 0){
 5c6:	fe0993e3          	bnez	s3,5ac <vprintf+0x40>
      if(c0 == '%'){
 5ca:	fd579ce3          	bne	a5,s5,5a2 <vprintf+0x36>
        state = '%';
 5ce:	89be                	mv	s3,a5
 5d0:	b7c5                	j	5b0 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 5d2:	00ea06b3          	add	a3,s4,a4
 5d6:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 5da:	1c060863          	beqz	a2,7aa <vprintf+0x23e>
      if(c0 == 'd'){
 5de:	03878763          	beq	a5,s8,60c <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5e2:	f9478693          	addi	a3,a5,-108
 5e6:	0016b693          	seqz	a3,a3
 5ea:	f9c60593          	addi	a1,a2,-100
 5ee:	e99d                	bnez	a1,624 <vprintf+0xb8>
 5f0:	ca95                	beqz	a3,624 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5f2:	008b8493          	addi	s1,s7,8
 5f6:	4685                	li	a3,1
 5f8:	4629                	li	a2,10
 5fa:	000bb583          	ld	a1,0(s7)
 5fe:	855a                	mv	a0,s6
 600:	ec9ff0ef          	jal	4c8 <printint>
        i += 1;
 604:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 606:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 608:	4981                	li	s3,0
 60a:	b75d                	j	5b0 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 60c:	008b8493          	addi	s1,s7,8
 610:	4685                	li	a3,1
 612:	4629                	li	a2,10
 614:	000ba583          	lw	a1,0(s7)
 618:	855a                	mv	a0,s6
 61a:	eafff0ef          	jal	4c8 <printint>
 61e:	8ba6                	mv	s7,s1
      state = 0;
 620:	4981                	li	s3,0
 622:	b779                	j	5b0 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 624:	9752                	add	a4,a4,s4
 626:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 62a:	f9460713          	addi	a4,a2,-108
 62e:	00173713          	seqz	a4,a4
 632:	8f75                	and	a4,a4,a3
 634:	f9c58513          	addi	a0,a1,-100
 638:	18051363          	bnez	a0,7be <vprintf+0x252>
 63c:	18070163          	beqz	a4,7be <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 640:	008b8493          	addi	s1,s7,8
 644:	4685                	li	a3,1
 646:	4629                	li	a2,10
 648:	000bb583          	ld	a1,0(s7)
 64c:	855a                	mv	a0,s6
 64e:	e7bff0ef          	jal	4c8 <printint>
        i += 2;
 652:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 654:	8ba6                	mv	s7,s1
      state = 0;
 656:	4981                	li	s3,0
        i += 2;
 658:	bfa1                	j	5b0 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 65a:	008b8493          	addi	s1,s7,8
 65e:	4681                	li	a3,0
 660:	4629                	li	a2,10
 662:	000be583          	lwu	a1,0(s7)
 666:	855a                	mv	a0,s6
 668:	e61ff0ef          	jal	4c8 <printint>
 66c:	8ba6                	mv	s7,s1
      state = 0;
 66e:	4981                	li	s3,0
 670:	b781                	j	5b0 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 672:	008b8493          	addi	s1,s7,8
 676:	4681                	li	a3,0
 678:	4629                	li	a2,10
 67a:	000bb583          	ld	a1,0(s7)
 67e:	855a                	mv	a0,s6
 680:	e49ff0ef          	jal	4c8 <printint>
        i += 1;
 684:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 686:	8ba6                	mv	s7,s1
      state = 0;
 688:	4981                	li	s3,0
 68a:	b71d                	j	5b0 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 68c:	008b8493          	addi	s1,s7,8
 690:	4681                	li	a3,0
 692:	4629                	li	a2,10
 694:	000bb583          	ld	a1,0(s7)
 698:	855a                	mv	a0,s6
 69a:	e2fff0ef          	jal	4c8 <printint>
        i += 2;
 69e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 6a0:	8ba6                	mv	s7,s1
      state = 0;
 6a2:	4981                	li	s3,0
        i += 2;
 6a4:	b731                	j	5b0 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 6a6:	008b8493          	addi	s1,s7,8
 6aa:	4681                	li	a3,0
 6ac:	4641                	li	a2,16
 6ae:	000be583          	lwu	a1,0(s7)
 6b2:	855a                	mv	a0,s6
 6b4:	e15ff0ef          	jal	4c8 <printint>
 6b8:	8ba6                	mv	s7,s1
      state = 0;
 6ba:	4981                	li	s3,0
 6bc:	bdd5                	j	5b0 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6be:	008b8493          	addi	s1,s7,8
 6c2:	4681                	li	a3,0
 6c4:	4641                	li	a2,16
 6c6:	000bb583          	ld	a1,0(s7)
 6ca:	855a                	mv	a0,s6
 6cc:	dfdff0ef          	jal	4c8 <printint>
        i += 1;
 6d0:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 6d2:	8ba6                	mv	s7,s1
      state = 0;
 6d4:	4981                	li	s3,0
 6d6:	bde9                	j	5b0 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6d8:	008b8493          	addi	s1,s7,8
 6dc:	4681                	li	a3,0
 6de:	4641                	li	a2,16
 6e0:	000bb583          	ld	a1,0(s7)
 6e4:	855a                	mv	a0,s6
 6e6:	de3ff0ef          	jal	4c8 <printint>
        i += 2;
 6ea:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6ec:	8ba6                	mv	s7,s1
      state = 0;
 6ee:	4981                	li	s3,0
        i += 2;
 6f0:	b5c1                	j	5b0 <vprintf+0x44>
 6f2:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 6f4:	008b8793          	addi	a5,s7,8
 6f8:	8cbe                	mv	s9,a5
 6fa:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6fe:	03000593          	li	a1,48
 702:	855a                	mv	a0,s6
 704:	da7ff0ef          	jal	4aa <putc>
  putc(fd, 'x');
 708:	07800593          	li	a1,120
 70c:	855a                	mv	a0,s6
 70e:	d9dff0ef          	jal	4aa <putc>
 712:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 714:	00000b97          	auipc	s7,0x0
 718:	48cb8b93          	addi	s7,s7,1164 # ba0 <digits>
 71c:	03c9d793          	srli	a5,s3,0x3c
 720:	97de                	add	a5,a5,s7
 722:	0007c583          	lbu	a1,0(a5)
 726:	855a                	mv	a0,s6
 728:	d83ff0ef          	jal	4aa <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 72c:	0992                	slli	s3,s3,0x4
 72e:	34fd                	addiw	s1,s1,-1
 730:	f4f5                	bnez	s1,71c <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 732:	8be6                	mv	s7,s9
      state = 0;
 734:	4981                	li	s3,0
 736:	6ca2                	ld	s9,8(sp)
 738:	bda5                	j	5b0 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 73a:	008b8493          	addi	s1,s7,8
 73e:	000bc583          	lbu	a1,0(s7)
 742:	855a                	mv	a0,s6
 744:	d67ff0ef          	jal	4aa <putc>
 748:	8ba6                	mv	s7,s1
      state = 0;
 74a:	4981                	li	s3,0
 74c:	b595                	j	5b0 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 74e:	008b8993          	addi	s3,s7,8
 752:	000bb483          	ld	s1,0(s7)
 756:	cc91                	beqz	s1,772 <vprintf+0x206>
        for(; *s; s++)
 758:	0004c583          	lbu	a1,0(s1)
 75c:	c985                	beqz	a1,78c <vprintf+0x220>
          putc(fd, *s);
 75e:	855a                	mv	a0,s6
 760:	d4bff0ef          	jal	4aa <putc>
        for(; *s; s++)
 764:	0485                	addi	s1,s1,1
 766:	0004c583          	lbu	a1,0(s1)
 76a:	f9f5                	bnez	a1,75e <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 76c:	8bce                	mv	s7,s3
      state = 0;
 76e:	4981                	li	s3,0
 770:	b581                	j	5b0 <vprintf+0x44>
          s = "(null)";
 772:	00000497          	auipc	s1,0x0
 776:	42648493          	addi	s1,s1,1062 # b98 <malloc+0x28a>
        for(; *s; s++)
 77a:	02800593          	li	a1,40
 77e:	b7c5                	j	75e <vprintf+0x1f2>
        putc(fd, '%');
 780:	85be                	mv	a1,a5
 782:	855a                	mv	a0,s6
 784:	d27ff0ef          	jal	4aa <putc>
      state = 0;
 788:	4981                	li	s3,0
 78a:	b51d                	j	5b0 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 78c:	8bce                	mv	s7,s3
      state = 0;
 78e:	4981                	li	s3,0
 790:	b505                	j	5b0 <vprintf+0x44>
 792:	6906                	ld	s2,64(sp)
 794:	79e2                	ld	s3,56(sp)
 796:	7a42                	ld	s4,48(sp)
 798:	7aa2                	ld	s5,40(sp)
 79a:	7b02                	ld	s6,32(sp)
 79c:	6be2                	ld	s7,24(sp)
 79e:	6c42                	ld	s8,16(sp)
    }
  }
}
 7a0:	60e6                	ld	ra,88(sp)
 7a2:	6446                	ld	s0,80(sp)
 7a4:	64a6                	ld	s1,72(sp)
 7a6:	6125                	addi	sp,sp,96
 7a8:	8082                	ret
      if(c0 == 'd'){
 7aa:	06400713          	li	a4,100
 7ae:	e4e78fe3          	beq	a5,a4,60c <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 7b2:	f9478693          	addi	a3,a5,-108
 7b6:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 7ba:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 7bc:	4701                	li	a4,0
      } else if(c0 == 'u'){
 7be:	07500513          	li	a0,117
 7c2:	e8a78ce3          	beq	a5,a0,65a <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 7c6:	f8b60513          	addi	a0,a2,-117
 7ca:	e119                	bnez	a0,7d0 <vprintf+0x264>
 7cc:	ea0693e3          	bnez	a3,672 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 7d0:	f8b58513          	addi	a0,a1,-117
 7d4:	e119                	bnez	a0,7da <vprintf+0x26e>
 7d6:	ea071be3          	bnez	a4,68c <vprintf+0x120>
      } else if(c0 == 'x'){
 7da:	07800513          	li	a0,120
 7de:	eca784e3          	beq	a5,a0,6a6 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 7e2:	f8860613          	addi	a2,a2,-120
 7e6:	e219                	bnez	a2,7ec <vprintf+0x280>
 7e8:	ec069be3          	bnez	a3,6be <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 7ec:	f8858593          	addi	a1,a1,-120
 7f0:	e199                	bnez	a1,7f6 <vprintf+0x28a>
 7f2:	ee0713e3          	bnez	a4,6d8 <vprintf+0x16c>
      } else if(c0 == 'p'){
 7f6:	07000713          	li	a4,112
 7fa:	eee78ce3          	beq	a5,a4,6f2 <vprintf+0x186>
      } else if(c0 == 'c'){
 7fe:	06300713          	li	a4,99
 802:	f2e78ce3          	beq	a5,a4,73a <vprintf+0x1ce>
      } else if(c0 == 's'){
 806:	07300713          	li	a4,115
 80a:	f4e782e3          	beq	a5,a4,74e <vprintf+0x1e2>
      } else if(c0 == '%'){
 80e:	02500713          	li	a4,37
 812:	f6e787e3          	beq	a5,a4,780 <vprintf+0x214>
        putc(fd, '%');
 816:	02500593          	li	a1,37
 81a:	855a                	mv	a0,s6
 81c:	c8fff0ef          	jal	4aa <putc>
        putc(fd, c0);
 820:	85a6                	mv	a1,s1
 822:	855a                	mv	a0,s6
 824:	c87ff0ef          	jal	4aa <putc>
      state = 0;
 828:	4981                	li	s3,0
 82a:	b359                	j	5b0 <vprintf+0x44>

000000000000082c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 82c:	715d                	addi	sp,sp,-80
 82e:	ec06                	sd	ra,24(sp)
 830:	e822                	sd	s0,16(sp)
 832:	1000                	addi	s0,sp,32
 834:	e010                	sd	a2,0(s0)
 836:	e414                	sd	a3,8(s0)
 838:	e818                	sd	a4,16(s0)
 83a:	ec1c                	sd	a5,24(s0)
 83c:	03043023          	sd	a6,32(s0)
 840:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 844:	8622                	mv	a2,s0
 846:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 84a:	d23ff0ef          	jal	56c <vprintf>
}
 84e:	60e2                	ld	ra,24(sp)
 850:	6442                	ld	s0,16(sp)
 852:	6161                	addi	sp,sp,80
 854:	8082                	ret

0000000000000856 <printf>:

void
printf(const char *fmt, ...)
{
 856:	711d                	addi	sp,sp,-96
 858:	ec06                	sd	ra,24(sp)
 85a:	e822                	sd	s0,16(sp)
 85c:	1000                	addi	s0,sp,32
 85e:	e40c                	sd	a1,8(s0)
 860:	e810                	sd	a2,16(s0)
 862:	ec14                	sd	a3,24(s0)
 864:	f018                	sd	a4,32(s0)
 866:	f41c                	sd	a5,40(s0)
 868:	03043823          	sd	a6,48(s0)
 86c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 870:	00840613          	addi	a2,s0,8
 874:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 878:	85aa                	mv	a1,a0
 87a:	4505                	li	a0,1
 87c:	cf1ff0ef          	jal	56c <vprintf>
}
 880:	60e2                	ld	ra,24(sp)
 882:	6442                	ld	s0,16(sp)
 884:	6125                	addi	sp,sp,96
 886:	8082                	ret

0000000000000888 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 888:	1141                	addi	sp,sp,-16
 88a:	e406                	sd	ra,8(sp)
 88c:	e022                	sd	s0,0(sp)
 88e:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 890:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 894:	00000797          	auipc	a5,0x0
 898:	76c7b783          	ld	a5,1900(a5) # 1000 <freep>
 89c:	a039                	j	8aa <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 89e:	6398                	ld	a4,0(a5)
 8a0:	00e7e463          	bltu	a5,a4,8a8 <free+0x20>
 8a4:	00e6ea63          	bltu	a3,a4,8b8 <free+0x30>
{
 8a8:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8aa:	fed7fae3          	bgeu	a5,a3,89e <free+0x16>
 8ae:	6398                	ld	a4,0(a5)
 8b0:	00e6e463          	bltu	a3,a4,8b8 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8b4:	fee7eae3          	bltu	a5,a4,8a8 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 8b8:	ff852583          	lw	a1,-8(a0)
 8bc:	6390                	ld	a2,0(a5)
 8be:	02059813          	slli	a6,a1,0x20
 8c2:	01c85713          	srli	a4,a6,0x1c
 8c6:	9736                	add	a4,a4,a3
 8c8:	02e60563          	beq	a2,a4,8f2 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 8cc:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 8d0:	4790                	lw	a2,8(a5)
 8d2:	02061593          	slli	a1,a2,0x20
 8d6:	01c5d713          	srli	a4,a1,0x1c
 8da:	973e                	add	a4,a4,a5
 8dc:	02e68263          	beq	a3,a4,900 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 8e0:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 8e2:	00000717          	auipc	a4,0x0
 8e6:	70f73f23          	sd	a5,1822(a4) # 1000 <freep>
}
 8ea:	60a2                	ld	ra,8(sp)
 8ec:	6402                	ld	s0,0(sp)
 8ee:	0141                	addi	sp,sp,16
 8f0:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 8f2:	4618                	lw	a4,8(a2)
 8f4:	9f2d                	addw	a4,a4,a1
 8f6:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 8fa:	6398                	ld	a4,0(a5)
 8fc:	6310                	ld	a2,0(a4)
 8fe:	b7f9                	j	8cc <free+0x44>
    p->s.size += bp->s.size;
 900:	ff852703          	lw	a4,-8(a0)
 904:	9f31                	addw	a4,a4,a2
 906:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 908:	ff053683          	ld	a3,-16(a0)
 90c:	bfd1                	j	8e0 <free+0x58>

000000000000090e <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 90e:	7139                	addi	sp,sp,-64
 910:	fc06                	sd	ra,56(sp)
 912:	f822                	sd	s0,48(sp)
 914:	f04a                	sd	s2,32(sp)
 916:	ec4e                	sd	s3,24(sp)
 918:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 91a:	02051993          	slli	s3,a0,0x20
 91e:	0209d993          	srli	s3,s3,0x20
 922:	09bd                	addi	s3,s3,15
 924:	0049d993          	srli	s3,s3,0x4
 928:	2985                	addiw	s3,s3,1
 92a:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 92c:	00000517          	auipc	a0,0x0
 930:	6d453503          	ld	a0,1748(a0) # 1000 <freep>
 934:	c905                	beqz	a0,964 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 936:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 938:	4798                	lw	a4,8(a5)
 93a:	09377663          	bgeu	a4,s3,9c6 <malloc+0xb8>
 93e:	f426                	sd	s1,40(sp)
 940:	e852                	sd	s4,16(sp)
 942:	e456                	sd	s5,8(sp)
 944:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 946:	8a4e                	mv	s4,s3
 948:	6705                	lui	a4,0x1
 94a:	00e9f363          	bgeu	s3,a4,950 <malloc+0x42>
 94e:	6a05                	lui	s4,0x1
 950:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 954:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 958:	00000497          	auipc	s1,0x0
 95c:	6a848493          	addi	s1,s1,1704 # 1000 <freep>
  if(p == SBRK_ERROR)
 960:	5afd                	li	s5,-1
 962:	a83d                	j	9a0 <malloc+0x92>
 964:	f426                	sd	s1,40(sp)
 966:	e852                	sd	s4,16(sp)
 968:	e456                	sd	s5,8(sp)
 96a:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 96c:	00000797          	auipc	a5,0x0
 970:	6a478793          	addi	a5,a5,1700 # 1010 <base>
 974:	00000717          	auipc	a4,0x0
 978:	68f73623          	sd	a5,1676(a4) # 1000 <freep>
 97c:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 97e:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 982:	b7d1                	j	946 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 984:	6398                	ld	a4,0(a5)
 986:	e118                	sd	a4,0(a0)
 988:	a899                	j	9de <malloc+0xd0>
  hp->s.size = nu;
 98a:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 98e:	0541                	addi	a0,a0,16
 990:	ef9ff0ef          	jal	888 <free>
  return freep;
 994:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 996:	c125                	beqz	a0,9f6 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 998:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 99a:	4798                	lw	a4,8(a5)
 99c:	03277163          	bgeu	a4,s2,9be <malloc+0xb0>
    if(p == freep)
 9a0:	6098                	ld	a4,0(s1)
 9a2:	853e                	mv	a0,a5
 9a4:	fef71ae3          	bne	a4,a5,998 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 9a8:	8552                	mv	a0,s4
 9aa:	9f5ff0ef          	jal	39e <sbrk>
  if(p == SBRK_ERROR)
 9ae:	fd551ee3          	bne	a0,s5,98a <malloc+0x7c>
        return 0;
 9b2:	4501                	li	a0,0
 9b4:	74a2                	ld	s1,40(sp)
 9b6:	6a42                	ld	s4,16(sp)
 9b8:	6aa2                	ld	s5,8(sp)
 9ba:	6b02                	ld	s6,0(sp)
 9bc:	a03d                	j	9ea <malloc+0xdc>
 9be:	74a2                	ld	s1,40(sp)
 9c0:	6a42                	ld	s4,16(sp)
 9c2:	6aa2                	ld	s5,8(sp)
 9c4:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 9c6:	fae90fe3          	beq	s2,a4,984 <malloc+0x76>
        p->s.size -= nunits;
 9ca:	4137073b          	subw	a4,a4,s3
 9ce:	c798                	sw	a4,8(a5)
        p += p->s.size;
 9d0:	02071693          	slli	a3,a4,0x20
 9d4:	01c6d713          	srli	a4,a3,0x1c
 9d8:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 9da:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 9de:	00000717          	auipc	a4,0x0
 9e2:	62a73123          	sd	a0,1570(a4) # 1000 <freep>
      return (void*)(p + 1);
 9e6:	01078513          	addi	a0,a5,16
  }
}
 9ea:	70e2                	ld	ra,56(sp)
 9ec:	7442                	ld	s0,48(sp)
 9ee:	7902                	ld	s2,32(sp)
 9f0:	69e2                	ld	s3,24(sp)
 9f2:	6121                	addi	sp,sp,64
 9f4:	8082                	ret
 9f6:	74a2                	ld	s1,40(sp)
 9f8:	6a42                	ld	s4,16(sp)
 9fa:	6aa2                	ld	s5,8(sp)
 9fc:	6b02                	ld	s6,0(sp)
 9fe:	b7f5                	j	9ea <malloc+0xdc>
