// user/cowtest.c
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
  char *p = malloc(4096);
  if (p == 0) {
    printf("malloc failed\n");
    exit(1);
  }

  p[0] = 'A';
  uint64 pa_parent_before = va2pa((uint64)p);
  printf("parent BEFORE fork: p[0] = %c, va = %p, pa = 0x%p\n",
         p[0], p, (void*)pa_parent_before);

  int pid = fork();
  if (pid < 0) {
    printf("fork failed\n");
    exit(1);
  } else if (pid == 0) {
    uint64 pa_child_before = va2pa((uint64)p);
    printf("child BEFORE modifying: p[0] = %c, va = %p, pa = 0x%p\n",
           p[0], p, (void*)pa_child_before);

    p[0] = 'C';  // should trigger COW

    uint64 pa_child_after = va2pa((uint64)p);
    printf("child AFTER modifying:  p[0] = %c, va = %p, pa = 0x%p\n",
           p[0], p, (void*)pa_child_after);

    if (pa_child_before != pa_child_after)
      printf("COW SUCCESS: child got new page.\n");
    else
      printf("COW FAILED: same physical page after write!\n");

    exit(0);
  } else {
    wait(0);
    uint64 pa_parent_after = va2pa((uint64)p);
    printf("parent AFTER child exit: p[0] = %c, va = %p, pa = 0x%p\n",
           p[0], p, (void*)pa_parent_after);

    if (pa_parent_before == pa_parent_after)
      printf("Parent page unchanged.\n");
    else
      printf("Parent page changed (unexpected!).\n");
  }

  exit(0);
}