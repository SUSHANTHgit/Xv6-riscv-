
user/_grep:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <matchstar>:
  return 0;
}

// matchstar: search for c*re at beginning of text
int matchstar(int c, char *re, char *text)
{
   0:	7179                	addi	sp,sp,-48
   2:	f406                	sd	ra,40(sp)
   4:	f022                	sd	s0,32(sp)
   6:	ec26                	sd	s1,24(sp)
   8:	e84a                	sd	s2,16(sp)
   a:	e44e                	sd	s3,8(sp)
   c:	e052                	sd	s4,0(sp)
   e:	1800                	addi	s0,sp,48
  10:	892a                	mv	s2,a0
  12:	89ae                	mv	s3,a1
  14:	84b2                	mv	s1,a2
  do{  // a * matches zero or more instances
    if(matchhere(re, text))
      return 1;
  }while(*text!='\0' && (*text++==c || c=='.'));
  16:	fd250a13          	addi	s4,a0,-46
  1a:	001a3a13          	seqz	s4,s4
    if(matchhere(re, text))
  1e:	85a6                	mv	a1,s1
  20:	854e                	mv	a0,s3
  22:	02a000ef          	jal	4c <matchhere>
  26:	e911                	bnez	a0,3a <matchstar+0x3a>
  }while(*text!='\0' && (*text++==c || c=='.'));
  28:	0004c783          	lbu	a5,0(s1)
  2c:	cb81                	beqz	a5,3c <matchstar+0x3c>
  2e:	0485                	addi	s1,s1,1
  30:	ff2787e3          	beq	a5,s2,1e <matchstar+0x1e>
  34:	fe0a15e3          	bnez	s4,1e <matchstar+0x1e>
  38:	a011                	j	3c <matchstar+0x3c>
      return 1;
  3a:	4505                	li	a0,1
  return 0;
}
  3c:	70a2                	ld	ra,40(sp)
  3e:	7402                	ld	s0,32(sp)
  40:	64e2                	ld	s1,24(sp)
  42:	6942                	ld	s2,16(sp)
  44:	69a2                	ld	s3,8(sp)
  46:	6a02                	ld	s4,0(sp)
  48:	6145                	addi	sp,sp,48
  4a:	8082                	ret

000000000000004c <matchhere>:
  if(re[0] == '\0')
  4c:	00054703          	lbu	a4,0(a0)
  50:	cf39                	beqz	a4,ae <matchhere+0x62>
{
  52:	1141                	addi	sp,sp,-16
  54:	e406                	sd	ra,8(sp)
  56:	e022                	sd	s0,0(sp)
  58:	0800                	addi	s0,sp,16
  5a:	87aa                	mv	a5,a0
  if(re[1] == '*')
  5c:	00154683          	lbu	a3,1(a0)
  60:	02a00613          	li	a2,42
  64:	02c68363          	beq	a3,a2,8a <matchhere+0x3e>
  if(re[0] == '$' && re[1] == '\0')
  68:	e681                	bnez	a3,70 <matchhere+0x24>
  6a:	fdc70693          	addi	a3,a4,-36
  6e:	c68d                	beqz	a3,98 <matchhere+0x4c>
  if(*text!='\0' && (re[0]=='.' || re[0]==*text))
  70:	0005c683          	lbu	a3,0(a1)
  return 0;
  74:	4501                	li	a0,0
  if(*text!='\0' && (re[0]=='.' || re[0]==*text))
  76:	c691                	beqz	a3,82 <matchhere+0x36>
  78:	02d70563          	beq	a4,a3,a2 <matchhere+0x56>
  7c:	fd270713          	addi	a4,a4,-46
  80:	c30d                	beqz	a4,a2 <matchhere+0x56>
}
  82:	60a2                	ld	ra,8(sp)
  84:	6402                	ld	s0,0(sp)
  86:	0141                	addi	sp,sp,16
  88:	8082                	ret
    return matchstar(re[0], re+2, text);
  8a:	862e                	mv	a2,a1
  8c:	00250593          	addi	a1,a0,2
  90:	853a                	mv	a0,a4
  92:	f6fff0ef          	jal	0 <matchstar>
  96:	b7f5                	j	82 <matchhere+0x36>
    return *text == '\0';
  98:	0005c503          	lbu	a0,0(a1)
  9c:	00153513          	seqz	a0,a0
  a0:	b7cd                	j	82 <matchhere+0x36>
    return matchhere(re+1, text+1);
  a2:	0585                	addi	a1,a1,1
  a4:	00178513          	addi	a0,a5,1
  a8:	fa5ff0ef          	jal	4c <matchhere>
  ac:	bfd9                	j	82 <matchhere+0x36>
    return 1;
  ae:	4505                	li	a0,1
}
  b0:	8082                	ret

00000000000000b2 <match>:
{
  b2:	1101                	addi	sp,sp,-32
  b4:	ec06                	sd	ra,24(sp)
  b6:	e822                	sd	s0,16(sp)
  b8:	e426                	sd	s1,8(sp)
  ba:	e04a                	sd	s2,0(sp)
  bc:	1000                	addi	s0,sp,32
  be:	892a                	mv	s2,a0
  c0:	84ae                	mv	s1,a1
  if(re[0] == '^')
  c2:	00054703          	lbu	a4,0(a0)
  c6:	05e00793          	li	a5,94
  ca:	00f70c63          	beq	a4,a5,e2 <match+0x30>
    if(matchhere(re, text))
  ce:	85a6                	mv	a1,s1
  d0:	854a                	mv	a0,s2
  d2:	f7bff0ef          	jal	4c <matchhere>
  d6:	e911                	bnez	a0,ea <match+0x38>
  }while(*text++ != '\0');
  d8:	0485                	addi	s1,s1,1
  da:	fff4c783          	lbu	a5,-1(s1)
  de:	fbe5                	bnez	a5,ce <match+0x1c>
  e0:	a031                	j	ec <match+0x3a>
    return matchhere(re+1, text);
  e2:	0505                	addi	a0,a0,1
  e4:	f69ff0ef          	jal	4c <matchhere>
  e8:	a011                	j	ec <match+0x3a>
      return 1;
  ea:	4505                	li	a0,1
}
  ec:	60e2                	ld	ra,24(sp)
  ee:	6442                	ld	s0,16(sp)
  f0:	64a2                	ld	s1,8(sp)
  f2:	6902                	ld	s2,0(sp)
  f4:	6105                	addi	sp,sp,32
  f6:	8082                	ret

00000000000000f8 <grep>:
{
  f8:	711d                	addi	sp,sp,-96
  fa:	ec86                	sd	ra,88(sp)
  fc:	e8a2                	sd	s0,80(sp)
  fe:	e4a6                	sd	s1,72(sp)
 100:	e0ca                	sd	s2,64(sp)
 102:	fc4e                	sd	s3,56(sp)
 104:	f852                	sd	s4,48(sp)
 106:	f456                	sd	s5,40(sp)
 108:	f05a                	sd	s6,32(sp)
 10a:	ec5e                	sd	s7,24(sp)
 10c:	e862                	sd	s8,16(sp)
 10e:	e466                	sd	s9,8(sp)
 110:	e06a                	sd	s10,0(sp)
 112:	1080                	addi	s0,sp,96
 114:	8aaa                	mv	s5,a0
 116:	8cae                	mv	s9,a1
  m = 0;
 118:	4b01                	li	s6,0
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 11a:	3ff00d13          	li	s10,1023
 11e:	00001b97          	auipc	s7,0x1
 122:	ef2b8b93          	addi	s7,s7,-270 # 1010 <buf>
    while((q = strchr(p, '\n')) != 0){
 126:	49a9                	li	s3,10
        write(1, p, q+1 - p);
 128:	4c05                	li	s8,1
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 12a:	a82d                	j	164 <grep+0x6c>
      p = q+1;
 12c:	00148913          	addi	s2,s1,1
    while((q = strchr(p, '\n')) != 0){
 130:	85ce                	mv	a1,s3
 132:	854a                	mv	a0,s2
 134:	1dc000ef          	jal	310 <strchr>
 138:	84aa                	mv	s1,a0
 13a:	c11d                	beqz	a0,160 <grep+0x68>
      *q = 0;
 13c:	00048023          	sb	zero,0(s1)
      if(match(pattern, p)){
 140:	85ca                	mv	a1,s2
 142:	8556                	mv	a0,s5
 144:	f6fff0ef          	jal	b2 <match>
 148:	d175                	beqz	a0,12c <grep+0x34>
        *q = '\n';
 14a:	01348023          	sb	s3,0(s1)
        write(1, p, q+1 - p);
 14e:	00148613          	addi	a2,s1,1
 152:	4126063b          	subw	a2,a2,s2
 156:	85ca                	mv	a1,s2
 158:	8562                	mv	a0,s8
 15a:	3da000ef          	jal	534 <write>
 15e:	b7f9                	j	12c <grep+0x34>
    if(m > 0){
 160:	03604463          	bgtz	s6,188 <grep+0x90>
  while((n = read(fd, buf+m, sizeof(buf)-m-1)) > 0){
 164:	416d063b          	subw	a2,s10,s6
 168:	016b85b3          	add	a1,s7,s6
 16c:	8566                	mv	a0,s9
 16e:	3be000ef          	jal	52c <read>
 172:	02a05c63          	blez	a0,1aa <grep+0xb2>
    m += n;
 176:	00ab0a3b          	addw	s4,s6,a0
 17a:	8b52                	mv	s6,s4
    buf[m] = '\0';
 17c:	014b87b3          	add	a5,s7,s4
 180:	00078023          	sb	zero,0(a5)
    p = buf;
 184:	895e                	mv	s2,s7
    while((q = strchr(p, '\n')) != 0){
 186:	b76d                	j	130 <grep+0x38>
      m -= p - buf;
 188:	00001797          	auipc	a5,0x1
 18c:	e8878793          	addi	a5,a5,-376 # 1010 <buf>
 190:	40f907b3          	sub	a5,s2,a5
 194:	40fa063b          	subw	a2,s4,a5
 198:	8b32                	mv	s6,a2
      memmove(buf, p, m);
 19a:	85ca                	mv	a1,s2
 19c:	00001517          	auipc	a0,0x1
 1a0:	e7450513          	addi	a0,a0,-396 # 1010 <buf>
 1a4:	292000ef          	jal	436 <memmove>
 1a8:	bf75                	j	164 <grep+0x6c>
}
 1aa:	60e6                	ld	ra,88(sp)
 1ac:	6446                	ld	s0,80(sp)
 1ae:	64a6                	ld	s1,72(sp)
 1b0:	6906                	ld	s2,64(sp)
 1b2:	79e2                	ld	s3,56(sp)
 1b4:	7a42                	ld	s4,48(sp)
 1b6:	7aa2                	ld	s5,40(sp)
 1b8:	7b02                	ld	s6,32(sp)
 1ba:	6be2                	ld	s7,24(sp)
 1bc:	6c42                	ld	s8,16(sp)
 1be:	6ca2                	ld	s9,8(sp)
 1c0:	6d02                	ld	s10,0(sp)
 1c2:	6125                	addi	sp,sp,96
 1c4:	8082                	ret

00000000000001c6 <main>:
{
 1c6:	7179                	addi	sp,sp,-48
 1c8:	f406                	sd	ra,40(sp)
 1ca:	f022                	sd	s0,32(sp)
 1cc:	ec26                	sd	s1,24(sp)
 1ce:	e84a                	sd	s2,16(sp)
 1d0:	e44e                	sd	s3,8(sp)
 1d2:	e052                	sd	s4,0(sp)
 1d4:	1800                	addi	s0,sp,48
  if(argc <= 1){
 1d6:	4785                	li	a5,1
 1d8:	04a7d663          	bge	a5,a0,224 <main+0x5e>
  pattern = argv[1];
 1dc:	0085ba03          	ld	s4,8(a1)
  if(argc <= 2){
 1e0:	4789                	li	a5,2
 1e2:	04a7db63          	bge	a5,a0,238 <main+0x72>
 1e6:	01058913          	addi	s2,a1,16
 1ea:	ffd5099b          	addiw	s3,a0,-3
 1ee:	02099793          	slli	a5,s3,0x20
 1f2:	01d7d993          	srli	s3,a5,0x1d
 1f6:	05e1                	addi	a1,a1,24
 1f8:	99ae                	add	s3,s3,a1
    if((fd = open(argv[i], O_RDONLY)) < 0){
 1fa:	4581                	li	a1,0
 1fc:	00093503          	ld	a0,0(s2)
 200:	354000ef          	jal	554 <open>
 204:	84aa                	mv	s1,a0
 206:	04054063          	bltz	a0,246 <main+0x80>
    grep(pattern, fd);
 20a:	85aa                	mv	a1,a0
 20c:	8552                	mv	a0,s4
 20e:	eebff0ef          	jal	f8 <grep>
    close(fd);
 212:	8526                	mv	a0,s1
 214:	328000ef          	jal	53c <close>
  for(i = 2; i < argc; i++){
 218:	0921                	addi	s2,s2,8
 21a:	ff3910e3          	bne	s2,s3,1fa <main+0x34>
  exit(0);
 21e:	4501                	li	a0,0
 220:	2f4000ef          	jal	514 <exit>
    fprintf(2, "usage: grep pattern [file ...]\n");
 224:	00001597          	auipc	a1,0x1
 228:	92c58593          	addi	a1,a1,-1748 # b50 <malloc+0x100>
 22c:	4509                	li	a0,2
 22e:	740000ef          	jal	96e <fprintf>
    exit(1);
 232:	4505                	li	a0,1
 234:	2e0000ef          	jal	514 <exit>
    grep(pattern, 0);
 238:	4581                	li	a1,0
 23a:	8552                	mv	a0,s4
 23c:	ebdff0ef          	jal	f8 <grep>
    exit(0);
 240:	4501                	li	a0,0
 242:	2d2000ef          	jal	514 <exit>
      printf("grep: cannot open %s\n", argv[i]);
 246:	00093583          	ld	a1,0(s2)
 24a:	00001517          	auipc	a0,0x1
 24e:	92650513          	addi	a0,a0,-1754 # b70 <malloc+0x120>
 252:	746000ef          	jal	998 <printf>
      exit(1);
 256:	4505                	li	a0,1
 258:	2bc000ef          	jal	514 <exit>

000000000000025c <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 25c:	1141                	addi	sp,sp,-16
 25e:	e406                	sd	ra,8(sp)
 260:	e022                	sd	s0,0(sp)
 262:	0800                	addi	s0,sp,16
  extern int main();
  main();
 264:	f63ff0ef          	jal	1c6 <main>
  exit(0);
 268:	4501                	li	a0,0
 26a:	2aa000ef          	jal	514 <exit>

000000000000026e <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 26e:	1141                	addi	sp,sp,-16
 270:	e406                	sd	ra,8(sp)
 272:	e022                	sd	s0,0(sp)
 274:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 276:	87aa                	mv	a5,a0
 278:	0585                	addi	a1,a1,1
 27a:	0785                	addi	a5,a5,1
 27c:	fff5c703          	lbu	a4,-1(a1)
 280:	fee78fa3          	sb	a4,-1(a5)
 284:	fb75                	bnez	a4,278 <strcpy+0xa>
    ;
  return os;
}
 286:	60a2                	ld	ra,8(sp)
 288:	6402                	ld	s0,0(sp)
 28a:	0141                	addi	sp,sp,16
 28c:	8082                	ret

000000000000028e <strcmp>:

int
strcmp(const char *p, const char *q)
{
 28e:	1141                	addi	sp,sp,-16
 290:	e406                	sd	ra,8(sp)
 292:	e022                	sd	s0,0(sp)
 294:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 296:	00054783          	lbu	a5,0(a0)
 29a:	cb91                	beqz	a5,2ae <strcmp+0x20>
 29c:	0005c703          	lbu	a4,0(a1)
 2a0:	00f71763          	bne	a4,a5,2ae <strcmp+0x20>
    p++, q++;
 2a4:	0505                	addi	a0,a0,1
 2a6:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 2a8:	00054783          	lbu	a5,0(a0)
 2ac:	fbe5                	bnez	a5,29c <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 2ae:	0005c503          	lbu	a0,0(a1)
}
 2b2:	40a7853b          	subw	a0,a5,a0
 2b6:	60a2                	ld	ra,8(sp)
 2b8:	6402                	ld	s0,0(sp)
 2ba:	0141                	addi	sp,sp,16
 2bc:	8082                	ret

00000000000002be <strlen>:

uint
strlen(const char *s)
{
 2be:	1141                	addi	sp,sp,-16
 2c0:	e406                	sd	ra,8(sp)
 2c2:	e022                	sd	s0,0(sp)
 2c4:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 2c6:	00054783          	lbu	a5,0(a0)
 2ca:	cf91                	beqz	a5,2e6 <strlen+0x28>
 2cc:	00150793          	addi	a5,a0,1
 2d0:	86be                	mv	a3,a5
 2d2:	0785                	addi	a5,a5,1
 2d4:	fff7c703          	lbu	a4,-1(a5)
 2d8:	ff65                	bnez	a4,2d0 <strlen+0x12>
 2da:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 2de:	60a2                	ld	ra,8(sp)
 2e0:	6402                	ld	s0,0(sp)
 2e2:	0141                	addi	sp,sp,16
 2e4:	8082                	ret
  for(n = 0; s[n]; n++)
 2e6:	4501                	li	a0,0
 2e8:	bfdd                	j	2de <strlen+0x20>

00000000000002ea <memset>:

void*
memset(void *dst, int c, uint n)
{
 2ea:	1141                	addi	sp,sp,-16
 2ec:	e406                	sd	ra,8(sp)
 2ee:	e022                	sd	s0,0(sp)
 2f0:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 2f2:	ca19                	beqz	a2,308 <memset+0x1e>
 2f4:	87aa                	mv	a5,a0
 2f6:	1602                	slli	a2,a2,0x20
 2f8:	9201                	srli	a2,a2,0x20
 2fa:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 2fe:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 302:	0785                	addi	a5,a5,1
 304:	fee79de3          	bne	a5,a4,2fe <memset+0x14>
  }
  return dst;
}
 308:	60a2                	ld	ra,8(sp)
 30a:	6402                	ld	s0,0(sp)
 30c:	0141                	addi	sp,sp,16
 30e:	8082                	ret

0000000000000310 <strchr>:

char*
strchr(const char *s, char c)
{
 310:	1141                	addi	sp,sp,-16
 312:	e406                	sd	ra,8(sp)
 314:	e022                	sd	s0,0(sp)
 316:	0800                	addi	s0,sp,16
  for(; *s; s++)
 318:	00054783          	lbu	a5,0(a0)
 31c:	cf81                	beqz	a5,334 <strchr+0x24>
    if(*s == c)
 31e:	00f58763          	beq	a1,a5,32c <strchr+0x1c>
  for(; *s; s++)
 322:	0505                	addi	a0,a0,1
 324:	00054783          	lbu	a5,0(a0)
 328:	fbfd                	bnez	a5,31e <strchr+0xe>
      return (char*)s;
  return 0;
 32a:	4501                	li	a0,0
}
 32c:	60a2                	ld	ra,8(sp)
 32e:	6402                	ld	s0,0(sp)
 330:	0141                	addi	sp,sp,16
 332:	8082                	ret
  return 0;
 334:	4501                	li	a0,0
 336:	bfdd                	j	32c <strchr+0x1c>

0000000000000338 <gets>:

char*
gets(char *buf, int max)
{
 338:	711d                	addi	sp,sp,-96
 33a:	ec86                	sd	ra,88(sp)
 33c:	e8a2                	sd	s0,80(sp)
 33e:	e4a6                	sd	s1,72(sp)
 340:	e0ca                	sd	s2,64(sp)
 342:	fc4e                	sd	s3,56(sp)
 344:	f852                	sd	s4,48(sp)
 346:	f456                	sd	s5,40(sp)
 348:	f05a                	sd	s6,32(sp)
 34a:	ec5e                	sd	s7,24(sp)
 34c:	e862                	sd	s8,16(sp)
 34e:	1080                	addi	s0,sp,96
 350:	8baa                	mv	s7,a0
 352:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 354:	892a                	mv	s2,a0
 356:	4481                	li	s1,0
    cc = read(0, &c, 1);
 358:	faf40b13          	addi	s6,s0,-81
 35c:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 35e:	8c26                	mv	s8,s1
 360:	0014899b          	addiw	s3,s1,1
 364:	84ce                	mv	s1,s3
 366:	0349d463          	bge	s3,s4,38e <gets+0x56>
    cc = read(0, &c, 1);
 36a:	8656                	mv	a2,s5
 36c:	85da                	mv	a1,s6
 36e:	4501                	li	a0,0
 370:	1bc000ef          	jal	52c <read>
    if(cc < 1)
 374:	00a05d63          	blez	a0,38e <gets+0x56>
      break;
    buf[i++] = c;
 378:	faf44783          	lbu	a5,-81(s0)
 37c:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 380:	0905                	addi	s2,s2,1
 382:	ff678713          	addi	a4,a5,-10
 386:	c319                	beqz	a4,38c <gets+0x54>
 388:	17cd                	addi	a5,a5,-13
 38a:	fbf1                	bnez	a5,35e <gets+0x26>
    buf[i++] = c;
 38c:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 38e:	9c5e                	add	s8,s8,s7
 390:	000c0023          	sb	zero,0(s8)
  return buf;
}
 394:	855e                	mv	a0,s7
 396:	60e6                	ld	ra,88(sp)
 398:	6446                	ld	s0,80(sp)
 39a:	64a6                	ld	s1,72(sp)
 39c:	6906                	ld	s2,64(sp)
 39e:	79e2                	ld	s3,56(sp)
 3a0:	7a42                	ld	s4,48(sp)
 3a2:	7aa2                	ld	s5,40(sp)
 3a4:	7b02                	ld	s6,32(sp)
 3a6:	6be2                	ld	s7,24(sp)
 3a8:	6c42                	ld	s8,16(sp)
 3aa:	6125                	addi	sp,sp,96
 3ac:	8082                	ret

00000000000003ae <stat>:

int
stat(const char *n, struct stat *st)
{
 3ae:	1101                	addi	sp,sp,-32
 3b0:	ec06                	sd	ra,24(sp)
 3b2:	e822                	sd	s0,16(sp)
 3b4:	e04a                	sd	s2,0(sp)
 3b6:	1000                	addi	s0,sp,32
 3b8:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 3ba:	4581                	li	a1,0
 3bc:	198000ef          	jal	554 <open>
  if(fd < 0)
 3c0:	02054263          	bltz	a0,3e4 <stat+0x36>
 3c4:	e426                	sd	s1,8(sp)
 3c6:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 3c8:	85ca                	mv	a1,s2
 3ca:	1a2000ef          	jal	56c <fstat>
 3ce:	892a                	mv	s2,a0
  close(fd);
 3d0:	8526                	mv	a0,s1
 3d2:	16a000ef          	jal	53c <close>
  return r;
 3d6:	64a2                	ld	s1,8(sp)
}
 3d8:	854a                	mv	a0,s2
 3da:	60e2                	ld	ra,24(sp)
 3dc:	6442                	ld	s0,16(sp)
 3de:	6902                	ld	s2,0(sp)
 3e0:	6105                	addi	sp,sp,32
 3e2:	8082                	ret
    return -1;
 3e4:	57fd                	li	a5,-1
 3e6:	893e                	mv	s2,a5
 3e8:	bfc5                	j	3d8 <stat+0x2a>

00000000000003ea <atoi>:

int
atoi(const char *s)
{
 3ea:	1141                	addi	sp,sp,-16
 3ec:	e406                	sd	ra,8(sp)
 3ee:	e022                	sd	s0,0(sp)
 3f0:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 3f2:	00054683          	lbu	a3,0(a0)
 3f6:	fd06879b          	addiw	a5,a3,-48
 3fa:	0ff7f793          	zext.b	a5,a5
 3fe:	4625                	li	a2,9
 400:	02f66963          	bltu	a2,a5,432 <atoi+0x48>
 404:	872a                	mv	a4,a0
  n = 0;
 406:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 408:	0705                	addi	a4,a4,1
 40a:	0025179b          	slliw	a5,a0,0x2
 40e:	9fa9                	addw	a5,a5,a0
 410:	0017979b          	slliw	a5,a5,0x1
 414:	9fb5                	addw	a5,a5,a3
 416:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 41a:	00074683          	lbu	a3,0(a4)
 41e:	fd06879b          	addiw	a5,a3,-48
 422:	0ff7f793          	zext.b	a5,a5
 426:	fef671e3          	bgeu	a2,a5,408 <atoi+0x1e>
  return n;
}
 42a:	60a2                	ld	ra,8(sp)
 42c:	6402                	ld	s0,0(sp)
 42e:	0141                	addi	sp,sp,16
 430:	8082                	ret
  n = 0;
 432:	4501                	li	a0,0
 434:	bfdd                	j	42a <atoi+0x40>

0000000000000436 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 436:	1141                	addi	sp,sp,-16
 438:	e406                	sd	ra,8(sp)
 43a:	e022                	sd	s0,0(sp)
 43c:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 43e:	02b57563          	bgeu	a0,a1,468 <memmove+0x32>
    while(n-- > 0)
 442:	00c05f63          	blez	a2,460 <memmove+0x2a>
 446:	1602                	slli	a2,a2,0x20
 448:	9201                	srli	a2,a2,0x20
 44a:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 44e:	872a                	mv	a4,a0
      *dst++ = *src++;
 450:	0585                	addi	a1,a1,1
 452:	0705                	addi	a4,a4,1
 454:	fff5c683          	lbu	a3,-1(a1)
 458:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 45c:	fee79ae3          	bne	a5,a4,450 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 460:	60a2                	ld	ra,8(sp)
 462:	6402                	ld	s0,0(sp)
 464:	0141                	addi	sp,sp,16
 466:	8082                	ret
    while(n-- > 0)
 468:	fec05ce3          	blez	a2,460 <memmove+0x2a>
    dst += n;
 46c:	00c50733          	add	a4,a0,a2
    src += n;
 470:	95b2                	add	a1,a1,a2
 472:	fff6079b          	addiw	a5,a2,-1
 476:	1782                	slli	a5,a5,0x20
 478:	9381                	srli	a5,a5,0x20
 47a:	fff7c793          	not	a5,a5
 47e:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 480:	15fd                	addi	a1,a1,-1
 482:	177d                	addi	a4,a4,-1
 484:	0005c683          	lbu	a3,0(a1)
 488:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 48c:	fef71ae3          	bne	a4,a5,480 <memmove+0x4a>
 490:	bfc1                	j	460 <memmove+0x2a>

0000000000000492 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 492:	1141                	addi	sp,sp,-16
 494:	e406                	sd	ra,8(sp)
 496:	e022                	sd	s0,0(sp)
 498:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 49a:	c61d                	beqz	a2,4c8 <memcmp+0x36>
 49c:	1602                	slli	a2,a2,0x20
 49e:	9201                	srli	a2,a2,0x20
 4a0:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 4a4:	00054783          	lbu	a5,0(a0)
 4a8:	0005c703          	lbu	a4,0(a1)
 4ac:	00e79863          	bne	a5,a4,4bc <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 4b0:	0505                	addi	a0,a0,1
    p2++;
 4b2:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 4b4:	fed518e3          	bne	a0,a3,4a4 <memcmp+0x12>
  }
  return 0;
 4b8:	4501                	li	a0,0
 4ba:	a019                	j	4c0 <memcmp+0x2e>
      return *p1 - *p2;
 4bc:	40e7853b          	subw	a0,a5,a4
}
 4c0:	60a2                	ld	ra,8(sp)
 4c2:	6402                	ld	s0,0(sp)
 4c4:	0141                	addi	sp,sp,16
 4c6:	8082                	ret
  return 0;
 4c8:	4501                	li	a0,0
 4ca:	bfdd                	j	4c0 <memcmp+0x2e>

00000000000004cc <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 4cc:	1141                	addi	sp,sp,-16
 4ce:	e406                	sd	ra,8(sp)
 4d0:	e022                	sd	s0,0(sp)
 4d2:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 4d4:	f63ff0ef          	jal	436 <memmove>
}
 4d8:	60a2                	ld	ra,8(sp)
 4da:	6402                	ld	s0,0(sp)
 4dc:	0141                	addi	sp,sp,16
 4de:	8082                	ret

00000000000004e0 <sbrk>:

char *
sbrk(int n) {
 4e0:	1141                	addi	sp,sp,-16
 4e2:	e406                	sd	ra,8(sp)
 4e4:	e022                	sd	s0,0(sp)
 4e6:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 4e8:	4585                	li	a1,1
 4ea:	0b2000ef          	jal	59c <sys_sbrk>
}
 4ee:	60a2                	ld	ra,8(sp)
 4f0:	6402                	ld	s0,0(sp)
 4f2:	0141                	addi	sp,sp,16
 4f4:	8082                	ret

00000000000004f6 <sbrklazy>:

char *
sbrklazy(int n) {
 4f6:	1141                	addi	sp,sp,-16
 4f8:	e406                	sd	ra,8(sp)
 4fa:	e022                	sd	s0,0(sp)
 4fc:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 4fe:	4589                	li	a1,2
 500:	09c000ef          	jal	59c <sys_sbrk>
}
 504:	60a2                	ld	ra,8(sp)
 506:	6402                	ld	s0,0(sp)
 508:	0141                	addi	sp,sp,16
 50a:	8082                	ret

000000000000050c <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 50c:	4885                	li	a7,1
 ecall
 50e:	00000073          	ecall
 ret
 512:	8082                	ret

0000000000000514 <exit>:
.global exit
exit:
 li a7, SYS_exit
 514:	4889                	li	a7,2
 ecall
 516:	00000073          	ecall
 ret
 51a:	8082                	ret

000000000000051c <wait>:
.global wait
wait:
 li a7, SYS_wait
 51c:	488d                	li	a7,3
 ecall
 51e:	00000073          	ecall
 ret
 522:	8082                	ret

0000000000000524 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 524:	4891                	li	a7,4
 ecall
 526:	00000073          	ecall
 ret
 52a:	8082                	ret

000000000000052c <read>:
.global read
read:
 li a7, SYS_read
 52c:	4895                	li	a7,5
 ecall
 52e:	00000073          	ecall
 ret
 532:	8082                	ret

0000000000000534 <write>:
.global write
write:
 li a7, SYS_write
 534:	48c1                	li	a7,16
 ecall
 536:	00000073          	ecall
 ret
 53a:	8082                	ret

000000000000053c <close>:
.global close
close:
 li a7, SYS_close
 53c:	48d5                	li	a7,21
 ecall
 53e:	00000073          	ecall
 ret
 542:	8082                	ret

0000000000000544 <kill>:
.global kill
kill:
 li a7, SYS_kill
 544:	4899                	li	a7,6
 ecall
 546:	00000073          	ecall
 ret
 54a:	8082                	ret

000000000000054c <exec>:
.global exec
exec:
 li a7, SYS_exec
 54c:	489d                	li	a7,7
 ecall
 54e:	00000073          	ecall
 ret
 552:	8082                	ret

0000000000000554 <open>:
.global open
open:
 li a7, SYS_open
 554:	48bd                	li	a7,15
 ecall
 556:	00000073          	ecall
 ret
 55a:	8082                	ret

000000000000055c <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 55c:	48c5                	li	a7,17
 ecall
 55e:	00000073          	ecall
 ret
 562:	8082                	ret

0000000000000564 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 564:	48c9                	li	a7,18
 ecall
 566:	00000073          	ecall
 ret
 56a:	8082                	ret

000000000000056c <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 56c:	48a1                	li	a7,8
 ecall
 56e:	00000073          	ecall
 ret
 572:	8082                	ret

0000000000000574 <link>:
.global link
link:
 li a7, SYS_link
 574:	48cd                	li	a7,19
 ecall
 576:	00000073          	ecall
 ret
 57a:	8082                	ret

000000000000057c <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 57c:	48d1                	li	a7,20
 ecall
 57e:	00000073          	ecall
 ret
 582:	8082                	ret

0000000000000584 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 584:	48a5                	li	a7,9
 ecall
 586:	00000073          	ecall
 ret
 58a:	8082                	ret

000000000000058c <dup>:
.global dup
dup:
 li a7, SYS_dup
 58c:	48a9                	li	a7,10
 ecall
 58e:	00000073          	ecall
 ret
 592:	8082                	ret

0000000000000594 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 594:	48ad                	li	a7,11
 ecall
 596:	00000073          	ecall
 ret
 59a:	8082                	ret

000000000000059c <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 59c:	48b1                	li	a7,12
 ecall
 59e:	00000073          	ecall
 ret
 5a2:	8082                	ret

00000000000005a4 <pause>:
.global pause
pause:
 li a7, SYS_pause
 5a4:	48b5                	li	a7,13
 ecall
 5a6:	00000073          	ecall
 ret
 5aa:	8082                	ret

00000000000005ac <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 5ac:	48b9                	li	a7,14
 ecall
 5ae:	00000073          	ecall
 ret
 5b2:	8082                	ret

00000000000005b4 <shm_create>:
.global shm_create
shm_create:
 li a7, SYS_shm_create
 5b4:	48d9                	li	a7,22
 ecall
 5b6:	00000073          	ecall
 ret
 5ba:	8082                	ret

00000000000005bc <shm_get>:
.global shm_get
shm_get:
 li a7, SYS_shm_get
 5bc:	48dd                	li	a7,23
 ecall
 5be:	00000073          	ecall
 ret
 5c2:	8082                	ret

00000000000005c4 <shm_close>:
.global shm_close
shm_close:
 li a7, SYS_shm_close
 5c4:	48e1                	li	a7,24
 ecall
 5c6:	00000073          	ecall
 ret
 5ca:	8082                	ret

00000000000005cc <mbox_create>:
.global mbox_create
mbox_create:
 li a7, SYS_mbox_create
 5cc:	48e5                	li	a7,25
 ecall
 5ce:	00000073          	ecall
 ret
 5d2:	8082                	ret

00000000000005d4 <mbox_send>:
.global mbox_send
mbox_send:
 li a7, SYS_mbox_send
 5d4:	48e9                	li	a7,26
 ecall
 5d6:	00000073          	ecall
 ret
 5da:	8082                	ret

00000000000005dc <mbox_recv>:
.global mbox_recv
mbox_recv:
 li a7, SYS_mbox_recv
 5dc:	48ed                	li	a7,27
 ecall
 5de:	00000073          	ecall
 ret
 5e2:	8082                	ret

00000000000005e4 <va2pa>:
.global va2pa
va2pa:
 li a7, SYS_va2pa
 5e4:	48f1                	li	a7,28
 ecall
 5e6:	00000073          	ecall
 ret
 5ea:	8082                	ret

00000000000005ec <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 5ec:	1101                	addi	sp,sp,-32
 5ee:	ec06                	sd	ra,24(sp)
 5f0:	e822                	sd	s0,16(sp)
 5f2:	1000                	addi	s0,sp,32
 5f4:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 5f8:	4605                	li	a2,1
 5fa:	fef40593          	addi	a1,s0,-17
 5fe:	f37ff0ef          	jal	534 <write>
}
 602:	60e2                	ld	ra,24(sp)
 604:	6442                	ld	s0,16(sp)
 606:	6105                	addi	sp,sp,32
 608:	8082                	ret

000000000000060a <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 60a:	715d                	addi	sp,sp,-80
 60c:	e486                	sd	ra,72(sp)
 60e:	e0a2                	sd	s0,64(sp)
 610:	f84a                	sd	s2,48(sp)
 612:	f44e                	sd	s3,40(sp)
 614:	0880                	addi	s0,sp,80
 616:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 618:	cac1                	beqz	a3,6a8 <printint+0x9e>
 61a:	0805d763          	bgez	a1,6a8 <printint+0x9e>
    neg = 1;
    x = -xx;
 61e:	40b005bb          	negw	a1,a1
    neg = 1;
 622:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 624:	fb840993          	addi	s3,s0,-72
  neg = 0;
 628:	86ce                	mv	a3,s3
  i = 0;
 62a:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 62c:	00000817          	auipc	a6,0x0
 630:	56480813          	addi	a6,a6,1380 # b90 <digits>
 634:	88ba                	mv	a7,a4
 636:	0017051b          	addiw	a0,a4,1
 63a:	872a                	mv	a4,a0
 63c:	02c5f7bb          	remuw	a5,a1,a2
 640:	1782                	slli	a5,a5,0x20
 642:	9381                	srli	a5,a5,0x20
 644:	97c2                	add	a5,a5,a6
 646:	0007c783          	lbu	a5,0(a5)
 64a:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 64e:	87ae                	mv	a5,a1
 650:	02c5d5bb          	divuw	a1,a1,a2
 654:	0685                	addi	a3,a3,1
 656:	fcc7ffe3          	bgeu	a5,a2,634 <printint+0x2a>
  if(neg)
 65a:	00030c63          	beqz	t1,672 <printint+0x68>
    buf[i++] = '-';
 65e:	fd050793          	addi	a5,a0,-48
 662:	00878533          	add	a0,a5,s0
 666:	02d00793          	li	a5,45
 66a:	fef50423          	sb	a5,-24(a0)
 66e:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 672:	02e05563          	blez	a4,69c <printint+0x92>
 676:	fc26                	sd	s1,56(sp)
 678:	377d                	addiw	a4,a4,-1
 67a:	00e984b3          	add	s1,s3,a4
 67e:	19fd                	addi	s3,s3,-1
 680:	99ba                	add	s3,s3,a4
 682:	1702                	slli	a4,a4,0x20
 684:	9301                	srli	a4,a4,0x20
 686:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 68a:	0004c583          	lbu	a1,0(s1)
 68e:	854a                	mv	a0,s2
 690:	f5dff0ef          	jal	5ec <putc>
  while(--i >= 0)
 694:	14fd                	addi	s1,s1,-1
 696:	ff349ae3          	bne	s1,s3,68a <printint+0x80>
 69a:	74e2                	ld	s1,56(sp)
}
 69c:	60a6                	ld	ra,72(sp)
 69e:	6406                	ld	s0,64(sp)
 6a0:	7942                	ld	s2,48(sp)
 6a2:	79a2                	ld	s3,40(sp)
 6a4:	6161                	addi	sp,sp,80
 6a6:	8082                	ret
    x = xx;
 6a8:	2581                	sext.w	a1,a1
  neg = 0;
 6aa:	4301                	li	t1,0
 6ac:	bfa5                	j	624 <printint+0x1a>

00000000000006ae <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 6ae:	711d                	addi	sp,sp,-96
 6b0:	ec86                	sd	ra,88(sp)
 6b2:	e8a2                	sd	s0,80(sp)
 6b4:	e4a6                	sd	s1,72(sp)
 6b6:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 6b8:	0005c483          	lbu	s1,0(a1)
 6bc:	22048363          	beqz	s1,8e2 <vprintf+0x234>
 6c0:	e0ca                	sd	s2,64(sp)
 6c2:	fc4e                	sd	s3,56(sp)
 6c4:	f852                	sd	s4,48(sp)
 6c6:	f456                	sd	s5,40(sp)
 6c8:	f05a                	sd	s6,32(sp)
 6ca:	ec5e                	sd	s7,24(sp)
 6cc:	e862                	sd	s8,16(sp)
 6ce:	8b2a                	mv	s6,a0
 6d0:	8a2e                	mv	s4,a1
 6d2:	8bb2                	mv	s7,a2
  state = 0;
 6d4:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 6d6:	4901                	li	s2,0
 6d8:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 6da:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 6de:	06400c13          	li	s8,100
 6e2:	a00d                	j	704 <vprintf+0x56>
        putc(fd, c0);
 6e4:	85a6                	mv	a1,s1
 6e6:	855a                	mv	a0,s6
 6e8:	f05ff0ef          	jal	5ec <putc>
 6ec:	a019                	j	6f2 <vprintf+0x44>
    } else if(state == '%'){
 6ee:	03598363          	beq	s3,s5,714 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 6f2:	0019079b          	addiw	a5,s2,1
 6f6:	893e                	mv	s2,a5
 6f8:	873e                	mv	a4,a5
 6fa:	97d2                	add	a5,a5,s4
 6fc:	0007c483          	lbu	s1,0(a5)
 700:	1c048a63          	beqz	s1,8d4 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 704:	0004879b          	sext.w	a5,s1
    if(state == 0){
 708:	fe0993e3          	bnez	s3,6ee <vprintf+0x40>
      if(c0 == '%'){
 70c:	fd579ce3          	bne	a5,s5,6e4 <vprintf+0x36>
        state = '%';
 710:	89be                	mv	s3,a5
 712:	b7c5                	j	6f2 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 714:	00ea06b3          	add	a3,s4,a4
 718:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 71c:	1c060863          	beqz	a2,8ec <vprintf+0x23e>
      if(c0 == 'd'){
 720:	03878763          	beq	a5,s8,74e <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 724:	f9478693          	addi	a3,a5,-108
 728:	0016b693          	seqz	a3,a3
 72c:	f9c60593          	addi	a1,a2,-100
 730:	e99d                	bnez	a1,766 <vprintf+0xb8>
 732:	ca95                	beqz	a3,766 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 734:	008b8493          	addi	s1,s7,8
 738:	4685                	li	a3,1
 73a:	4629                	li	a2,10
 73c:	000bb583          	ld	a1,0(s7)
 740:	855a                	mv	a0,s6
 742:	ec9ff0ef          	jal	60a <printint>
        i += 1;
 746:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 748:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 74a:	4981                	li	s3,0
 74c:	b75d                	j	6f2 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 74e:	008b8493          	addi	s1,s7,8
 752:	4685                	li	a3,1
 754:	4629                	li	a2,10
 756:	000ba583          	lw	a1,0(s7)
 75a:	855a                	mv	a0,s6
 75c:	eafff0ef          	jal	60a <printint>
 760:	8ba6                	mv	s7,s1
      state = 0;
 762:	4981                	li	s3,0
 764:	b779                	j	6f2 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 766:	9752                	add	a4,a4,s4
 768:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 76c:	f9460713          	addi	a4,a2,-108
 770:	00173713          	seqz	a4,a4
 774:	8f75                	and	a4,a4,a3
 776:	f9c58513          	addi	a0,a1,-100
 77a:	18051363          	bnez	a0,900 <vprintf+0x252>
 77e:	18070163          	beqz	a4,900 <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 782:	008b8493          	addi	s1,s7,8
 786:	4685                	li	a3,1
 788:	4629                	li	a2,10
 78a:	000bb583          	ld	a1,0(s7)
 78e:	855a                	mv	a0,s6
 790:	e7bff0ef          	jal	60a <printint>
        i += 2;
 794:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 796:	8ba6                	mv	s7,s1
      state = 0;
 798:	4981                	li	s3,0
        i += 2;
 79a:	bfa1                	j	6f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 79c:	008b8493          	addi	s1,s7,8
 7a0:	4681                	li	a3,0
 7a2:	4629                	li	a2,10
 7a4:	000be583          	lwu	a1,0(s7)
 7a8:	855a                	mv	a0,s6
 7aa:	e61ff0ef          	jal	60a <printint>
 7ae:	8ba6                	mv	s7,s1
      state = 0;
 7b0:	4981                	li	s3,0
 7b2:	b781                	j	6f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7b4:	008b8493          	addi	s1,s7,8
 7b8:	4681                	li	a3,0
 7ba:	4629                	li	a2,10
 7bc:	000bb583          	ld	a1,0(s7)
 7c0:	855a                	mv	a0,s6
 7c2:	e49ff0ef          	jal	60a <printint>
        i += 1;
 7c6:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 7c8:	8ba6                	mv	s7,s1
      state = 0;
 7ca:	4981                	li	s3,0
 7cc:	b71d                	j	6f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 7ce:	008b8493          	addi	s1,s7,8
 7d2:	4681                	li	a3,0
 7d4:	4629                	li	a2,10
 7d6:	000bb583          	ld	a1,0(s7)
 7da:	855a                	mv	a0,s6
 7dc:	e2fff0ef          	jal	60a <printint>
        i += 2;
 7e0:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 7e2:	8ba6                	mv	s7,s1
      state = 0;
 7e4:	4981                	li	s3,0
        i += 2;
 7e6:	b731                	j	6f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 7e8:	008b8493          	addi	s1,s7,8
 7ec:	4681                	li	a3,0
 7ee:	4641                	li	a2,16
 7f0:	000be583          	lwu	a1,0(s7)
 7f4:	855a                	mv	a0,s6
 7f6:	e15ff0ef          	jal	60a <printint>
 7fa:	8ba6                	mv	s7,s1
      state = 0;
 7fc:	4981                	li	s3,0
 7fe:	bdd5                	j	6f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 800:	008b8493          	addi	s1,s7,8
 804:	4681                	li	a3,0
 806:	4641                	li	a2,16
 808:	000bb583          	ld	a1,0(s7)
 80c:	855a                	mv	a0,s6
 80e:	dfdff0ef          	jal	60a <printint>
        i += 1;
 812:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 814:	8ba6                	mv	s7,s1
      state = 0;
 816:	4981                	li	s3,0
 818:	bde9                	j	6f2 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 81a:	008b8493          	addi	s1,s7,8
 81e:	4681                	li	a3,0
 820:	4641                	li	a2,16
 822:	000bb583          	ld	a1,0(s7)
 826:	855a                	mv	a0,s6
 828:	de3ff0ef          	jal	60a <printint>
        i += 2;
 82c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 82e:	8ba6                	mv	s7,s1
      state = 0;
 830:	4981                	li	s3,0
        i += 2;
 832:	b5c1                	j	6f2 <vprintf+0x44>
 834:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 836:	008b8793          	addi	a5,s7,8
 83a:	8cbe                	mv	s9,a5
 83c:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 840:	03000593          	li	a1,48
 844:	855a                	mv	a0,s6
 846:	da7ff0ef          	jal	5ec <putc>
  putc(fd, 'x');
 84a:	07800593          	li	a1,120
 84e:	855a                	mv	a0,s6
 850:	d9dff0ef          	jal	5ec <putc>
 854:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 856:	00000b97          	auipc	s7,0x0
 85a:	33ab8b93          	addi	s7,s7,826 # b90 <digits>
 85e:	03c9d793          	srli	a5,s3,0x3c
 862:	97de                	add	a5,a5,s7
 864:	0007c583          	lbu	a1,0(a5)
 868:	855a                	mv	a0,s6
 86a:	d83ff0ef          	jal	5ec <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 86e:	0992                	slli	s3,s3,0x4
 870:	34fd                	addiw	s1,s1,-1
 872:	f4f5                	bnez	s1,85e <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 874:	8be6                	mv	s7,s9
      state = 0;
 876:	4981                	li	s3,0
 878:	6ca2                	ld	s9,8(sp)
 87a:	bda5                	j	6f2 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 87c:	008b8493          	addi	s1,s7,8
 880:	000bc583          	lbu	a1,0(s7)
 884:	855a                	mv	a0,s6
 886:	d67ff0ef          	jal	5ec <putc>
 88a:	8ba6                	mv	s7,s1
      state = 0;
 88c:	4981                	li	s3,0
 88e:	b595                	j	6f2 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 890:	008b8993          	addi	s3,s7,8
 894:	000bb483          	ld	s1,0(s7)
 898:	cc91                	beqz	s1,8b4 <vprintf+0x206>
        for(; *s; s++)
 89a:	0004c583          	lbu	a1,0(s1)
 89e:	c985                	beqz	a1,8ce <vprintf+0x220>
          putc(fd, *s);
 8a0:	855a                	mv	a0,s6
 8a2:	d4bff0ef          	jal	5ec <putc>
        for(; *s; s++)
 8a6:	0485                	addi	s1,s1,1
 8a8:	0004c583          	lbu	a1,0(s1)
 8ac:	f9f5                	bnez	a1,8a0 <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 8ae:	8bce                	mv	s7,s3
      state = 0;
 8b0:	4981                	li	s3,0
 8b2:	b581                	j	6f2 <vprintf+0x44>
          s = "(null)";
 8b4:	00000497          	auipc	s1,0x0
 8b8:	2d448493          	addi	s1,s1,724 # b88 <malloc+0x138>
        for(; *s; s++)
 8bc:	02800593          	li	a1,40
 8c0:	b7c5                	j	8a0 <vprintf+0x1f2>
        putc(fd, '%');
 8c2:	85be                	mv	a1,a5
 8c4:	855a                	mv	a0,s6
 8c6:	d27ff0ef          	jal	5ec <putc>
      state = 0;
 8ca:	4981                	li	s3,0
 8cc:	b51d                	j	6f2 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 8ce:	8bce                	mv	s7,s3
      state = 0;
 8d0:	4981                	li	s3,0
 8d2:	b505                	j	6f2 <vprintf+0x44>
 8d4:	6906                	ld	s2,64(sp)
 8d6:	79e2                	ld	s3,56(sp)
 8d8:	7a42                	ld	s4,48(sp)
 8da:	7aa2                	ld	s5,40(sp)
 8dc:	7b02                	ld	s6,32(sp)
 8de:	6be2                	ld	s7,24(sp)
 8e0:	6c42                	ld	s8,16(sp)
    }
  }
}
 8e2:	60e6                	ld	ra,88(sp)
 8e4:	6446                	ld	s0,80(sp)
 8e6:	64a6                	ld	s1,72(sp)
 8e8:	6125                	addi	sp,sp,96
 8ea:	8082                	ret
      if(c0 == 'd'){
 8ec:	06400713          	li	a4,100
 8f0:	e4e78fe3          	beq	a5,a4,74e <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 8f4:	f9478693          	addi	a3,a5,-108
 8f8:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 8fc:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 8fe:	4701                	li	a4,0
      } else if(c0 == 'u'){
 900:	07500513          	li	a0,117
 904:	e8a78ce3          	beq	a5,a0,79c <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 908:	f8b60513          	addi	a0,a2,-117
 90c:	e119                	bnez	a0,912 <vprintf+0x264>
 90e:	ea0693e3          	bnez	a3,7b4 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 912:	f8b58513          	addi	a0,a1,-117
 916:	e119                	bnez	a0,91c <vprintf+0x26e>
 918:	ea071be3          	bnez	a4,7ce <vprintf+0x120>
      } else if(c0 == 'x'){
 91c:	07800513          	li	a0,120
 920:	eca784e3          	beq	a5,a0,7e8 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 924:	f8860613          	addi	a2,a2,-120
 928:	e219                	bnez	a2,92e <vprintf+0x280>
 92a:	ec069be3          	bnez	a3,800 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 92e:	f8858593          	addi	a1,a1,-120
 932:	e199                	bnez	a1,938 <vprintf+0x28a>
 934:	ee0713e3          	bnez	a4,81a <vprintf+0x16c>
      } else if(c0 == 'p'){
 938:	07000713          	li	a4,112
 93c:	eee78ce3          	beq	a5,a4,834 <vprintf+0x186>
      } else if(c0 == 'c'){
 940:	06300713          	li	a4,99
 944:	f2e78ce3          	beq	a5,a4,87c <vprintf+0x1ce>
      } else if(c0 == 's'){
 948:	07300713          	li	a4,115
 94c:	f4e782e3          	beq	a5,a4,890 <vprintf+0x1e2>
      } else if(c0 == '%'){
 950:	02500713          	li	a4,37
 954:	f6e787e3          	beq	a5,a4,8c2 <vprintf+0x214>
        putc(fd, '%');
 958:	02500593          	li	a1,37
 95c:	855a                	mv	a0,s6
 95e:	c8fff0ef          	jal	5ec <putc>
        putc(fd, c0);
 962:	85a6                	mv	a1,s1
 964:	855a                	mv	a0,s6
 966:	c87ff0ef          	jal	5ec <putc>
      state = 0;
 96a:	4981                	li	s3,0
 96c:	b359                	j	6f2 <vprintf+0x44>

000000000000096e <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 96e:	715d                	addi	sp,sp,-80
 970:	ec06                	sd	ra,24(sp)
 972:	e822                	sd	s0,16(sp)
 974:	1000                	addi	s0,sp,32
 976:	e010                	sd	a2,0(s0)
 978:	e414                	sd	a3,8(s0)
 97a:	e818                	sd	a4,16(s0)
 97c:	ec1c                	sd	a5,24(s0)
 97e:	03043023          	sd	a6,32(s0)
 982:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 986:	8622                	mv	a2,s0
 988:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 98c:	d23ff0ef          	jal	6ae <vprintf>
}
 990:	60e2                	ld	ra,24(sp)
 992:	6442                	ld	s0,16(sp)
 994:	6161                	addi	sp,sp,80
 996:	8082                	ret

0000000000000998 <printf>:

void
printf(const char *fmt, ...)
{
 998:	711d                	addi	sp,sp,-96
 99a:	ec06                	sd	ra,24(sp)
 99c:	e822                	sd	s0,16(sp)
 99e:	1000                	addi	s0,sp,32
 9a0:	e40c                	sd	a1,8(s0)
 9a2:	e810                	sd	a2,16(s0)
 9a4:	ec14                	sd	a3,24(s0)
 9a6:	f018                	sd	a4,32(s0)
 9a8:	f41c                	sd	a5,40(s0)
 9aa:	03043823          	sd	a6,48(s0)
 9ae:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 9b2:	00840613          	addi	a2,s0,8
 9b6:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 9ba:	85aa                	mv	a1,a0
 9bc:	4505                	li	a0,1
 9be:	cf1ff0ef          	jal	6ae <vprintf>
}
 9c2:	60e2                	ld	ra,24(sp)
 9c4:	6442                	ld	s0,16(sp)
 9c6:	6125                	addi	sp,sp,96
 9c8:	8082                	ret

00000000000009ca <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 9ca:	1141                	addi	sp,sp,-16
 9cc:	e406                	sd	ra,8(sp)
 9ce:	e022                	sd	s0,0(sp)
 9d0:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 9d2:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9d6:	00000797          	auipc	a5,0x0
 9da:	62a7b783          	ld	a5,1578(a5) # 1000 <freep>
 9de:	a039                	j	9ec <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9e0:	6398                	ld	a4,0(a5)
 9e2:	00e7e463          	bltu	a5,a4,9ea <free+0x20>
 9e6:	00e6ea63          	bltu	a3,a4,9fa <free+0x30>
{
 9ea:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 9ec:	fed7fae3          	bgeu	a5,a3,9e0 <free+0x16>
 9f0:	6398                	ld	a4,0(a5)
 9f2:	00e6e463          	bltu	a3,a4,9fa <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 9f6:	fee7eae3          	bltu	a5,a4,9ea <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 9fa:	ff852583          	lw	a1,-8(a0)
 9fe:	6390                	ld	a2,0(a5)
 a00:	02059813          	slli	a6,a1,0x20
 a04:	01c85713          	srli	a4,a6,0x1c
 a08:	9736                	add	a4,a4,a3
 a0a:	02e60563          	beq	a2,a4,a34 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 a0e:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 a12:	4790                	lw	a2,8(a5)
 a14:	02061593          	slli	a1,a2,0x20
 a18:	01c5d713          	srli	a4,a1,0x1c
 a1c:	973e                	add	a4,a4,a5
 a1e:	02e68263          	beq	a3,a4,a42 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 a22:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 a24:	00000717          	auipc	a4,0x0
 a28:	5cf73e23          	sd	a5,1500(a4) # 1000 <freep>
}
 a2c:	60a2                	ld	ra,8(sp)
 a2e:	6402                	ld	s0,0(sp)
 a30:	0141                	addi	sp,sp,16
 a32:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 a34:	4618                	lw	a4,8(a2)
 a36:	9f2d                	addw	a4,a4,a1
 a38:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 a3c:	6398                	ld	a4,0(a5)
 a3e:	6310                	ld	a2,0(a4)
 a40:	b7f9                	j	a0e <free+0x44>
    p->s.size += bp->s.size;
 a42:	ff852703          	lw	a4,-8(a0)
 a46:	9f31                	addw	a4,a4,a2
 a48:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 a4a:	ff053683          	ld	a3,-16(a0)
 a4e:	bfd1                	j	a22 <free+0x58>

0000000000000a50 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 a50:	7139                	addi	sp,sp,-64
 a52:	fc06                	sd	ra,56(sp)
 a54:	f822                	sd	s0,48(sp)
 a56:	f04a                	sd	s2,32(sp)
 a58:	ec4e                	sd	s3,24(sp)
 a5a:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 a5c:	02051993          	slli	s3,a0,0x20
 a60:	0209d993          	srli	s3,s3,0x20
 a64:	09bd                	addi	s3,s3,15
 a66:	0049d993          	srli	s3,s3,0x4
 a6a:	2985                	addiw	s3,s3,1
 a6c:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 a6e:	00000517          	auipc	a0,0x0
 a72:	59253503          	ld	a0,1426(a0) # 1000 <freep>
 a76:	c905                	beqz	a0,aa6 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 a78:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 a7a:	4798                	lw	a4,8(a5)
 a7c:	09377663          	bgeu	a4,s3,b08 <malloc+0xb8>
 a80:	f426                	sd	s1,40(sp)
 a82:	e852                	sd	s4,16(sp)
 a84:	e456                	sd	s5,8(sp)
 a86:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 a88:	8a4e                	mv	s4,s3
 a8a:	6705                	lui	a4,0x1
 a8c:	00e9f363          	bgeu	s3,a4,a92 <malloc+0x42>
 a90:	6a05                	lui	s4,0x1
 a92:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 a96:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 a9a:	00000497          	auipc	s1,0x0
 a9e:	56648493          	addi	s1,s1,1382 # 1000 <freep>
  if(p == SBRK_ERROR)
 aa2:	5afd                	li	s5,-1
 aa4:	a83d                	j	ae2 <malloc+0x92>
 aa6:	f426                	sd	s1,40(sp)
 aa8:	e852                	sd	s4,16(sp)
 aaa:	e456                	sd	s5,8(sp)
 aac:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 aae:	00001797          	auipc	a5,0x1
 ab2:	96278793          	addi	a5,a5,-1694 # 1410 <base>
 ab6:	00000717          	auipc	a4,0x0
 aba:	54f73523          	sd	a5,1354(a4) # 1000 <freep>
 abe:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 ac0:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 ac4:	b7d1                	j	a88 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 ac6:	6398                	ld	a4,0(a5)
 ac8:	e118                	sd	a4,0(a0)
 aca:	a899                	j	b20 <malloc+0xd0>
  hp->s.size = nu;
 acc:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 ad0:	0541                	addi	a0,a0,16
 ad2:	ef9ff0ef          	jal	9ca <free>
  return freep;
 ad6:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 ad8:	c125                	beqz	a0,b38 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 ada:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 adc:	4798                	lw	a4,8(a5)
 ade:	03277163          	bgeu	a4,s2,b00 <malloc+0xb0>
    if(p == freep)
 ae2:	6098                	ld	a4,0(s1)
 ae4:	853e                	mv	a0,a5
 ae6:	fef71ae3          	bne	a4,a5,ada <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 aea:	8552                	mv	a0,s4
 aec:	9f5ff0ef          	jal	4e0 <sbrk>
  if(p == SBRK_ERROR)
 af0:	fd551ee3          	bne	a0,s5,acc <malloc+0x7c>
        return 0;
 af4:	4501                	li	a0,0
 af6:	74a2                	ld	s1,40(sp)
 af8:	6a42                	ld	s4,16(sp)
 afa:	6aa2                	ld	s5,8(sp)
 afc:	6b02                	ld	s6,0(sp)
 afe:	a03d                	j	b2c <malloc+0xdc>
 b00:	74a2                	ld	s1,40(sp)
 b02:	6a42                	ld	s4,16(sp)
 b04:	6aa2                	ld	s5,8(sp)
 b06:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 b08:	fae90fe3          	beq	s2,a4,ac6 <malloc+0x76>
        p->s.size -= nunits;
 b0c:	4137073b          	subw	a4,a4,s3
 b10:	c798                	sw	a4,8(a5)
        p += p->s.size;
 b12:	02071693          	slli	a3,a4,0x20
 b16:	01c6d713          	srli	a4,a3,0x1c
 b1a:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 b1c:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 b20:	00000717          	auipc	a4,0x0
 b24:	4ea73023          	sd	a0,1248(a4) # 1000 <freep>
      return (void*)(p + 1);
 b28:	01078513          	addi	a0,a5,16
  }
}
 b2c:	70e2                	ld	ra,56(sp)
 b2e:	7442                	ld	s0,48(sp)
 b30:	7902                	ld	s2,32(sp)
 b32:	69e2                	ld	s3,24(sp)
 b34:	6121                	addi	sp,sp,64
 b36:	8082                	ret
 b38:	74a2                	ld	s1,40(sp)
 b3a:	6a42                	ld	s4,16(sp)
 b3c:	6aa2                	ld	s5,8(sp)
 b3e:	6b02                	ld	s6,0(sp)
 b40:	b7f5                	j	b2c <malloc+0xdc>
