
user/_master:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"
int main(){
   0:	7139                	addi	sp,sp,-64
   2:	fc06                	sd	ra,56(sp)
   4:	f822                	sd	s0,48(sp)
   6:	f426                	sd	s1,40(sp)
   8:	0080                	addi	s0,sp,64
    int *ptr;
    ptr=(int*)shm_get(1);
   a:	4505                	li	a0,1
   c:	44e000ef          	jal	45a <shm_get>
  10:	84aa                	mv	s1,a0
    if(ptr==0)printf("shm_get failed\n");
  12:	c929                	beqz	a0,64 <main+0x64>
    // hardcoding interwined path
    ptr[0]=5; 
  14:	4795                	li	a5,5
  16:	c09c                	sw	a5,0(s1)
    ptr[1]=6;
  18:	4799                	li	a5,6
  1a:	c0dc                	sw	a5,4(s1)
    ptr[6]=10;
  1c:	47a9                	li	a5,10
  1e:	cc9c                	sw	a5,24(s1)
    ptr[5]=11;
  20:	47ad                	li	a5,11
  22:	c8dc                	sw	a5,20(s1)
    ptr[11]=20;
  24:	47d1                	li	a5,20
  26:	d4dc                	sw	a5,44(s1)
    ptr[10]=21;
  28:	47d5                	li	a5,21
  2a:	d49c                	sw	a5,40(s1)
    if(mbox_create(1)<0)printf("mbox already exists with this key");
  2c:	4505                	li	a0,1
  2e:	43c000ef          	jal	46a <mbox_create>
  32:	04054063          	bltz	a0,72 <main+0x72>
    if(mbox_create(2)<0)printf("mbox already exists with this key");
  36:	4509                	li	a0,2
  38:	432000ef          	jal	46a <mbox_create>
  3c:	04054263          	bltz	a0,80 <main+0x80>
       //forking twice for two child processes one for process A and another for process B
       int pid=fork();
  40:	36a000ef          	jal	3aa <fork>
       if(pid==0){
  44:	c529                	beqz	a0,8e <main+0x8e>
          char * args[]={"process","0","21",0};
          exec("process",args);
          exit(0);
       }
       int pid2=fork();
  46:	364000ef          	jal	3aa <fork>
       if(pid2==0){
  4a:	cd2d                	beqz	a0,c4 <main+0xc4>
          char * args[]={"process","1","20",0};
          exec("process",args);
          exit(0);
       }
     wait(0);
  4c:	4501                	li	a0,0
  4e:	36c000ef          	jal	3ba <wait>
     shm_close(1);
  52:	4505                	li	a0,1
  54:	40e000ef          	jal	462 <shm_close>
    return 0;
  58:	4501                	li	a0,0
  5a:	70e2                	ld	ra,56(sp)
  5c:	7442                	ld	s0,48(sp)
  5e:	74a2                	ld	s1,40(sp)
  60:	6121                	addi	sp,sp,64
  62:	8082                	ret
    if(ptr==0)printf("shm_get failed\n");
  64:	00001517          	auipc	a0,0x1
  68:	97c50513          	addi	a0,a0,-1668 # 9e0 <malloc+0xf2>
  6c:	7ca000ef          	jal	836 <printf>
  70:	b755                	j	14 <main+0x14>
    if(mbox_create(1)<0)printf("mbox already exists with this key");
  72:	00001517          	auipc	a0,0x1
  76:	97e50513          	addi	a0,a0,-1666 # 9f0 <malloc+0x102>
  7a:	7bc000ef          	jal	836 <printf>
  7e:	bf65                	j	36 <main+0x36>
    if(mbox_create(2)<0)printf("mbox already exists with this key");
  80:	00001517          	auipc	a0,0x1
  84:	97050513          	addi	a0,a0,-1680 # 9f0 <malloc+0x102>
  88:	7ae000ef          	jal	836 <printf>
  8c:	bf55                	j	40 <main+0x40>
          char * args[]={"process","0","21",0};
  8e:	00001797          	auipc	a5,0x1
  92:	9ba78793          	addi	a5,a5,-1606 # a48 <malloc+0x15a>
  96:	6390                	ld	a2,0(a5)
  98:	6794                	ld	a3,8(a5)
  9a:	6b98                	ld	a4,16(a5)
  9c:	fcc43023          	sd	a2,-64(s0)
  a0:	fcd43423          	sd	a3,-56(s0)
  a4:	fce43823          	sd	a4,-48(s0)
  a8:	6f9c                	ld	a5,24(a5)
  aa:	fcf43c23          	sd	a5,-40(s0)
          exec("process",args);
  ae:	fc040593          	addi	a1,s0,-64
  b2:	00001517          	auipc	a0,0x1
  b6:	96650513          	addi	a0,a0,-1690 # a18 <malloc+0x12a>
  ba:	330000ef          	jal	3ea <exec>
          exit(0);
  be:	4501                	li	a0,0
  c0:	2f2000ef          	jal	3b2 <exit>
          char * args[]={"process","1","20",0};
  c4:	00001797          	auipc	a5,0x1
  c8:	98478793          	addi	a5,a5,-1660 # a48 <malloc+0x15a>
  cc:	7390                	ld	a2,32(a5)
  ce:	7794                	ld	a3,40(a5)
  d0:	7b98                	ld	a4,48(a5)
  d2:	fcc43023          	sd	a2,-64(s0)
  d6:	fcd43423          	sd	a3,-56(s0)
  da:	fce43823          	sd	a4,-48(s0)
  de:	7f9c                	ld	a5,56(a5)
  e0:	fcf43c23          	sd	a5,-40(s0)
          exec("process",args);
  e4:	fc040593          	addi	a1,s0,-64
  e8:	00001517          	auipc	a0,0x1
  ec:	93050513          	addi	a0,a0,-1744 # a18 <malloc+0x12a>
  f0:	2fa000ef          	jal	3ea <exec>
          exit(0);
  f4:	4501                	li	a0,0
  f6:	2bc000ef          	jal	3b2 <exit>

00000000000000fa <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  fa:	1141                	addi	sp,sp,-16
  fc:	e406                	sd	ra,8(sp)
  fe:	e022                	sd	s0,0(sp)
 100:	0800                	addi	s0,sp,16
  extern int main();
  main();
 102:	effff0ef          	jal	0 <main>
  exit(0);
 106:	4501                	li	a0,0
 108:	2aa000ef          	jal	3b2 <exit>

000000000000010c <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 10c:	1141                	addi	sp,sp,-16
 10e:	e406                	sd	ra,8(sp)
 110:	e022                	sd	s0,0(sp)
 112:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 114:	87aa                	mv	a5,a0
 116:	0585                	addi	a1,a1,1
 118:	0785                	addi	a5,a5,1
 11a:	fff5c703          	lbu	a4,-1(a1)
 11e:	fee78fa3          	sb	a4,-1(a5)
 122:	fb75                	bnez	a4,116 <strcpy+0xa>
    ;
  return os;
}
 124:	60a2                	ld	ra,8(sp)
 126:	6402                	ld	s0,0(sp)
 128:	0141                	addi	sp,sp,16
 12a:	8082                	ret

000000000000012c <strcmp>:

int
strcmp(const char *p, const char *q)
{
 12c:	1141                	addi	sp,sp,-16
 12e:	e406                	sd	ra,8(sp)
 130:	e022                	sd	s0,0(sp)
 132:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 134:	00054783          	lbu	a5,0(a0)
 138:	cb91                	beqz	a5,14c <strcmp+0x20>
 13a:	0005c703          	lbu	a4,0(a1)
 13e:	00f71763          	bne	a4,a5,14c <strcmp+0x20>
    p++, q++;
 142:	0505                	addi	a0,a0,1
 144:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 146:	00054783          	lbu	a5,0(a0)
 14a:	fbe5                	bnez	a5,13a <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 14c:	0005c503          	lbu	a0,0(a1)
}
 150:	40a7853b          	subw	a0,a5,a0
 154:	60a2                	ld	ra,8(sp)
 156:	6402                	ld	s0,0(sp)
 158:	0141                	addi	sp,sp,16
 15a:	8082                	ret

000000000000015c <strlen>:

uint
strlen(const char *s)
{
 15c:	1141                	addi	sp,sp,-16
 15e:	e406                	sd	ra,8(sp)
 160:	e022                	sd	s0,0(sp)
 162:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 164:	00054783          	lbu	a5,0(a0)
 168:	cf91                	beqz	a5,184 <strlen+0x28>
 16a:	00150793          	addi	a5,a0,1
 16e:	86be                	mv	a3,a5
 170:	0785                	addi	a5,a5,1
 172:	fff7c703          	lbu	a4,-1(a5)
 176:	ff65                	bnez	a4,16e <strlen+0x12>
 178:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 17c:	60a2                	ld	ra,8(sp)
 17e:	6402                	ld	s0,0(sp)
 180:	0141                	addi	sp,sp,16
 182:	8082                	ret
  for(n = 0; s[n]; n++)
 184:	4501                	li	a0,0
 186:	bfdd                	j	17c <strlen+0x20>

0000000000000188 <memset>:

void*
memset(void *dst, int c, uint n)
{
 188:	1141                	addi	sp,sp,-16
 18a:	e406                	sd	ra,8(sp)
 18c:	e022                	sd	s0,0(sp)
 18e:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 190:	ca19                	beqz	a2,1a6 <memset+0x1e>
 192:	87aa                	mv	a5,a0
 194:	1602                	slli	a2,a2,0x20
 196:	9201                	srli	a2,a2,0x20
 198:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 19c:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 1a0:	0785                	addi	a5,a5,1
 1a2:	fee79de3          	bne	a5,a4,19c <memset+0x14>
  }
  return dst;
}
 1a6:	60a2                	ld	ra,8(sp)
 1a8:	6402                	ld	s0,0(sp)
 1aa:	0141                	addi	sp,sp,16
 1ac:	8082                	ret

00000000000001ae <strchr>:

char*
strchr(const char *s, char c)
{
 1ae:	1141                	addi	sp,sp,-16
 1b0:	e406                	sd	ra,8(sp)
 1b2:	e022                	sd	s0,0(sp)
 1b4:	0800                	addi	s0,sp,16
  for(; *s; s++)
 1b6:	00054783          	lbu	a5,0(a0)
 1ba:	cf81                	beqz	a5,1d2 <strchr+0x24>
    if(*s == c)
 1bc:	00f58763          	beq	a1,a5,1ca <strchr+0x1c>
  for(; *s; s++)
 1c0:	0505                	addi	a0,a0,1
 1c2:	00054783          	lbu	a5,0(a0)
 1c6:	fbfd                	bnez	a5,1bc <strchr+0xe>
      return (char*)s;
  return 0;
 1c8:	4501                	li	a0,0
}
 1ca:	60a2                	ld	ra,8(sp)
 1cc:	6402                	ld	s0,0(sp)
 1ce:	0141                	addi	sp,sp,16
 1d0:	8082                	ret
  return 0;
 1d2:	4501                	li	a0,0
 1d4:	bfdd                	j	1ca <strchr+0x1c>

00000000000001d6 <gets>:

char*
gets(char *buf, int max)
{
 1d6:	711d                	addi	sp,sp,-96
 1d8:	ec86                	sd	ra,88(sp)
 1da:	e8a2                	sd	s0,80(sp)
 1dc:	e4a6                	sd	s1,72(sp)
 1de:	e0ca                	sd	s2,64(sp)
 1e0:	fc4e                	sd	s3,56(sp)
 1e2:	f852                	sd	s4,48(sp)
 1e4:	f456                	sd	s5,40(sp)
 1e6:	f05a                	sd	s6,32(sp)
 1e8:	ec5e                	sd	s7,24(sp)
 1ea:	e862                	sd	s8,16(sp)
 1ec:	1080                	addi	s0,sp,96
 1ee:	8baa                	mv	s7,a0
 1f0:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1f2:	892a                	mv	s2,a0
 1f4:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1f6:	faf40b13          	addi	s6,s0,-81
 1fa:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 1fc:	8c26                	mv	s8,s1
 1fe:	0014899b          	addiw	s3,s1,1
 202:	84ce                	mv	s1,s3
 204:	0349d463          	bge	s3,s4,22c <gets+0x56>
    cc = read(0, &c, 1);
 208:	8656                	mv	a2,s5
 20a:	85da                	mv	a1,s6
 20c:	4501                	li	a0,0
 20e:	1bc000ef          	jal	3ca <read>
    if(cc < 1)
 212:	00a05d63          	blez	a0,22c <gets+0x56>
      break;
    buf[i++] = c;
 216:	faf44783          	lbu	a5,-81(s0)
 21a:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 21e:	0905                	addi	s2,s2,1
 220:	ff678713          	addi	a4,a5,-10
 224:	c319                	beqz	a4,22a <gets+0x54>
 226:	17cd                	addi	a5,a5,-13
 228:	fbf1                	bnez	a5,1fc <gets+0x26>
    buf[i++] = c;
 22a:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 22c:	9c5e                	add	s8,s8,s7
 22e:	000c0023          	sb	zero,0(s8)
  return buf;
}
 232:	855e                	mv	a0,s7
 234:	60e6                	ld	ra,88(sp)
 236:	6446                	ld	s0,80(sp)
 238:	64a6                	ld	s1,72(sp)
 23a:	6906                	ld	s2,64(sp)
 23c:	79e2                	ld	s3,56(sp)
 23e:	7a42                	ld	s4,48(sp)
 240:	7aa2                	ld	s5,40(sp)
 242:	7b02                	ld	s6,32(sp)
 244:	6be2                	ld	s7,24(sp)
 246:	6c42                	ld	s8,16(sp)
 248:	6125                	addi	sp,sp,96
 24a:	8082                	ret

000000000000024c <stat>:

int
stat(const char *n, struct stat *st)
{
 24c:	1101                	addi	sp,sp,-32
 24e:	ec06                	sd	ra,24(sp)
 250:	e822                	sd	s0,16(sp)
 252:	e04a                	sd	s2,0(sp)
 254:	1000                	addi	s0,sp,32
 256:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 258:	4581                	li	a1,0
 25a:	198000ef          	jal	3f2 <open>
  if(fd < 0)
 25e:	02054263          	bltz	a0,282 <stat+0x36>
 262:	e426                	sd	s1,8(sp)
 264:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 266:	85ca                	mv	a1,s2
 268:	1a2000ef          	jal	40a <fstat>
 26c:	892a                	mv	s2,a0
  close(fd);
 26e:	8526                	mv	a0,s1
 270:	16a000ef          	jal	3da <close>
  return r;
 274:	64a2                	ld	s1,8(sp)
}
 276:	854a                	mv	a0,s2
 278:	60e2                	ld	ra,24(sp)
 27a:	6442                	ld	s0,16(sp)
 27c:	6902                	ld	s2,0(sp)
 27e:	6105                	addi	sp,sp,32
 280:	8082                	ret
    return -1;
 282:	57fd                	li	a5,-1
 284:	893e                	mv	s2,a5
 286:	bfc5                	j	276 <stat+0x2a>

0000000000000288 <atoi>:

int
atoi(const char *s)
{
 288:	1141                	addi	sp,sp,-16
 28a:	e406                	sd	ra,8(sp)
 28c:	e022                	sd	s0,0(sp)
 28e:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 290:	00054683          	lbu	a3,0(a0)
 294:	fd06879b          	addiw	a5,a3,-48
 298:	0ff7f793          	zext.b	a5,a5
 29c:	4625                	li	a2,9
 29e:	02f66963          	bltu	a2,a5,2d0 <atoi+0x48>
 2a2:	872a                	mv	a4,a0
  n = 0;
 2a4:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 2a6:	0705                	addi	a4,a4,1
 2a8:	0025179b          	slliw	a5,a0,0x2
 2ac:	9fa9                	addw	a5,a5,a0
 2ae:	0017979b          	slliw	a5,a5,0x1
 2b2:	9fb5                	addw	a5,a5,a3
 2b4:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 2b8:	00074683          	lbu	a3,0(a4)
 2bc:	fd06879b          	addiw	a5,a3,-48
 2c0:	0ff7f793          	zext.b	a5,a5
 2c4:	fef671e3          	bgeu	a2,a5,2a6 <atoi+0x1e>
  return n;
}
 2c8:	60a2                	ld	ra,8(sp)
 2ca:	6402                	ld	s0,0(sp)
 2cc:	0141                	addi	sp,sp,16
 2ce:	8082                	ret
  n = 0;
 2d0:	4501                	li	a0,0
 2d2:	bfdd                	j	2c8 <atoi+0x40>

00000000000002d4 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 2d4:	1141                	addi	sp,sp,-16
 2d6:	e406                	sd	ra,8(sp)
 2d8:	e022                	sd	s0,0(sp)
 2da:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2dc:	02b57563          	bgeu	a0,a1,306 <memmove+0x32>
    while(n-- > 0)
 2e0:	00c05f63          	blez	a2,2fe <memmove+0x2a>
 2e4:	1602                	slli	a2,a2,0x20
 2e6:	9201                	srli	a2,a2,0x20
 2e8:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2ec:	872a                	mv	a4,a0
      *dst++ = *src++;
 2ee:	0585                	addi	a1,a1,1
 2f0:	0705                	addi	a4,a4,1
 2f2:	fff5c683          	lbu	a3,-1(a1)
 2f6:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 2fa:	fee79ae3          	bne	a5,a4,2ee <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2fe:	60a2                	ld	ra,8(sp)
 300:	6402                	ld	s0,0(sp)
 302:	0141                	addi	sp,sp,16
 304:	8082                	ret
    while(n-- > 0)
 306:	fec05ce3          	blez	a2,2fe <memmove+0x2a>
    dst += n;
 30a:	00c50733          	add	a4,a0,a2
    src += n;
 30e:	95b2                	add	a1,a1,a2
 310:	fff6079b          	addiw	a5,a2,-1
 314:	1782                	slli	a5,a5,0x20
 316:	9381                	srli	a5,a5,0x20
 318:	fff7c793          	not	a5,a5
 31c:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 31e:	15fd                	addi	a1,a1,-1
 320:	177d                	addi	a4,a4,-1
 322:	0005c683          	lbu	a3,0(a1)
 326:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 32a:	fef71ae3          	bne	a4,a5,31e <memmove+0x4a>
 32e:	bfc1                	j	2fe <memmove+0x2a>

0000000000000330 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 330:	1141                	addi	sp,sp,-16
 332:	e406                	sd	ra,8(sp)
 334:	e022                	sd	s0,0(sp)
 336:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 338:	c61d                	beqz	a2,366 <memcmp+0x36>
 33a:	1602                	slli	a2,a2,0x20
 33c:	9201                	srli	a2,a2,0x20
 33e:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 342:	00054783          	lbu	a5,0(a0)
 346:	0005c703          	lbu	a4,0(a1)
 34a:	00e79863          	bne	a5,a4,35a <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 34e:	0505                	addi	a0,a0,1
    p2++;
 350:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 352:	fed518e3          	bne	a0,a3,342 <memcmp+0x12>
  }
  return 0;
 356:	4501                	li	a0,0
 358:	a019                	j	35e <memcmp+0x2e>
      return *p1 - *p2;
 35a:	40e7853b          	subw	a0,a5,a4
}
 35e:	60a2                	ld	ra,8(sp)
 360:	6402                	ld	s0,0(sp)
 362:	0141                	addi	sp,sp,16
 364:	8082                	ret
  return 0;
 366:	4501                	li	a0,0
 368:	bfdd                	j	35e <memcmp+0x2e>

000000000000036a <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 36a:	1141                	addi	sp,sp,-16
 36c:	e406                	sd	ra,8(sp)
 36e:	e022                	sd	s0,0(sp)
 370:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 372:	f63ff0ef          	jal	2d4 <memmove>
}
 376:	60a2                	ld	ra,8(sp)
 378:	6402                	ld	s0,0(sp)
 37a:	0141                	addi	sp,sp,16
 37c:	8082                	ret

000000000000037e <sbrk>:

char *
sbrk(int n) {
 37e:	1141                	addi	sp,sp,-16
 380:	e406                	sd	ra,8(sp)
 382:	e022                	sd	s0,0(sp)
 384:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 386:	4585                	li	a1,1
 388:	0b2000ef          	jal	43a <sys_sbrk>
}
 38c:	60a2                	ld	ra,8(sp)
 38e:	6402                	ld	s0,0(sp)
 390:	0141                	addi	sp,sp,16
 392:	8082                	ret

0000000000000394 <sbrklazy>:

char *
sbrklazy(int n) {
 394:	1141                	addi	sp,sp,-16
 396:	e406                	sd	ra,8(sp)
 398:	e022                	sd	s0,0(sp)
 39a:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 39c:	4589                	li	a1,2
 39e:	09c000ef          	jal	43a <sys_sbrk>
}
 3a2:	60a2                	ld	ra,8(sp)
 3a4:	6402                	ld	s0,0(sp)
 3a6:	0141                	addi	sp,sp,16
 3a8:	8082                	ret

00000000000003aa <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3aa:	4885                	li	a7,1
 ecall
 3ac:	00000073          	ecall
 ret
 3b0:	8082                	ret

00000000000003b2 <exit>:
.global exit
exit:
 li a7, SYS_exit
 3b2:	4889                	li	a7,2
 ecall
 3b4:	00000073          	ecall
 ret
 3b8:	8082                	ret

00000000000003ba <wait>:
.global wait
wait:
 li a7, SYS_wait
 3ba:	488d                	li	a7,3
 ecall
 3bc:	00000073          	ecall
 ret
 3c0:	8082                	ret

00000000000003c2 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 3c2:	4891                	li	a7,4
 ecall
 3c4:	00000073          	ecall
 ret
 3c8:	8082                	ret

00000000000003ca <read>:
.global read
read:
 li a7, SYS_read
 3ca:	4895                	li	a7,5
 ecall
 3cc:	00000073          	ecall
 ret
 3d0:	8082                	ret

00000000000003d2 <write>:
.global write
write:
 li a7, SYS_write
 3d2:	48c1                	li	a7,16
 ecall
 3d4:	00000073          	ecall
 ret
 3d8:	8082                	ret

00000000000003da <close>:
.global close
close:
 li a7, SYS_close
 3da:	48d5                	li	a7,21
 ecall
 3dc:	00000073          	ecall
 ret
 3e0:	8082                	ret

00000000000003e2 <kill>:
.global kill
kill:
 li a7, SYS_kill
 3e2:	4899                	li	a7,6
 ecall
 3e4:	00000073          	ecall
 ret
 3e8:	8082                	ret

00000000000003ea <exec>:
.global exec
exec:
 li a7, SYS_exec
 3ea:	489d                	li	a7,7
 ecall
 3ec:	00000073          	ecall
 ret
 3f0:	8082                	ret

00000000000003f2 <open>:
.global open
open:
 li a7, SYS_open
 3f2:	48bd                	li	a7,15
 ecall
 3f4:	00000073          	ecall
 ret
 3f8:	8082                	ret

00000000000003fa <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3fa:	48c5                	li	a7,17
 ecall
 3fc:	00000073          	ecall
 ret
 400:	8082                	ret

0000000000000402 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 402:	48c9                	li	a7,18
 ecall
 404:	00000073          	ecall
 ret
 408:	8082                	ret

000000000000040a <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 40a:	48a1                	li	a7,8
 ecall
 40c:	00000073          	ecall
 ret
 410:	8082                	ret

0000000000000412 <link>:
.global link
link:
 li a7, SYS_link
 412:	48cd                	li	a7,19
 ecall
 414:	00000073          	ecall
 ret
 418:	8082                	ret

000000000000041a <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 41a:	48d1                	li	a7,20
 ecall
 41c:	00000073          	ecall
 ret
 420:	8082                	ret

0000000000000422 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 422:	48a5                	li	a7,9
 ecall
 424:	00000073          	ecall
 ret
 428:	8082                	ret

000000000000042a <dup>:
.global dup
dup:
 li a7, SYS_dup
 42a:	48a9                	li	a7,10
 ecall
 42c:	00000073          	ecall
 ret
 430:	8082                	ret

0000000000000432 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 432:	48ad                	li	a7,11
 ecall
 434:	00000073          	ecall
 ret
 438:	8082                	ret

000000000000043a <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 43a:	48b1                	li	a7,12
 ecall
 43c:	00000073          	ecall
 ret
 440:	8082                	ret

0000000000000442 <pause>:
.global pause
pause:
 li a7, SYS_pause
 442:	48b5                	li	a7,13
 ecall
 444:	00000073          	ecall
 ret
 448:	8082                	ret

000000000000044a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 44a:	48b9                	li	a7,14
 ecall
 44c:	00000073          	ecall
 ret
 450:	8082                	ret

0000000000000452 <shm_create>:
.global shm_create
shm_create:
 li a7, SYS_shm_create
 452:	48d9                	li	a7,22
 ecall
 454:	00000073          	ecall
 ret
 458:	8082                	ret

000000000000045a <shm_get>:
.global shm_get
shm_get:
 li a7, SYS_shm_get
 45a:	48dd                	li	a7,23
 ecall
 45c:	00000073          	ecall
 ret
 460:	8082                	ret

0000000000000462 <shm_close>:
.global shm_close
shm_close:
 li a7, SYS_shm_close
 462:	48e1                	li	a7,24
 ecall
 464:	00000073          	ecall
 ret
 468:	8082                	ret

000000000000046a <mbox_create>:
.global mbox_create
mbox_create:
 li a7, SYS_mbox_create
 46a:	48e5                	li	a7,25
 ecall
 46c:	00000073          	ecall
 ret
 470:	8082                	ret

0000000000000472 <mbox_send>:
.global mbox_send
mbox_send:
 li a7, SYS_mbox_send
 472:	48e9                	li	a7,26
 ecall
 474:	00000073          	ecall
 ret
 478:	8082                	ret

000000000000047a <mbox_recv>:
.global mbox_recv
mbox_recv:
 li a7, SYS_mbox_recv
 47a:	48ed                	li	a7,27
 ecall
 47c:	00000073          	ecall
 ret
 480:	8082                	ret

0000000000000482 <va2pa>:
.global va2pa
va2pa:
 li a7, SYS_va2pa
 482:	48f1                	li	a7,28
 ecall
 484:	00000073          	ecall
 ret
 488:	8082                	ret

000000000000048a <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 48a:	1101                	addi	sp,sp,-32
 48c:	ec06                	sd	ra,24(sp)
 48e:	e822                	sd	s0,16(sp)
 490:	1000                	addi	s0,sp,32
 492:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 496:	4605                	li	a2,1
 498:	fef40593          	addi	a1,s0,-17
 49c:	f37ff0ef          	jal	3d2 <write>
}
 4a0:	60e2                	ld	ra,24(sp)
 4a2:	6442                	ld	s0,16(sp)
 4a4:	6105                	addi	sp,sp,32
 4a6:	8082                	ret

00000000000004a8 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 4a8:	715d                	addi	sp,sp,-80
 4aa:	e486                	sd	ra,72(sp)
 4ac:	e0a2                	sd	s0,64(sp)
 4ae:	f84a                	sd	s2,48(sp)
 4b0:	f44e                	sd	s3,40(sp)
 4b2:	0880                	addi	s0,sp,80
 4b4:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 4b6:	cac1                	beqz	a3,546 <printint+0x9e>
 4b8:	0805d763          	bgez	a1,546 <printint+0x9e>
    neg = 1;
    x = -xx;
 4bc:	40b005bb          	negw	a1,a1
    neg = 1;
 4c0:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 4c2:	fb840993          	addi	s3,s0,-72
  neg = 0;
 4c6:	86ce                	mv	a3,s3
  i = 0;
 4c8:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 4ca:	00000817          	auipc	a6,0x0
 4ce:	5be80813          	addi	a6,a6,1470 # a88 <digits>
 4d2:	88ba                	mv	a7,a4
 4d4:	0017051b          	addiw	a0,a4,1
 4d8:	872a                	mv	a4,a0
 4da:	02c5f7bb          	remuw	a5,a1,a2
 4de:	1782                	slli	a5,a5,0x20
 4e0:	9381                	srli	a5,a5,0x20
 4e2:	97c2                	add	a5,a5,a6
 4e4:	0007c783          	lbu	a5,0(a5)
 4e8:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 4ec:	87ae                	mv	a5,a1
 4ee:	02c5d5bb          	divuw	a1,a1,a2
 4f2:	0685                	addi	a3,a3,1
 4f4:	fcc7ffe3          	bgeu	a5,a2,4d2 <printint+0x2a>
  if(neg)
 4f8:	00030c63          	beqz	t1,510 <printint+0x68>
    buf[i++] = '-';
 4fc:	fd050793          	addi	a5,a0,-48
 500:	00878533          	add	a0,a5,s0
 504:	02d00793          	li	a5,45
 508:	fef50423          	sb	a5,-24(a0)
 50c:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 510:	02e05563          	blez	a4,53a <printint+0x92>
 514:	fc26                	sd	s1,56(sp)
 516:	377d                	addiw	a4,a4,-1
 518:	00e984b3          	add	s1,s3,a4
 51c:	19fd                	addi	s3,s3,-1
 51e:	99ba                	add	s3,s3,a4
 520:	1702                	slli	a4,a4,0x20
 522:	9301                	srli	a4,a4,0x20
 524:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 528:	0004c583          	lbu	a1,0(s1)
 52c:	854a                	mv	a0,s2
 52e:	f5dff0ef          	jal	48a <putc>
  while(--i >= 0)
 532:	14fd                	addi	s1,s1,-1
 534:	ff349ae3          	bne	s1,s3,528 <printint+0x80>
 538:	74e2                	ld	s1,56(sp)
}
 53a:	60a6                	ld	ra,72(sp)
 53c:	6406                	ld	s0,64(sp)
 53e:	7942                	ld	s2,48(sp)
 540:	79a2                	ld	s3,40(sp)
 542:	6161                	addi	sp,sp,80
 544:	8082                	ret
    x = xx;
 546:	2581                	sext.w	a1,a1
  neg = 0;
 548:	4301                	li	t1,0
 54a:	bfa5                	j	4c2 <printint+0x1a>

000000000000054c <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 54c:	711d                	addi	sp,sp,-96
 54e:	ec86                	sd	ra,88(sp)
 550:	e8a2                	sd	s0,80(sp)
 552:	e4a6                	sd	s1,72(sp)
 554:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 556:	0005c483          	lbu	s1,0(a1)
 55a:	22048363          	beqz	s1,780 <vprintf+0x234>
 55e:	e0ca                	sd	s2,64(sp)
 560:	fc4e                	sd	s3,56(sp)
 562:	f852                	sd	s4,48(sp)
 564:	f456                	sd	s5,40(sp)
 566:	f05a                	sd	s6,32(sp)
 568:	ec5e                	sd	s7,24(sp)
 56a:	e862                	sd	s8,16(sp)
 56c:	8b2a                	mv	s6,a0
 56e:	8a2e                	mv	s4,a1
 570:	8bb2                	mv	s7,a2
  state = 0;
 572:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 574:	4901                	li	s2,0
 576:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 578:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 57c:	06400c13          	li	s8,100
 580:	a00d                	j	5a2 <vprintf+0x56>
        putc(fd, c0);
 582:	85a6                	mv	a1,s1
 584:	855a                	mv	a0,s6
 586:	f05ff0ef          	jal	48a <putc>
 58a:	a019                	j	590 <vprintf+0x44>
    } else if(state == '%'){
 58c:	03598363          	beq	s3,s5,5b2 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 590:	0019079b          	addiw	a5,s2,1
 594:	893e                	mv	s2,a5
 596:	873e                	mv	a4,a5
 598:	97d2                	add	a5,a5,s4
 59a:	0007c483          	lbu	s1,0(a5)
 59e:	1c048a63          	beqz	s1,772 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 5a2:	0004879b          	sext.w	a5,s1
    if(state == 0){
 5a6:	fe0993e3          	bnez	s3,58c <vprintf+0x40>
      if(c0 == '%'){
 5aa:	fd579ce3          	bne	a5,s5,582 <vprintf+0x36>
        state = '%';
 5ae:	89be                	mv	s3,a5
 5b0:	b7c5                	j	590 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 5b2:	00ea06b3          	add	a3,s4,a4
 5b6:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 5ba:	1c060863          	beqz	a2,78a <vprintf+0x23e>
      if(c0 == 'd'){
 5be:	03878763          	beq	a5,s8,5ec <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5c2:	f9478693          	addi	a3,a5,-108
 5c6:	0016b693          	seqz	a3,a3
 5ca:	f9c60593          	addi	a1,a2,-100
 5ce:	e99d                	bnez	a1,604 <vprintf+0xb8>
 5d0:	ca95                	beqz	a3,604 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5d2:	008b8493          	addi	s1,s7,8
 5d6:	4685                	li	a3,1
 5d8:	4629                	li	a2,10
 5da:	000bb583          	ld	a1,0(s7)
 5de:	855a                	mv	a0,s6
 5e0:	ec9ff0ef          	jal	4a8 <printint>
        i += 1;
 5e4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 5e6:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 5e8:	4981                	li	s3,0
 5ea:	b75d                	j	590 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 5ec:	008b8493          	addi	s1,s7,8
 5f0:	4685                	li	a3,1
 5f2:	4629                	li	a2,10
 5f4:	000ba583          	lw	a1,0(s7)
 5f8:	855a                	mv	a0,s6
 5fa:	eafff0ef          	jal	4a8 <printint>
 5fe:	8ba6                	mv	s7,s1
      state = 0;
 600:	4981                	li	s3,0
 602:	b779                	j	590 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 604:	9752                	add	a4,a4,s4
 606:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 60a:	f9460713          	addi	a4,a2,-108
 60e:	00173713          	seqz	a4,a4
 612:	8f75                	and	a4,a4,a3
 614:	f9c58513          	addi	a0,a1,-100
 618:	18051363          	bnez	a0,79e <vprintf+0x252>
 61c:	18070163          	beqz	a4,79e <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 620:	008b8493          	addi	s1,s7,8
 624:	4685                	li	a3,1
 626:	4629                	li	a2,10
 628:	000bb583          	ld	a1,0(s7)
 62c:	855a                	mv	a0,s6
 62e:	e7bff0ef          	jal	4a8 <printint>
        i += 2;
 632:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 634:	8ba6                	mv	s7,s1
      state = 0;
 636:	4981                	li	s3,0
        i += 2;
 638:	bfa1                	j	590 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 63a:	008b8493          	addi	s1,s7,8
 63e:	4681                	li	a3,0
 640:	4629                	li	a2,10
 642:	000be583          	lwu	a1,0(s7)
 646:	855a                	mv	a0,s6
 648:	e61ff0ef          	jal	4a8 <printint>
 64c:	8ba6                	mv	s7,s1
      state = 0;
 64e:	4981                	li	s3,0
 650:	b781                	j	590 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 652:	008b8493          	addi	s1,s7,8
 656:	4681                	li	a3,0
 658:	4629                	li	a2,10
 65a:	000bb583          	ld	a1,0(s7)
 65e:	855a                	mv	a0,s6
 660:	e49ff0ef          	jal	4a8 <printint>
        i += 1;
 664:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 666:	8ba6                	mv	s7,s1
      state = 0;
 668:	4981                	li	s3,0
 66a:	b71d                	j	590 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 66c:	008b8493          	addi	s1,s7,8
 670:	4681                	li	a3,0
 672:	4629                	li	a2,10
 674:	000bb583          	ld	a1,0(s7)
 678:	855a                	mv	a0,s6
 67a:	e2fff0ef          	jal	4a8 <printint>
        i += 2;
 67e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 680:	8ba6                	mv	s7,s1
      state = 0;
 682:	4981                	li	s3,0
        i += 2;
 684:	b731                	j	590 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 686:	008b8493          	addi	s1,s7,8
 68a:	4681                	li	a3,0
 68c:	4641                	li	a2,16
 68e:	000be583          	lwu	a1,0(s7)
 692:	855a                	mv	a0,s6
 694:	e15ff0ef          	jal	4a8 <printint>
 698:	8ba6                	mv	s7,s1
      state = 0;
 69a:	4981                	li	s3,0
 69c:	bdd5                	j	590 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 69e:	008b8493          	addi	s1,s7,8
 6a2:	4681                	li	a3,0
 6a4:	4641                	li	a2,16
 6a6:	000bb583          	ld	a1,0(s7)
 6aa:	855a                	mv	a0,s6
 6ac:	dfdff0ef          	jal	4a8 <printint>
        i += 1;
 6b0:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 6b2:	8ba6                	mv	s7,s1
      state = 0;
 6b4:	4981                	li	s3,0
 6b6:	bde9                	j	590 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6b8:	008b8493          	addi	s1,s7,8
 6bc:	4681                	li	a3,0
 6be:	4641                	li	a2,16
 6c0:	000bb583          	ld	a1,0(s7)
 6c4:	855a                	mv	a0,s6
 6c6:	de3ff0ef          	jal	4a8 <printint>
        i += 2;
 6ca:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6cc:	8ba6                	mv	s7,s1
      state = 0;
 6ce:	4981                	li	s3,0
        i += 2;
 6d0:	b5c1                	j	590 <vprintf+0x44>
 6d2:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 6d4:	008b8793          	addi	a5,s7,8
 6d8:	8cbe                	mv	s9,a5
 6da:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6de:	03000593          	li	a1,48
 6e2:	855a                	mv	a0,s6
 6e4:	da7ff0ef          	jal	48a <putc>
  putc(fd, 'x');
 6e8:	07800593          	li	a1,120
 6ec:	855a                	mv	a0,s6
 6ee:	d9dff0ef          	jal	48a <putc>
 6f2:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6f4:	00000b97          	auipc	s7,0x0
 6f8:	394b8b93          	addi	s7,s7,916 # a88 <digits>
 6fc:	03c9d793          	srli	a5,s3,0x3c
 700:	97de                	add	a5,a5,s7
 702:	0007c583          	lbu	a1,0(a5)
 706:	855a                	mv	a0,s6
 708:	d83ff0ef          	jal	48a <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 70c:	0992                	slli	s3,s3,0x4
 70e:	34fd                	addiw	s1,s1,-1
 710:	f4f5                	bnez	s1,6fc <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 712:	8be6                	mv	s7,s9
      state = 0;
 714:	4981                	li	s3,0
 716:	6ca2                	ld	s9,8(sp)
 718:	bda5                	j	590 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 71a:	008b8493          	addi	s1,s7,8
 71e:	000bc583          	lbu	a1,0(s7)
 722:	855a                	mv	a0,s6
 724:	d67ff0ef          	jal	48a <putc>
 728:	8ba6                	mv	s7,s1
      state = 0;
 72a:	4981                	li	s3,0
 72c:	b595                	j	590 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 72e:	008b8993          	addi	s3,s7,8
 732:	000bb483          	ld	s1,0(s7)
 736:	cc91                	beqz	s1,752 <vprintf+0x206>
        for(; *s; s++)
 738:	0004c583          	lbu	a1,0(s1)
 73c:	c985                	beqz	a1,76c <vprintf+0x220>
          putc(fd, *s);
 73e:	855a                	mv	a0,s6
 740:	d4bff0ef          	jal	48a <putc>
        for(; *s; s++)
 744:	0485                	addi	s1,s1,1
 746:	0004c583          	lbu	a1,0(s1)
 74a:	f9f5                	bnez	a1,73e <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 74c:	8bce                	mv	s7,s3
      state = 0;
 74e:	4981                	li	s3,0
 750:	b581                	j	590 <vprintf+0x44>
          s = "(null)";
 752:	00000497          	auipc	s1,0x0
 756:	2ee48493          	addi	s1,s1,750 # a40 <malloc+0x152>
        for(; *s; s++)
 75a:	02800593          	li	a1,40
 75e:	b7c5                	j	73e <vprintf+0x1f2>
        putc(fd, '%');
 760:	85be                	mv	a1,a5
 762:	855a                	mv	a0,s6
 764:	d27ff0ef          	jal	48a <putc>
      state = 0;
 768:	4981                	li	s3,0
 76a:	b51d                	j	590 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 76c:	8bce                	mv	s7,s3
      state = 0;
 76e:	4981                	li	s3,0
 770:	b505                	j	590 <vprintf+0x44>
 772:	6906                	ld	s2,64(sp)
 774:	79e2                	ld	s3,56(sp)
 776:	7a42                	ld	s4,48(sp)
 778:	7aa2                	ld	s5,40(sp)
 77a:	7b02                	ld	s6,32(sp)
 77c:	6be2                	ld	s7,24(sp)
 77e:	6c42                	ld	s8,16(sp)
    }
  }
}
 780:	60e6                	ld	ra,88(sp)
 782:	6446                	ld	s0,80(sp)
 784:	64a6                	ld	s1,72(sp)
 786:	6125                	addi	sp,sp,96
 788:	8082                	ret
      if(c0 == 'd'){
 78a:	06400713          	li	a4,100
 78e:	e4e78fe3          	beq	a5,a4,5ec <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 792:	f9478693          	addi	a3,a5,-108
 796:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 79a:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 79c:	4701                	li	a4,0
      } else if(c0 == 'u'){
 79e:	07500513          	li	a0,117
 7a2:	e8a78ce3          	beq	a5,a0,63a <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 7a6:	f8b60513          	addi	a0,a2,-117
 7aa:	e119                	bnez	a0,7b0 <vprintf+0x264>
 7ac:	ea0693e3          	bnez	a3,652 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 7b0:	f8b58513          	addi	a0,a1,-117
 7b4:	e119                	bnez	a0,7ba <vprintf+0x26e>
 7b6:	ea071be3          	bnez	a4,66c <vprintf+0x120>
      } else if(c0 == 'x'){
 7ba:	07800513          	li	a0,120
 7be:	eca784e3          	beq	a5,a0,686 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 7c2:	f8860613          	addi	a2,a2,-120
 7c6:	e219                	bnez	a2,7cc <vprintf+0x280>
 7c8:	ec069be3          	bnez	a3,69e <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 7cc:	f8858593          	addi	a1,a1,-120
 7d0:	e199                	bnez	a1,7d6 <vprintf+0x28a>
 7d2:	ee0713e3          	bnez	a4,6b8 <vprintf+0x16c>
      } else if(c0 == 'p'){
 7d6:	07000713          	li	a4,112
 7da:	eee78ce3          	beq	a5,a4,6d2 <vprintf+0x186>
      } else if(c0 == 'c'){
 7de:	06300713          	li	a4,99
 7e2:	f2e78ce3          	beq	a5,a4,71a <vprintf+0x1ce>
      } else if(c0 == 's'){
 7e6:	07300713          	li	a4,115
 7ea:	f4e782e3          	beq	a5,a4,72e <vprintf+0x1e2>
      } else if(c0 == '%'){
 7ee:	02500713          	li	a4,37
 7f2:	f6e787e3          	beq	a5,a4,760 <vprintf+0x214>
        putc(fd, '%');
 7f6:	02500593          	li	a1,37
 7fa:	855a                	mv	a0,s6
 7fc:	c8fff0ef          	jal	48a <putc>
        putc(fd, c0);
 800:	85a6                	mv	a1,s1
 802:	855a                	mv	a0,s6
 804:	c87ff0ef          	jal	48a <putc>
      state = 0;
 808:	4981                	li	s3,0
 80a:	b359                	j	590 <vprintf+0x44>

000000000000080c <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 80c:	715d                	addi	sp,sp,-80
 80e:	ec06                	sd	ra,24(sp)
 810:	e822                	sd	s0,16(sp)
 812:	1000                	addi	s0,sp,32
 814:	e010                	sd	a2,0(s0)
 816:	e414                	sd	a3,8(s0)
 818:	e818                	sd	a4,16(s0)
 81a:	ec1c                	sd	a5,24(s0)
 81c:	03043023          	sd	a6,32(s0)
 820:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 824:	8622                	mv	a2,s0
 826:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 82a:	d23ff0ef          	jal	54c <vprintf>
}
 82e:	60e2                	ld	ra,24(sp)
 830:	6442                	ld	s0,16(sp)
 832:	6161                	addi	sp,sp,80
 834:	8082                	ret

0000000000000836 <printf>:

void
printf(const char *fmt, ...)
{
 836:	711d                	addi	sp,sp,-96
 838:	ec06                	sd	ra,24(sp)
 83a:	e822                	sd	s0,16(sp)
 83c:	1000                	addi	s0,sp,32
 83e:	e40c                	sd	a1,8(s0)
 840:	e810                	sd	a2,16(s0)
 842:	ec14                	sd	a3,24(s0)
 844:	f018                	sd	a4,32(s0)
 846:	f41c                	sd	a5,40(s0)
 848:	03043823          	sd	a6,48(s0)
 84c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 850:	00840613          	addi	a2,s0,8
 854:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 858:	85aa                	mv	a1,a0
 85a:	4505                	li	a0,1
 85c:	cf1ff0ef          	jal	54c <vprintf>
}
 860:	60e2                	ld	ra,24(sp)
 862:	6442                	ld	s0,16(sp)
 864:	6125                	addi	sp,sp,96
 866:	8082                	ret

0000000000000868 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 868:	1141                	addi	sp,sp,-16
 86a:	e406                	sd	ra,8(sp)
 86c:	e022                	sd	s0,0(sp)
 86e:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 870:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 874:	00000797          	auipc	a5,0x0
 878:	78c7b783          	ld	a5,1932(a5) # 1000 <freep>
 87c:	a039                	j	88a <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 87e:	6398                	ld	a4,0(a5)
 880:	00e7e463          	bltu	a5,a4,888 <free+0x20>
 884:	00e6ea63          	bltu	a3,a4,898 <free+0x30>
{
 888:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 88a:	fed7fae3          	bgeu	a5,a3,87e <free+0x16>
 88e:	6398                	ld	a4,0(a5)
 890:	00e6e463          	bltu	a3,a4,898 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 894:	fee7eae3          	bltu	a5,a4,888 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 898:	ff852583          	lw	a1,-8(a0)
 89c:	6390                	ld	a2,0(a5)
 89e:	02059813          	slli	a6,a1,0x20
 8a2:	01c85713          	srli	a4,a6,0x1c
 8a6:	9736                	add	a4,a4,a3
 8a8:	02e60563          	beq	a2,a4,8d2 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 8ac:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 8b0:	4790                	lw	a2,8(a5)
 8b2:	02061593          	slli	a1,a2,0x20
 8b6:	01c5d713          	srli	a4,a1,0x1c
 8ba:	973e                	add	a4,a4,a5
 8bc:	02e68263          	beq	a3,a4,8e0 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 8c0:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 8c2:	00000717          	auipc	a4,0x0
 8c6:	72f73f23          	sd	a5,1854(a4) # 1000 <freep>
}
 8ca:	60a2                	ld	ra,8(sp)
 8cc:	6402                	ld	s0,0(sp)
 8ce:	0141                	addi	sp,sp,16
 8d0:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 8d2:	4618                	lw	a4,8(a2)
 8d4:	9f2d                	addw	a4,a4,a1
 8d6:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 8da:	6398                	ld	a4,0(a5)
 8dc:	6310                	ld	a2,0(a4)
 8de:	b7f9                	j	8ac <free+0x44>
    p->s.size += bp->s.size;
 8e0:	ff852703          	lw	a4,-8(a0)
 8e4:	9f31                	addw	a4,a4,a2
 8e6:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 8e8:	ff053683          	ld	a3,-16(a0)
 8ec:	bfd1                	j	8c0 <free+0x58>

00000000000008ee <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 8ee:	7139                	addi	sp,sp,-64
 8f0:	fc06                	sd	ra,56(sp)
 8f2:	f822                	sd	s0,48(sp)
 8f4:	f04a                	sd	s2,32(sp)
 8f6:	ec4e                	sd	s3,24(sp)
 8f8:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 8fa:	02051993          	slli	s3,a0,0x20
 8fe:	0209d993          	srli	s3,s3,0x20
 902:	09bd                	addi	s3,s3,15
 904:	0049d993          	srli	s3,s3,0x4
 908:	2985                	addiw	s3,s3,1
 90a:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 90c:	00000517          	auipc	a0,0x0
 910:	6f453503          	ld	a0,1780(a0) # 1000 <freep>
 914:	c905                	beqz	a0,944 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 916:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 918:	4798                	lw	a4,8(a5)
 91a:	09377663          	bgeu	a4,s3,9a6 <malloc+0xb8>
 91e:	f426                	sd	s1,40(sp)
 920:	e852                	sd	s4,16(sp)
 922:	e456                	sd	s5,8(sp)
 924:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 926:	8a4e                	mv	s4,s3
 928:	6705                	lui	a4,0x1
 92a:	00e9f363          	bgeu	s3,a4,930 <malloc+0x42>
 92e:	6a05                	lui	s4,0x1
 930:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 934:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 938:	00000497          	auipc	s1,0x0
 93c:	6c848493          	addi	s1,s1,1736 # 1000 <freep>
  if(p == SBRK_ERROR)
 940:	5afd                	li	s5,-1
 942:	a83d                	j	980 <malloc+0x92>
 944:	f426                	sd	s1,40(sp)
 946:	e852                	sd	s4,16(sp)
 948:	e456                	sd	s5,8(sp)
 94a:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 94c:	00000797          	auipc	a5,0x0
 950:	6c478793          	addi	a5,a5,1732 # 1010 <base>
 954:	00000717          	auipc	a4,0x0
 958:	6af73623          	sd	a5,1708(a4) # 1000 <freep>
 95c:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 95e:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 962:	b7d1                	j	926 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 964:	6398                	ld	a4,0(a5)
 966:	e118                	sd	a4,0(a0)
 968:	a899                	j	9be <malloc+0xd0>
  hp->s.size = nu;
 96a:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 96e:	0541                	addi	a0,a0,16
 970:	ef9ff0ef          	jal	868 <free>
  return freep;
 974:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 976:	c125                	beqz	a0,9d6 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 978:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 97a:	4798                	lw	a4,8(a5)
 97c:	03277163          	bgeu	a4,s2,99e <malloc+0xb0>
    if(p == freep)
 980:	6098                	ld	a4,0(s1)
 982:	853e                	mv	a0,a5
 984:	fef71ae3          	bne	a4,a5,978 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 988:	8552                	mv	a0,s4
 98a:	9f5ff0ef          	jal	37e <sbrk>
  if(p == SBRK_ERROR)
 98e:	fd551ee3          	bne	a0,s5,96a <malloc+0x7c>
        return 0;
 992:	4501                	li	a0,0
 994:	74a2                	ld	s1,40(sp)
 996:	6a42                	ld	s4,16(sp)
 998:	6aa2                	ld	s5,8(sp)
 99a:	6b02                	ld	s6,0(sp)
 99c:	a03d                	j	9ca <malloc+0xdc>
 99e:	74a2                	ld	s1,40(sp)
 9a0:	6a42                	ld	s4,16(sp)
 9a2:	6aa2                	ld	s5,8(sp)
 9a4:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 9a6:	fae90fe3          	beq	s2,a4,964 <malloc+0x76>
        p->s.size -= nunits;
 9aa:	4137073b          	subw	a4,a4,s3
 9ae:	c798                	sw	a4,8(a5)
        p += p->s.size;
 9b0:	02071693          	slli	a3,a4,0x20
 9b4:	01c6d713          	srli	a4,a3,0x1c
 9b8:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 9ba:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 9be:	00000717          	auipc	a4,0x0
 9c2:	64a73123          	sd	a0,1602(a4) # 1000 <freep>
      return (void*)(p + 1);
 9c6:	01078513          	addi	a0,a5,16
  }
}
 9ca:	70e2                	ld	ra,56(sp)
 9cc:	7442                	ld	s0,48(sp)
 9ce:	7902                	ld	s2,32(sp)
 9d0:	69e2                	ld	s3,24(sp)
 9d2:	6121                	addi	sp,sp,64
 9d4:	8082                	ret
 9d6:	74a2                	ld	s1,40(sp)
 9d8:	6a42                	ld	s4,16(sp)
 9da:	6aa2                	ld	s5,8(sp)
 9dc:	6b02                	ld	s6,0(sp)
 9de:	b7f5                	j	9ca <malloc+0xdc>
