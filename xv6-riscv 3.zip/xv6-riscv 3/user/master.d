user/master.o: user/master.c kernel/types.h kernel/stat.h user/user.h
