
user/_mboxtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
   0:	7139                	addi	sp,sp,-64
   2:	fc06                	sd	ra,56(sp)
   4:	f822                	sd	s0,48(sp)
   6:	0080                	addi	s0,sp,64
  int key = 1;   // mailbox id
  int pid;

  if(mbox_create(key) < 0){
   8:	4505                	li	a0,1
   a:	41e000ef          	jal	428 <mbox_create>
   e:	04054063          	bltz	a0,4e <main+0x4e>
  12:	f426                	sd	s1,40(sp)
    printf("mbtest: mailbox already exists\n");
    exit(1);
  }

  pid = fork();
  14:	354000ef          	jal	368 <fork>
  18:	84aa                	mv	s1,a0
  if(pid < 0){
  1a:	04054763          	bltz	a0,68 <main+0x68>
    printf("mbtest: fork failed\n");
    exit(1);
  }

  if(pid == 0){
  1e:	e12d                	bnez	a0,80 <main+0x80>
  20:	f04a                	sd	s2,32(sp)
  22:	ec4e                	sd	s3,24(sp)
  24:	e852                	sd	s4,16(sp)
    // child process: send some messages
    for(int i = 0; i < 5; i++){
      printf("child:sending%d\n", i);
  26:	00001a17          	auipc	s4,0x1
  2a:	9baa0a13          	addi	s4,s4,-1606 # 9e0 <malloc+0x134>
      mbox_send(key, i);
  2e:	4985                	li	s3,1
    for(int i = 0; i < 5; i++){
  30:	4915                	li	s2,5
      printf("child:sending%d\n", i);
  32:	85a6                	mv	a1,s1
  34:	8552                	mv	a0,s4
  36:	7be000ef          	jal	7f4 <printf>
      mbox_send(key, i);
  3a:	85a6                	mv	a1,s1
  3c:	854e                	mv	a0,s3
  3e:	3f2000ef          	jal	430 <mbox_send>
    for(int i = 0; i < 5; i++){
  42:	2485                	addiw	s1,s1,1
  44:	ff2497e3          	bne	s1,s2,32 <main+0x32>
    }
    exit(0);
  48:	4501                	li	a0,0
  4a:	326000ef          	jal	370 <exit>
  4e:	f426                	sd	s1,40(sp)
  50:	f04a                	sd	s2,32(sp)
  52:	ec4e                	sd	s3,24(sp)
  54:	e852                	sd	s4,16(sp)
    printf("mbtest: mailbox already exists\n");
  56:	00001517          	auipc	a0,0x1
  5a:	94a50513          	addi	a0,a0,-1718 # 9a0 <malloc+0xf4>
  5e:	796000ef          	jal	7f4 <printf>
    exit(1);
  62:	4505                	li	a0,1
  64:	30c000ef          	jal	370 <exit>
  68:	f04a                	sd	s2,32(sp)
  6a:	ec4e                	sd	s3,24(sp)
  6c:	e852                	sd	s4,16(sp)
    printf("mbtest: fork failed\n");
  6e:	00001517          	auipc	a0,0x1
  72:	95250513          	addi	a0,a0,-1710 # 9c0 <malloc+0x114>
  76:	77e000ef          	jal	7f4 <printf>
    exit(1);
  7a:	4505                	li	a0,1
  7c:	2f4000ef          	jal	370 <exit>
  80:	f04a                	sd	s2,32(sp)
  82:	ec4e                	sd	s3,24(sp)
  84:	e852                	sd	s4,16(sp)
  86:	4495                	li	s1,5
  } else {
     
    // parent process: receive messages
    int msg;
    for(int i = 0; i < 5; i++){
      mbox_recv(key, &msg);
  88:	fcc40a13          	addi	s4,s0,-52
  8c:	4985                	li	s3,1
      printf("parent:received%d\n", msg);
  8e:	00001917          	auipc	s2,0x1
  92:	96a90913          	addi	s2,s2,-1686 # 9f8 <malloc+0x14c>
      mbox_recv(key, &msg);
  96:	85d2                	mv	a1,s4
  98:	854e                	mv	a0,s3
  9a:	39e000ef          	jal	438 <mbox_recv>
      printf("parent:received%d\n", msg);
  9e:	fcc42583          	lw	a1,-52(s0)
  a2:	854a                	mv	a0,s2
  a4:	750000ef          	jal	7f4 <printf>
    for(int i = 0; i < 5; i++){
  a8:	34fd                	addiw	s1,s1,-1
  aa:	f4f5                	bnez	s1,96 <main+0x96>
    }
    wait(0);
  ac:	4501                	li	a0,0
  ae:	2ca000ef          	jal	378 <wait>
  }

  exit(0);
  b2:	4501                	li	a0,0
  b4:	2bc000ef          	jal	370 <exit>

00000000000000b8 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  b8:	1141                	addi	sp,sp,-16
  ba:	e406                	sd	ra,8(sp)
  bc:	e022                	sd	s0,0(sp)
  be:	0800                	addi	s0,sp,16
  extern int main();
  main();
  c0:	f41ff0ef          	jal	0 <main>
  exit(0);
  c4:	4501                	li	a0,0
  c6:	2aa000ef          	jal	370 <exit>

00000000000000ca <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  ca:	1141                	addi	sp,sp,-16
  cc:	e406                	sd	ra,8(sp)
  ce:	e022                	sd	s0,0(sp)
  d0:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  d2:	87aa                	mv	a5,a0
  d4:	0585                	addi	a1,a1,1
  d6:	0785                	addi	a5,a5,1
  d8:	fff5c703          	lbu	a4,-1(a1)
  dc:	fee78fa3          	sb	a4,-1(a5)
  e0:	fb75                	bnez	a4,d4 <strcpy+0xa>
    ;
  return os;
}
  e2:	60a2                	ld	ra,8(sp)
  e4:	6402                	ld	s0,0(sp)
  e6:	0141                	addi	sp,sp,16
  e8:	8082                	ret

00000000000000ea <strcmp>:

int
strcmp(const char *p, const char *q)
{
  ea:	1141                	addi	sp,sp,-16
  ec:	e406                	sd	ra,8(sp)
  ee:	e022                	sd	s0,0(sp)
  f0:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
  f2:	00054783          	lbu	a5,0(a0)
  f6:	cb91                	beqz	a5,10a <strcmp+0x20>
  f8:	0005c703          	lbu	a4,0(a1)
  fc:	00f71763          	bne	a4,a5,10a <strcmp+0x20>
    p++, q++;
 100:	0505                	addi	a0,a0,1
 102:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 104:	00054783          	lbu	a5,0(a0)
 108:	fbe5                	bnez	a5,f8 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 10a:	0005c503          	lbu	a0,0(a1)
}
 10e:	40a7853b          	subw	a0,a5,a0
 112:	60a2                	ld	ra,8(sp)
 114:	6402                	ld	s0,0(sp)
 116:	0141                	addi	sp,sp,16
 118:	8082                	ret

000000000000011a <strlen>:

uint
strlen(const char *s)
{
 11a:	1141                	addi	sp,sp,-16
 11c:	e406                	sd	ra,8(sp)
 11e:	e022                	sd	s0,0(sp)
 120:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 122:	00054783          	lbu	a5,0(a0)
 126:	cf91                	beqz	a5,142 <strlen+0x28>
 128:	00150793          	addi	a5,a0,1
 12c:	86be                	mv	a3,a5
 12e:	0785                	addi	a5,a5,1
 130:	fff7c703          	lbu	a4,-1(a5)
 134:	ff65                	bnez	a4,12c <strlen+0x12>
 136:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 13a:	60a2                	ld	ra,8(sp)
 13c:	6402                	ld	s0,0(sp)
 13e:	0141                	addi	sp,sp,16
 140:	8082                	ret
  for(n = 0; s[n]; n++)
 142:	4501                	li	a0,0
 144:	bfdd                	j	13a <strlen+0x20>

0000000000000146 <memset>:

void*
memset(void *dst, int c, uint n)
{
 146:	1141                	addi	sp,sp,-16
 148:	e406                	sd	ra,8(sp)
 14a:	e022                	sd	s0,0(sp)
 14c:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 14e:	ca19                	beqz	a2,164 <memset+0x1e>
 150:	87aa                	mv	a5,a0
 152:	1602                	slli	a2,a2,0x20
 154:	9201                	srli	a2,a2,0x20
 156:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 15a:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 15e:	0785                	addi	a5,a5,1
 160:	fee79de3          	bne	a5,a4,15a <memset+0x14>
  }
  return dst;
}
 164:	60a2                	ld	ra,8(sp)
 166:	6402                	ld	s0,0(sp)
 168:	0141                	addi	sp,sp,16
 16a:	8082                	ret

000000000000016c <strchr>:

char*
strchr(const char *s, char c)
{
 16c:	1141                	addi	sp,sp,-16
 16e:	e406                	sd	ra,8(sp)
 170:	e022                	sd	s0,0(sp)
 172:	0800                	addi	s0,sp,16
  for(; *s; s++)
 174:	00054783          	lbu	a5,0(a0)
 178:	cf81                	beqz	a5,190 <strchr+0x24>
    if(*s == c)
 17a:	00f58763          	beq	a1,a5,188 <strchr+0x1c>
  for(; *s; s++)
 17e:	0505                	addi	a0,a0,1
 180:	00054783          	lbu	a5,0(a0)
 184:	fbfd                	bnez	a5,17a <strchr+0xe>
      return (char*)s;
  return 0;
 186:	4501                	li	a0,0
}
 188:	60a2                	ld	ra,8(sp)
 18a:	6402                	ld	s0,0(sp)
 18c:	0141                	addi	sp,sp,16
 18e:	8082                	ret
  return 0;
 190:	4501                	li	a0,0
 192:	bfdd                	j	188 <strchr+0x1c>

0000000000000194 <gets>:

char*
gets(char *buf, int max)
{
 194:	711d                	addi	sp,sp,-96
 196:	ec86                	sd	ra,88(sp)
 198:	e8a2                	sd	s0,80(sp)
 19a:	e4a6                	sd	s1,72(sp)
 19c:	e0ca                	sd	s2,64(sp)
 19e:	fc4e                	sd	s3,56(sp)
 1a0:	f852                	sd	s4,48(sp)
 1a2:	f456                	sd	s5,40(sp)
 1a4:	f05a                	sd	s6,32(sp)
 1a6:	ec5e                	sd	s7,24(sp)
 1a8:	e862                	sd	s8,16(sp)
 1aa:	1080                	addi	s0,sp,96
 1ac:	8baa                	mv	s7,a0
 1ae:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1b0:	892a                	mv	s2,a0
 1b2:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1b4:	faf40b13          	addi	s6,s0,-81
 1b8:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 1ba:	8c26                	mv	s8,s1
 1bc:	0014899b          	addiw	s3,s1,1
 1c0:	84ce                	mv	s1,s3
 1c2:	0349d463          	bge	s3,s4,1ea <gets+0x56>
    cc = read(0, &c, 1);
 1c6:	8656                	mv	a2,s5
 1c8:	85da                	mv	a1,s6
 1ca:	4501                	li	a0,0
 1cc:	1bc000ef          	jal	388 <read>
    if(cc < 1)
 1d0:	00a05d63          	blez	a0,1ea <gets+0x56>
      break;
    buf[i++] = c;
 1d4:	faf44783          	lbu	a5,-81(s0)
 1d8:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 1dc:	0905                	addi	s2,s2,1
 1de:	ff678713          	addi	a4,a5,-10
 1e2:	c319                	beqz	a4,1e8 <gets+0x54>
 1e4:	17cd                	addi	a5,a5,-13
 1e6:	fbf1                	bnez	a5,1ba <gets+0x26>
    buf[i++] = c;
 1e8:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 1ea:	9c5e                	add	s8,s8,s7
 1ec:	000c0023          	sb	zero,0(s8)
  return buf;
}
 1f0:	855e                	mv	a0,s7
 1f2:	60e6                	ld	ra,88(sp)
 1f4:	6446                	ld	s0,80(sp)
 1f6:	64a6                	ld	s1,72(sp)
 1f8:	6906                	ld	s2,64(sp)
 1fa:	79e2                	ld	s3,56(sp)
 1fc:	7a42                	ld	s4,48(sp)
 1fe:	7aa2                	ld	s5,40(sp)
 200:	7b02                	ld	s6,32(sp)
 202:	6be2                	ld	s7,24(sp)
 204:	6c42                	ld	s8,16(sp)
 206:	6125                	addi	sp,sp,96
 208:	8082                	ret

000000000000020a <stat>:

int
stat(const char *n, struct stat *st)
{
 20a:	1101                	addi	sp,sp,-32
 20c:	ec06                	sd	ra,24(sp)
 20e:	e822                	sd	s0,16(sp)
 210:	e04a                	sd	s2,0(sp)
 212:	1000                	addi	s0,sp,32
 214:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 216:	4581                	li	a1,0
 218:	198000ef          	jal	3b0 <open>
  if(fd < 0)
 21c:	02054263          	bltz	a0,240 <stat+0x36>
 220:	e426                	sd	s1,8(sp)
 222:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 224:	85ca                	mv	a1,s2
 226:	1a2000ef          	jal	3c8 <fstat>
 22a:	892a                	mv	s2,a0
  close(fd);
 22c:	8526                	mv	a0,s1
 22e:	16a000ef          	jal	398 <close>
  return r;
 232:	64a2                	ld	s1,8(sp)
}
 234:	854a                	mv	a0,s2
 236:	60e2                	ld	ra,24(sp)
 238:	6442                	ld	s0,16(sp)
 23a:	6902                	ld	s2,0(sp)
 23c:	6105                	addi	sp,sp,32
 23e:	8082                	ret
    return -1;
 240:	57fd                	li	a5,-1
 242:	893e                	mv	s2,a5
 244:	bfc5                	j	234 <stat+0x2a>

0000000000000246 <atoi>:

int
atoi(const char *s)
{
 246:	1141                	addi	sp,sp,-16
 248:	e406                	sd	ra,8(sp)
 24a:	e022                	sd	s0,0(sp)
 24c:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 24e:	00054683          	lbu	a3,0(a0)
 252:	fd06879b          	addiw	a5,a3,-48
 256:	0ff7f793          	zext.b	a5,a5
 25a:	4625                	li	a2,9
 25c:	02f66963          	bltu	a2,a5,28e <atoi+0x48>
 260:	872a                	mv	a4,a0
  n = 0;
 262:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 264:	0705                	addi	a4,a4,1
 266:	0025179b          	slliw	a5,a0,0x2
 26a:	9fa9                	addw	a5,a5,a0
 26c:	0017979b          	slliw	a5,a5,0x1
 270:	9fb5                	addw	a5,a5,a3
 272:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 276:	00074683          	lbu	a3,0(a4)
 27a:	fd06879b          	addiw	a5,a3,-48
 27e:	0ff7f793          	zext.b	a5,a5
 282:	fef671e3          	bgeu	a2,a5,264 <atoi+0x1e>
  return n;
}
 286:	60a2                	ld	ra,8(sp)
 288:	6402                	ld	s0,0(sp)
 28a:	0141                	addi	sp,sp,16
 28c:	8082                	ret
  n = 0;
 28e:	4501                	li	a0,0
 290:	bfdd                	j	286 <atoi+0x40>

0000000000000292 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 292:	1141                	addi	sp,sp,-16
 294:	e406                	sd	ra,8(sp)
 296:	e022                	sd	s0,0(sp)
 298:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 29a:	02b57563          	bgeu	a0,a1,2c4 <memmove+0x32>
    while(n-- > 0)
 29e:	00c05f63          	blez	a2,2bc <memmove+0x2a>
 2a2:	1602                	slli	a2,a2,0x20
 2a4:	9201                	srli	a2,a2,0x20
 2a6:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2aa:	872a                	mv	a4,a0
      *dst++ = *src++;
 2ac:	0585                	addi	a1,a1,1
 2ae:	0705                	addi	a4,a4,1
 2b0:	fff5c683          	lbu	a3,-1(a1)
 2b4:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 2b8:	fee79ae3          	bne	a5,a4,2ac <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2bc:	60a2                	ld	ra,8(sp)
 2be:	6402                	ld	s0,0(sp)
 2c0:	0141                	addi	sp,sp,16
 2c2:	8082                	ret
    while(n-- > 0)
 2c4:	fec05ce3          	blez	a2,2bc <memmove+0x2a>
    dst += n;
 2c8:	00c50733          	add	a4,a0,a2
    src += n;
 2cc:	95b2                	add	a1,a1,a2
 2ce:	fff6079b          	addiw	a5,a2,-1
 2d2:	1782                	slli	a5,a5,0x20
 2d4:	9381                	srli	a5,a5,0x20
 2d6:	fff7c793          	not	a5,a5
 2da:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2dc:	15fd                	addi	a1,a1,-1
 2de:	177d                	addi	a4,a4,-1
 2e0:	0005c683          	lbu	a3,0(a1)
 2e4:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 2e8:	fef71ae3          	bne	a4,a5,2dc <memmove+0x4a>
 2ec:	bfc1                	j	2bc <memmove+0x2a>

00000000000002ee <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 2ee:	1141                	addi	sp,sp,-16
 2f0:	e406                	sd	ra,8(sp)
 2f2:	e022                	sd	s0,0(sp)
 2f4:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 2f6:	c61d                	beqz	a2,324 <memcmp+0x36>
 2f8:	1602                	slli	a2,a2,0x20
 2fa:	9201                	srli	a2,a2,0x20
 2fc:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 300:	00054783          	lbu	a5,0(a0)
 304:	0005c703          	lbu	a4,0(a1)
 308:	00e79863          	bne	a5,a4,318 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 30c:	0505                	addi	a0,a0,1
    p2++;
 30e:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 310:	fed518e3          	bne	a0,a3,300 <memcmp+0x12>
  }
  return 0;
 314:	4501                	li	a0,0
 316:	a019                	j	31c <memcmp+0x2e>
      return *p1 - *p2;
 318:	40e7853b          	subw	a0,a5,a4
}
 31c:	60a2                	ld	ra,8(sp)
 31e:	6402                	ld	s0,0(sp)
 320:	0141                	addi	sp,sp,16
 322:	8082                	ret
  return 0;
 324:	4501                	li	a0,0
 326:	bfdd                	j	31c <memcmp+0x2e>

0000000000000328 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 328:	1141                	addi	sp,sp,-16
 32a:	e406                	sd	ra,8(sp)
 32c:	e022                	sd	s0,0(sp)
 32e:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 330:	f63ff0ef          	jal	292 <memmove>
}
 334:	60a2                	ld	ra,8(sp)
 336:	6402                	ld	s0,0(sp)
 338:	0141                	addi	sp,sp,16
 33a:	8082                	ret

000000000000033c <sbrk>:

char *
sbrk(int n) {
 33c:	1141                	addi	sp,sp,-16
 33e:	e406                	sd	ra,8(sp)
 340:	e022                	sd	s0,0(sp)
 342:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 344:	4585                	li	a1,1
 346:	0b2000ef          	jal	3f8 <sys_sbrk>
}
 34a:	60a2                	ld	ra,8(sp)
 34c:	6402                	ld	s0,0(sp)
 34e:	0141                	addi	sp,sp,16
 350:	8082                	ret

0000000000000352 <sbrklazy>:

char *
sbrklazy(int n) {
 352:	1141                	addi	sp,sp,-16
 354:	e406                	sd	ra,8(sp)
 356:	e022                	sd	s0,0(sp)
 358:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 35a:	4589                	li	a1,2
 35c:	09c000ef          	jal	3f8 <sys_sbrk>
}
 360:	60a2                	ld	ra,8(sp)
 362:	6402                	ld	s0,0(sp)
 364:	0141                	addi	sp,sp,16
 366:	8082                	ret

0000000000000368 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 368:	4885                	li	a7,1
 ecall
 36a:	00000073          	ecall
 ret
 36e:	8082                	ret

0000000000000370 <exit>:
.global exit
exit:
 li a7, SYS_exit
 370:	4889                	li	a7,2
 ecall
 372:	00000073          	ecall
 ret
 376:	8082                	ret

0000000000000378 <wait>:
.global wait
wait:
 li a7, SYS_wait
 378:	488d                	li	a7,3
 ecall
 37a:	00000073          	ecall
 ret
 37e:	8082                	ret

0000000000000380 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 380:	4891                	li	a7,4
 ecall
 382:	00000073          	ecall
 ret
 386:	8082                	ret

0000000000000388 <read>:
.global read
read:
 li a7, SYS_read
 388:	4895                	li	a7,5
 ecall
 38a:	00000073          	ecall
 ret
 38e:	8082                	ret

0000000000000390 <write>:
.global write
write:
 li a7, SYS_write
 390:	48c1                	li	a7,16
 ecall
 392:	00000073          	ecall
 ret
 396:	8082                	ret

0000000000000398 <close>:
.global close
close:
 li a7, SYS_close
 398:	48d5                	li	a7,21
 ecall
 39a:	00000073          	ecall
 ret
 39e:	8082                	ret

00000000000003a0 <kill>:
.global kill
kill:
 li a7, SYS_kill
 3a0:	4899                	li	a7,6
 ecall
 3a2:	00000073          	ecall
 ret
 3a6:	8082                	ret

00000000000003a8 <exec>:
.global exec
exec:
 li a7, SYS_exec
 3a8:	489d                	li	a7,7
 ecall
 3aa:	00000073          	ecall
 ret
 3ae:	8082                	ret

00000000000003b0 <open>:
.global open
open:
 li a7, SYS_open
 3b0:	48bd                	li	a7,15
 ecall
 3b2:	00000073          	ecall
 ret
 3b6:	8082                	ret

00000000000003b8 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3b8:	48c5                	li	a7,17
 ecall
 3ba:	00000073          	ecall
 ret
 3be:	8082                	ret

00000000000003c0 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3c0:	48c9                	li	a7,18
 ecall
 3c2:	00000073          	ecall
 ret
 3c6:	8082                	ret

00000000000003c8 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3c8:	48a1                	li	a7,8
 ecall
 3ca:	00000073          	ecall
 ret
 3ce:	8082                	ret

00000000000003d0 <link>:
.global link
link:
 li a7, SYS_link
 3d0:	48cd                	li	a7,19
 ecall
 3d2:	00000073          	ecall
 ret
 3d6:	8082                	ret

00000000000003d8 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3d8:	48d1                	li	a7,20
 ecall
 3da:	00000073          	ecall
 ret
 3de:	8082                	ret

00000000000003e0 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 3e0:	48a5                	li	a7,9
 ecall
 3e2:	00000073          	ecall
 ret
 3e6:	8082                	ret

00000000000003e8 <dup>:
.global dup
dup:
 li a7, SYS_dup
 3e8:	48a9                	li	a7,10
 ecall
 3ea:	00000073          	ecall
 ret
 3ee:	8082                	ret

00000000000003f0 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 3f0:	48ad                	li	a7,11
 ecall
 3f2:	00000073          	ecall
 ret
 3f6:	8082                	ret

00000000000003f8 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 3f8:	48b1                	li	a7,12
 ecall
 3fa:	00000073          	ecall
 ret
 3fe:	8082                	ret

0000000000000400 <pause>:
.global pause
pause:
 li a7, SYS_pause
 400:	48b5                	li	a7,13
 ecall
 402:	00000073          	ecall
 ret
 406:	8082                	ret

0000000000000408 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 408:	48b9                	li	a7,14
 ecall
 40a:	00000073          	ecall
 ret
 40e:	8082                	ret

0000000000000410 <shm_create>:
.global shm_create
shm_create:
 li a7, SYS_shm_create
 410:	48d9                	li	a7,22
 ecall
 412:	00000073          	ecall
 ret
 416:	8082                	ret

0000000000000418 <shm_get>:
.global shm_get
shm_get:
 li a7, SYS_shm_get
 418:	48dd                	li	a7,23
 ecall
 41a:	00000073          	ecall
 ret
 41e:	8082                	ret

0000000000000420 <shm_close>:
.global shm_close
shm_close:
 li a7, SYS_shm_close
 420:	48e1                	li	a7,24
 ecall
 422:	00000073          	ecall
 ret
 426:	8082                	ret

0000000000000428 <mbox_create>:
.global mbox_create
mbox_create:
 li a7, SYS_mbox_create
 428:	48e5                	li	a7,25
 ecall
 42a:	00000073          	ecall
 ret
 42e:	8082                	ret

0000000000000430 <mbox_send>:
.global mbox_send
mbox_send:
 li a7, SYS_mbox_send
 430:	48e9                	li	a7,26
 ecall
 432:	00000073          	ecall
 ret
 436:	8082                	ret

0000000000000438 <mbox_recv>:
.global mbox_recv
mbox_recv:
 li a7, SYS_mbox_recv
 438:	48ed                	li	a7,27
 ecall
 43a:	00000073          	ecall
 ret
 43e:	8082                	ret

0000000000000440 <va2pa>:
.global va2pa
va2pa:
 li a7, SYS_va2pa
 440:	48f1                	li	a7,28
 ecall
 442:	00000073          	ecall
 ret
 446:	8082                	ret

0000000000000448 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 448:	1101                	addi	sp,sp,-32
 44a:	ec06                	sd	ra,24(sp)
 44c:	e822                	sd	s0,16(sp)
 44e:	1000                	addi	s0,sp,32
 450:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 454:	4605                	li	a2,1
 456:	fef40593          	addi	a1,s0,-17
 45a:	f37ff0ef          	jal	390 <write>
}
 45e:	60e2                	ld	ra,24(sp)
 460:	6442                	ld	s0,16(sp)
 462:	6105                	addi	sp,sp,32
 464:	8082                	ret

0000000000000466 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 466:	715d                	addi	sp,sp,-80
 468:	e486                	sd	ra,72(sp)
 46a:	e0a2                	sd	s0,64(sp)
 46c:	f84a                	sd	s2,48(sp)
 46e:	f44e                	sd	s3,40(sp)
 470:	0880                	addi	s0,sp,80
 472:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 474:	cac1                	beqz	a3,504 <printint+0x9e>
 476:	0805d763          	bgez	a1,504 <printint+0x9e>
    neg = 1;
    x = -xx;
 47a:	40b005bb          	negw	a1,a1
    neg = 1;
 47e:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 480:	fb840993          	addi	s3,s0,-72
  neg = 0;
 484:	86ce                	mv	a3,s3
  i = 0;
 486:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 488:	00000817          	auipc	a6,0x0
 48c:	59080813          	addi	a6,a6,1424 # a18 <digits>
 490:	88ba                	mv	a7,a4
 492:	0017051b          	addiw	a0,a4,1
 496:	872a                	mv	a4,a0
 498:	02c5f7bb          	remuw	a5,a1,a2
 49c:	1782                	slli	a5,a5,0x20
 49e:	9381                	srli	a5,a5,0x20
 4a0:	97c2                	add	a5,a5,a6
 4a2:	0007c783          	lbu	a5,0(a5)
 4a6:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 4aa:	87ae                	mv	a5,a1
 4ac:	02c5d5bb          	divuw	a1,a1,a2
 4b0:	0685                	addi	a3,a3,1
 4b2:	fcc7ffe3          	bgeu	a5,a2,490 <printint+0x2a>
  if(neg)
 4b6:	00030c63          	beqz	t1,4ce <printint+0x68>
    buf[i++] = '-';
 4ba:	fd050793          	addi	a5,a0,-48
 4be:	00878533          	add	a0,a5,s0
 4c2:	02d00793          	li	a5,45
 4c6:	fef50423          	sb	a5,-24(a0)
 4ca:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 4ce:	02e05563          	blez	a4,4f8 <printint+0x92>
 4d2:	fc26                	sd	s1,56(sp)
 4d4:	377d                	addiw	a4,a4,-1
 4d6:	00e984b3          	add	s1,s3,a4
 4da:	19fd                	addi	s3,s3,-1
 4dc:	99ba                	add	s3,s3,a4
 4de:	1702                	slli	a4,a4,0x20
 4e0:	9301                	srli	a4,a4,0x20
 4e2:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 4e6:	0004c583          	lbu	a1,0(s1)
 4ea:	854a                	mv	a0,s2
 4ec:	f5dff0ef          	jal	448 <putc>
  while(--i >= 0)
 4f0:	14fd                	addi	s1,s1,-1
 4f2:	ff349ae3          	bne	s1,s3,4e6 <printint+0x80>
 4f6:	74e2                	ld	s1,56(sp)
}
 4f8:	60a6                	ld	ra,72(sp)
 4fa:	6406                	ld	s0,64(sp)
 4fc:	7942                	ld	s2,48(sp)
 4fe:	79a2                	ld	s3,40(sp)
 500:	6161                	addi	sp,sp,80
 502:	8082                	ret
    x = xx;
 504:	2581                	sext.w	a1,a1
  neg = 0;
 506:	4301                	li	t1,0
 508:	bfa5                	j	480 <printint+0x1a>

000000000000050a <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 50a:	711d                	addi	sp,sp,-96
 50c:	ec86                	sd	ra,88(sp)
 50e:	e8a2                	sd	s0,80(sp)
 510:	e4a6                	sd	s1,72(sp)
 512:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 514:	0005c483          	lbu	s1,0(a1)
 518:	22048363          	beqz	s1,73e <vprintf+0x234>
 51c:	e0ca                	sd	s2,64(sp)
 51e:	fc4e                	sd	s3,56(sp)
 520:	f852                	sd	s4,48(sp)
 522:	f456                	sd	s5,40(sp)
 524:	f05a                	sd	s6,32(sp)
 526:	ec5e                	sd	s7,24(sp)
 528:	e862                	sd	s8,16(sp)
 52a:	8b2a                	mv	s6,a0
 52c:	8a2e                	mv	s4,a1
 52e:	8bb2                	mv	s7,a2
  state = 0;
 530:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 532:	4901                	li	s2,0
 534:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 536:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 53a:	06400c13          	li	s8,100
 53e:	a00d                	j	560 <vprintf+0x56>
        putc(fd, c0);
 540:	85a6                	mv	a1,s1
 542:	855a                	mv	a0,s6
 544:	f05ff0ef          	jal	448 <putc>
 548:	a019                	j	54e <vprintf+0x44>
    } else if(state == '%'){
 54a:	03598363          	beq	s3,s5,570 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 54e:	0019079b          	addiw	a5,s2,1
 552:	893e                	mv	s2,a5
 554:	873e                	mv	a4,a5
 556:	97d2                	add	a5,a5,s4
 558:	0007c483          	lbu	s1,0(a5)
 55c:	1c048a63          	beqz	s1,730 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 560:	0004879b          	sext.w	a5,s1
    if(state == 0){
 564:	fe0993e3          	bnez	s3,54a <vprintf+0x40>
      if(c0 == '%'){
 568:	fd579ce3          	bne	a5,s5,540 <vprintf+0x36>
        state = '%';
 56c:	89be                	mv	s3,a5
 56e:	b7c5                	j	54e <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 570:	00ea06b3          	add	a3,s4,a4
 574:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 578:	1c060863          	beqz	a2,748 <vprintf+0x23e>
      if(c0 == 'd'){
 57c:	03878763          	beq	a5,s8,5aa <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 580:	f9478693          	addi	a3,a5,-108
 584:	0016b693          	seqz	a3,a3
 588:	f9c60593          	addi	a1,a2,-100
 58c:	e99d                	bnez	a1,5c2 <vprintf+0xb8>
 58e:	ca95                	beqz	a3,5c2 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 590:	008b8493          	addi	s1,s7,8
 594:	4685                	li	a3,1
 596:	4629                	li	a2,10
 598:	000bb583          	ld	a1,0(s7)
 59c:	855a                	mv	a0,s6
 59e:	ec9ff0ef          	jal	466 <printint>
        i += 1;
 5a2:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 5a4:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 5a6:	4981                	li	s3,0
 5a8:	b75d                	j	54e <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 5aa:	008b8493          	addi	s1,s7,8
 5ae:	4685                	li	a3,1
 5b0:	4629                	li	a2,10
 5b2:	000ba583          	lw	a1,0(s7)
 5b6:	855a                	mv	a0,s6
 5b8:	eafff0ef          	jal	466 <printint>
 5bc:	8ba6                	mv	s7,s1
      state = 0;
 5be:	4981                	li	s3,0
 5c0:	b779                	j	54e <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 5c2:	9752                	add	a4,a4,s4
 5c4:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 5c8:	f9460713          	addi	a4,a2,-108
 5cc:	00173713          	seqz	a4,a4
 5d0:	8f75                	and	a4,a4,a3
 5d2:	f9c58513          	addi	a0,a1,-100
 5d6:	18051363          	bnez	a0,75c <vprintf+0x252>
 5da:	18070163          	beqz	a4,75c <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5de:	008b8493          	addi	s1,s7,8
 5e2:	4685                	li	a3,1
 5e4:	4629                	li	a2,10
 5e6:	000bb583          	ld	a1,0(s7)
 5ea:	855a                	mv	a0,s6
 5ec:	e7bff0ef          	jal	466 <printint>
        i += 2;
 5f0:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 5f2:	8ba6                	mv	s7,s1
      state = 0;
 5f4:	4981                	li	s3,0
        i += 2;
 5f6:	bfa1                	j	54e <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 5f8:	008b8493          	addi	s1,s7,8
 5fc:	4681                	li	a3,0
 5fe:	4629                	li	a2,10
 600:	000be583          	lwu	a1,0(s7)
 604:	855a                	mv	a0,s6
 606:	e61ff0ef          	jal	466 <printint>
 60a:	8ba6                	mv	s7,s1
      state = 0;
 60c:	4981                	li	s3,0
 60e:	b781                	j	54e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 610:	008b8493          	addi	s1,s7,8
 614:	4681                	li	a3,0
 616:	4629                	li	a2,10
 618:	000bb583          	ld	a1,0(s7)
 61c:	855a                	mv	a0,s6
 61e:	e49ff0ef          	jal	466 <printint>
        i += 1;
 622:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 624:	8ba6                	mv	s7,s1
      state = 0;
 626:	4981                	li	s3,0
 628:	b71d                	j	54e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 62a:	008b8493          	addi	s1,s7,8
 62e:	4681                	li	a3,0
 630:	4629                	li	a2,10
 632:	000bb583          	ld	a1,0(s7)
 636:	855a                	mv	a0,s6
 638:	e2fff0ef          	jal	466 <printint>
        i += 2;
 63c:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 63e:	8ba6                	mv	s7,s1
      state = 0;
 640:	4981                	li	s3,0
        i += 2;
 642:	b731                	j	54e <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 644:	008b8493          	addi	s1,s7,8
 648:	4681                	li	a3,0
 64a:	4641                	li	a2,16
 64c:	000be583          	lwu	a1,0(s7)
 650:	855a                	mv	a0,s6
 652:	e15ff0ef          	jal	466 <printint>
 656:	8ba6                	mv	s7,s1
      state = 0;
 658:	4981                	li	s3,0
 65a:	bdd5                	j	54e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 65c:	008b8493          	addi	s1,s7,8
 660:	4681                	li	a3,0
 662:	4641                	li	a2,16
 664:	000bb583          	ld	a1,0(s7)
 668:	855a                	mv	a0,s6
 66a:	dfdff0ef          	jal	466 <printint>
        i += 1;
 66e:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 670:	8ba6                	mv	s7,s1
      state = 0;
 672:	4981                	li	s3,0
 674:	bde9                	j	54e <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 676:	008b8493          	addi	s1,s7,8
 67a:	4681                	li	a3,0
 67c:	4641                	li	a2,16
 67e:	000bb583          	ld	a1,0(s7)
 682:	855a                	mv	a0,s6
 684:	de3ff0ef          	jal	466 <printint>
        i += 2;
 688:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 68a:	8ba6                	mv	s7,s1
      state = 0;
 68c:	4981                	li	s3,0
        i += 2;
 68e:	b5c1                	j	54e <vprintf+0x44>
 690:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 692:	008b8793          	addi	a5,s7,8
 696:	8cbe                	mv	s9,a5
 698:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 69c:	03000593          	li	a1,48
 6a0:	855a                	mv	a0,s6
 6a2:	da7ff0ef          	jal	448 <putc>
  putc(fd, 'x');
 6a6:	07800593          	li	a1,120
 6aa:	855a                	mv	a0,s6
 6ac:	d9dff0ef          	jal	448 <putc>
 6b0:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6b2:	00000b97          	auipc	s7,0x0
 6b6:	366b8b93          	addi	s7,s7,870 # a18 <digits>
 6ba:	03c9d793          	srli	a5,s3,0x3c
 6be:	97de                	add	a5,a5,s7
 6c0:	0007c583          	lbu	a1,0(a5)
 6c4:	855a                	mv	a0,s6
 6c6:	d83ff0ef          	jal	448 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 6ca:	0992                	slli	s3,s3,0x4
 6cc:	34fd                	addiw	s1,s1,-1
 6ce:	f4f5                	bnez	s1,6ba <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 6d0:	8be6                	mv	s7,s9
      state = 0;
 6d2:	4981                	li	s3,0
 6d4:	6ca2                	ld	s9,8(sp)
 6d6:	bda5                	j	54e <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 6d8:	008b8493          	addi	s1,s7,8
 6dc:	000bc583          	lbu	a1,0(s7)
 6e0:	855a                	mv	a0,s6
 6e2:	d67ff0ef          	jal	448 <putc>
 6e6:	8ba6                	mv	s7,s1
      state = 0;
 6e8:	4981                	li	s3,0
 6ea:	b595                	j	54e <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 6ec:	008b8993          	addi	s3,s7,8
 6f0:	000bb483          	ld	s1,0(s7)
 6f4:	cc91                	beqz	s1,710 <vprintf+0x206>
        for(; *s; s++)
 6f6:	0004c583          	lbu	a1,0(s1)
 6fa:	c985                	beqz	a1,72a <vprintf+0x220>
          putc(fd, *s);
 6fc:	855a                	mv	a0,s6
 6fe:	d4bff0ef          	jal	448 <putc>
        for(; *s; s++)
 702:	0485                	addi	s1,s1,1
 704:	0004c583          	lbu	a1,0(s1)
 708:	f9f5                	bnez	a1,6fc <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 70a:	8bce                	mv	s7,s3
      state = 0;
 70c:	4981                	li	s3,0
 70e:	b581                	j	54e <vprintf+0x44>
          s = "(null)";
 710:	00000497          	auipc	s1,0x0
 714:	30048493          	addi	s1,s1,768 # a10 <malloc+0x164>
        for(; *s; s++)
 718:	02800593          	li	a1,40
 71c:	b7c5                	j	6fc <vprintf+0x1f2>
        putc(fd, '%');
 71e:	85be                	mv	a1,a5
 720:	855a                	mv	a0,s6
 722:	d27ff0ef          	jal	448 <putc>
      state = 0;
 726:	4981                	li	s3,0
 728:	b51d                	j	54e <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 72a:	8bce                	mv	s7,s3
      state = 0;
 72c:	4981                	li	s3,0
 72e:	b505                	j	54e <vprintf+0x44>
 730:	6906                	ld	s2,64(sp)
 732:	79e2                	ld	s3,56(sp)
 734:	7a42                	ld	s4,48(sp)
 736:	7aa2                	ld	s5,40(sp)
 738:	7b02                	ld	s6,32(sp)
 73a:	6be2                	ld	s7,24(sp)
 73c:	6c42                	ld	s8,16(sp)
    }
  }
}
 73e:	60e6                	ld	ra,88(sp)
 740:	6446                	ld	s0,80(sp)
 742:	64a6                	ld	s1,72(sp)
 744:	6125                	addi	sp,sp,96
 746:	8082                	ret
      if(c0 == 'd'){
 748:	06400713          	li	a4,100
 74c:	e4e78fe3          	beq	a5,a4,5aa <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 750:	f9478693          	addi	a3,a5,-108
 754:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 758:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 75a:	4701                	li	a4,0
      } else if(c0 == 'u'){
 75c:	07500513          	li	a0,117
 760:	e8a78ce3          	beq	a5,a0,5f8 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 764:	f8b60513          	addi	a0,a2,-117
 768:	e119                	bnez	a0,76e <vprintf+0x264>
 76a:	ea0693e3          	bnez	a3,610 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 76e:	f8b58513          	addi	a0,a1,-117
 772:	e119                	bnez	a0,778 <vprintf+0x26e>
 774:	ea071be3          	bnez	a4,62a <vprintf+0x120>
      } else if(c0 == 'x'){
 778:	07800513          	li	a0,120
 77c:	eca784e3          	beq	a5,a0,644 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 780:	f8860613          	addi	a2,a2,-120
 784:	e219                	bnez	a2,78a <vprintf+0x280>
 786:	ec069be3          	bnez	a3,65c <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 78a:	f8858593          	addi	a1,a1,-120
 78e:	e199                	bnez	a1,794 <vprintf+0x28a>
 790:	ee0713e3          	bnez	a4,676 <vprintf+0x16c>
      } else if(c0 == 'p'){
 794:	07000713          	li	a4,112
 798:	eee78ce3          	beq	a5,a4,690 <vprintf+0x186>
      } else if(c0 == 'c'){
 79c:	06300713          	li	a4,99
 7a0:	f2e78ce3          	beq	a5,a4,6d8 <vprintf+0x1ce>
      } else if(c0 == 's'){
 7a4:	07300713          	li	a4,115
 7a8:	f4e782e3          	beq	a5,a4,6ec <vprintf+0x1e2>
      } else if(c0 == '%'){
 7ac:	02500713          	li	a4,37
 7b0:	f6e787e3          	beq	a5,a4,71e <vprintf+0x214>
        putc(fd, '%');
 7b4:	02500593          	li	a1,37
 7b8:	855a                	mv	a0,s6
 7ba:	c8fff0ef          	jal	448 <putc>
        putc(fd, c0);
 7be:	85a6                	mv	a1,s1
 7c0:	855a                	mv	a0,s6
 7c2:	c87ff0ef          	jal	448 <putc>
      state = 0;
 7c6:	4981                	li	s3,0
 7c8:	b359                	j	54e <vprintf+0x44>

00000000000007ca <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 7ca:	715d                	addi	sp,sp,-80
 7cc:	ec06                	sd	ra,24(sp)
 7ce:	e822                	sd	s0,16(sp)
 7d0:	1000                	addi	s0,sp,32
 7d2:	e010                	sd	a2,0(s0)
 7d4:	e414                	sd	a3,8(s0)
 7d6:	e818                	sd	a4,16(s0)
 7d8:	ec1c                	sd	a5,24(s0)
 7da:	03043023          	sd	a6,32(s0)
 7de:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 7e2:	8622                	mv	a2,s0
 7e4:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 7e8:	d23ff0ef          	jal	50a <vprintf>
}
 7ec:	60e2                	ld	ra,24(sp)
 7ee:	6442                	ld	s0,16(sp)
 7f0:	6161                	addi	sp,sp,80
 7f2:	8082                	ret

00000000000007f4 <printf>:

void
printf(const char *fmt, ...)
{
 7f4:	711d                	addi	sp,sp,-96
 7f6:	ec06                	sd	ra,24(sp)
 7f8:	e822                	sd	s0,16(sp)
 7fa:	1000                	addi	s0,sp,32
 7fc:	e40c                	sd	a1,8(s0)
 7fe:	e810                	sd	a2,16(s0)
 800:	ec14                	sd	a3,24(s0)
 802:	f018                	sd	a4,32(s0)
 804:	f41c                	sd	a5,40(s0)
 806:	03043823          	sd	a6,48(s0)
 80a:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 80e:	00840613          	addi	a2,s0,8
 812:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 816:	85aa                	mv	a1,a0
 818:	4505                	li	a0,1
 81a:	cf1ff0ef          	jal	50a <vprintf>
}
 81e:	60e2                	ld	ra,24(sp)
 820:	6442                	ld	s0,16(sp)
 822:	6125                	addi	sp,sp,96
 824:	8082                	ret

0000000000000826 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 826:	1141                	addi	sp,sp,-16
 828:	e406                	sd	ra,8(sp)
 82a:	e022                	sd	s0,0(sp)
 82c:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 82e:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 832:	00000797          	auipc	a5,0x0
 836:	7ce7b783          	ld	a5,1998(a5) # 1000 <freep>
 83a:	a039                	j	848 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 83c:	6398                	ld	a4,0(a5)
 83e:	00e7e463          	bltu	a5,a4,846 <free+0x20>
 842:	00e6ea63          	bltu	a3,a4,856 <free+0x30>
{
 846:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 848:	fed7fae3          	bgeu	a5,a3,83c <free+0x16>
 84c:	6398                	ld	a4,0(a5)
 84e:	00e6e463          	bltu	a3,a4,856 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 852:	fee7eae3          	bltu	a5,a4,846 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 856:	ff852583          	lw	a1,-8(a0)
 85a:	6390                	ld	a2,0(a5)
 85c:	02059813          	slli	a6,a1,0x20
 860:	01c85713          	srli	a4,a6,0x1c
 864:	9736                	add	a4,a4,a3
 866:	02e60563          	beq	a2,a4,890 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 86a:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 86e:	4790                	lw	a2,8(a5)
 870:	02061593          	slli	a1,a2,0x20
 874:	01c5d713          	srli	a4,a1,0x1c
 878:	973e                	add	a4,a4,a5
 87a:	02e68263          	beq	a3,a4,89e <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 87e:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 880:	00000717          	auipc	a4,0x0
 884:	78f73023          	sd	a5,1920(a4) # 1000 <freep>
}
 888:	60a2                	ld	ra,8(sp)
 88a:	6402                	ld	s0,0(sp)
 88c:	0141                	addi	sp,sp,16
 88e:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 890:	4618                	lw	a4,8(a2)
 892:	9f2d                	addw	a4,a4,a1
 894:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 898:	6398                	ld	a4,0(a5)
 89a:	6310                	ld	a2,0(a4)
 89c:	b7f9                	j	86a <free+0x44>
    p->s.size += bp->s.size;
 89e:	ff852703          	lw	a4,-8(a0)
 8a2:	9f31                	addw	a4,a4,a2
 8a4:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 8a6:	ff053683          	ld	a3,-16(a0)
 8aa:	bfd1                	j	87e <free+0x58>

00000000000008ac <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 8ac:	7139                	addi	sp,sp,-64
 8ae:	fc06                	sd	ra,56(sp)
 8b0:	f822                	sd	s0,48(sp)
 8b2:	f04a                	sd	s2,32(sp)
 8b4:	ec4e                	sd	s3,24(sp)
 8b6:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 8b8:	02051993          	slli	s3,a0,0x20
 8bc:	0209d993          	srli	s3,s3,0x20
 8c0:	09bd                	addi	s3,s3,15
 8c2:	0049d993          	srli	s3,s3,0x4
 8c6:	2985                	addiw	s3,s3,1
 8c8:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 8ca:	00000517          	auipc	a0,0x0
 8ce:	73653503          	ld	a0,1846(a0) # 1000 <freep>
 8d2:	c905                	beqz	a0,902 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8d4:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8d6:	4798                	lw	a4,8(a5)
 8d8:	09377663          	bgeu	a4,s3,964 <malloc+0xb8>
 8dc:	f426                	sd	s1,40(sp)
 8de:	e852                	sd	s4,16(sp)
 8e0:	e456                	sd	s5,8(sp)
 8e2:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 8e4:	8a4e                	mv	s4,s3
 8e6:	6705                	lui	a4,0x1
 8e8:	00e9f363          	bgeu	s3,a4,8ee <malloc+0x42>
 8ec:	6a05                	lui	s4,0x1
 8ee:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 8f2:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 8f6:	00000497          	auipc	s1,0x0
 8fa:	70a48493          	addi	s1,s1,1802 # 1000 <freep>
  if(p == SBRK_ERROR)
 8fe:	5afd                	li	s5,-1
 900:	a83d                	j	93e <malloc+0x92>
 902:	f426                	sd	s1,40(sp)
 904:	e852                	sd	s4,16(sp)
 906:	e456                	sd	s5,8(sp)
 908:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 90a:	00000797          	auipc	a5,0x0
 90e:	70678793          	addi	a5,a5,1798 # 1010 <base>
 912:	00000717          	auipc	a4,0x0
 916:	6ef73723          	sd	a5,1774(a4) # 1000 <freep>
 91a:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 91c:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 920:	b7d1                	j	8e4 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 922:	6398                	ld	a4,0(a5)
 924:	e118                	sd	a4,0(a0)
 926:	a899                	j	97c <malloc+0xd0>
  hp->s.size = nu;
 928:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 92c:	0541                	addi	a0,a0,16
 92e:	ef9ff0ef          	jal	826 <free>
  return freep;
 932:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 934:	c125                	beqz	a0,994 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 936:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 938:	4798                	lw	a4,8(a5)
 93a:	03277163          	bgeu	a4,s2,95c <malloc+0xb0>
    if(p == freep)
 93e:	6098                	ld	a4,0(s1)
 940:	853e                	mv	a0,a5
 942:	fef71ae3          	bne	a4,a5,936 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 946:	8552                	mv	a0,s4
 948:	9f5ff0ef          	jal	33c <sbrk>
  if(p == SBRK_ERROR)
 94c:	fd551ee3          	bne	a0,s5,928 <malloc+0x7c>
        return 0;
 950:	4501                	li	a0,0
 952:	74a2                	ld	s1,40(sp)
 954:	6a42                	ld	s4,16(sp)
 956:	6aa2                	ld	s5,8(sp)
 958:	6b02                	ld	s6,0(sp)
 95a:	a03d                	j	988 <malloc+0xdc>
 95c:	74a2                	ld	s1,40(sp)
 95e:	6a42                	ld	s4,16(sp)
 960:	6aa2                	ld	s5,8(sp)
 962:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 964:	fae90fe3          	beq	s2,a4,922 <malloc+0x76>
        p->s.size -= nunits;
 968:	4137073b          	subw	a4,a4,s3
 96c:	c798                	sw	a4,8(a5)
        p += p->s.size;
 96e:	02071693          	slli	a3,a4,0x20
 972:	01c6d713          	srli	a4,a3,0x1c
 976:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 978:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 97c:	00000717          	auipc	a4,0x0
 980:	68a73223          	sd	a0,1668(a4) # 1000 <freep>
      return (void*)(p + 1);
 984:	01078513          	addi	a0,a5,16
  }
}
 988:	70e2                	ld	ra,56(sp)
 98a:	7442                	ld	s0,48(sp)
 98c:	7902                	ld	s2,32(sp)
 98e:	69e2                	ld	s3,24(sp)
 990:	6121                	addi	sp,sp,64
 992:	8082                	ret
 994:	74a2                	ld	s1,40(sp)
 996:	6a42                	ld	s4,16(sp)
 998:	6aa2                	ld	s5,8(sp)
 99a:	6b02                	ld	s6,0(sp)
 99c:	b7f5                	j	988 <malloc+0xdc>
