
user/_process:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/types.h"
#include "kernel/stat.h"
#include "user/user.h"

int main(int argc, char *argv[]){
   0:	715d                	addi	sp,sp,-80
   2:	e486                	sd	ra,72(sp)
   4:	e0a2                	sd	s0,64(sp)
   6:	fc26                	sd	s1,56(sp)
   8:	f84a                	sd	s2,48(sp)
   a:	f44e                	sd	s3,40(sp)
   c:	0880                	addi	s0,sp,80
   e:	892e                	mv	s2,a1
    int* ptr=(int*)shm_get(1);
  10:	4505                	li	a0,1
  12:	480000ef          	jal	492 <shm_get>
  16:	84aa                	mv	s1,a0
    if(ptr==0){
  18:	c91d                	beqz	a0,4e <main+0x4e>
        printf("shm_get failed\n");
    }
    int start_point=atoi(argv[1]);
  1a:	00893503          	ld	a0,8(s2)
  1e:	2a2000ef          	jal	2c0 <atoi>
  22:	89aa                	mv	s3,a0
    int end_point=atoi(argv[2]);
  24:	01093503          	ld	a0,16(s2)
  28:	298000ef          	jal	2c0 <atoi>
  2c:	892a                	mv	s2,a0
    int next_pos;
    if(start_point==0){
  2e:	02098763          	beqz	s3,5c <main+0x5c>
        printf("process A currently at:%d\n",next_pos);
        mbox_send(1,ptr[next_pos]);
        mbox_recv(2,&next_pos);
        }
    }
    else if(start_point==1){
  32:	4785                	li	a5,1
  34:	08f98a63          	beq	s3,a5,c8 <main+0xc8>
        printf("process B currently at:%d\n",next_pos);
        mbox_send(2,ptr[next_pos]);
        mbox_recv(1,&next_pos);
        }
    }
    shm_close(1);
  38:	4505                	li	a0,1
  3a:	460000ef          	jal	49a <shm_close>
   return 0;
  3e:	4501                	li	a0,0
  40:	60a6                	ld	ra,72(sp)
  42:	6406                	ld	s0,64(sp)
  44:	74e2                	ld	s1,56(sp)
  46:	7942                	ld	s2,48(sp)
  48:	79a2                	ld	s3,40(sp)
  4a:	6161                	addi	sp,sp,80
  4c:	8082                	ret
        printf("shm_get failed\n");
  4e:	00001517          	auipc	a0,0x1
  52:	9d250513          	addi	a0,a0,-1582 # a20 <malloc+0xfa>
  56:	019000ef          	jal	86e <printf>
  5a:	b7c1                	j	1a <main+0x1a>
        printf("process A currently at:%d\n",start_point);
  5c:	4581                	li	a1,0
  5e:	00001517          	auipc	a0,0x1
  62:	9d250513          	addi	a0,a0,-1582 # a30 <malloc+0x10a>
  66:	009000ef          	jal	86e <printf>
        mbox_send(1,ptr[start_point]);
  6a:	408c                	lw	a1,0(s1)
  6c:	4505                	li	a0,1
  6e:	43c000ef          	jal	4aa <mbox_send>
        mbox_recv(2,&next_pos);
  72:	fbc40593          	addi	a1,s0,-68
  76:	4509                	li	a0,2
  78:	43a000ef          	jal	4b2 <mbox_recv>
        while(next_pos!=end_point){
  7c:	fbc42583          	lw	a1,-68(s0)
  80:	fab90ce3          	beq	s2,a1,38 <main+0x38>
  84:	f052                	sd	s4,32(sp)
  86:	ec56                	sd	s5,24(sp)
  88:	e85a                	sd	s6,16(sp)
        printf("process A currently at:%d\n",next_pos);
  8a:	00001b17          	auipc	s6,0x1
  8e:	9a6b0b13          	addi	s6,s6,-1626 # a30 <malloc+0x10a>
        mbox_send(1,ptr[next_pos]);
  92:	4a85                	li	s5,1
        mbox_recv(2,&next_pos);
  94:	fbc40a13          	addi	s4,s0,-68
  98:	4989                	li	s3,2
        printf("process A currently at:%d\n",next_pos);
  9a:	855a                	mv	a0,s6
  9c:	7d2000ef          	jal	86e <printf>
        mbox_send(1,ptr[next_pos]);
  a0:	fbc42783          	lw	a5,-68(s0)
  a4:	078a                	slli	a5,a5,0x2
  a6:	97a6                	add	a5,a5,s1
  a8:	438c                	lw	a1,0(a5)
  aa:	8556                	mv	a0,s5
  ac:	3fe000ef          	jal	4aa <mbox_send>
        mbox_recv(2,&next_pos);
  b0:	85d2                	mv	a1,s4
  b2:	854e                	mv	a0,s3
  b4:	3fe000ef          	jal	4b2 <mbox_recv>
        while(next_pos!=end_point){
  b8:	fbc42583          	lw	a1,-68(s0)
  bc:	fd259fe3          	bne	a1,s2,9a <main+0x9a>
  c0:	7a02                	ld	s4,32(sp)
  c2:	6ae2                	ld	s5,24(sp)
  c4:	6b42                	ld	s6,16(sp)
  c6:	bf8d                	j	38 <main+0x38>
        printf("process B currently at:%d\n",start_point);
  c8:	85ce                	mv	a1,s3
  ca:	00001517          	auipc	a0,0x1
  ce:	98650513          	addi	a0,a0,-1658 # a50 <malloc+0x12a>
  d2:	79c000ef          	jal	86e <printf>
        mbox_send(2,ptr[start_point]);
  d6:	40cc                	lw	a1,4(s1)
  d8:	4509                	li	a0,2
  da:	3d0000ef          	jal	4aa <mbox_send>
        mbox_recv(1,&next_pos);
  de:	fbc40593          	addi	a1,s0,-68
  e2:	854e                	mv	a0,s3
  e4:	3ce000ef          	jal	4b2 <mbox_recv>
        while(next_pos!=end_point){
  e8:	fbc42583          	lw	a1,-68(s0)
  ec:	f4b906e3          	beq	s2,a1,38 <main+0x38>
  f0:	f052                	sd	s4,32(sp)
  f2:	ec56                	sd	s5,24(sp)
  f4:	e85a                	sd	s6,16(sp)
        printf("process B currently at:%d\n",next_pos);
  f6:	00001b17          	auipc	s6,0x1
  fa:	95ab0b13          	addi	s6,s6,-1702 # a50 <malloc+0x12a>
        mbox_send(2,ptr[next_pos]);
  fe:	4a89                	li	s5,2
        mbox_recv(1,&next_pos);
 100:	fbc40a13          	addi	s4,s0,-68
        printf("process B currently at:%d\n",next_pos);
 104:	855a                	mv	a0,s6
 106:	768000ef          	jal	86e <printf>
        mbox_send(2,ptr[next_pos]);
 10a:	fbc42783          	lw	a5,-68(s0)
 10e:	078a                	slli	a5,a5,0x2
 110:	97a6                	add	a5,a5,s1
 112:	438c                	lw	a1,0(a5)
 114:	8556                	mv	a0,s5
 116:	394000ef          	jal	4aa <mbox_send>
        mbox_recv(1,&next_pos);
 11a:	85d2                	mv	a1,s4
 11c:	854e                	mv	a0,s3
 11e:	394000ef          	jal	4b2 <mbox_recv>
        while(next_pos!=end_point){
 122:	fbc42583          	lw	a1,-68(s0)
 126:	fd259fe3          	bne	a1,s2,104 <main+0x104>
 12a:	7a02                	ld	s4,32(sp)
 12c:	6ae2                	ld	s5,24(sp)
 12e:	6b42                	ld	s6,16(sp)
 130:	b721                	j	38 <main+0x38>

0000000000000132 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
 132:	1141                	addi	sp,sp,-16
 134:	e406                	sd	ra,8(sp)
 136:	e022                	sd	s0,0(sp)
 138:	0800                	addi	s0,sp,16
  extern int main();
  main();
 13a:	ec7ff0ef          	jal	0 <main>
  exit(0);
 13e:	4501                	li	a0,0
 140:	2aa000ef          	jal	3ea <exit>

0000000000000144 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
 144:	1141                	addi	sp,sp,-16
 146:	e406                	sd	ra,8(sp)
 148:	e022                	sd	s0,0(sp)
 14a:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
 14c:	87aa                	mv	a5,a0
 14e:	0585                	addi	a1,a1,1
 150:	0785                	addi	a5,a5,1
 152:	fff5c703          	lbu	a4,-1(a1)
 156:	fee78fa3          	sb	a4,-1(a5)
 15a:	fb75                	bnez	a4,14e <strcpy+0xa>
    ;
  return os;
}
 15c:	60a2                	ld	ra,8(sp)
 15e:	6402                	ld	s0,0(sp)
 160:	0141                	addi	sp,sp,16
 162:	8082                	ret

0000000000000164 <strcmp>:

int
strcmp(const char *p, const char *q)
{
 164:	1141                	addi	sp,sp,-16
 166:	e406                	sd	ra,8(sp)
 168:	e022                	sd	s0,0(sp)
 16a:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 16c:	00054783          	lbu	a5,0(a0)
 170:	cb91                	beqz	a5,184 <strcmp+0x20>
 172:	0005c703          	lbu	a4,0(a1)
 176:	00f71763          	bne	a4,a5,184 <strcmp+0x20>
    p++, q++;
 17a:	0505                	addi	a0,a0,1
 17c:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 17e:	00054783          	lbu	a5,0(a0)
 182:	fbe5                	bnez	a5,172 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 184:	0005c503          	lbu	a0,0(a1)
}
 188:	40a7853b          	subw	a0,a5,a0
 18c:	60a2                	ld	ra,8(sp)
 18e:	6402                	ld	s0,0(sp)
 190:	0141                	addi	sp,sp,16
 192:	8082                	ret

0000000000000194 <strlen>:

uint
strlen(const char *s)
{
 194:	1141                	addi	sp,sp,-16
 196:	e406                	sd	ra,8(sp)
 198:	e022                	sd	s0,0(sp)
 19a:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 19c:	00054783          	lbu	a5,0(a0)
 1a0:	cf91                	beqz	a5,1bc <strlen+0x28>
 1a2:	00150793          	addi	a5,a0,1
 1a6:	86be                	mv	a3,a5
 1a8:	0785                	addi	a5,a5,1
 1aa:	fff7c703          	lbu	a4,-1(a5)
 1ae:	ff65                	bnez	a4,1a6 <strlen+0x12>
 1b0:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 1b4:	60a2                	ld	ra,8(sp)
 1b6:	6402                	ld	s0,0(sp)
 1b8:	0141                	addi	sp,sp,16
 1ba:	8082                	ret
  for(n = 0; s[n]; n++)
 1bc:	4501                	li	a0,0
 1be:	bfdd                	j	1b4 <strlen+0x20>

00000000000001c0 <memset>:

void*
memset(void *dst, int c, uint n)
{
 1c0:	1141                	addi	sp,sp,-16
 1c2:	e406                	sd	ra,8(sp)
 1c4:	e022                	sd	s0,0(sp)
 1c6:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 1c8:	ca19                	beqz	a2,1de <memset+0x1e>
 1ca:	87aa                	mv	a5,a0
 1cc:	1602                	slli	a2,a2,0x20
 1ce:	9201                	srli	a2,a2,0x20
 1d0:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 1d4:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 1d8:	0785                	addi	a5,a5,1
 1da:	fee79de3          	bne	a5,a4,1d4 <memset+0x14>
  }
  return dst;
}
 1de:	60a2                	ld	ra,8(sp)
 1e0:	6402                	ld	s0,0(sp)
 1e2:	0141                	addi	sp,sp,16
 1e4:	8082                	ret

00000000000001e6 <strchr>:

char*
strchr(const char *s, char c)
{
 1e6:	1141                	addi	sp,sp,-16
 1e8:	e406                	sd	ra,8(sp)
 1ea:	e022                	sd	s0,0(sp)
 1ec:	0800                	addi	s0,sp,16
  for(; *s; s++)
 1ee:	00054783          	lbu	a5,0(a0)
 1f2:	cf81                	beqz	a5,20a <strchr+0x24>
    if(*s == c)
 1f4:	00f58763          	beq	a1,a5,202 <strchr+0x1c>
  for(; *s; s++)
 1f8:	0505                	addi	a0,a0,1
 1fa:	00054783          	lbu	a5,0(a0)
 1fe:	fbfd                	bnez	a5,1f4 <strchr+0xe>
      return (char*)s;
  return 0;
 200:	4501                	li	a0,0
}
 202:	60a2                	ld	ra,8(sp)
 204:	6402                	ld	s0,0(sp)
 206:	0141                	addi	sp,sp,16
 208:	8082                	ret
  return 0;
 20a:	4501                	li	a0,0
 20c:	bfdd                	j	202 <strchr+0x1c>

000000000000020e <gets>:

char*
gets(char *buf, int max)
{
 20e:	711d                	addi	sp,sp,-96
 210:	ec86                	sd	ra,88(sp)
 212:	e8a2                	sd	s0,80(sp)
 214:	e4a6                	sd	s1,72(sp)
 216:	e0ca                	sd	s2,64(sp)
 218:	fc4e                	sd	s3,56(sp)
 21a:	f852                	sd	s4,48(sp)
 21c:	f456                	sd	s5,40(sp)
 21e:	f05a                	sd	s6,32(sp)
 220:	ec5e                	sd	s7,24(sp)
 222:	e862                	sd	s8,16(sp)
 224:	1080                	addi	s0,sp,96
 226:	8baa                	mv	s7,a0
 228:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 22a:	892a                	mv	s2,a0
 22c:	4481                	li	s1,0
    cc = read(0, &c, 1);
 22e:	faf40b13          	addi	s6,s0,-81
 232:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 234:	8c26                	mv	s8,s1
 236:	0014899b          	addiw	s3,s1,1
 23a:	84ce                	mv	s1,s3
 23c:	0349d463          	bge	s3,s4,264 <gets+0x56>
    cc = read(0, &c, 1);
 240:	8656                	mv	a2,s5
 242:	85da                	mv	a1,s6
 244:	4501                	li	a0,0
 246:	1bc000ef          	jal	402 <read>
    if(cc < 1)
 24a:	00a05d63          	blez	a0,264 <gets+0x56>
      break;
    buf[i++] = c;
 24e:	faf44783          	lbu	a5,-81(s0)
 252:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 256:	0905                	addi	s2,s2,1
 258:	ff678713          	addi	a4,a5,-10
 25c:	c319                	beqz	a4,262 <gets+0x54>
 25e:	17cd                	addi	a5,a5,-13
 260:	fbf1                	bnez	a5,234 <gets+0x26>
    buf[i++] = c;
 262:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 264:	9c5e                	add	s8,s8,s7
 266:	000c0023          	sb	zero,0(s8)
  return buf;
}
 26a:	855e                	mv	a0,s7
 26c:	60e6                	ld	ra,88(sp)
 26e:	6446                	ld	s0,80(sp)
 270:	64a6                	ld	s1,72(sp)
 272:	6906                	ld	s2,64(sp)
 274:	79e2                	ld	s3,56(sp)
 276:	7a42                	ld	s4,48(sp)
 278:	7aa2                	ld	s5,40(sp)
 27a:	7b02                	ld	s6,32(sp)
 27c:	6be2                	ld	s7,24(sp)
 27e:	6c42                	ld	s8,16(sp)
 280:	6125                	addi	sp,sp,96
 282:	8082                	ret

0000000000000284 <stat>:

int
stat(const char *n, struct stat *st)
{
 284:	1101                	addi	sp,sp,-32
 286:	ec06                	sd	ra,24(sp)
 288:	e822                	sd	s0,16(sp)
 28a:	e04a                	sd	s2,0(sp)
 28c:	1000                	addi	s0,sp,32
 28e:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 290:	4581                	li	a1,0
 292:	198000ef          	jal	42a <open>
  if(fd < 0)
 296:	02054263          	bltz	a0,2ba <stat+0x36>
 29a:	e426                	sd	s1,8(sp)
 29c:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 29e:	85ca                	mv	a1,s2
 2a0:	1a2000ef          	jal	442 <fstat>
 2a4:	892a                	mv	s2,a0
  close(fd);
 2a6:	8526                	mv	a0,s1
 2a8:	16a000ef          	jal	412 <close>
  return r;
 2ac:	64a2                	ld	s1,8(sp)
}
 2ae:	854a                	mv	a0,s2
 2b0:	60e2                	ld	ra,24(sp)
 2b2:	6442                	ld	s0,16(sp)
 2b4:	6902                	ld	s2,0(sp)
 2b6:	6105                	addi	sp,sp,32
 2b8:	8082                	ret
    return -1;
 2ba:	57fd                	li	a5,-1
 2bc:	893e                	mv	s2,a5
 2be:	bfc5                	j	2ae <stat+0x2a>

00000000000002c0 <atoi>:

int
atoi(const char *s)
{
 2c0:	1141                	addi	sp,sp,-16
 2c2:	e406                	sd	ra,8(sp)
 2c4:	e022                	sd	s0,0(sp)
 2c6:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 2c8:	00054683          	lbu	a3,0(a0)
 2cc:	fd06879b          	addiw	a5,a3,-48
 2d0:	0ff7f793          	zext.b	a5,a5
 2d4:	4625                	li	a2,9
 2d6:	02f66963          	bltu	a2,a5,308 <atoi+0x48>
 2da:	872a                	mv	a4,a0
  n = 0;
 2dc:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 2de:	0705                	addi	a4,a4,1
 2e0:	0025179b          	slliw	a5,a0,0x2
 2e4:	9fa9                	addw	a5,a5,a0
 2e6:	0017979b          	slliw	a5,a5,0x1
 2ea:	9fb5                	addw	a5,a5,a3
 2ec:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 2f0:	00074683          	lbu	a3,0(a4)
 2f4:	fd06879b          	addiw	a5,a3,-48
 2f8:	0ff7f793          	zext.b	a5,a5
 2fc:	fef671e3          	bgeu	a2,a5,2de <atoi+0x1e>
  return n;
}
 300:	60a2                	ld	ra,8(sp)
 302:	6402                	ld	s0,0(sp)
 304:	0141                	addi	sp,sp,16
 306:	8082                	ret
  n = 0;
 308:	4501                	li	a0,0
 30a:	bfdd                	j	300 <atoi+0x40>

000000000000030c <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 30c:	1141                	addi	sp,sp,-16
 30e:	e406                	sd	ra,8(sp)
 310:	e022                	sd	s0,0(sp)
 312:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 314:	02b57563          	bgeu	a0,a1,33e <memmove+0x32>
    while(n-- > 0)
 318:	00c05f63          	blez	a2,336 <memmove+0x2a>
 31c:	1602                	slli	a2,a2,0x20
 31e:	9201                	srli	a2,a2,0x20
 320:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 324:	872a                	mv	a4,a0
      *dst++ = *src++;
 326:	0585                	addi	a1,a1,1
 328:	0705                	addi	a4,a4,1
 32a:	fff5c683          	lbu	a3,-1(a1)
 32e:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 332:	fee79ae3          	bne	a5,a4,326 <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 336:	60a2                	ld	ra,8(sp)
 338:	6402                	ld	s0,0(sp)
 33a:	0141                	addi	sp,sp,16
 33c:	8082                	ret
    while(n-- > 0)
 33e:	fec05ce3          	blez	a2,336 <memmove+0x2a>
    dst += n;
 342:	00c50733          	add	a4,a0,a2
    src += n;
 346:	95b2                	add	a1,a1,a2
 348:	fff6079b          	addiw	a5,a2,-1
 34c:	1782                	slli	a5,a5,0x20
 34e:	9381                	srli	a5,a5,0x20
 350:	fff7c793          	not	a5,a5
 354:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 356:	15fd                	addi	a1,a1,-1
 358:	177d                	addi	a4,a4,-1
 35a:	0005c683          	lbu	a3,0(a1)
 35e:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 362:	fef71ae3          	bne	a4,a5,356 <memmove+0x4a>
 366:	bfc1                	j	336 <memmove+0x2a>

0000000000000368 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 368:	1141                	addi	sp,sp,-16
 36a:	e406                	sd	ra,8(sp)
 36c:	e022                	sd	s0,0(sp)
 36e:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 370:	c61d                	beqz	a2,39e <memcmp+0x36>
 372:	1602                	slli	a2,a2,0x20
 374:	9201                	srli	a2,a2,0x20
 376:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 37a:	00054783          	lbu	a5,0(a0)
 37e:	0005c703          	lbu	a4,0(a1)
 382:	00e79863          	bne	a5,a4,392 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 386:	0505                	addi	a0,a0,1
    p2++;
 388:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 38a:	fed518e3          	bne	a0,a3,37a <memcmp+0x12>
  }
  return 0;
 38e:	4501                	li	a0,0
 390:	a019                	j	396 <memcmp+0x2e>
      return *p1 - *p2;
 392:	40e7853b          	subw	a0,a5,a4
}
 396:	60a2                	ld	ra,8(sp)
 398:	6402                	ld	s0,0(sp)
 39a:	0141                	addi	sp,sp,16
 39c:	8082                	ret
  return 0;
 39e:	4501                	li	a0,0
 3a0:	bfdd                	j	396 <memcmp+0x2e>

00000000000003a2 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 3a2:	1141                	addi	sp,sp,-16
 3a4:	e406                	sd	ra,8(sp)
 3a6:	e022                	sd	s0,0(sp)
 3a8:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 3aa:	f63ff0ef          	jal	30c <memmove>
}
 3ae:	60a2                	ld	ra,8(sp)
 3b0:	6402                	ld	s0,0(sp)
 3b2:	0141                	addi	sp,sp,16
 3b4:	8082                	ret

00000000000003b6 <sbrk>:

char *
sbrk(int n) {
 3b6:	1141                	addi	sp,sp,-16
 3b8:	e406                	sd	ra,8(sp)
 3ba:	e022                	sd	s0,0(sp)
 3bc:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 3be:	4585                	li	a1,1
 3c0:	0b2000ef          	jal	472 <sys_sbrk>
}
 3c4:	60a2                	ld	ra,8(sp)
 3c6:	6402                	ld	s0,0(sp)
 3c8:	0141                	addi	sp,sp,16
 3ca:	8082                	ret

00000000000003cc <sbrklazy>:

char *
sbrklazy(int n) {
 3cc:	1141                	addi	sp,sp,-16
 3ce:	e406                	sd	ra,8(sp)
 3d0:	e022                	sd	s0,0(sp)
 3d2:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 3d4:	4589                	li	a1,2
 3d6:	09c000ef          	jal	472 <sys_sbrk>
}
 3da:	60a2                	ld	ra,8(sp)
 3dc:	6402                	ld	s0,0(sp)
 3de:	0141                	addi	sp,sp,16
 3e0:	8082                	ret

00000000000003e2 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 3e2:	4885                	li	a7,1
 ecall
 3e4:	00000073          	ecall
 ret
 3e8:	8082                	ret

00000000000003ea <exit>:
.global exit
exit:
 li a7, SYS_exit
 3ea:	4889                	li	a7,2
 ecall
 3ec:	00000073          	ecall
 ret
 3f0:	8082                	ret

00000000000003f2 <wait>:
.global wait
wait:
 li a7, SYS_wait
 3f2:	488d                	li	a7,3
 ecall
 3f4:	00000073          	ecall
 ret
 3f8:	8082                	ret

00000000000003fa <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 3fa:	4891                	li	a7,4
 ecall
 3fc:	00000073          	ecall
 ret
 400:	8082                	ret

0000000000000402 <read>:
.global read
read:
 li a7, SYS_read
 402:	4895                	li	a7,5
 ecall
 404:	00000073          	ecall
 ret
 408:	8082                	ret

000000000000040a <write>:
.global write
write:
 li a7, SYS_write
 40a:	48c1                	li	a7,16
 ecall
 40c:	00000073          	ecall
 ret
 410:	8082                	ret

0000000000000412 <close>:
.global close
close:
 li a7, SYS_close
 412:	48d5                	li	a7,21
 ecall
 414:	00000073          	ecall
 ret
 418:	8082                	ret

000000000000041a <kill>:
.global kill
kill:
 li a7, SYS_kill
 41a:	4899                	li	a7,6
 ecall
 41c:	00000073          	ecall
 ret
 420:	8082                	ret

0000000000000422 <exec>:
.global exec
exec:
 li a7, SYS_exec
 422:	489d                	li	a7,7
 ecall
 424:	00000073          	ecall
 ret
 428:	8082                	ret

000000000000042a <open>:
.global open
open:
 li a7, SYS_open
 42a:	48bd                	li	a7,15
 ecall
 42c:	00000073          	ecall
 ret
 430:	8082                	ret

0000000000000432 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 432:	48c5                	li	a7,17
 ecall
 434:	00000073          	ecall
 ret
 438:	8082                	ret

000000000000043a <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 43a:	48c9                	li	a7,18
 ecall
 43c:	00000073          	ecall
 ret
 440:	8082                	ret

0000000000000442 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 442:	48a1                	li	a7,8
 ecall
 444:	00000073          	ecall
 ret
 448:	8082                	ret

000000000000044a <link>:
.global link
link:
 li a7, SYS_link
 44a:	48cd                	li	a7,19
 ecall
 44c:	00000073          	ecall
 ret
 450:	8082                	ret

0000000000000452 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 452:	48d1                	li	a7,20
 ecall
 454:	00000073          	ecall
 ret
 458:	8082                	ret

000000000000045a <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 45a:	48a5                	li	a7,9
 ecall
 45c:	00000073          	ecall
 ret
 460:	8082                	ret

0000000000000462 <dup>:
.global dup
dup:
 li a7, SYS_dup
 462:	48a9                	li	a7,10
 ecall
 464:	00000073          	ecall
 ret
 468:	8082                	ret

000000000000046a <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 46a:	48ad                	li	a7,11
 ecall
 46c:	00000073          	ecall
 ret
 470:	8082                	ret

0000000000000472 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 472:	48b1                	li	a7,12
 ecall
 474:	00000073          	ecall
 ret
 478:	8082                	ret

000000000000047a <pause>:
.global pause
pause:
 li a7, SYS_pause
 47a:	48b5                	li	a7,13
 ecall
 47c:	00000073          	ecall
 ret
 480:	8082                	ret

0000000000000482 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 482:	48b9                	li	a7,14
 ecall
 484:	00000073          	ecall
 ret
 488:	8082                	ret

000000000000048a <shm_create>:
.global shm_create
shm_create:
 li a7, SYS_shm_create
 48a:	48d9                	li	a7,22
 ecall
 48c:	00000073          	ecall
 ret
 490:	8082                	ret

0000000000000492 <shm_get>:
.global shm_get
shm_get:
 li a7, SYS_shm_get
 492:	48dd                	li	a7,23
 ecall
 494:	00000073          	ecall
 ret
 498:	8082                	ret

000000000000049a <shm_close>:
.global shm_close
shm_close:
 li a7, SYS_shm_close
 49a:	48e1                	li	a7,24
 ecall
 49c:	00000073          	ecall
 ret
 4a0:	8082                	ret

00000000000004a2 <mbox_create>:
.global mbox_create
mbox_create:
 li a7, SYS_mbox_create
 4a2:	48e5                	li	a7,25
 ecall
 4a4:	00000073          	ecall
 ret
 4a8:	8082                	ret

00000000000004aa <mbox_send>:
.global mbox_send
mbox_send:
 li a7, SYS_mbox_send
 4aa:	48e9                	li	a7,26
 ecall
 4ac:	00000073          	ecall
 ret
 4b0:	8082                	ret

00000000000004b2 <mbox_recv>:
.global mbox_recv
mbox_recv:
 li a7, SYS_mbox_recv
 4b2:	48ed                	li	a7,27
 ecall
 4b4:	00000073          	ecall
 ret
 4b8:	8082                	ret

00000000000004ba <va2pa>:
.global va2pa
va2pa:
 li a7, SYS_va2pa
 4ba:	48f1                	li	a7,28
 ecall
 4bc:	00000073          	ecall
 ret
 4c0:	8082                	ret

00000000000004c2 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 4c2:	1101                	addi	sp,sp,-32
 4c4:	ec06                	sd	ra,24(sp)
 4c6:	e822                	sd	s0,16(sp)
 4c8:	1000                	addi	s0,sp,32
 4ca:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 4ce:	4605                	li	a2,1
 4d0:	fef40593          	addi	a1,s0,-17
 4d4:	f37ff0ef          	jal	40a <write>
}
 4d8:	60e2                	ld	ra,24(sp)
 4da:	6442                	ld	s0,16(sp)
 4dc:	6105                	addi	sp,sp,32
 4de:	8082                	ret

00000000000004e0 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 4e0:	715d                	addi	sp,sp,-80
 4e2:	e486                	sd	ra,72(sp)
 4e4:	e0a2                	sd	s0,64(sp)
 4e6:	f84a                	sd	s2,48(sp)
 4e8:	f44e                	sd	s3,40(sp)
 4ea:	0880                	addi	s0,sp,80
 4ec:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 4ee:	cac1                	beqz	a3,57e <printint+0x9e>
 4f0:	0805d763          	bgez	a1,57e <printint+0x9e>
    neg = 1;
    x = -xx;
 4f4:	40b005bb          	negw	a1,a1
    neg = 1;
 4f8:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 4fa:	fb840993          	addi	s3,s0,-72
  neg = 0;
 4fe:	86ce                	mv	a3,s3
  i = 0;
 500:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 502:	00000817          	auipc	a6,0x0
 506:	57680813          	addi	a6,a6,1398 # a78 <digits>
 50a:	88ba                	mv	a7,a4
 50c:	0017051b          	addiw	a0,a4,1
 510:	872a                	mv	a4,a0
 512:	02c5f7bb          	remuw	a5,a1,a2
 516:	1782                	slli	a5,a5,0x20
 518:	9381                	srli	a5,a5,0x20
 51a:	97c2                	add	a5,a5,a6
 51c:	0007c783          	lbu	a5,0(a5)
 520:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 524:	87ae                	mv	a5,a1
 526:	02c5d5bb          	divuw	a1,a1,a2
 52a:	0685                	addi	a3,a3,1
 52c:	fcc7ffe3          	bgeu	a5,a2,50a <printint+0x2a>
  if(neg)
 530:	00030c63          	beqz	t1,548 <printint+0x68>
    buf[i++] = '-';
 534:	fd050793          	addi	a5,a0,-48
 538:	00878533          	add	a0,a5,s0
 53c:	02d00793          	li	a5,45
 540:	fef50423          	sb	a5,-24(a0)
 544:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 548:	02e05563          	blez	a4,572 <printint+0x92>
 54c:	fc26                	sd	s1,56(sp)
 54e:	377d                	addiw	a4,a4,-1
 550:	00e984b3          	add	s1,s3,a4
 554:	19fd                	addi	s3,s3,-1
 556:	99ba                	add	s3,s3,a4
 558:	1702                	slli	a4,a4,0x20
 55a:	9301                	srli	a4,a4,0x20
 55c:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 560:	0004c583          	lbu	a1,0(s1)
 564:	854a                	mv	a0,s2
 566:	f5dff0ef          	jal	4c2 <putc>
  while(--i >= 0)
 56a:	14fd                	addi	s1,s1,-1
 56c:	ff349ae3          	bne	s1,s3,560 <printint+0x80>
 570:	74e2                	ld	s1,56(sp)
}
 572:	60a6                	ld	ra,72(sp)
 574:	6406                	ld	s0,64(sp)
 576:	7942                	ld	s2,48(sp)
 578:	79a2                	ld	s3,40(sp)
 57a:	6161                	addi	sp,sp,80
 57c:	8082                	ret
    x = xx;
 57e:	2581                	sext.w	a1,a1
  neg = 0;
 580:	4301                	li	t1,0
 582:	bfa5                	j	4fa <printint+0x1a>

0000000000000584 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 584:	711d                	addi	sp,sp,-96
 586:	ec86                	sd	ra,88(sp)
 588:	e8a2                	sd	s0,80(sp)
 58a:	e4a6                	sd	s1,72(sp)
 58c:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 58e:	0005c483          	lbu	s1,0(a1)
 592:	22048363          	beqz	s1,7b8 <vprintf+0x234>
 596:	e0ca                	sd	s2,64(sp)
 598:	fc4e                	sd	s3,56(sp)
 59a:	f852                	sd	s4,48(sp)
 59c:	f456                	sd	s5,40(sp)
 59e:	f05a                	sd	s6,32(sp)
 5a0:	ec5e                	sd	s7,24(sp)
 5a2:	e862                	sd	s8,16(sp)
 5a4:	8b2a                	mv	s6,a0
 5a6:	8a2e                	mv	s4,a1
 5a8:	8bb2                	mv	s7,a2
  state = 0;
 5aa:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 5ac:	4901                	li	s2,0
 5ae:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 5b0:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 5b4:	06400c13          	li	s8,100
 5b8:	a00d                	j	5da <vprintf+0x56>
        putc(fd, c0);
 5ba:	85a6                	mv	a1,s1
 5bc:	855a                	mv	a0,s6
 5be:	f05ff0ef          	jal	4c2 <putc>
 5c2:	a019                	j	5c8 <vprintf+0x44>
    } else if(state == '%'){
 5c4:	03598363          	beq	s3,s5,5ea <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 5c8:	0019079b          	addiw	a5,s2,1
 5cc:	893e                	mv	s2,a5
 5ce:	873e                	mv	a4,a5
 5d0:	97d2                	add	a5,a5,s4
 5d2:	0007c483          	lbu	s1,0(a5)
 5d6:	1c048a63          	beqz	s1,7aa <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 5da:	0004879b          	sext.w	a5,s1
    if(state == 0){
 5de:	fe0993e3          	bnez	s3,5c4 <vprintf+0x40>
      if(c0 == '%'){
 5e2:	fd579ce3          	bne	a5,s5,5ba <vprintf+0x36>
        state = '%';
 5e6:	89be                	mv	s3,a5
 5e8:	b7c5                	j	5c8 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 5ea:	00ea06b3          	add	a3,s4,a4
 5ee:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 5f2:	1c060863          	beqz	a2,7c2 <vprintf+0x23e>
      if(c0 == 'd'){
 5f6:	03878763          	beq	a5,s8,624 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5fa:	f9478693          	addi	a3,a5,-108
 5fe:	0016b693          	seqz	a3,a3
 602:	f9c60593          	addi	a1,a2,-100
 606:	e99d                	bnez	a1,63c <vprintf+0xb8>
 608:	ca95                	beqz	a3,63c <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 60a:	008b8493          	addi	s1,s7,8
 60e:	4685                	li	a3,1
 610:	4629                	li	a2,10
 612:	000bb583          	ld	a1,0(s7)
 616:	855a                	mv	a0,s6
 618:	ec9ff0ef          	jal	4e0 <printint>
        i += 1;
 61c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 61e:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 620:	4981                	li	s3,0
 622:	b75d                	j	5c8 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 624:	008b8493          	addi	s1,s7,8
 628:	4685                	li	a3,1
 62a:	4629                	li	a2,10
 62c:	000ba583          	lw	a1,0(s7)
 630:	855a                	mv	a0,s6
 632:	eafff0ef          	jal	4e0 <printint>
 636:	8ba6                	mv	s7,s1
      state = 0;
 638:	4981                	li	s3,0
 63a:	b779                	j	5c8 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 63c:	9752                	add	a4,a4,s4
 63e:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 642:	f9460713          	addi	a4,a2,-108
 646:	00173713          	seqz	a4,a4
 64a:	8f75                	and	a4,a4,a3
 64c:	f9c58513          	addi	a0,a1,-100
 650:	18051363          	bnez	a0,7d6 <vprintf+0x252>
 654:	18070163          	beqz	a4,7d6 <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 658:	008b8493          	addi	s1,s7,8
 65c:	4685                	li	a3,1
 65e:	4629                	li	a2,10
 660:	000bb583          	ld	a1,0(s7)
 664:	855a                	mv	a0,s6
 666:	e7bff0ef          	jal	4e0 <printint>
        i += 2;
 66a:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 66c:	8ba6                	mv	s7,s1
      state = 0;
 66e:	4981                	li	s3,0
        i += 2;
 670:	bfa1                	j	5c8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 672:	008b8493          	addi	s1,s7,8
 676:	4681                	li	a3,0
 678:	4629                	li	a2,10
 67a:	000be583          	lwu	a1,0(s7)
 67e:	855a                	mv	a0,s6
 680:	e61ff0ef          	jal	4e0 <printint>
 684:	8ba6                	mv	s7,s1
      state = 0;
 686:	4981                	li	s3,0
 688:	b781                	j	5c8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 68a:	008b8493          	addi	s1,s7,8
 68e:	4681                	li	a3,0
 690:	4629                	li	a2,10
 692:	000bb583          	ld	a1,0(s7)
 696:	855a                	mv	a0,s6
 698:	e49ff0ef          	jal	4e0 <printint>
        i += 1;
 69c:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 69e:	8ba6                	mv	s7,s1
      state = 0;
 6a0:	4981                	li	s3,0
 6a2:	b71d                	j	5c8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 6a4:	008b8493          	addi	s1,s7,8
 6a8:	4681                	li	a3,0
 6aa:	4629                	li	a2,10
 6ac:	000bb583          	ld	a1,0(s7)
 6b0:	855a                	mv	a0,s6
 6b2:	e2fff0ef          	jal	4e0 <printint>
        i += 2;
 6b6:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 6b8:	8ba6                	mv	s7,s1
      state = 0;
 6ba:	4981                	li	s3,0
        i += 2;
 6bc:	b731                	j	5c8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 6be:	008b8493          	addi	s1,s7,8
 6c2:	4681                	li	a3,0
 6c4:	4641                	li	a2,16
 6c6:	000be583          	lwu	a1,0(s7)
 6ca:	855a                	mv	a0,s6
 6cc:	e15ff0ef          	jal	4e0 <printint>
 6d0:	8ba6                	mv	s7,s1
      state = 0;
 6d2:	4981                	li	s3,0
 6d4:	bdd5                	j	5c8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6d6:	008b8493          	addi	s1,s7,8
 6da:	4681                	li	a3,0
 6dc:	4641                	li	a2,16
 6de:	000bb583          	ld	a1,0(s7)
 6e2:	855a                	mv	a0,s6
 6e4:	dfdff0ef          	jal	4e0 <printint>
        i += 1;
 6e8:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 6ea:	8ba6                	mv	s7,s1
      state = 0;
 6ec:	4981                	li	s3,0
 6ee:	bde9                	j	5c8 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 6f0:	008b8493          	addi	s1,s7,8
 6f4:	4681                	li	a3,0
 6f6:	4641                	li	a2,16
 6f8:	000bb583          	ld	a1,0(s7)
 6fc:	855a                	mv	a0,s6
 6fe:	de3ff0ef          	jal	4e0 <printint>
        i += 2;
 702:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 704:	8ba6                	mv	s7,s1
      state = 0;
 706:	4981                	li	s3,0
        i += 2;
 708:	b5c1                	j	5c8 <vprintf+0x44>
 70a:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 70c:	008b8793          	addi	a5,s7,8
 710:	8cbe                	mv	s9,a5
 712:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 716:	03000593          	li	a1,48
 71a:	855a                	mv	a0,s6
 71c:	da7ff0ef          	jal	4c2 <putc>
  putc(fd, 'x');
 720:	07800593          	li	a1,120
 724:	855a                	mv	a0,s6
 726:	d9dff0ef          	jal	4c2 <putc>
 72a:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 72c:	00000b97          	auipc	s7,0x0
 730:	34cb8b93          	addi	s7,s7,844 # a78 <digits>
 734:	03c9d793          	srli	a5,s3,0x3c
 738:	97de                	add	a5,a5,s7
 73a:	0007c583          	lbu	a1,0(a5)
 73e:	855a                	mv	a0,s6
 740:	d83ff0ef          	jal	4c2 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 744:	0992                	slli	s3,s3,0x4
 746:	34fd                	addiw	s1,s1,-1
 748:	f4f5                	bnez	s1,734 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 74a:	8be6                	mv	s7,s9
      state = 0;
 74c:	4981                	li	s3,0
 74e:	6ca2                	ld	s9,8(sp)
 750:	bda5                	j	5c8 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 752:	008b8493          	addi	s1,s7,8
 756:	000bc583          	lbu	a1,0(s7)
 75a:	855a                	mv	a0,s6
 75c:	d67ff0ef          	jal	4c2 <putc>
 760:	8ba6                	mv	s7,s1
      state = 0;
 762:	4981                	li	s3,0
 764:	b595                	j	5c8 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 766:	008b8993          	addi	s3,s7,8
 76a:	000bb483          	ld	s1,0(s7)
 76e:	cc91                	beqz	s1,78a <vprintf+0x206>
        for(; *s; s++)
 770:	0004c583          	lbu	a1,0(s1)
 774:	c985                	beqz	a1,7a4 <vprintf+0x220>
          putc(fd, *s);
 776:	855a                	mv	a0,s6
 778:	d4bff0ef          	jal	4c2 <putc>
        for(; *s; s++)
 77c:	0485                	addi	s1,s1,1
 77e:	0004c583          	lbu	a1,0(s1)
 782:	f9f5                	bnez	a1,776 <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 784:	8bce                	mv	s7,s3
      state = 0;
 786:	4981                	li	s3,0
 788:	b581                	j	5c8 <vprintf+0x44>
          s = "(null)";
 78a:	00000497          	auipc	s1,0x0
 78e:	2e648493          	addi	s1,s1,742 # a70 <malloc+0x14a>
        for(; *s; s++)
 792:	02800593          	li	a1,40
 796:	b7c5                	j	776 <vprintf+0x1f2>
        putc(fd, '%');
 798:	85be                	mv	a1,a5
 79a:	855a                	mv	a0,s6
 79c:	d27ff0ef          	jal	4c2 <putc>
      state = 0;
 7a0:	4981                	li	s3,0
 7a2:	b51d                	j	5c8 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 7a4:	8bce                	mv	s7,s3
      state = 0;
 7a6:	4981                	li	s3,0
 7a8:	b505                	j	5c8 <vprintf+0x44>
 7aa:	6906                	ld	s2,64(sp)
 7ac:	79e2                	ld	s3,56(sp)
 7ae:	7a42                	ld	s4,48(sp)
 7b0:	7aa2                	ld	s5,40(sp)
 7b2:	7b02                	ld	s6,32(sp)
 7b4:	6be2                	ld	s7,24(sp)
 7b6:	6c42                	ld	s8,16(sp)
    }
  }
}
 7b8:	60e6                	ld	ra,88(sp)
 7ba:	6446                	ld	s0,80(sp)
 7bc:	64a6                	ld	s1,72(sp)
 7be:	6125                	addi	sp,sp,96
 7c0:	8082                	ret
      if(c0 == 'd'){
 7c2:	06400713          	li	a4,100
 7c6:	e4e78fe3          	beq	a5,a4,624 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 7ca:	f9478693          	addi	a3,a5,-108
 7ce:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 7d2:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 7d4:	4701                	li	a4,0
      } else if(c0 == 'u'){
 7d6:	07500513          	li	a0,117
 7da:	e8a78ce3          	beq	a5,a0,672 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 7de:	f8b60513          	addi	a0,a2,-117
 7e2:	e119                	bnez	a0,7e8 <vprintf+0x264>
 7e4:	ea0693e3          	bnez	a3,68a <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 7e8:	f8b58513          	addi	a0,a1,-117
 7ec:	e119                	bnez	a0,7f2 <vprintf+0x26e>
 7ee:	ea071be3          	bnez	a4,6a4 <vprintf+0x120>
      } else if(c0 == 'x'){
 7f2:	07800513          	li	a0,120
 7f6:	eca784e3          	beq	a5,a0,6be <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 7fa:	f8860613          	addi	a2,a2,-120
 7fe:	e219                	bnez	a2,804 <vprintf+0x280>
 800:	ec069be3          	bnez	a3,6d6 <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 804:	f8858593          	addi	a1,a1,-120
 808:	e199                	bnez	a1,80e <vprintf+0x28a>
 80a:	ee0713e3          	bnez	a4,6f0 <vprintf+0x16c>
      } else if(c0 == 'p'){
 80e:	07000713          	li	a4,112
 812:	eee78ce3          	beq	a5,a4,70a <vprintf+0x186>
      } else if(c0 == 'c'){
 816:	06300713          	li	a4,99
 81a:	f2e78ce3          	beq	a5,a4,752 <vprintf+0x1ce>
      } else if(c0 == 's'){
 81e:	07300713          	li	a4,115
 822:	f4e782e3          	beq	a5,a4,766 <vprintf+0x1e2>
      } else if(c0 == '%'){
 826:	02500713          	li	a4,37
 82a:	f6e787e3          	beq	a5,a4,798 <vprintf+0x214>
        putc(fd, '%');
 82e:	02500593          	li	a1,37
 832:	855a                	mv	a0,s6
 834:	c8fff0ef          	jal	4c2 <putc>
        putc(fd, c0);
 838:	85a6                	mv	a1,s1
 83a:	855a                	mv	a0,s6
 83c:	c87ff0ef          	jal	4c2 <putc>
      state = 0;
 840:	4981                	li	s3,0
 842:	b359                	j	5c8 <vprintf+0x44>

0000000000000844 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 844:	715d                	addi	sp,sp,-80
 846:	ec06                	sd	ra,24(sp)
 848:	e822                	sd	s0,16(sp)
 84a:	1000                	addi	s0,sp,32
 84c:	e010                	sd	a2,0(s0)
 84e:	e414                	sd	a3,8(s0)
 850:	e818                	sd	a4,16(s0)
 852:	ec1c                	sd	a5,24(s0)
 854:	03043023          	sd	a6,32(s0)
 858:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 85c:	8622                	mv	a2,s0
 85e:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 862:	d23ff0ef          	jal	584 <vprintf>
}
 866:	60e2                	ld	ra,24(sp)
 868:	6442                	ld	s0,16(sp)
 86a:	6161                	addi	sp,sp,80
 86c:	8082                	ret

000000000000086e <printf>:

void
printf(const char *fmt, ...)
{
 86e:	711d                	addi	sp,sp,-96
 870:	ec06                	sd	ra,24(sp)
 872:	e822                	sd	s0,16(sp)
 874:	1000                	addi	s0,sp,32
 876:	e40c                	sd	a1,8(s0)
 878:	e810                	sd	a2,16(s0)
 87a:	ec14                	sd	a3,24(s0)
 87c:	f018                	sd	a4,32(s0)
 87e:	f41c                	sd	a5,40(s0)
 880:	03043823          	sd	a6,48(s0)
 884:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 888:	00840613          	addi	a2,s0,8
 88c:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 890:	85aa                	mv	a1,a0
 892:	4505                	li	a0,1
 894:	cf1ff0ef          	jal	584 <vprintf>
}
 898:	60e2                	ld	ra,24(sp)
 89a:	6442                	ld	s0,16(sp)
 89c:	6125                	addi	sp,sp,96
 89e:	8082                	ret

00000000000008a0 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 8a0:	1141                	addi	sp,sp,-16
 8a2:	e406                	sd	ra,8(sp)
 8a4:	e022                	sd	s0,0(sp)
 8a6:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 8a8:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8ac:	00000797          	auipc	a5,0x0
 8b0:	7547b783          	ld	a5,1876(a5) # 1000 <freep>
 8b4:	a039                	j	8c2 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8b6:	6398                	ld	a4,0(a5)
 8b8:	00e7e463          	bltu	a5,a4,8c0 <free+0x20>
 8bc:	00e6ea63          	bltu	a3,a4,8d0 <free+0x30>
{
 8c0:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 8c2:	fed7fae3          	bgeu	a5,a3,8b6 <free+0x16>
 8c6:	6398                	ld	a4,0(a5)
 8c8:	00e6e463          	bltu	a3,a4,8d0 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 8cc:	fee7eae3          	bltu	a5,a4,8c0 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 8d0:	ff852583          	lw	a1,-8(a0)
 8d4:	6390                	ld	a2,0(a5)
 8d6:	02059813          	slli	a6,a1,0x20
 8da:	01c85713          	srli	a4,a6,0x1c
 8de:	9736                	add	a4,a4,a3
 8e0:	02e60563          	beq	a2,a4,90a <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 8e4:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 8e8:	4790                	lw	a2,8(a5)
 8ea:	02061593          	slli	a1,a2,0x20
 8ee:	01c5d713          	srli	a4,a1,0x1c
 8f2:	973e                	add	a4,a4,a5
 8f4:	02e68263          	beq	a3,a4,918 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 8f8:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 8fa:	00000717          	auipc	a4,0x0
 8fe:	70f73323          	sd	a5,1798(a4) # 1000 <freep>
}
 902:	60a2                	ld	ra,8(sp)
 904:	6402                	ld	s0,0(sp)
 906:	0141                	addi	sp,sp,16
 908:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 90a:	4618                	lw	a4,8(a2)
 90c:	9f2d                	addw	a4,a4,a1
 90e:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 912:	6398                	ld	a4,0(a5)
 914:	6310                	ld	a2,0(a4)
 916:	b7f9                	j	8e4 <free+0x44>
    p->s.size += bp->s.size;
 918:	ff852703          	lw	a4,-8(a0)
 91c:	9f31                	addw	a4,a4,a2
 91e:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 920:	ff053683          	ld	a3,-16(a0)
 924:	bfd1                	j	8f8 <free+0x58>

0000000000000926 <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 926:	7139                	addi	sp,sp,-64
 928:	fc06                	sd	ra,56(sp)
 92a:	f822                	sd	s0,48(sp)
 92c:	f04a                	sd	s2,32(sp)
 92e:	ec4e                	sd	s3,24(sp)
 930:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 932:	02051993          	slli	s3,a0,0x20
 936:	0209d993          	srli	s3,s3,0x20
 93a:	09bd                	addi	s3,s3,15
 93c:	0049d993          	srli	s3,s3,0x4
 940:	2985                	addiw	s3,s3,1
 942:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 944:	00000517          	auipc	a0,0x0
 948:	6bc53503          	ld	a0,1724(a0) # 1000 <freep>
 94c:	c905                	beqz	a0,97c <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 94e:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 950:	4798                	lw	a4,8(a5)
 952:	09377663          	bgeu	a4,s3,9de <malloc+0xb8>
 956:	f426                	sd	s1,40(sp)
 958:	e852                	sd	s4,16(sp)
 95a:	e456                	sd	s5,8(sp)
 95c:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 95e:	8a4e                	mv	s4,s3
 960:	6705                	lui	a4,0x1
 962:	00e9f363          	bgeu	s3,a4,968 <malloc+0x42>
 966:	6a05                	lui	s4,0x1
 968:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 96c:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 970:	00000497          	auipc	s1,0x0
 974:	69048493          	addi	s1,s1,1680 # 1000 <freep>
  if(p == SBRK_ERROR)
 978:	5afd                	li	s5,-1
 97a:	a83d                	j	9b8 <malloc+0x92>
 97c:	f426                	sd	s1,40(sp)
 97e:	e852                	sd	s4,16(sp)
 980:	e456                	sd	s5,8(sp)
 982:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 984:	00000797          	auipc	a5,0x0
 988:	68c78793          	addi	a5,a5,1676 # 1010 <base>
 98c:	00000717          	auipc	a4,0x0
 990:	66f73a23          	sd	a5,1652(a4) # 1000 <freep>
 994:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 996:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 99a:	b7d1                	j	95e <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 99c:	6398                	ld	a4,0(a5)
 99e:	e118                	sd	a4,0(a0)
 9a0:	a899                	j	9f6 <malloc+0xd0>
  hp->s.size = nu;
 9a2:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 9a6:	0541                	addi	a0,a0,16
 9a8:	ef9ff0ef          	jal	8a0 <free>
  return freep;
 9ac:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 9ae:	c125                	beqz	a0,a0e <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 9b0:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 9b2:	4798                	lw	a4,8(a5)
 9b4:	03277163          	bgeu	a4,s2,9d6 <malloc+0xb0>
    if(p == freep)
 9b8:	6098                	ld	a4,0(s1)
 9ba:	853e                	mv	a0,a5
 9bc:	fef71ae3          	bne	a4,a5,9b0 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 9c0:	8552                	mv	a0,s4
 9c2:	9f5ff0ef          	jal	3b6 <sbrk>
  if(p == SBRK_ERROR)
 9c6:	fd551ee3          	bne	a0,s5,9a2 <malloc+0x7c>
        return 0;
 9ca:	4501                	li	a0,0
 9cc:	74a2                	ld	s1,40(sp)
 9ce:	6a42                	ld	s4,16(sp)
 9d0:	6aa2                	ld	s5,8(sp)
 9d2:	6b02                	ld	s6,0(sp)
 9d4:	a03d                	j	a02 <malloc+0xdc>
 9d6:	74a2                	ld	s1,40(sp)
 9d8:	6a42                	ld	s4,16(sp)
 9da:	6aa2                	ld	s5,8(sp)
 9dc:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 9de:	fae90fe3          	beq	s2,a4,99c <malloc+0x76>
        p->s.size -= nunits;
 9e2:	4137073b          	subw	a4,a4,s3
 9e6:	c798                	sw	a4,8(a5)
        p += p->s.size;
 9e8:	02071693          	slli	a3,a4,0x20
 9ec:	01c6d713          	srli	a4,a3,0x1c
 9f0:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 9f2:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 9f6:	00000717          	auipc	a4,0x0
 9fa:	60a73523          	sd	a0,1546(a4) # 1000 <freep>
      return (void*)(p + 1);
 9fe:	01078513          	addi	a0,a5,16
  }
}
 a02:	70e2                	ld	ra,56(sp)
 a04:	7442                	ld	s0,48(sp)
 a06:	7902                	ld	s2,32(sp)
 a08:	69e2                	ld	s3,24(sp)
 a0a:	6121                	addi	sp,sp,64
 a0c:	8082                	ret
 a0e:	74a2                	ld	s1,40(sp)
 a10:	6a42                	ld	s4,16(sp)
 a12:	6aa2                	ld	s5,8(sp)
 a14:	6b02                	ld	s6,0(sp)
 a16:	b7f5                	j	a02 <malloc+0xdc>
