
user/_shmtest:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <main>:
#include "kernel/stat.h"
#include "user/user.h"

int
main(int argc, char *argv[])
{
   0:	1101                	addi	sp,sp,-32
   2:	ec06                	sd	ra,24(sp)
   4:	e822                	sd	s0,16(sp)
   6:	1000                	addi	s0,sp,32
    printf("shmtest: starting...\n");
   8:	00001517          	auipc	a0,0x1
   c:	9b850513          	addi	a0,a0,-1608 # 9c0 <malloc+0xf2>
  10:	007000ef          	jal	816 <printf>

    int key = 1;  // shared memory key
    char *ptr;

    // Process 1: get shared memory
    ptr = (char *) shm_get(key);
  14:	4505                	li	a0,1
  16:	424000ef          	jal	43a <shm_get>
    if(ptr == 0){
  1a:	cd31                	beqz	a0,76 <main+0x76>
  1c:	e426                	sd	s1,8(sp)
  1e:	84aa                	mv	s1,a0
        printf("shmtest: shm_get failed\n");
        exit(1);
    }
    printf("shmtest: writing to shared memory\n");
  20:	00001517          	auipc	a0,0x1
  24:	9e050513          	addi	a0,a0,-1568 # a00 <malloc+0x132>
  28:	7ee000ef          	jal	816 <printf>
    strcpy(ptr, "hello from proc1");
  2c:	00001597          	auipc	a1,0x1
  30:	9fc58593          	addi	a1,a1,-1540 # a28 <malloc+0x15a>
  34:	8526                	mv	a0,s1
  36:	0b6000ef          	jal	ec <strcpy>

    // Fork so child can also use the shared memory
    int pid = fork();
  3a:	350000ef          	jal	38a <fork>
    if(pid < 0){
  3e:	04054663          	bltz	a0,8a <main+0x8a>
        printf("shmtest: fork failed\n");
        exit(1);
    }

    if(pid == 0){
  42:	e535                	bnez	a0,ae <main+0xae>
        // Child process: attach same shared memory
        char *child_ptr = (char *) shm_get(key);
  44:	4505                	li	a0,1
  46:	3f4000ef          	jal	43a <shm_get>
  4a:	84aa                	mv	s1,a0
        if(child_ptr == 0){
  4c:	c921                	beqz	a0,9c <main+0x9c>
            printf("child: shm_get failed\n");
            exit(1);
        }

        printf("child: read from shared memory: %s\n", child_ptr);
  4e:	85aa                	mv	a1,a0
  50:	00001517          	auipc	a0,0x1
  54:	a2050513          	addi	a0,a0,-1504 # a70 <malloc+0x1a2>
  58:	7be000ef          	jal	816 <printf>
        strcpy(child_ptr, "hello from child");
  5c:	00001597          	auipc	a1,0x1
  60:	a3c58593          	addi	a1,a1,-1476 # a98 <malloc+0x1ca>
  64:	8526                	mv	a0,s1
  66:	086000ef          	jal	ec <strcpy>
        // close shared memory
        shm_close(key);
  6a:	4505                	li	a0,1
  6c:	3d6000ef          	jal	442 <shm_close>
        exit(0);
  70:	4501                	li	a0,0
  72:	320000ef          	jal	392 <exit>
  76:	e426                	sd	s1,8(sp)
        printf("shmtest: shm_get failed\n");
  78:	00001517          	auipc	a0,0x1
  7c:	96850513          	addi	a0,a0,-1688 # 9e0 <malloc+0x112>
  80:	796000ef          	jal	816 <printf>
        exit(1);
  84:	4505                	li	a0,1
  86:	30c000ef          	jal	392 <exit>
        printf("shmtest: fork failed\n");
  8a:	00001517          	auipc	a0,0x1
  8e:	9b650513          	addi	a0,a0,-1610 # a40 <malloc+0x172>
  92:	784000ef          	jal	816 <printf>
        exit(1);
  96:	4505                	li	a0,1
  98:	2fa000ef          	jal	392 <exit>
            printf("child: shm_get failed\n");
  9c:	00001517          	auipc	a0,0x1
  a0:	9bc50513          	addi	a0,a0,-1604 # a58 <malloc+0x18a>
  a4:	772000ef          	jal	816 <printf>
            exit(1);
  a8:	4505                	li	a0,1
  aa:	2e8000ef          	jal	392 <exit>
    } else {
        // Parent waits
        wait(0);
  ae:	4501                	li	a0,0
  b0:	2ea000ef          	jal	39a <wait>
        printf("parent: read from shared memory: %s\n", ptr);
  b4:	85a6                	mv	a1,s1
  b6:	00001517          	auipc	a0,0x1
  ba:	9fa50513          	addi	a0,a0,-1542 # ab0 <malloc+0x1e2>
  be:	758000ef          	jal	816 <printf>
        // parent closes shared memory
        shm_close(key);
  c2:	4505                	li	a0,1
  c4:	37e000ef          	jal	442 <shm_close>
    }

    printf("shmtest: finished.\n");
  c8:	00001517          	auipc	a0,0x1
  cc:	a1050513          	addi	a0,a0,-1520 # ad8 <malloc+0x20a>
  d0:	746000ef          	jal	816 <printf>
    exit(0);
  d4:	4501                	li	a0,0
  d6:	2bc000ef          	jal	392 <exit>

00000000000000da <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
  da:	1141                	addi	sp,sp,-16
  dc:	e406                	sd	ra,8(sp)
  de:	e022                	sd	s0,0(sp)
  e0:	0800                	addi	s0,sp,16
  extern int main();
  main();
  e2:	f1fff0ef          	jal	0 <main>
  exit(0);
  e6:	4501                	li	a0,0
  e8:	2aa000ef          	jal	392 <exit>

00000000000000ec <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
  ec:	1141                	addi	sp,sp,-16
  ee:	e406                	sd	ra,8(sp)
  f0:	e022                	sd	s0,0(sp)
  f2:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
  f4:	87aa                	mv	a5,a0
  f6:	0585                	addi	a1,a1,1
  f8:	0785                	addi	a5,a5,1
  fa:	fff5c703          	lbu	a4,-1(a1)
  fe:	fee78fa3          	sb	a4,-1(a5)
 102:	fb75                	bnez	a4,f6 <strcpy+0xa>
    ;
  return os;
}
 104:	60a2                	ld	ra,8(sp)
 106:	6402                	ld	s0,0(sp)
 108:	0141                	addi	sp,sp,16
 10a:	8082                	ret

000000000000010c <strcmp>:

int
strcmp(const char *p, const char *q)
{
 10c:	1141                	addi	sp,sp,-16
 10e:	e406                	sd	ra,8(sp)
 110:	e022                	sd	s0,0(sp)
 112:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
 114:	00054783          	lbu	a5,0(a0)
 118:	cb91                	beqz	a5,12c <strcmp+0x20>
 11a:	0005c703          	lbu	a4,0(a1)
 11e:	00f71763          	bne	a4,a5,12c <strcmp+0x20>
    p++, q++;
 122:	0505                	addi	a0,a0,1
 124:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
 126:	00054783          	lbu	a5,0(a0)
 12a:	fbe5                	bnez	a5,11a <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
 12c:	0005c503          	lbu	a0,0(a1)
}
 130:	40a7853b          	subw	a0,a5,a0
 134:	60a2                	ld	ra,8(sp)
 136:	6402                	ld	s0,0(sp)
 138:	0141                	addi	sp,sp,16
 13a:	8082                	ret

000000000000013c <strlen>:

uint
strlen(const char *s)
{
 13c:	1141                	addi	sp,sp,-16
 13e:	e406                	sd	ra,8(sp)
 140:	e022                	sd	s0,0(sp)
 142:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
 144:	00054783          	lbu	a5,0(a0)
 148:	cf91                	beqz	a5,164 <strlen+0x28>
 14a:	00150793          	addi	a5,a0,1
 14e:	86be                	mv	a3,a5
 150:	0785                	addi	a5,a5,1
 152:	fff7c703          	lbu	a4,-1(a5)
 156:	ff65                	bnez	a4,14e <strlen+0x12>
 158:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
 15c:	60a2                	ld	ra,8(sp)
 15e:	6402                	ld	s0,0(sp)
 160:	0141                	addi	sp,sp,16
 162:	8082                	ret
  for(n = 0; s[n]; n++)
 164:	4501                	li	a0,0
 166:	bfdd                	j	15c <strlen+0x20>

0000000000000168 <memset>:

void*
memset(void *dst, int c, uint n)
{
 168:	1141                	addi	sp,sp,-16
 16a:	e406                	sd	ra,8(sp)
 16c:	e022                	sd	s0,0(sp)
 16e:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
 170:	ca19                	beqz	a2,186 <memset+0x1e>
 172:	87aa                	mv	a5,a0
 174:	1602                	slli	a2,a2,0x20
 176:	9201                	srli	a2,a2,0x20
 178:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
 17c:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
 180:	0785                	addi	a5,a5,1
 182:	fee79de3          	bne	a5,a4,17c <memset+0x14>
  }
  return dst;
}
 186:	60a2                	ld	ra,8(sp)
 188:	6402                	ld	s0,0(sp)
 18a:	0141                	addi	sp,sp,16
 18c:	8082                	ret

000000000000018e <strchr>:

char*
strchr(const char *s, char c)
{
 18e:	1141                	addi	sp,sp,-16
 190:	e406                	sd	ra,8(sp)
 192:	e022                	sd	s0,0(sp)
 194:	0800                	addi	s0,sp,16
  for(; *s; s++)
 196:	00054783          	lbu	a5,0(a0)
 19a:	cf81                	beqz	a5,1b2 <strchr+0x24>
    if(*s == c)
 19c:	00f58763          	beq	a1,a5,1aa <strchr+0x1c>
  for(; *s; s++)
 1a0:	0505                	addi	a0,a0,1
 1a2:	00054783          	lbu	a5,0(a0)
 1a6:	fbfd                	bnez	a5,19c <strchr+0xe>
      return (char*)s;
  return 0;
 1a8:	4501                	li	a0,0
}
 1aa:	60a2                	ld	ra,8(sp)
 1ac:	6402                	ld	s0,0(sp)
 1ae:	0141                	addi	sp,sp,16
 1b0:	8082                	ret
  return 0;
 1b2:	4501                	li	a0,0
 1b4:	bfdd                	j	1aa <strchr+0x1c>

00000000000001b6 <gets>:

char*
gets(char *buf, int max)
{
 1b6:	711d                	addi	sp,sp,-96
 1b8:	ec86                	sd	ra,88(sp)
 1ba:	e8a2                	sd	s0,80(sp)
 1bc:	e4a6                	sd	s1,72(sp)
 1be:	e0ca                	sd	s2,64(sp)
 1c0:	fc4e                	sd	s3,56(sp)
 1c2:	f852                	sd	s4,48(sp)
 1c4:	f456                	sd	s5,40(sp)
 1c6:	f05a                	sd	s6,32(sp)
 1c8:	ec5e                	sd	s7,24(sp)
 1ca:	e862                	sd	s8,16(sp)
 1cc:	1080                	addi	s0,sp,96
 1ce:	8baa                	mv	s7,a0
 1d0:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
 1d2:	892a                	mv	s2,a0
 1d4:	4481                	li	s1,0
    cc = read(0, &c, 1);
 1d6:	faf40b13          	addi	s6,s0,-81
 1da:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
 1dc:	8c26                	mv	s8,s1
 1de:	0014899b          	addiw	s3,s1,1
 1e2:	84ce                	mv	s1,s3
 1e4:	0349d463          	bge	s3,s4,20c <gets+0x56>
    cc = read(0, &c, 1);
 1e8:	8656                	mv	a2,s5
 1ea:	85da                	mv	a1,s6
 1ec:	4501                	li	a0,0
 1ee:	1bc000ef          	jal	3aa <read>
    if(cc < 1)
 1f2:	00a05d63          	blez	a0,20c <gets+0x56>
      break;
    buf[i++] = c;
 1f6:	faf44783          	lbu	a5,-81(s0)
 1fa:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
 1fe:	0905                	addi	s2,s2,1
 200:	ff678713          	addi	a4,a5,-10
 204:	c319                	beqz	a4,20a <gets+0x54>
 206:	17cd                	addi	a5,a5,-13
 208:	fbf1                	bnez	a5,1dc <gets+0x26>
    buf[i++] = c;
 20a:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
 20c:	9c5e                	add	s8,s8,s7
 20e:	000c0023          	sb	zero,0(s8)
  return buf;
}
 212:	855e                	mv	a0,s7
 214:	60e6                	ld	ra,88(sp)
 216:	6446                	ld	s0,80(sp)
 218:	64a6                	ld	s1,72(sp)
 21a:	6906                	ld	s2,64(sp)
 21c:	79e2                	ld	s3,56(sp)
 21e:	7a42                	ld	s4,48(sp)
 220:	7aa2                	ld	s5,40(sp)
 222:	7b02                	ld	s6,32(sp)
 224:	6be2                	ld	s7,24(sp)
 226:	6c42                	ld	s8,16(sp)
 228:	6125                	addi	sp,sp,96
 22a:	8082                	ret

000000000000022c <stat>:

int
stat(const char *n, struct stat *st)
{
 22c:	1101                	addi	sp,sp,-32
 22e:	ec06                	sd	ra,24(sp)
 230:	e822                	sd	s0,16(sp)
 232:	e04a                	sd	s2,0(sp)
 234:	1000                	addi	s0,sp,32
 236:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
 238:	4581                	li	a1,0
 23a:	198000ef          	jal	3d2 <open>
  if(fd < 0)
 23e:	02054263          	bltz	a0,262 <stat+0x36>
 242:	e426                	sd	s1,8(sp)
 244:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
 246:	85ca                	mv	a1,s2
 248:	1a2000ef          	jal	3ea <fstat>
 24c:	892a                	mv	s2,a0
  close(fd);
 24e:	8526                	mv	a0,s1
 250:	16a000ef          	jal	3ba <close>
  return r;
 254:	64a2                	ld	s1,8(sp)
}
 256:	854a                	mv	a0,s2
 258:	60e2                	ld	ra,24(sp)
 25a:	6442                	ld	s0,16(sp)
 25c:	6902                	ld	s2,0(sp)
 25e:	6105                	addi	sp,sp,32
 260:	8082                	ret
    return -1;
 262:	57fd                	li	a5,-1
 264:	893e                	mv	s2,a5
 266:	bfc5                	j	256 <stat+0x2a>

0000000000000268 <atoi>:

int
atoi(const char *s)
{
 268:	1141                	addi	sp,sp,-16
 26a:	e406                	sd	ra,8(sp)
 26c:	e022                	sd	s0,0(sp)
 26e:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
 270:	00054683          	lbu	a3,0(a0)
 274:	fd06879b          	addiw	a5,a3,-48
 278:	0ff7f793          	zext.b	a5,a5
 27c:	4625                	li	a2,9
 27e:	02f66963          	bltu	a2,a5,2b0 <atoi+0x48>
 282:	872a                	mv	a4,a0
  n = 0;
 284:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
 286:	0705                	addi	a4,a4,1
 288:	0025179b          	slliw	a5,a0,0x2
 28c:	9fa9                	addw	a5,a5,a0
 28e:	0017979b          	slliw	a5,a5,0x1
 292:	9fb5                	addw	a5,a5,a3
 294:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
 298:	00074683          	lbu	a3,0(a4)
 29c:	fd06879b          	addiw	a5,a3,-48
 2a0:	0ff7f793          	zext.b	a5,a5
 2a4:	fef671e3          	bgeu	a2,a5,286 <atoi+0x1e>
  return n;
}
 2a8:	60a2                	ld	ra,8(sp)
 2aa:	6402                	ld	s0,0(sp)
 2ac:	0141                	addi	sp,sp,16
 2ae:	8082                	ret
  n = 0;
 2b0:	4501                	li	a0,0
 2b2:	bfdd                	j	2a8 <atoi+0x40>

00000000000002b4 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
 2b4:	1141                	addi	sp,sp,-16
 2b6:	e406                	sd	ra,8(sp)
 2b8:	e022                	sd	s0,0(sp)
 2ba:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
 2bc:	02b57563          	bgeu	a0,a1,2e6 <memmove+0x32>
    while(n-- > 0)
 2c0:	00c05f63          	blez	a2,2de <memmove+0x2a>
 2c4:	1602                	slli	a2,a2,0x20
 2c6:	9201                	srli	a2,a2,0x20
 2c8:	00c507b3          	add	a5,a0,a2
  dst = vdst;
 2cc:	872a                	mv	a4,a0
      *dst++ = *src++;
 2ce:	0585                	addi	a1,a1,1
 2d0:	0705                	addi	a4,a4,1
 2d2:	fff5c683          	lbu	a3,-1(a1)
 2d6:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
 2da:	fee79ae3          	bne	a5,a4,2ce <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
 2de:	60a2                	ld	ra,8(sp)
 2e0:	6402                	ld	s0,0(sp)
 2e2:	0141                	addi	sp,sp,16
 2e4:	8082                	ret
    while(n-- > 0)
 2e6:	fec05ce3          	blez	a2,2de <memmove+0x2a>
    dst += n;
 2ea:	00c50733          	add	a4,a0,a2
    src += n;
 2ee:	95b2                	add	a1,a1,a2
 2f0:	fff6079b          	addiw	a5,a2,-1
 2f4:	1782                	slli	a5,a5,0x20
 2f6:	9381                	srli	a5,a5,0x20
 2f8:	fff7c793          	not	a5,a5
 2fc:	97ba                	add	a5,a5,a4
      *--dst = *--src;
 2fe:	15fd                	addi	a1,a1,-1
 300:	177d                	addi	a4,a4,-1
 302:	0005c683          	lbu	a3,0(a1)
 306:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
 30a:	fef71ae3          	bne	a4,a5,2fe <memmove+0x4a>
 30e:	bfc1                	j	2de <memmove+0x2a>

0000000000000310 <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
 310:	1141                	addi	sp,sp,-16
 312:	e406                	sd	ra,8(sp)
 314:	e022                	sd	s0,0(sp)
 316:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
 318:	c61d                	beqz	a2,346 <memcmp+0x36>
 31a:	1602                	slli	a2,a2,0x20
 31c:	9201                	srli	a2,a2,0x20
 31e:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
 322:	00054783          	lbu	a5,0(a0)
 326:	0005c703          	lbu	a4,0(a1)
 32a:	00e79863          	bne	a5,a4,33a <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
 32e:	0505                	addi	a0,a0,1
    p2++;
 330:	0585                	addi	a1,a1,1
  while (n-- > 0) {
 332:	fed518e3          	bne	a0,a3,322 <memcmp+0x12>
  }
  return 0;
 336:	4501                	li	a0,0
 338:	a019                	j	33e <memcmp+0x2e>
      return *p1 - *p2;
 33a:	40e7853b          	subw	a0,a5,a4
}
 33e:	60a2                	ld	ra,8(sp)
 340:	6402                	ld	s0,0(sp)
 342:	0141                	addi	sp,sp,16
 344:	8082                	ret
  return 0;
 346:	4501                	li	a0,0
 348:	bfdd                	j	33e <memcmp+0x2e>

000000000000034a <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
 34a:	1141                	addi	sp,sp,-16
 34c:	e406                	sd	ra,8(sp)
 34e:	e022                	sd	s0,0(sp)
 350:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
 352:	f63ff0ef          	jal	2b4 <memmove>
}
 356:	60a2                	ld	ra,8(sp)
 358:	6402                	ld	s0,0(sp)
 35a:	0141                	addi	sp,sp,16
 35c:	8082                	ret

000000000000035e <sbrk>:

char *
sbrk(int n) {
 35e:	1141                	addi	sp,sp,-16
 360:	e406                	sd	ra,8(sp)
 362:	e022                	sd	s0,0(sp)
 364:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
 366:	4585                	li	a1,1
 368:	0b2000ef          	jal	41a <sys_sbrk>
}
 36c:	60a2                	ld	ra,8(sp)
 36e:	6402                	ld	s0,0(sp)
 370:	0141                	addi	sp,sp,16
 372:	8082                	ret

0000000000000374 <sbrklazy>:

char *
sbrklazy(int n) {
 374:	1141                	addi	sp,sp,-16
 376:	e406                	sd	ra,8(sp)
 378:	e022                	sd	s0,0(sp)
 37a:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
 37c:	4589                	li	a1,2
 37e:	09c000ef          	jal	41a <sys_sbrk>
}
 382:	60a2                	ld	ra,8(sp)
 384:	6402                	ld	s0,0(sp)
 386:	0141                	addi	sp,sp,16
 388:	8082                	ret

000000000000038a <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
 38a:	4885                	li	a7,1
 ecall
 38c:	00000073          	ecall
 ret
 390:	8082                	ret

0000000000000392 <exit>:
.global exit
exit:
 li a7, SYS_exit
 392:	4889                	li	a7,2
 ecall
 394:	00000073          	ecall
 ret
 398:	8082                	ret

000000000000039a <wait>:
.global wait
wait:
 li a7, SYS_wait
 39a:	488d                	li	a7,3
 ecall
 39c:	00000073          	ecall
 ret
 3a0:	8082                	ret

00000000000003a2 <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
 3a2:	4891                	li	a7,4
 ecall
 3a4:	00000073          	ecall
 ret
 3a8:	8082                	ret

00000000000003aa <read>:
.global read
read:
 li a7, SYS_read
 3aa:	4895                	li	a7,5
 ecall
 3ac:	00000073          	ecall
 ret
 3b0:	8082                	ret

00000000000003b2 <write>:
.global write
write:
 li a7, SYS_write
 3b2:	48c1                	li	a7,16
 ecall
 3b4:	00000073          	ecall
 ret
 3b8:	8082                	ret

00000000000003ba <close>:
.global close
close:
 li a7, SYS_close
 3ba:	48d5                	li	a7,21
 ecall
 3bc:	00000073          	ecall
 ret
 3c0:	8082                	ret

00000000000003c2 <kill>:
.global kill
kill:
 li a7, SYS_kill
 3c2:	4899                	li	a7,6
 ecall
 3c4:	00000073          	ecall
 ret
 3c8:	8082                	ret

00000000000003ca <exec>:
.global exec
exec:
 li a7, SYS_exec
 3ca:	489d                	li	a7,7
 ecall
 3cc:	00000073          	ecall
 ret
 3d0:	8082                	ret

00000000000003d2 <open>:
.global open
open:
 li a7, SYS_open
 3d2:	48bd                	li	a7,15
 ecall
 3d4:	00000073          	ecall
 ret
 3d8:	8082                	ret

00000000000003da <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
 3da:	48c5                	li	a7,17
 ecall
 3dc:	00000073          	ecall
 ret
 3e0:	8082                	ret

00000000000003e2 <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
 3e2:	48c9                	li	a7,18
 ecall
 3e4:	00000073          	ecall
 ret
 3e8:	8082                	ret

00000000000003ea <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
 3ea:	48a1                	li	a7,8
 ecall
 3ec:	00000073          	ecall
 ret
 3f0:	8082                	ret

00000000000003f2 <link>:
.global link
link:
 li a7, SYS_link
 3f2:	48cd                	li	a7,19
 ecall
 3f4:	00000073          	ecall
 ret
 3f8:	8082                	ret

00000000000003fa <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
 3fa:	48d1                	li	a7,20
 ecall
 3fc:	00000073          	ecall
 ret
 400:	8082                	ret

0000000000000402 <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
 402:	48a5                	li	a7,9
 ecall
 404:	00000073          	ecall
 ret
 408:	8082                	ret

000000000000040a <dup>:
.global dup
dup:
 li a7, SYS_dup
 40a:	48a9                	li	a7,10
 ecall
 40c:	00000073          	ecall
 ret
 410:	8082                	ret

0000000000000412 <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
 412:	48ad                	li	a7,11
 ecall
 414:	00000073          	ecall
 ret
 418:	8082                	ret

000000000000041a <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
 41a:	48b1                	li	a7,12
 ecall
 41c:	00000073          	ecall
 ret
 420:	8082                	ret

0000000000000422 <pause>:
.global pause
pause:
 li a7, SYS_pause
 422:	48b5                	li	a7,13
 ecall
 424:	00000073          	ecall
 ret
 428:	8082                	ret

000000000000042a <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
 42a:	48b9                	li	a7,14
 ecall
 42c:	00000073          	ecall
 ret
 430:	8082                	ret

0000000000000432 <shm_create>:
.global shm_create
shm_create:
 li a7, SYS_shm_create
 432:	48d9                	li	a7,22
 ecall
 434:	00000073          	ecall
 ret
 438:	8082                	ret

000000000000043a <shm_get>:
.global shm_get
shm_get:
 li a7, SYS_shm_get
 43a:	48dd                	li	a7,23
 ecall
 43c:	00000073          	ecall
 ret
 440:	8082                	ret

0000000000000442 <shm_close>:
.global shm_close
shm_close:
 li a7, SYS_shm_close
 442:	48e1                	li	a7,24
 ecall
 444:	00000073          	ecall
 ret
 448:	8082                	ret

000000000000044a <mbox_create>:
.global mbox_create
mbox_create:
 li a7, SYS_mbox_create
 44a:	48e5                	li	a7,25
 ecall
 44c:	00000073          	ecall
 ret
 450:	8082                	ret

0000000000000452 <mbox_send>:
.global mbox_send
mbox_send:
 li a7, SYS_mbox_send
 452:	48e9                	li	a7,26
 ecall
 454:	00000073          	ecall
 ret
 458:	8082                	ret

000000000000045a <mbox_recv>:
.global mbox_recv
mbox_recv:
 li a7, SYS_mbox_recv
 45a:	48ed                	li	a7,27
 ecall
 45c:	00000073          	ecall
 ret
 460:	8082                	ret

0000000000000462 <va2pa>:
.global va2pa
va2pa:
 li a7, SYS_va2pa
 462:	48f1                	li	a7,28
 ecall
 464:	00000073          	ecall
 ret
 468:	8082                	ret

000000000000046a <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
 46a:	1101                	addi	sp,sp,-32
 46c:	ec06                	sd	ra,24(sp)
 46e:	e822                	sd	s0,16(sp)
 470:	1000                	addi	s0,sp,32
 472:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
 476:	4605                	li	a2,1
 478:	fef40593          	addi	a1,s0,-17
 47c:	f37ff0ef          	jal	3b2 <write>
}
 480:	60e2                	ld	ra,24(sp)
 482:	6442                	ld	s0,16(sp)
 484:	6105                	addi	sp,sp,32
 486:	8082                	ret

0000000000000488 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
 488:	715d                	addi	sp,sp,-80
 48a:	e486                	sd	ra,72(sp)
 48c:	e0a2                	sd	s0,64(sp)
 48e:	f84a                	sd	s2,48(sp)
 490:	f44e                	sd	s3,40(sp)
 492:	0880                	addi	s0,sp,80
 494:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
 496:	cac1                	beqz	a3,526 <printint+0x9e>
 498:	0805d763          	bgez	a1,526 <printint+0x9e>
    neg = 1;
    x = -xx;
 49c:	40b005bb          	negw	a1,a1
    neg = 1;
 4a0:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
 4a2:	fb840993          	addi	s3,s0,-72
  neg = 0;
 4a6:	86ce                	mv	a3,s3
  i = 0;
 4a8:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
 4aa:	00000817          	auipc	a6,0x0
 4ae:	64e80813          	addi	a6,a6,1614 # af8 <digits>
 4b2:	88ba                	mv	a7,a4
 4b4:	0017051b          	addiw	a0,a4,1
 4b8:	872a                	mv	a4,a0
 4ba:	02c5f7bb          	remuw	a5,a1,a2
 4be:	1782                	slli	a5,a5,0x20
 4c0:	9381                	srli	a5,a5,0x20
 4c2:	97c2                	add	a5,a5,a6
 4c4:	0007c783          	lbu	a5,0(a5)
 4c8:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
 4cc:	87ae                	mv	a5,a1
 4ce:	02c5d5bb          	divuw	a1,a1,a2
 4d2:	0685                	addi	a3,a3,1
 4d4:	fcc7ffe3          	bgeu	a5,a2,4b2 <printint+0x2a>
  if(neg)
 4d8:	00030c63          	beqz	t1,4f0 <printint+0x68>
    buf[i++] = '-';
 4dc:	fd050793          	addi	a5,a0,-48
 4e0:	00878533          	add	a0,a5,s0
 4e4:	02d00793          	li	a5,45
 4e8:	fef50423          	sb	a5,-24(a0)
 4ec:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
 4f0:	02e05563          	blez	a4,51a <printint+0x92>
 4f4:	fc26                	sd	s1,56(sp)
 4f6:	377d                	addiw	a4,a4,-1
 4f8:	00e984b3          	add	s1,s3,a4
 4fc:	19fd                	addi	s3,s3,-1
 4fe:	99ba                	add	s3,s3,a4
 500:	1702                	slli	a4,a4,0x20
 502:	9301                	srli	a4,a4,0x20
 504:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
 508:	0004c583          	lbu	a1,0(s1)
 50c:	854a                	mv	a0,s2
 50e:	f5dff0ef          	jal	46a <putc>
  while(--i >= 0)
 512:	14fd                	addi	s1,s1,-1
 514:	ff349ae3          	bne	s1,s3,508 <printint+0x80>
 518:	74e2                	ld	s1,56(sp)
}
 51a:	60a6                	ld	ra,72(sp)
 51c:	6406                	ld	s0,64(sp)
 51e:	7942                	ld	s2,48(sp)
 520:	79a2                	ld	s3,40(sp)
 522:	6161                	addi	sp,sp,80
 524:	8082                	ret
    x = xx;
 526:	2581                	sext.w	a1,a1
  neg = 0;
 528:	4301                	li	t1,0
 52a:	bfa5                	j	4a2 <printint+0x1a>

000000000000052c <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
 52c:	711d                	addi	sp,sp,-96
 52e:	ec86                	sd	ra,88(sp)
 530:	e8a2                	sd	s0,80(sp)
 532:	e4a6                	sd	s1,72(sp)
 534:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
 536:	0005c483          	lbu	s1,0(a1)
 53a:	22048363          	beqz	s1,760 <vprintf+0x234>
 53e:	e0ca                	sd	s2,64(sp)
 540:	fc4e                	sd	s3,56(sp)
 542:	f852                	sd	s4,48(sp)
 544:	f456                	sd	s5,40(sp)
 546:	f05a                	sd	s6,32(sp)
 548:	ec5e                	sd	s7,24(sp)
 54a:	e862                	sd	s8,16(sp)
 54c:	8b2a                	mv	s6,a0
 54e:	8a2e                	mv	s4,a1
 550:	8bb2                	mv	s7,a2
  state = 0;
 552:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
 554:	4901                	li	s2,0
 556:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
 558:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
 55c:	06400c13          	li	s8,100
 560:	a00d                	j	582 <vprintf+0x56>
        putc(fd, c0);
 562:	85a6                	mv	a1,s1
 564:	855a                	mv	a0,s6
 566:	f05ff0ef          	jal	46a <putc>
 56a:	a019                	j	570 <vprintf+0x44>
    } else if(state == '%'){
 56c:	03598363          	beq	s3,s5,592 <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
 570:	0019079b          	addiw	a5,s2,1
 574:	893e                	mv	s2,a5
 576:	873e                	mv	a4,a5
 578:	97d2                	add	a5,a5,s4
 57a:	0007c483          	lbu	s1,0(a5)
 57e:	1c048a63          	beqz	s1,752 <vprintf+0x226>
    c0 = fmt[i] & 0xff;
 582:	0004879b          	sext.w	a5,s1
    if(state == 0){
 586:	fe0993e3          	bnez	s3,56c <vprintf+0x40>
      if(c0 == '%'){
 58a:	fd579ce3          	bne	a5,s5,562 <vprintf+0x36>
        state = '%';
 58e:	89be                	mv	s3,a5
 590:	b7c5                	j	570 <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
 592:	00ea06b3          	add	a3,s4,a4
 596:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
 59a:	1c060863          	beqz	a2,76a <vprintf+0x23e>
      if(c0 == 'd'){
 59e:	03878763          	beq	a5,s8,5cc <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
 5a2:	f9478693          	addi	a3,a5,-108
 5a6:	0016b693          	seqz	a3,a3
 5aa:	f9c60593          	addi	a1,a2,-100
 5ae:	e99d                	bnez	a1,5e4 <vprintf+0xb8>
 5b0:	ca95                	beqz	a3,5e4 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
 5b2:	008b8493          	addi	s1,s7,8
 5b6:	4685                	li	a3,1
 5b8:	4629                	li	a2,10
 5ba:	000bb583          	ld	a1,0(s7)
 5be:	855a                	mv	a0,s6
 5c0:	ec9ff0ef          	jal	488 <printint>
        i += 1;
 5c4:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
 5c6:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
 5c8:	4981                	li	s3,0
 5ca:	b75d                	j	570 <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
 5cc:	008b8493          	addi	s1,s7,8
 5d0:	4685                	li	a3,1
 5d2:	4629                	li	a2,10
 5d4:	000ba583          	lw	a1,0(s7)
 5d8:	855a                	mv	a0,s6
 5da:	eafff0ef          	jal	488 <printint>
 5de:	8ba6                	mv	s7,s1
      state = 0;
 5e0:	4981                	li	s3,0
 5e2:	b779                	j	570 <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
 5e4:	9752                	add	a4,a4,s4
 5e6:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 5ea:	f9460713          	addi	a4,a2,-108
 5ee:	00173713          	seqz	a4,a4
 5f2:	8f75                	and	a4,a4,a3
 5f4:	f9c58513          	addi	a0,a1,-100
 5f8:	18051363          	bnez	a0,77e <vprintf+0x252>
 5fc:	18070163          	beqz	a4,77e <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
 600:	008b8493          	addi	s1,s7,8
 604:	4685                	li	a3,1
 606:	4629                	li	a2,10
 608:	000bb583          	ld	a1,0(s7)
 60c:	855a                	mv	a0,s6
 60e:	e7bff0ef          	jal	488 <printint>
        i += 2;
 612:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
 614:	8ba6                	mv	s7,s1
      state = 0;
 616:	4981                	li	s3,0
        i += 2;
 618:	bfa1                	j	570 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
 61a:	008b8493          	addi	s1,s7,8
 61e:	4681                	li	a3,0
 620:	4629                	li	a2,10
 622:	000be583          	lwu	a1,0(s7)
 626:	855a                	mv	a0,s6
 628:	e61ff0ef          	jal	488 <printint>
 62c:	8ba6                	mv	s7,s1
      state = 0;
 62e:	4981                	li	s3,0
 630:	b781                	j	570 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 632:	008b8493          	addi	s1,s7,8
 636:	4681                	li	a3,0
 638:	4629                	li	a2,10
 63a:	000bb583          	ld	a1,0(s7)
 63e:	855a                	mv	a0,s6
 640:	e49ff0ef          	jal	488 <printint>
        i += 1;
 644:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
 646:	8ba6                	mv	s7,s1
      state = 0;
 648:	4981                	li	s3,0
 64a:	b71d                	j	570 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
 64c:	008b8493          	addi	s1,s7,8
 650:	4681                	li	a3,0
 652:	4629                	li	a2,10
 654:	000bb583          	ld	a1,0(s7)
 658:	855a                	mv	a0,s6
 65a:	e2fff0ef          	jal	488 <printint>
        i += 2;
 65e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
 660:	8ba6                	mv	s7,s1
      state = 0;
 662:	4981                	li	s3,0
        i += 2;
 664:	b731                	j	570 <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
 666:	008b8493          	addi	s1,s7,8
 66a:	4681                	li	a3,0
 66c:	4641                	li	a2,16
 66e:	000be583          	lwu	a1,0(s7)
 672:	855a                	mv	a0,s6
 674:	e15ff0ef          	jal	488 <printint>
 678:	8ba6                	mv	s7,s1
      state = 0;
 67a:	4981                	li	s3,0
 67c:	bdd5                	j	570 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 67e:	008b8493          	addi	s1,s7,8
 682:	4681                	li	a3,0
 684:	4641                	li	a2,16
 686:	000bb583          	ld	a1,0(s7)
 68a:	855a                	mv	a0,s6
 68c:	dfdff0ef          	jal	488 <printint>
        i += 1;
 690:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
 692:	8ba6                	mv	s7,s1
      state = 0;
 694:	4981                	li	s3,0
 696:	bde9                	j	570 <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
 698:	008b8493          	addi	s1,s7,8
 69c:	4681                	li	a3,0
 69e:	4641                	li	a2,16
 6a0:	000bb583          	ld	a1,0(s7)
 6a4:	855a                	mv	a0,s6
 6a6:	de3ff0ef          	jal	488 <printint>
        i += 2;
 6aa:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
 6ac:	8ba6                	mv	s7,s1
      state = 0;
 6ae:	4981                	li	s3,0
        i += 2;
 6b0:	b5c1                	j	570 <vprintf+0x44>
 6b2:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
 6b4:	008b8793          	addi	a5,s7,8
 6b8:	8cbe                	mv	s9,a5
 6ba:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
 6be:	03000593          	li	a1,48
 6c2:	855a                	mv	a0,s6
 6c4:	da7ff0ef          	jal	46a <putc>
  putc(fd, 'x');
 6c8:	07800593          	li	a1,120
 6cc:	855a                	mv	a0,s6
 6ce:	d9dff0ef          	jal	46a <putc>
 6d2:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
 6d4:	00000b97          	auipc	s7,0x0
 6d8:	424b8b93          	addi	s7,s7,1060 # af8 <digits>
 6dc:	03c9d793          	srli	a5,s3,0x3c
 6e0:	97de                	add	a5,a5,s7
 6e2:	0007c583          	lbu	a1,0(a5)
 6e6:	855a                	mv	a0,s6
 6e8:	d83ff0ef          	jal	46a <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
 6ec:	0992                	slli	s3,s3,0x4
 6ee:	34fd                	addiw	s1,s1,-1
 6f0:	f4f5                	bnez	s1,6dc <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
 6f2:	8be6                	mv	s7,s9
      state = 0;
 6f4:	4981                	li	s3,0
 6f6:	6ca2                	ld	s9,8(sp)
 6f8:	bda5                	j	570 <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
 6fa:	008b8493          	addi	s1,s7,8
 6fe:	000bc583          	lbu	a1,0(s7)
 702:	855a                	mv	a0,s6
 704:	d67ff0ef          	jal	46a <putc>
 708:	8ba6                	mv	s7,s1
      state = 0;
 70a:	4981                	li	s3,0
 70c:	b595                	j	570 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 70e:	008b8993          	addi	s3,s7,8
 712:	000bb483          	ld	s1,0(s7)
 716:	cc91                	beqz	s1,732 <vprintf+0x206>
        for(; *s; s++)
 718:	0004c583          	lbu	a1,0(s1)
 71c:	c985                	beqz	a1,74c <vprintf+0x220>
          putc(fd, *s);
 71e:	855a                	mv	a0,s6
 720:	d4bff0ef          	jal	46a <putc>
        for(; *s; s++)
 724:	0485                	addi	s1,s1,1
 726:	0004c583          	lbu	a1,0(s1)
 72a:	f9f5                	bnez	a1,71e <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
 72c:	8bce                	mv	s7,s3
      state = 0;
 72e:	4981                	li	s3,0
 730:	b581                	j	570 <vprintf+0x44>
          s = "(null)";
 732:	00000497          	auipc	s1,0x0
 736:	3be48493          	addi	s1,s1,958 # af0 <malloc+0x222>
        for(; *s; s++)
 73a:	02800593          	li	a1,40
 73e:	b7c5                	j	71e <vprintf+0x1f2>
        putc(fd, '%');
 740:	85be                	mv	a1,a5
 742:	855a                	mv	a0,s6
 744:	d27ff0ef          	jal	46a <putc>
      state = 0;
 748:	4981                	li	s3,0
 74a:	b51d                	j	570 <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
 74c:	8bce                	mv	s7,s3
      state = 0;
 74e:	4981                	li	s3,0
 750:	b505                	j	570 <vprintf+0x44>
 752:	6906                	ld	s2,64(sp)
 754:	79e2                	ld	s3,56(sp)
 756:	7a42                	ld	s4,48(sp)
 758:	7aa2                	ld	s5,40(sp)
 75a:	7b02                	ld	s6,32(sp)
 75c:	6be2                	ld	s7,24(sp)
 75e:	6c42                	ld	s8,16(sp)
    }
  }
}
 760:	60e6                	ld	ra,88(sp)
 762:	6446                	ld	s0,80(sp)
 764:	64a6                	ld	s1,72(sp)
 766:	6125                	addi	sp,sp,96
 768:	8082                	ret
      if(c0 == 'd'){
 76a:	06400713          	li	a4,100
 76e:	e4e78fe3          	beq	a5,a4,5cc <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
 772:	f9478693          	addi	a3,a5,-108
 776:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
 77a:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
 77c:	4701                	li	a4,0
      } else if(c0 == 'u'){
 77e:	07500513          	li	a0,117
 782:	e8a78ce3          	beq	a5,a0,61a <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
 786:	f8b60513          	addi	a0,a2,-117
 78a:	e119                	bnez	a0,790 <vprintf+0x264>
 78c:	ea0693e3          	bnez	a3,632 <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
 790:	f8b58513          	addi	a0,a1,-117
 794:	e119                	bnez	a0,79a <vprintf+0x26e>
 796:	ea071be3          	bnez	a4,64c <vprintf+0x120>
      } else if(c0 == 'x'){
 79a:	07800513          	li	a0,120
 79e:	eca784e3          	beq	a5,a0,666 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
 7a2:	f8860613          	addi	a2,a2,-120
 7a6:	e219                	bnez	a2,7ac <vprintf+0x280>
 7a8:	ec069be3          	bnez	a3,67e <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
 7ac:	f8858593          	addi	a1,a1,-120
 7b0:	e199                	bnez	a1,7b6 <vprintf+0x28a>
 7b2:	ee0713e3          	bnez	a4,698 <vprintf+0x16c>
      } else if(c0 == 'p'){
 7b6:	07000713          	li	a4,112
 7ba:	eee78ce3          	beq	a5,a4,6b2 <vprintf+0x186>
      } else if(c0 == 'c'){
 7be:	06300713          	li	a4,99
 7c2:	f2e78ce3          	beq	a5,a4,6fa <vprintf+0x1ce>
      } else if(c0 == 's'){
 7c6:	07300713          	li	a4,115
 7ca:	f4e782e3          	beq	a5,a4,70e <vprintf+0x1e2>
      } else if(c0 == '%'){
 7ce:	02500713          	li	a4,37
 7d2:	f6e787e3          	beq	a5,a4,740 <vprintf+0x214>
        putc(fd, '%');
 7d6:	02500593          	li	a1,37
 7da:	855a                	mv	a0,s6
 7dc:	c8fff0ef          	jal	46a <putc>
        putc(fd, c0);
 7e0:	85a6                	mv	a1,s1
 7e2:	855a                	mv	a0,s6
 7e4:	c87ff0ef          	jal	46a <putc>
      state = 0;
 7e8:	4981                	li	s3,0
 7ea:	b359                	j	570 <vprintf+0x44>

00000000000007ec <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
 7ec:	715d                	addi	sp,sp,-80
 7ee:	ec06                	sd	ra,24(sp)
 7f0:	e822                	sd	s0,16(sp)
 7f2:	1000                	addi	s0,sp,32
 7f4:	e010                	sd	a2,0(s0)
 7f6:	e414                	sd	a3,8(s0)
 7f8:	e818                	sd	a4,16(s0)
 7fa:	ec1c                	sd	a5,24(s0)
 7fc:	03043023          	sd	a6,32(s0)
 800:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
 804:	8622                	mv	a2,s0
 806:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
 80a:	d23ff0ef          	jal	52c <vprintf>
}
 80e:	60e2                	ld	ra,24(sp)
 810:	6442                	ld	s0,16(sp)
 812:	6161                	addi	sp,sp,80
 814:	8082                	ret

0000000000000816 <printf>:

void
printf(const char *fmt, ...)
{
 816:	711d                	addi	sp,sp,-96
 818:	ec06                	sd	ra,24(sp)
 81a:	e822                	sd	s0,16(sp)
 81c:	1000                	addi	s0,sp,32
 81e:	e40c                	sd	a1,8(s0)
 820:	e810                	sd	a2,16(s0)
 822:	ec14                	sd	a3,24(s0)
 824:	f018                	sd	a4,32(s0)
 826:	f41c                	sd	a5,40(s0)
 828:	03043823          	sd	a6,48(s0)
 82c:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
 830:	00840613          	addi	a2,s0,8
 834:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
 838:	85aa                	mv	a1,a0
 83a:	4505                	li	a0,1
 83c:	cf1ff0ef          	jal	52c <vprintf>
}
 840:	60e2                	ld	ra,24(sp)
 842:	6442                	ld	s0,16(sp)
 844:	6125                	addi	sp,sp,96
 846:	8082                	ret

0000000000000848 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
 848:	1141                	addi	sp,sp,-16
 84a:	e406                	sd	ra,8(sp)
 84c:	e022                	sd	s0,0(sp)
 84e:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
 850:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 854:	00000797          	auipc	a5,0x0
 858:	7ac7b783          	ld	a5,1964(a5) # 1000 <freep>
 85c:	a039                	j	86a <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 85e:	6398                	ld	a4,0(a5)
 860:	00e7e463          	bltu	a5,a4,868 <free+0x20>
 864:	00e6ea63          	bltu	a3,a4,878 <free+0x30>
{
 868:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
 86a:	fed7fae3          	bgeu	a5,a3,85e <free+0x16>
 86e:	6398                	ld	a4,0(a5)
 870:	00e6e463          	bltu	a3,a4,878 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
 874:	fee7eae3          	bltu	a5,a4,868 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
 878:	ff852583          	lw	a1,-8(a0)
 87c:	6390                	ld	a2,0(a5)
 87e:	02059813          	slli	a6,a1,0x20
 882:	01c85713          	srli	a4,a6,0x1c
 886:	9736                	add	a4,a4,a3
 888:	02e60563          	beq	a2,a4,8b2 <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
 88c:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
 890:	4790                	lw	a2,8(a5)
 892:	02061593          	slli	a1,a2,0x20
 896:	01c5d713          	srli	a4,a1,0x1c
 89a:	973e                	add	a4,a4,a5
 89c:	02e68263          	beq	a3,a4,8c0 <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
 8a0:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
 8a2:	00000717          	auipc	a4,0x0
 8a6:	74f73f23          	sd	a5,1886(a4) # 1000 <freep>
}
 8aa:	60a2                	ld	ra,8(sp)
 8ac:	6402                	ld	s0,0(sp)
 8ae:	0141                	addi	sp,sp,16
 8b0:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
 8b2:	4618                	lw	a4,8(a2)
 8b4:	9f2d                	addw	a4,a4,a1
 8b6:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
 8ba:	6398                	ld	a4,0(a5)
 8bc:	6310                	ld	a2,0(a4)
 8be:	b7f9                	j	88c <free+0x44>
    p->s.size += bp->s.size;
 8c0:	ff852703          	lw	a4,-8(a0)
 8c4:	9f31                	addw	a4,a4,a2
 8c6:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
 8c8:	ff053683          	ld	a3,-16(a0)
 8cc:	bfd1                	j	8a0 <free+0x58>

00000000000008ce <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
 8ce:	7139                	addi	sp,sp,-64
 8d0:	fc06                	sd	ra,56(sp)
 8d2:	f822                	sd	s0,48(sp)
 8d4:	f04a                	sd	s2,32(sp)
 8d6:	ec4e                	sd	s3,24(sp)
 8d8:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
 8da:	02051993          	slli	s3,a0,0x20
 8de:	0209d993          	srli	s3,s3,0x20
 8e2:	09bd                	addi	s3,s3,15
 8e4:	0049d993          	srli	s3,s3,0x4
 8e8:	2985                	addiw	s3,s3,1
 8ea:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
 8ec:	00000517          	auipc	a0,0x0
 8f0:	71453503          	ld	a0,1812(a0) # 1000 <freep>
 8f4:	c905                	beqz	a0,924 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 8f6:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 8f8:	4798                	lw	a4,8(a5)
 8fa:	09377663          	bgeu	a4,s3,986 <malloc+0xb8>
 8fe:	f426                	sd	s1,40(sp)
 900:	e852                	sd	s4,16(sp)
 902:	e456                	sd	s5,8(sp)
 904:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
 906:	8a4e                	mv	s4,s3
 908:	6705                	lui	a4,0x1
 90a:	00e9f363          	bgeu	s3,a4,910 <malloc+0x42>
 90e:	6a05                	lui	s4,0x1
 910:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
 914:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
 918:	00000497          	auipc	s1,0x0
 91c:	6e848493          	addi	s1,s1,1768 # 1000 <freep>
  if(p == SBRK_ERROR)
 920:	5afd                	li	s5,-1
 922:	a83d                	j	960 <malloc+0x92>
 924:	f426                	sd	s1,40(sp)
 926:	e852                	sd	s4,16(sp)
 928:	e456                	sd	s5,8(sp)
 92a:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
 92c:	00000797          	auipc	a5,0x0
 930:	6e478793          	addi	a5,a5,1764 # 1010 <base>
 934:	00000717          	auipc	a4,0x0
 938:	6cf73623          	sd	a5,1740(a4) # 1000 <freep>
 93c:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
 93e:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
 942:	b7d1                	j	906 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
 944:	6398                	ld	a4,0(a5)
 946:	e118                	sd	a4,0(a0)
 948:	a899                	j	99e <malloc+0xd0>
  hp->s.size = nu;
 94a:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
 94e:	0541                	addi	a0,a0,16
 950:	ef9ff0ef          	jal	848 <free>
  return freep;
 954:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
 956:	c125                	beqz	a0,9b6 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
 958:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
 95a:	4798                	lw	a4,8(a5)
 95c:	03277163          	bgeu	a4,s2,97e <malloc+0xb0>
    if(p == freep)
 960:	6098                	ld	a4,0(s1)
 962:	853e                	mv	a0,a5
 964:	fef71ae3          	bne	a4,a5,958 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
 968:	8552                	mv	a0,s4
 96a:	9f5ff0ef          	jal	35e <sbrk>
  if(p == SBRK_ERROR)
 96e:	fd551ee3          	bne	a0,s5,94a <malloc+0x7c>
        return 0;
 972:	4501                	li	a0,0
 974:	74a2                	ld	s1,40(sp)
 976:	6a42                	ld	s4,16(sp)
 978:	6aa2                	ld	s5,8(sp)
 97a:	6b02                	ld	s6,0(sp)
 97c:	a03d                	j	9aa <malloc+0xdc>
 97e:	74a2                	ld	s1,40(sp)
 980:	6a42                	ld	s4,16(sp)
 982:	6aa2                	ld	s5,8(sp)
 984:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
 986:	fae90fe3          	beq	s2,a4,944 <malloc+0x76>
        p->s.size -= nunits;
 98a:	4137073b          	subw	a4,a4,s3
 98e:	c798                	sw	a4,8(a5)
        p += p->s.size;
 990:	02071693          	slli	a3,a4,0x20
 994:	01c6d713          	srli	a4,a3,0x1c
 998:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
 99a:	0137a423          	sw	s3,8(a5)
      freep = prevp;
 99e:	00000717          	auipc	a4,0x0
 9a2:	66a73123          	sd	a0,1634(a4) # 1000 <freep>
      return (void*)(p + 1);
 9a6:	01078513          	addi	a0,a5,16
  }
}
 9aa:	70e2                	ld	ra,56(sp)
 9ac:	7442                	ld	s0,48(sp)
 9ae:	7902                	ld	s2,32(sp)
 9b0:	69e2                	ld	s3,24(sp)
 9b2:	6121                	addi	sp,sp,64
 9b4:	8082                	ret
 9b6:	74a2                	ld	s1,40(sp)
 9b8:	6a42                	ld	s4,16(sp)
 9ba:	6aa2                	ld	s5,8(sp)
 9bc:	6b02                	ld	s6,0(sp)
 9be:	b7f5                	j	9aa <malloc+0xdc>
