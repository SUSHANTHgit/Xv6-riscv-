
user/_usertests:     file format elf64-littleriscv


Disassembly of section .text:

0000000000000000 <copyinstr1>:
}

// what if you pass ridiculous string pointers to system calls?
void
copyinstr1(char *s)
{
       0:	711d                	addi	sp,sp,-96
       2:	ec86                	sd	ra,88(sp)
       4:	e8a2                	sd	s0,80(sp)
       6:	e4a6                	sd	s1,72(sp)
       8:	e0ca                	sd	s2,64(sp)
       a:	fc4e                	sd	s3,56(sp)
       c:	f852                	sd	s4,48(sp)
       e:	1080                	addi	s0,sp,96
  uint64 addrs[] = { 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
      10:	00008797          	auipc	a5,0x8
      14:	9a878793          	addi	a5,a5,-1624 # 79b8 <malloc+0x257e>
      18:	638c                	ld	a1,0(a5)
      1a:	6790                	ld	a2,8(a5)
      1c:	6b94                	ld	a3,16(a5)
      1e:	6f98                	ld	a4,24(a5)
      20:	fab43423          	sd	a1,-88(s0)
      24:	fac43823          	sd	a2,-80(s0)
      28:	fad43c23          	sd	a3,-72(s0)
      2c:	fce43023          	sd	a4,-64(s0)
      30:	739c                	ld	a5,32(a5)
      32:	fcf43423          	sd	a5,-56(s0)
                     0xffffffffffffffff };

  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
      36:	fa840493          	addi	s1,s0,-88
      3a:	fd040a13          	addi	s4,s0,-48
    uint64 addr = addrs[ai];

    int fd = open((char *)addr, O_CREATE|O_WRONLY);
      3e:	20100993          	li	s3,513
      42:	0004b903          	ld	s2,0(s1)
      46:	85ce                	mv	a1,s3
      48:	854a                	mv	a0,s2
      4a:	6f5040ef          	jal	4f3e <open>
    if(fd >= 0){
      4e:	00055d63          	bgez	a0,68 <copyinstr1+0x68>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
      52:	04a1                	addi	s1,s1,8
      54:	ff4497e3          	bne	s1,s4,42 <copyinstr1+0x42>
      printf("open(%p) returned %d, not -1\n", (void*)addr, fd);
      exit(1);
    }
  }
}
      58:	60e6                	ld	ra,88(sp)
      5a:	6446                	ld	s0,80(sp)
      5c:	64a6                	ld	s1,72(sp)
      5e:	6906                	ld	s2,64(sp)
      60:	79e2                	ld	s3,56(sp)
      62:	7a42                	ld	s4,48(sp)
      64:	6125                	addi	sp,sp,96
      66:	8082                	ret
      printf("open(%p) returned %d, not -1\n", (void*)addr, fd);
      68:	862a                	mv	a2,a0
      6a:	85ca                	mv	a1,s2
      6c:	00005517          	auipc	a0,0x5
      70:	4c450513          	addi	a0,a0,1220 # 5530 <malloc+0xf6>
      74:	30e050ef          	jal	5382 <printf>
      exit(1);
      78:	4505                	li	a0,1
      7a:	685040ef          	jal	4efe <exit>

000000000000007e <bsstest>:
void
bsstest(char *s)
{
  int i;

  for(i = 0; i < sizeof(uninit); i++){
      7e:	00009797          	auipc	a5,0x9
      82:	51a78793          	addi	a5,a5,1306 # 9598 <uninit>
      86:	0000c697          	auipc	a3,0xc
      8a:	c2268693          	addi	a3,a3,-990 # bca8 <buf>
    if(uninit[i] != '\0'){
      8e:	0007c703          	lbu	a4,0(a5)
      92:	e709                	bnez	a4,9c <bsstest+0x1e>
  for(i = 0; i < sizeof(uninit); i++){
      94:	0785                	addi	a5,a5,1
      96:	fed79ce3          	bne	a5,a3,8e <bsstest+0x10>
      9a:	8082                	ret
{
      9c:	1141                	addi	sp,sp,-16
      9e:	e406                	sd	ra,8(sp)
      a0:	e022                	sd	s0,0(sp)
      a2:	0800                	addi	s0,sp,16
      printf("%s: bss test failed\n", s);
      a4:	85aa                	mv	a1,a0
      a6:	00005517          	auipc	a0,0x5
      aa:	4aa50513          	addi	a0,a0,1194 # 5550 <malloc+0x116>
      ae:	2d4050ef          	jal	5382 <printf>
      exit(1);
      b2:	4505                	li	a0,1
      b4:	64b040ef          	jal	4efe <exit>

00000000000000b8 <opentest>:
{
      b8:	1101                	addi	sp,sp,-32
      ba:	ec06                	sd	ra,24(sp)
      bc:	e822                	sd	s0,16(sp)
      be:	e426                	sd	s1,8(sp)
      c0:	1000                	addi	s0,sp,32
      c2:	84aa                	mv	s1,a0
  fd = open("echo", 0);
      c4:	4581                	li	a1,0
      c6:	00005517          	auipc	a0,0x5
      ca:	4a250513          	addi	a0,a0,1186 # 5568 <malloc+0x12e>
      ce:	671040ef          	jal	4f3e <open>
  if(fd < 0){
      d2:	02054263          	bltz	a0,f6 <opentest+0x3e>
  close(fd);
      d6:	651040ef          	jal	4f26 <close>
  fd = open("doesnotexist", 0);
      da:	4581                	li	a1,0
      dc:	00005517          	auipc	a0,0x5
      e0:	4ac50513          	addi	a0,a0,1196 # 5588 <malloc+0x14e>
      e4:	65b040ef          	jal	4f3e <open>
  if(fd >= 0){
      e8:	02055163          	bgez	a0,10a <opentest+0x52>
}
      ec:	60e2                	ld	ra,24(sp)
      ee:	6442                	ld	s0,16(sp)
      f0:	64a2                	ld	s1,8(sp)
      f2:	6105                	addi	sp,sp,32
      f4:	8082                	ret
    printf("%s: open echo failed!\n", s);
      f6:	85a6                	mv	a1,s1
      f8:	00005517          	auipc	a0,0x5
      fc:	47850513          	addi	a0,a0,1144 # 5570 <malloc+0x136>
     100:	282050ef          	jal	5382 <printf>
    exit(1);
     104:	4505                	li	a0,1
     106:	5f9040ef          	jal	4efe <exit>
    printf("%s: open doesnotexist succeeded!\n", s);
     10a:	85a6                	mv	a1,s1
     10c:	00005517          	auipc	a0,0x5
     110:	48c50513          	addi	a0,a0,1164 # 5598 <malloc+0x15e>
     114:	26e050ef          	jal	5382 <printf>
    exit(1);
     118:	4505                	li	a0,1
     11a:	5e5040ef          	jal	4efe <exit>

000000000000011e <truncate2>:
{
     11e:	7179                	addi	sp,sp,-48
     120:	f406                	sd	ra,40(sp)
     122:	f022                	sd	s0,32(sp)
     124:	ec26                	sd	s1,24(sp)
     126:	e84a                	sd	s2,16(sp)
     128:	e44e                	sd	s3,8(sp)
     12a:	1800                	addi	s0,sp,48
     12c:	89aa                	mv	s3,a0
  unlink("truncfile");
     12e:	00005517          	auipc	a0,0x5
     132:	49250513          	addi	a0,a0,1170 # 55c0 <malloc+0x186>
     136:	619040ef          	jal	4f4e <unlink>
  int fd1 = open("truncfile", O_CREATE|O_TRUNC|O_WRONLY);
     13a:	60100593          	li	a1,1537
     13e:	00005517          	auipc	a0,0x5
     142:	48250513          	addi	a0,a0,1154 # 55c0 <malloc+0x186>
     146:	5f9040ef          	jal	4f3e <open>
     14a:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     14c:	4611                	li	a2,4
     14e:	00005597          	auipc	a1,0x5
     152:	48258593          	addi	a1,a1,1154 # 55d0 <malloc+0x196>
     156:	5c9040ef          	jal	4f1e <write>
  int fd2 = open("truncfile", O_TRUNC|O_WRONLY);
     15a:	40100593          	li	a1,1025
     15e:	00005517          	auipc	a0,0x5
     162:	46250513          	addi	a0,a0,1122 # 55c0 <malloc+0x186>
     166:	5d9040ef          	jal	4f3e <open>
     16a:	892a                	mv	s2,a0
  int n = write(fd1, "x", 1);
     16c:	4605                	li	a2,1
     16e:	00005597          	auipc	a1,0x5
     172:	46a58593          	addi	a1,a1,1130 # 55d8 <malloc+0x19e>
     176:	8526                	mv	a0,s1
     178:	5a7040ef          	jal	4f1e <write>
  if(n != -1){
     17c:	57fd                	li	a5,-1
     17e:	02f51563          	bne	a0,a5,1a8 <truncate2+0x8a>
  unlink("truncfile");
     182:	00005517          	auipc	a0,0x5
     186:	43e50513          	addi	a0,a0,1086 # 55c0 <malloc+0x186>
     18a:	5c5040ef          	jal	4f4e <unlink>
  close(fd1);
     18e:	8526                	mv	a0,s1
     190:	597040ef          	jal	4f26 <close>
  close(fd2);
     194:	854a                	mv	a0,s2
     196:	591040ef          	jal	4f26 <close>
}
     19a:	70a2                	ld	ra,40(sp)
     19c:	7402                	ld	s0,32(sp)
     19e:	64e2                	ld	s1,24(sp)
     1a0:	6942                	ld	s2,16(sp)
     1a2:	69a2                	ld	s3,8(sp)
     1a4:	6145                	addi	sp,sp,48
     1a6:	8082                	ret
    printf("%s: write returned %d, expected -1\n", s, n);
     1a8:	862a                	mv	a2,a0
     1aa:	85ce                	mv	a1,s3
     1ac:	00005517          	auipc	a0,0x5
     1b0:	43450513          	addi	a0,a0,1076 # 55e0 <malloc+0x1a6>
     1b4:	1ce050ef          	jal	5382 <printf>
    exit(1);
     1b8:	4505                	li	a0,1
     1ba:	545040ef          	jal	4efe <exit>

00000000000001be <createtest>:
{
     1be:	7139                	addi	sp,sp,-64
     1c0:	fc06                	sd	ra,56(sp)
     1c2:	f822                	sd	s0,48(sp)
     1c4:	f426                	sd	s1,40(sp)
     1c6:	f04a                	sd	s2,32(sp)
     1c8:	ec4e                	sd	s3,24(sp)
     1ca:	e852                	sd	s4,16(sp)
     1cc:	0080                	addi	s0,sp,64
  name[0] = 'a';
     1ce:	06100793          	li	a5,97
     1d2:	fcf40423          	sb	a5,-56(s0)
  name[2] = '\0';
     1d6:	fc040523          	sb	zero,-54(s0)
     1da:	03000493          	li	s1,48
    fd = open(name, O_CREATE|O_RDWR);
     1de:	fc840a13          	addi	s4,s0,-56
     1e2:	20200993          	li	s3,514
  for(i = 0; i < N; i++){
     1e6:	06400913          	li	s2,100
    name[1] = '0' + i;
     1ea:	fc9404a3          	sb	s1,-55(s0)
    fd = open(name, O_CREATE|O_RDWR);
     1ee:	85ce                	mv	a1,s3
     1f0:	8552                	mv	a0,s4
     1f2:	54d040ef          	jal	4f3e <open>
    close(fd);
     1f6:	531040ef          	jal	4f26 <close>
  for(i = 0; i < N; i++){
     1fa:	2485                	addiw	s1,s1,1
     1fc:	0ff4f493          	zext.b	s1,s1
     200:	ff2495e3          	bne	s1,s2,1ea <createtest+0x2c>
  name[0] = 'a';
     204:	06100793          	li	a5,97
     208:	fcf40423          	sb	a5,-56(s0)
  name[2] = '\0';
     20c:	fc040523          	sb	zero,-54(s0)
     210:	03000493          	li	s1,48
    unlink(name);
     214:	fc840993          	addi	s3,s0,-56
  for(i = 0; i < N; i++){
     218:	06400913          	li	s2,100
    name[1] = '0' + i;
     21c:	fc9404a3          	sb	s1,-55(s0)
    unlink(name);
     220:	854e                	mv	a0,s3
     222:	52d040ef          	jal	4f4e <unlink>
  for(i = 0; i < N; i++){
     226:	2485                	addiw	s1,s1,1
     228:	0ff4f493          	zext.b	s1,s1
     22c:	ff2498e3          	bne	s1,s2,21c <createtest+0x5e>
}
     230:	70e2                	ld	ra,56(sp)
     232:	7442                	ld	s0,48(sp)
     234:	74a2                	ld	s1,40(sp)
     236:	7902                	ld	s2,32(sp)
     238:	69e2                	ld	s3,24(sp)
     23a:	6a42                	ld	s4,16(sp)
     23c:	6121                	addi	sp,sp,64
     23e:	8082                	ret

0000000000000240 <bigwrite>:
{
     240:	711d                	addi	sp,sp,-96
     242:	ec86                	sd	ra,88(sp)
     244:	e8a2                	sd	s0,80(sp)
     246:	e4a6                	sd	s1,72(sp)
     248:	e0ca                	sd	s2,64(sp)
     24a:	fc4e                	sd	s3,56(sp)
     24c:	f852                	sd	s4,48(sp)
     24e:	f456                	sd	s5,40(sp)
     250:	f05a                	sd	s6,32(sp)
     252:	ec5e                	sd	s7,24(sp)
     254:	e862                	sd	s8,16(sp)
     256:	e466                	sd	s9,8(sp)
     258:	1080                	addi	s0,sp,96
     25a:	8caa                	mv	s9,a0
  unlink("bigwrite");
     25c:	00005517          	auipc	a0,0x5
     260:	3ac50513          	addi	a0,a0,940 # 5608 <malloc+0x1ce>
     264:	4eb040ef          	jal	4f4e <unlink>
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     268:	1f300493          	li	s1,499
    fd = open("bigwrite", O_CREATE | O_RDWR);
     26c:	20200b93          	li	s7,514
     270:	00005a17          	auipc	s4,0x5
     274:	398a0a13          	addi	s4,s4,920 # 5608 <malloc+0x1ce>
     278:	4b09                	li	s6,2
      int cc = write(fd, buf, sz);
     27a:	0000c997          	auipc	s3,0xc
     27e:	a2e98993          	addi	s3,s3,-1490 # bca8 <buf>
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     282:	6a8d                	lui	s5,0x3
     284:	1c9a8a93          	addi	s5,s5,457 # 31c9 <subdir+0x4c3>
    fd = open("bigwrite", O_CREATE | O_RDWR);
     288:	85de                	mv	a1,s7
     28a:	8552                	mv	a0,s4
     28c:	4b3040ef          	jal	4f3e <open>
     290:	892a                	mv	s2,a0
    if(fd < 0){
     292:	04054463          	bltz	a0,2da <bigwrite+0x9a>
     296:	8c5a                	mv	s8,s6
      int cc = write(fd, buf, sz);
     298:	8626                	mv	a2,s1
     29a:	85ce                	mv	a1,s3
     29c:	854a                	mv	a0,s2
     29e:	481040ef          	jal	4f1e <write>
      if(cc != sz){
     2a2:	04951663          	bne	a0,s1,2ee <bigwrite+0xae>
    for(i = 0; i < 2; i++){
     2a6:	3c7d                	addiw	s8,s8,-1
     2a8:	fe0c18e3          	bnez	s8,298 <bigwrite+0x58>
    close(fd);
     2ac:	854a                	mv	a0,s2
     2ae:	479040ef          	jal	4f26 <close>
    unlink("bigwrite");
     2b2:	8552                	mv	a0,s4
     2b4:	49b040ef          	jal	4f4e <unlink>
  for(sz = 499; sz < (MAXOPBLOCKS+2)*BSIZE; sz += 471){
     2b8:	1d74849b          	addiw	s1,s1,471
     2bc:	fd5496e3          	bne	s1,s5,288 <bigwrite+0x48>
}
     2c0:	60e6                	ld	ra,88(sp)
     2c2:	6446                	ld	s0,80(sp)
     2c4:	64a6                	ld	s1,72(sp)
     2c6:	6906                	ld	s2,64(sp)
     2c8:	79e2                	ld	s3,56(sp)
     2ca:	7a42                	ld	s4,48(sp)
     2cc:	7aa2                	ld	s5,40(sp)
     2ce:	7b02                	ld	s6,32(sp)
     2d0:	6be2                	ld	s7,24(sp)
     2d2:	6c42                	ld	s8,16(sp)
     2d4:	6ca2                	ld	s9,8(sp)
     2d6:	6125                	addi	sp,sp,96
     2d8:	8082                	ret
      printf("%s: cannot create bigwrite\n", s);
     2da:	85e6                	mv	a1,s9
     2dc:	00005517          	auipc	a0,0x5
     2e0:	33c50513          	addi	a0,a0,828 # 5618 <malloc+0x1de>
     2e4:	09e050ef          	jal	5382 <printf>
      exit(1);
     2e8:	4505                	li	a0,1
     2ea:	415040ef          	jal	4efe <exit>
        printf("%s: write(%d) ret %d\n", s, sz, cc);
     2ee:	86aa                	mv	a3,a0
     2f0:	8626                	mv	a2,s1
     2f2:	85e6                	mv	a1,s9
     2f4:	00005517          	auipc	a0,0x5
     2f8:	34450513          	addi	a0,a0,836 # 5638 <malloc+0x1fe>
     2fc:	086050ef          	jal	5382 <printf>
        exit(1);
     300:	4505                	li	a0,1
     302:	3fd040ef          	jal	4efe <exit>

0000000000000306 <badwrite>:
// file is deleted? if the kernel has this bug, it will panic: balloc:
// out of blocks. assumed_free may need to be raised to be more than
// the number of free blocks. this test takes a long time.
void
badwrite(char *s)
{
     306:	7139                	addi	sp,sp,-64
     308:	fc06                	sd	ra,56(sp)
     30a:	f822                	sd	s0,48(sp)
     30c:	f426                	sd	s1,40(sp)
     30e:	f04a                	sd	s2,32(sp)
     310:	ec4e                	sd	s3,24(sp)
     312:	e852                	sd	s4,16(sp)
     314:	e456                	sd	s5,8(sp)
     316:	e05a                	sd	s6,0(sp)
     318:	0080                	addi	s0,sp,64
  int assumed_free = 600;
  
  unlink("junk");
     31a:	00005517          	auipc	a0,0x5
     31e:	33650513          	addi	a0,a0,822 # 5650 <malloc+0x216>
     322:	42d040ef          	jal	4f4e <unlink>
     326:	25800913          	li	s2,600
  for(int i = 0; i < assumed_free; i++){
    int fd = open("junk", O_CREATE|O_WRONLY);
     32a:	20100a93          	li	s5,513
     32e:	00005997          	auipc	s3,0x5
     332:	32298993          	addi	s3,s3,802 # 5650 <malloc+0x216>
    if(fd < 0){
      printf("open junk failed\n");
      exit(1);
    }
    write(fd, (char*)0xffffffffffL, 1);
     336:	4b05                	li	s6,1
     338:	5a7d                	li	s4,-1
     33a:	018a5a13          	srli	s4,s4,0x18
    int fd = open("junk", O_CREATE|O_WRONLY);
     33e:	85d6                	mv	a1,s5
     340:	854e                	mv	a0,s3
     342:	3fd040ef          	jal	4f3e <open>
     346:	84aa                	mv	s1,a0
    if(fd < 0){
     348:	04054d63          	bltz	a0,3a2 <badwrite+0x9c>
    write(fd, (char*)0xffffffffffL, 1);
     34c:	865a                	mv	a2,s6
     34e:	85d2                	mv	a1,s4
     350:	3cf040ef          	jal	4f1e <write>
    close(fd);
     354:	8526                	mv	a0,s1
     356:	3d1040ef          	jal	4f26 <close>
    unlink("junk");
     35a:	854e                	mv	a0,s3
     35c:	3f3040ef          	jal	4f4e <unlink>
  for(int i = 0; i < assumed_free; i++){
     360:	397d                	addiw	s2,s2,-1
     362:	fc091ee3          	bnez	s2,33e <badwrite+0x38>
  }

  int fd = open("junk", O_CREATE|O_WRONLY);
     366:	20100593          	li	a1,513
     36a:	00005517          	auipc	a0,0x5
     36e:	2e650513          	addi	a0,a0,742 # 5650 <malloc+0x216>
     372:	3cd040ef          	jal	4f3e <open>
     376:	84aa                	mv	s1,a0
  if(fd < 0){
     378:	02054e63          	bltz	a0,3b4 <badwrite+0xae>
    printf("open junk failed\n");
    exit(1);
  }
  if(write(fd, "x", 1) != 1){
     37c:	4605                	li	a2,1
     37e:	00005597          	auipc	a1,0x5
     382:	25a58593          	addi	a1,a1,602 # 55d8 <malloc+0x19e>
     386:	399040ef          	jal	4f1e <write>
     38a:	4785                	li	a5,1
     38c:	02f50d63          	beq	a0,a5,3c6 <badwrite+0xc0>
    printf("write failed\n");
     390:	00005517          	auipc	a0,0x5
     394:	2e050513          	addi	a0,a0,736 # 5670 <malloc+0x236>
     398:	7eb040ef          	jal	5382 <printf>
    exit(1);
     39c:	4505                	li	a0,1
     39e:	361040ef          	jal	4efe <exit>
      printf("open junk failed\n");
     3a2:	00005517          	auipc	a0,0x5
     3a6:	2b650513          	addi	a0,a0,694 # 5658 <malloc+0x21e>
     3aa:	7d9040ef          	jal	5382 <printf>
      exit(1);
     3ae:	4505                	li	a0,1
     3b0:	34f040ef          	jal	4efe <exit>
    printf("open junk failed\n");
     3b4:	00005517          	auipc	a0,0x5
     3b8:	2a450513          	addi	a0,a0,676 # 5658 <malloc+0x21e>
     3bc:	7c7040ef          	jal	5382 <printf>
    exit(1);
     3c0:	4505                	li	a0,1
     3c2:	33d040ef          	jal	4efe <exit>
  }
  close(fd);
     3c6:	8526                	mv	a0,s1
     3c8:	35f040ef          	jal	4f26 <close>
  unlink("junk");
     3cc:	00005517          	auipc	a0,0x5
     3d0:	28450513          	addi	a0,a0,644 # 5650 <malloc+0x216>
     3d4:	37b040ef          	jal	4f4e <unlink>

  exit(0);
     3d8:	4501                	li	a0,0
     3da:	325040ef          	jal	4efe <exit>

00000000000003de <outofinodes>:
  }
}

void
outofinodes(char *s)
{
     3de:	711d                	addi	sp,sp,-96
     3e0:	ec86                	sd	ra,88(sp)
     3e2:	e8a2                	sd	s0,80(sp)
     3e4:	e4a6                	sd	s1,72(sp)
     3e6:	e0ca                	sd	s2,64(sp)
     3e8:	fc4e                	sd	s3,56(sp)
     3ea:	f852                	sd	s4,48(sp)
     3ec:	f456                	sd	s5,40(sp)
     3ee:	1080                	addi	s0,sp,96
  int nzz = 32*32;
  for(int i = 0; i < nzz; i++){
     3f0:	4481                	li	s1,0
    char name[32];
    name[0] = 'z';
     3f2:	07a00993          	li	s3,122
    name[1] = 'z';
    name[2] = '0' + (i / 32);
    name[3] = '0' + (i % 32);
    name[4] = '\0';
    unlink(name);
     3f6:	fa040913          	addi	s2,s0,-96
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
     3fa:	60200a13          	li	s4,1538
  for(int i = 0; i < nzz; i++){
     3fe:	40000a93          	li	s5,1024
    name[0] = 'z';
     402:	fb340023          	sb	s3,-96(s0)
    name[1] = 'z';
     406:	fb3400a3          	sb	s3,-95(s0)
    name[2] = '0' + (i / 32);
     40a:	41f4d71b          	sraiw	a4,s1,0x1f
     40e:	01b7571b          	srliw	a4,a4,0x1b
     412:	009707bb          	addw	a5,a4,s1
     416:	4057d69b          	sraiw	a3,a5,0x5
     41a:	0306869b          	addiw	a3,a3,48
     41e:	fad40123          	sb	a3,-94(s0)
    name[3] = '0' + (i % 32);
     422:	8bfd                	andi	a5,a5,31
     424:	9f99                	subw	a5,a5,a4
     426:	0307879b          	addiw	a5,a5,48
     42a:	faf401a3          	sb	a5,-93(s0)
    name[4] = '\0';
     42e:	fa040223          	sb	zero,-92(s0)
    unlink(name);
     432:	854a                	mv	a0,s2
     434:	31b040ef          	jal	4f4e <unlink>
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
     438:	85d2                	mv	a1,s4
     43a:	854a                	mv	a0,s2
     43c:	303040ef          	jal	4f3e <open>
    if(fd < 0){
     440:	00054763          	bltz	a0,44e <outofinodes+0x70>
      // failure is eventually expected.
      break;
    }
    close(fd);
     444:	2e3040ef          	jal	4f26 <close>
  for(int i = 0; i < nzz; i++){
     448:	2485                	addiw	s1,s1,1
     44a:	fb549ce3          	bne	s1,s5,402 <outofinodes+0x24>
     44e:	4481                	li	s1,0
  }

  for(int i = 0; i < nzz; i++){
    char name[32];
    name[0] = 'z';
     450:	07a00913          	li	s2,122
    name[1] = 'z';
    name[2] = '0' + (i / 32);
    name[3] = '0' + (i % 32);
    name[4] = '\0';
    unlink(name);
     454:	fa040a13          	addi	s4,s0,-96
  for(int i = 0; i < nzz; i++){
     458:	40000993          	li	s3,1024
    name[0] = 'z';
     45c:	fb240023          	sb	s2,-96(s0)
    name[1] = 'z';
     460:	fb2400a3          	sb	s2,-95(s0)
    name[2] = '0' + (i / 32);
     464:	41f4d71b          	sraiw	a4,s1,0x1f
     468:	01b7571b          	srliw	a4,a4,0x1b
     46c:	009707bb          	addw	a5,a4,s1
     470:	4057d69b          	sraiw	a3,a5,0x5
     474:	0306869b          	addiw	a3,a3,48
     478:	fad40123          	sb	a3,-94(s0)
    name[3] = '0' + (i % 32);
     47c:	8bfd                	andi	a5,a5,31
     47e:	9f99                	subw	a5,a5,a4
     480:	0307879b          	addiw	a5,a5,48
     484:	faf401a3          	sb	a5,-93(s0)
    name[4] = '\0';
     488:	fa040223          	sb	zero,-92(s0)
    unlink(name);
     48c:	8552                	mv	a0,s4
     48e:	2c1040ef          	jal	4f4e <unlink>
  for(int i = 0; i < nzz; i++){
     492:	2485                	addiw	s1,s1,1
     494:	fd3494e3          	bne	s1,s3,45c <outofinodes+0x7e>
  }
}
     498:	60e6                	ld	ra,88(sp)
     49a:	6446                	ld	s0,80(sp)
     49c:	64a6                	ld	s1,72(sp)
     49e:	6906                	ld	s2,64(sp)
     4a0:	79e2                	ld	s3,56(sp)
     4a2:	7a42                	ld	s4,48(sp)
     4a4:	7aa2                	ld	s5,40(sp)
     4a6:	6125                	addi	sp,sp,96
     4a8:	8082                	ret

00000000000004aa <copyin>:
{
     4aa:	7175                	addi	sp,sp,-144
     4ac:	e506                	sd	ra,136(sp)
     4ae:	e122                	sd	s0,128(sp)
     4b0:	fca6                	sd	s1,120(sp)
     4b2:	f8ca                	sd	s2,112(sp)
     4b4:	f4ce                	sd	s3,104(sp)
     4b6:	f0d2                	sd	s4,96(sp)
     4b8:	ecd6                	sd	s5,88(sp)
     4ba:	e8da                	sd	s6,80(sp)
     4bc:	e4de                	sd	s7,72(sp)
     4be:	e0e2                	sd	s8,64(sp)
     4c0:	fc66                	sd	s9,56(sp)
     4c2:	0900                	addi	s0,sp,144
  uint64 addrs[] = { 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
     4c4:	00007797          	auipc	a5,0x7
     4c8:	4f478793          	addi	a5,a5,1268 # 79b8 <malloc+0x257e>
     4cc:	638c                	ld	a1,0(a5)
     4ce:	6790                	ld	a2,8(a5)
     4d0:	6b94                	ld	a3,16(a5)
     4d2:	6f98                	ld	a4,24(a5)
     4d4:	f6b43c23          	sd	a1,-136(s0)
     4d8:	f8c43023          	sd	a2,-128(s0)
     4dc:	f8d43423          	sd	a3,-120(s0)
     4e0:	f8e43823          	sd	a4,-112(s0)
     4e4:	739c                	ld	a5,32(a5)
     4e6:	f8f43c23          	sd	a5,-104(s0)
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     4ea:	f7840913          	addi	s2,s0,-136
     4ee:	fa040c93          	addi	s9,s0,-96
    int fd = open("copyin1", O_CREATE|O_WRONLY);
     4f2:	20100b13          	li	s6,513
     4f6:	00005a97          	auipc	s5,0x5
     4fa:	18aa8a93          	addi	s5,s5,394 # 5680 <malloc+0x246>
    int n = write(fd, (void*)addr, 8192);
     4fe:	6a09                	lui	s4,0x2
    n = write(1, (char*)addr, 8192);
     500:	4c05                	li	s8,1
    if(pipe(fds) < 0){
     502:	f7040b93          	addi	s7,s0,-144
    uint64 addr = addrs[ai];
     506:	00093983          	ld	s3,0(s2)
    int fd = open("copyin1", O_CREATE|O_WRONLY);
     50a:	85da                	mv	a1,s6
     50c:	8556                	mv	a0,s5
     50e:	231040ef          	jal	4f3e <open>
     512:	84aa                	mv	s1,a0
    if(fd < 0){
     514:	06054a63          	bltz	a0,588 <copyin+0xde>
    int n = write(fd, (void*)addr, 8192);
     518:	8652                	mv	a2,s4
     51a:	85ce                	mv	a1,s3
     51c:	203040ef          	jal	4f1e <write>
    if(n >= 0){
     520:	06055d63          	bgez	a0,59a <copyin+0xf0>
    close(fd);
     524:	8526                	mv	a0,s1
     526:	201040ef          	jal	4f26 <close>
    unlink("copyin1");
     52a:	8556                	mv	a0,s5
     52c:	223040ef          	jal	4f4e <unlink>
    n = write(1, (char*)addr, 8192);
     530:	8652                	mv	a2,s4
     532:	85ce                	mv	a1,s3
     534:	8562                	mv	a0,s8
     536:	1e9040ef          	jal	4f1e <write>
    if(n > 0){
     53a:	06a04b63          	bgtz	a0,5b0 <copyin+0x106>
    if(pipe(fds) < 0){
     53e:	855e                	mv	a0,s7
     540:	1cf040ef          	jal	4f0e <pipe>
     544:	08054163          	bltz	a0,5c6 <copyin+0x11c>
    n = write(fds[1], (char*)addr, 8192);
     548:	8652                	mv	a2,s4
     54a:	85ce                	mv	a1,s3
     54c:	f7442503          	lw	a0,-140(s0)
     550:	1cf040ef          	jal	4f1e <write>
    if(n > 0){
     554:	08a04263          	bgtz	a0,5d8 <copyin+0x12e>
    close(fds[0]);
     558:	f7042503          	lw	a0,-144(s0)
     55c:	1cb040ef          	jal	4f26 <close>
    close(fds[1]);
     560:	f7442503          	lw	a0,-140(s0)
     564:	1c3040ef          	jal	4f26 <close>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     568:	0921                	addi	s2,s2,8
     56a:	f9991ee3          	bne	s2,s9,506 <copyin+0x5c>
}
     56e:	60aa                	ld	ra,136(sp)
     570:	640a                	ld	s0,128(sp)
     572:	74e6                	ld	s1,120(sp)
     574:	7946                	ld	s2,112(sp)
     576:	79a6                	ld	s3,104(sp)
     578:	7a06                	ld	s4,96(sp)
     57a:	6ae6                	ld	s5,88(sp)
     57c:	6b46                	ld	s6,80(sp)
     57e:	6ba6                	ld	s7,72(sp)
     580:	6c06                	ld	s8,64(sp)
     582:	7ce2                	ld	s9,56(sp)
     584:	6149                	addi	sp,sp,144
     586:	8082                	ret
      printf("open(copyin1) failed\n");
     588:	00005517          	auipc	a0,0x5
     58c:	10050513          	addi	a0,a0,256 # 5688 <malloc+0x24e>
     590:	5f3040ef          	jal	5382 <printf>
      exit(1);
     594:	4505                	li	a0,1
     596:	169040ef          	jal	4efe <exit>
      printf("write(fd, %p, 8192) returned %d, not -1\n", (void*)addr, n);
     59a:	862a                	mv	a2,a0
     59c:	85ce                	mv	a1,s3
     59e:	00005517          	auipc	a0,0x5
     5a2:	10250513          	addi	a0,a0,258 # 56a0 <malloc+0x266>
     5a6:	5dd040ef          	jal	5382 <printf>
      exit(1);
     5aa:	4505                	li	a0,1
     5ac:	153040ef          	jal	4efe <exit>
      printf("write(1, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     5b0:	862a                	mv	a2,a0
     5b2:	85ce                	mv	a1,s3
     5b4:	00005517          	auipc	a0,0x5
     5b8:	11c50513          	addi	a0,a0,284 # 56d0 <malloc+0x296>
     5bc:	5c7040ef          	jal	5382 <printf>
      exit(1);
     5c0:	4505                	li	a0,1
     5c2:	13d040ef          	jal	4efe <exit>
      printf("pipe() failed\n");
     5c6:	00005517          	auipc	a0,0x5
     5ca:	13a50513          	addi	a0,a0,314 # 5700 <malloc+0x2c6>
     5ce:	5b5040ef          	jal	5382 <printf>
      exit(1);
     5d2:	4505                	li	a0,1
     5d4:	12b040ef          	jal	4efe <exit>
      printf("write(pipe, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     5d8:	862a                	mv	a2,a0
     5da:	85ce                	mv	a1,s3
     5dc:	00005517          	auipc	a0,0x5
     5e0:	13450513          	addi	a0,a0,308 # 5710 <malloc+0x2d6>
     5e4:	59f040ef          	jal	5382 <printf>
      exit(1);
     5e8:	4505                	li	a0,1
     5ea:	115040ef          	jal	4efe <exit>

00000000000005ee <copyout>:
{
     5ee:	7135                	addi	sp,sp,-160
     5f0:	ed06                	sd	ra,152(sp)
     5f2:	e922                	sd	s0,144(sp)
     5f4:	e526                	sd	s1,136(sp)
     5f6:	e14a                	sd	s2,128(sp)
     5f8:	fcce                	sd	s3,120(sp)
     5fa:	f8d2                	sd	s4,112(sp)
     5fc:	f4d6                	sd	s5,104(sp)
     5fe:	f0da                	sd	s6,96(sp)
     600:	ecde                	sd	s7,88(sp)
     602:	e8e2                	sd	s8,80(sp)
     604:	e4e6                	sd	s9,72(sp)
     606:	1100                	addi	s0,sp,160
  uint64 addrs[] = { 0LL, 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
     608:	00007797          	auipc	a5,0x7
     60c:	3b078793          	addi	a5,a5,944 # 79b8 <malloc+0x257e>
     610:	7788                	ld	a0,40(a5)
     612:	7b8c                	ld	a1,48(a5)
     614:	7f90                	ld	a2,56(a5)
     616:	63b4                	ld	a3,64(a5)
     618:	67b8                	ld	a4,72(a5)
     61a:	f6a43823          	sd	a0,-144(s0)
     61e:	f6b43c23          	sd	a1,-136(s0)
     622:	f8c43023          	sd	a2,-128(s0)
     626:	f8d43423          	sd	a3,-120(s0)
     62a:	f8e43823          	sd	a4,-112(s0)
     62e:	6bbc                	ld	a5,80(a5)
     630:	f8f43c23          	sd	a5,-104(s0)
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     634:	f7040913          	addi	s2,s0,-144
     638:	fa040c93          	addi	s9,s0,-96
    int fd = open("README", 0);
     63c:	00005b17          	auipc	s6,0x5
     640:	104b0b13          	addi	s6,s6,260 # 5740 <malloc+0x306>
    int n = read(fd, (void*)addr, 8192);
     644:	6a89                	lui	s5,0x2
    if(pipe(fds) < 0){
     646:	f6840c13          	addi	s8,s0,-152
    n = write(fds[1], "x", 1);
     64a:	4a05                	li	s4,1
     64c:	00005b97          	auipc	s7,0x5
     650:	f8cb8b93          	addi	s7,s7,-116 # 55d8 <malloc+0x19e>
    uint64 addr = addrs[ai];
     654:	00093983          	ld	s3,0(s2)
    int fd = open("README", 0);
     658:	4581                	li	a1,0
     65a:	855a                	mv	a0,s6
     65c:	0e3040ef          	jal	4f3e <open>
     660:	84aa                	mv	s1,a0
    if(fd < 0){
     662:	06054863          	bltz	a0,6d2 <copyout+0xe4>
    int n = read(fd, (void*)addr, 8192);
     666:	8656                	mv	a2,s5
     668:	85ce                	mv	a1,s3
     66a:	0ad040ef          	jal	4f16 <read>
    if(n > 0){
     66e:	06a04b63          	bgtz	a0,6e4 <copyout+0xf6>
    close(fd);
     672:	8526                	mv	a0,s1
     674:	0b3040ef          	jal	4f26 <close>
    if(pipe(fds) < 0){
     678:	8562                	mv	a0,s8
     67a:	095040ef          	jal	4f0e <pipe>
     67e:	06054e63          	bltz	a0,6fa <copyout+0x10c>
    n = write(fds[1], "x", 1);
     682:	8652                	mv	a2,s4
     684:	85de                	mv	a1,s7
     686:	f6c42503          	lw	a0,-148(s0)
     68a:	095040ef          	jal	4f1e <write>
    if(n != 1){
     68e:	07451f63          	bne	a0,s4,70c <copyout+0x11e>
    n = read(fds[0], (void*)addr, 8192);
     692:	8656                	mv	a2,s5
     694:	85ce                	mv	a1,s3
     696:	f6842503          	lw	a0,-152(s0)
     69a:	07d040ef          	jal	4f16 <read>
    if(n > 0){
     69e:	08a04063          	bgtz	a0,71e <copyout+0x130>
    close(fds[0]);
     6a2:	f6842503          	lw	a0,-152(s0)
     6a6:	081040ef          	jal	4f26 <close>
    close(fds[1]);
     6aa:	f6c42503          	lw	a0,-148(s0)
     6ae:	079040ef          	jal	4f26 <close>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
     6b2:	0921                	addi	s2,s2,8
     6b4:	fb9910e3          	bne	s2,s9,654 <copyout+0x66>
}
     6b8:	60ea                	ld	ra,152(sp)
     6ba:	644a                	ld	s0,144(sp)
     6bc:	64aa                	ld	s1,136(sp)
     6be:	690a                	ld	s2,128(sp)
     6c0:	79e6                	ld	s3,120(sp)
     6c2:	7a46                	ld	s4,112(sp)
     6c4:	7aa6                	ld	s5,104(sp)
     6c6:	7b06                	ld	s6,96(sp)
     6c8:	6be6                	ld	s7,88(sp)
     6ca:	6c46                	ld	s8,80(sp)
     6cc:	6ca6                	ld	s9,72(sp)
     6ce:	610d                	addi	sp,sp,160
     6d0:	8082                	ret
      printf("open(README) failed\n");
     6d2:	00005517          	auipc	a0,0x5
     6d6:	07650513          	addi	a0,a0,118 # 5748 <malloc+0x30e>
     6da:	4a9040ef          	jal	5382 <printf>
      exit(1);
     6de:	4505                	li	a0,1
     6e0:	01f040ef          	jal	4efe <exit>
      printf("read(fd, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     6e4:	862a                	mv	a2,a0
     6e6:	85ce                	mv	a1,s3
     6e8:	00005517          	auipc	a0,0x5
     6ec:	07850513          	addi	a0,a0,120 # 5760 <malloc+0x326>
     6f0:	493040ef          	jal	5382 <printf>
      exit(1);
     6f4:	4505                	li	a0,1
     6f6:	009040ef          	jal	4efe <exit>
      printf("pipe() failed\n");
     6fa:	00005517          	auipc	a0,0x5
     6fe:	00650513          	addi	a0,a0,6 # 5700 <malloc+0x2c6>
     702:	481040ef          	jal	5382 <printf>
      exit(1);
     706:	4505                	li	a0,1
     708:	7f6040ef          	jal	4efe <exit>
      printf("pipe write failed\n");
     70c:	00005517          	auipc	a0,0x5
     710:	08450513          	addi	a0,a0,132 # 5790 <malloc+0x356>
     714:	46f040ef          	jal	5382 <printf>
      exit(1);
     718:	4505                	li	a0,1
     71a:	7e4040ef          	jal	4efe <exit>
      printf("read(pipe, %p, 8192) returned %d, not -1 or 0\n", (void*)addr, n);
     71e:	862a                	mv	a2,a0
     720:	85ce                	mv	a1,s3
     722:	00005517          	auipc	a0,0x5
     726:	08650513          	addi	a0,a0,134 # 57a8 <malloc+0x36e>
     72a:	459040ef          	jal	5382 <printf>
      exit(1);
     72e:	4505                	li	a0,1
     730:	7ce040ef          	jal	4efe <exit>

0000000000000734 <truncate1>:
{
     734:	711d                	addi	sp,sp,-96
     736:	ec86                	sd	ra,88(sp)
     738:	e8a2                	sd	s0,80(sp)
     73a:	e4a6                	sd	s1,72(sp)
     73c:	e0ca                	sd	s2,64(sp)
     73e:	fc4e                	sd	s3,56(sp)
     740:	f852                	sd	s4,48(sp)
     742:	f456                	sd	s5,40(sp)
     744:	1080                	addi	s0,sp,96
     746:	8a2a                	mv	s4,a0
  unlink("truncfile");
     748:	00005517          	auipc	a0,0x5
     74c:	e7850513          	addi	a0,a0,-392 # 55c0 <malloc+0x186>
     750:	7fe040ef          	jal	4f4e <unlink>
  int fd1 = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
     754:	60100593          	li	a1,1537
     758:	00005517          	auipc	a0,0x5
     75c:	e6850513          	addi	a0,a0,-408 # 55c0 <malloc+0x186>
     760:	7de040ef          	jal	4f3e <open>
     764:	84aa                	mv	s1,a0
  write(fd1, "abcd", 4);
     766:	4611                	li	a2,4
     768:	00005597          	auipc	a1,0x5
     76c:	e6858593          	addi	a1,a1,-408 # 55d0 <malloc+0x196>
     770:	7ae040ef          	jal	4f1e <write>
  close(fd1);
     774:	8526                	mv	a0,s1
     776:	7b0040ef          	jal	4f26 <close>
  int fd2 = open("truncfile", O_RDONLY);
     77a:	4581                	li	a1,0
     77c:	00005517          	auipc	a0,0x5
     780:	e4450513          	addi	a0,a0,-444 # 55c0 <malloc+0x186>
     784:	7ba040ef          	jal	4f3e <open>
     788:	84aa                	mv	s1,a0
  int n = read(fd2, buf, sizeof(buf));
     78a:	02000613          	li	a2,32
     78e:	fa040593          	addi	a1,s0,-96
     792:	784040ef          	jal	4f16 <read>
  if(n != 4){
     796:	4791                	li	a5,4
     798:	0af51863          	bne	a0,a5,848 <truncate1+0x114>
  fd1 = open("truncfile", O_WRONLY|O_TRUNC);
     79c:	40100593          	li	a1,1025
     7a0:	00005517          	auipc	a0,0x5
     7a4:	e2050513          	addi	a0,a0,-480 # 55c0 <malloc+0x186>
     7a8:	796040ef          	jal	4f3e <open>
     7ac:	89aa                	mv	s3,a0
  int fd3 = open("truncfile", O_RDONLY);
     7ae:	4581                	li	a1,0
     7b0:	00005517          	auipc	a0,0x5
     7b4:	e1050513          	addi	a0,a0,-496 # 55c0 <malloc+0x186>
     7b8:	786040ef          	jal	4f3e <open>
     7bc:	892a                	mv	s2,a0
  n = read(fd3, buf, sizeof(buf));
     7be:	02000613          	li	a2,32
     7c2:	fa040593          	addi	a1,s0,-96
     7c6:	750040ef          	jal	4f16 <read>
     7ca:	8aaa                	mv	s5,a0
  if(n != 0){
     7cc:	e949                	bnez	a0,85e <truncate1+0x12a>
  n = read(fd2, buf, sizeof(buf));
     7ce:	02000613          	li	a2,32
     7d2:	fa040593          	addi	a1,s0,-96
     7d6:	8526                	mv	a0,s1
     7d8:	73e040ef          	jal	4f16 <read>
     7dc:	8aaa                	mv	s5,a0
  if(n != 0){
     7de:	e155                	bnez	a0,882 <truncate1+0x14e>
  write(fd1, "abcdef", 6);
     7e0:	4619                	li	a2,6
     7e2:	00005597          	auipc	a1,0x5
     7e6:	05658593          	addi	a1,a1,86 # 5838 <malloc+0x3fe>
     7ea:	854e                	mv	a0,s3
     7ec:	732040ef          	jal	4f1e <write>
  n = read(fd3, buf, sizeof(buf));
     7f0:	02000613          	li	a2,32
     7f4:	fa040593          	addi	a1,s0,-96
     7f8:	854a                	mv	a0,s2
     7fa:	71c040ef          	jal	4f16 <read>
  if(n != 6){
     7fe:	4799                	li	a5,6
     800:	0af51363          	bne	a0,a5,8a6 <truncate1+0x172>
  n = read(fd2, buf, sizeof(buf));
     804:	02000613          	li	a2,32
     808:	fa040593          	addi	a1,s0,-96
     80c:	8526                	mv	a0,s1
     80e:	708040ef          	jal	4f16 <read>
  if(n != 2){
     812:	4789                	li	a5,2
     814:	0af51463          	bne	a0,a5,8bc <truncate1+0x188>
  unlink("truncfile");
     818:	00005517          	auipc	a0,0x5
     81c:	da850513          	addi	a0,a0,-600 # 55c0 <malloc+0x186>
     820:	72e040ef          	jal	4f4e <unlink>
  close(fd1);
     824:	854e                	mv	a0,s3
     826:	700040ef          	jal	4f26 <close>
  close(fd2);
     82a:	8526                	mv	a0,s1
     82c:	6fa040ef          	jal	4f26 <close>
  close(fd3);
     830:	854a                	mv	a0,s2
     832:	6f4040ef          	jal	4f26 <close>
}
     836:	60e6                	ld	ra,88(sp)
     838:	6446                	ld	s0,80(sp)
     83a:	64a6                	ld	s1,72(sp)
     83c:	6906                	ld	s2,64(sp)
     83e:	79e2                	ld	s3,56(sp)
     840:	7a42                	ld	s4,48(sp)
     842:	7aa2                	ld	s5,40(sp)
     844:	6125                	addi	sp,sp,96
     846:	8082                	ret
    printf("%s: read %d bytes, wanted 4\n", s, n);
     848:	862a                	mv	a2,a0
     84a:	85d2                	mv	a1,s4
     84c:	00005517          	auipc	a0,0x5
     850:	f8c50513          	addi	a0,a0,-116 # 57d8 <malloc+0x39e>
     854:	32f040ef          	jal	5382 <printf>
    exit(1);
     858:	4505                	li	a0,1
     85a:	6a4040ef          	jal	4efe <exit>
    printf("aaa fd3=%d\n", fd3);
     85e:	85ca                	mv	a1,s2
     860:	00005517          	auipc	a0,0x5
     864:	f9850513          	addi	a0,a0,-104 # 57f8 <malloc+0x3be>
     868:	31b040ef          	jal	5382 <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     86c:	8656                	mv	a2,s5
     86e:	85d2                	mv	a1,s4
     870:	00005517          	auipc	a0,0x5
     874:	f9850513          	addi	a0,a0,-104 # 5808 <malloc+0x3ce>
     878:	30b040ef          	jal	5382 <printf>
    exit(1);
     87c:	4505                	li	a0,1
     87e:	680040ef          	jal	4efe <exit>
    printf("bbb fd2=%d\n", fd2);
     882:	85a6                	mv	a1,s1
     884:	00005517          	auipc	a0,0x5
     888:	fa450513          	addi	a0,a0,-92 # 5828 <malloc+0x3ee>
     88c:	2f7040ef          	jal	5382 <printf>
    printf("%s: read %d bytes, wanted 0\n", s, n);
     890:	8656                	mv	a2,s5
     892:	85d2                	mv	a1,s4
     894:	00005517          	auipc	a0,0x5
     898:	f7450513          	addi	a0,a0,-140 # 5808 <malloc+0x3ce>
     89c:	2e7040ef          	jal	5382 <printf>
    exit(1);
     8a0:	4505                	li	a0,1
     8a2:	65c040ef          	jal	4efe <exit>
    printf("%s: read %d bytes, wanted 6\n", s, n);
     8a6:	862a                	mv	a2,a0
     8a8:	85d2                	mv	a1,s4
     8aa:	00005517          	auipc	a0,0x5
     8ae:	f9650513          	addi	a0,a0,-106 # 5840 <malloc+0x406>
     8b2:	2d1040ef          	jal	5382 <printf>
    exit(1);
     8b6:	4505                	li	a0,1
     8b8:	646040ef          	jal	4efe <exit>
    printf("%s: read %d bytes, wanted 2\n", s, n);
     8bc:	862a                	mv	a2,a0
     8be:	85d2                	mv	a1,s4
     8c0:	00005517          	auipc	a0,0x5
     8c4:	fa050513          	addi	a0,a0,-96 # 5860 <malloc+0x426>
     8c8:	2bb040ef          	jal	5382 <printf>
    exit(1);
     8cc:	4505                	li	a0,1
     8ce:	630040ef          	jal	4efe <exit>

00000000000008d2 <writetest>:
{
     8d2:	715d                	addi	sp,sp,-80
     8d4:	e486                	sd	ra,72(sp)
     8d6:	e0a2                	sd	s0,64(sp)
     8d8:	fc26                	sd	s1,56(sp)
     8da:	f84a                	sd	s2,48(sp)
     8dc:	f44e                	sd	s3,40(sp)
     8de:	f052                	sd	s4,32(sp)
     8e0:	ec56                	sd	s5,24(sp)
     8e2:	e85a                	sd	s6,16(sp)
     8e4:	e45e                	sd	s7,8(sp)
     8e6:	0880                	addi	s0,sp,80
     8e8:	8baa                	mv	s7,a0
  fd = open("small", O_CREATE|O_RDWR);
     8ea:	20200593          	li	a1,514
     8ee:	00005517          	auipc	a0,0x5
     8f2:	f9250513          	addi	a0,a0,-110 # 5880 <malloc+0x446>
     8f6:	648040ef          	jal	4f3e <open>
  if(fd < 0){
     8fa:	08054f63          	bltz	a0,998 <writetest+0xc6>
     8fe:	89aa                	mv	s3,a0
     900:	4901                	li	s2,0
    if(write(fd, "aaaaaaaaaa", SZ) != SZ){
     902:	44a9                	li	s1,10
     904:	00005a17          	auipc	s4,0x5
     908:	fa4a0a13          	addi	s4,s4,-92 # 58a8 <malloc+0x46e>
    if(write(fd, "bbbbbbbbbb", SZ) != SZ){
     90c:	00005b17          	auipc	s6,0x5
     910:	fd4b0b13          	addi	s6,s6,-44 # 58e0 <malloc+0x4a6>
  for(i = 0; i < N; i++){
     914:	06400a93          	li	s5,100
    if(write(fd, "aaaaaaaaaa", SZ) != SZ){
     918:	8626                	mv	a2,s1
     91a:	85d2                	mv	a1,s4
     91c:	854e                	mv	a0,s3
     91e:	600040ef          	jal	4f1e <write>
     922:	08951563          	bne	a0,s1,9ac <writetest+0xda>
    if(write(fd, "bbbbbbbbbb", SZ) != SZ){
     926:	8626                	mv	a2,s1
     928:	85da                	mv	a1,s6
     92a:	854e                	mv	a0,s3
     92c:	5f2040ef          	jal	4f1e <write>
     930:	08951963          	bne	a0,s1,9c2 <writetest+0xf0>
  for(i = 0; i < N; i++){
     934:	2905                	addiw	s2,s2,1
     936:	ff5911e3          	bne	s2,s5,918 <writetest+0x46>
  close(fd);
     93a:	854e                	mv	a0,s3
     93c:	5ea040ef          	jal	4f26 <close>
  fd = open("small", O_RDONLY);
     940:	4581                	li	a1,0
     942:	00005517          	auipc	a0,0x5
     946:	f3e50513          	addi	a0,a0,-194 # 5880 <malloc+0x446>
     94a:	5f4040ef          	jal	4f3e <open>
     94e:	84aa                	mv	s1,a0
  if(fd < 0){
     950:	08054463          	bltz	a0,9d8 <writetest+0x106>
  i = read(fd, buf, N*SZ*2);
     954:	7d000613          	li	a2,2000
     958:	0000b597          	auipc	a1,0xb
     95c:	35058593          	addi	a1,a1,848 # bca8 <buf>
     960:	5b6040ef          	jal	4f16 <read>
  if(i != N*SZ*2){
     964:	7d000793          	li	a5,2000
     968:	08f51263          	bne	a0,a5,9ec <writetest+0x11a>
  close(fd);
     96c:	8526                	mv	a0,s1
     96e:	5b8040ef          	jal	4f26 <close>
  if(unlink("small") < 0){
     972:	00005517          	auipc	a0,0x5
     976:	f0e50513          	addi	a0,a0,-242 # 5880 <malloc+0x446>
     97a:	5d4040ef          	jal	4f4e <unlink>
     97e:	08054163          	bltz	a0,a00 <writetest+0x12e>
}
     982:	60a6                	ld	ra,72(sp)
     984:	6406                	ld	s0,64(sp)
     986:	74e2                	ld	s1,56(sp)
     988:	7942                	ld	s2,48(sp)
     98a:	79a2                	ld	s3,40(sp)
     98c:	7a02                	ld	s4,32(sp)
     98e:	6ae2                	ld	s5,24(sp)
     990:	6b42                	ld	s6,16(sp)
     992:	6ba2                	ld	s7,8(sp)
     994:	6161                	addi	sp,sp,80
     996:	8082                	ret
    printf("%s: error: creat small failed!\n", s);
     998:	85de                	mv	a1,s7
     99a:	00005517          	auipc	a0,0x5
     99e:	eee50513          	addi	a0,a0,-274 # 5888 <malloc+0x44e>
     9a2:	1e1040ef          	jal	5382 <printf>
    exit(1);
     9a6:	4505                	li	a0,1
     9a8:	556040ef          	jal	4efe <exit>
      printf("%s: error: write aa %d new file failed\n", s, i);
     9ac:	864a                	mv	a2,s2
     9ae:	85de                	mv	a1,s7
     9b0:	00005517          	auipc	a0,0x5
     9b4:	f0850513          	addi	a0,a0,-248 # 58b8 <malloc+0x47e>
     9b8:	1cb040ef          	jal	5382 <printf>
      exit(1);
     9bc:	4505                	li	a0,1
     9be:	540040ef          	jal	4efe <exit>
      printf("%s: error: write bb %d new file failed\n", s, i);
     9c2:	864a                	mv	a2,s2
     9c4:	85de                	mv	a1,s7
     9c6:	00005517          	auipc	a0,0x5
     9ca:	f2a50513          	addi	a0,a0,-214 # 58f0 <malloc+0x4b6>
     9ce:	1b5040ef          	jal	5382 <printf>
      exit(1);
     9d2:	4505                	li	a0,1
     9d4:	52a040ef          	jal	4efe <exit>
    printf("%s: error: open small failed!\n", s);
     9d8:	85de                	mv	a1,s7
     9da:	00005517          	auipc	a0,0x5
     9de:	f3e50513          	addi	a0,a0,-194 # 5918 <malloc+0x4de>
     9e2:	1a1040ef          	jal	5382 <printf>
    exit(1);
     9e6:	4505                	li	a0,1
     9e8:	516040ef          	jal	4efe <exit>
    printf("%s: read failed\n", s);
     9ec:	85de                	mv	a1,s7
     9ee:	00005517          	auipc	a0,0x5
     9f2:	f4a50513          	addi	a0,a0,-182 # 5938 <malloc+0x4fe>
     9f6:	18d040ef          	jal	5382 <printf>
    exit(1);
     9fa:	4505                	li	a0,1
     9fc:	502040ef          	jal	4efe <exit>
    printf("%s: unlink small failed\n", s);
     a00:	85de                	mv	a1,s7
     a02:	00005517          	auipc	a0,0x5
     a06:	f4e50513          	addi	a0,a0,-178 # 5950 <malloc+0x516>
     a0a:	179040ef          	jal	5382 <printf>
    exit(1);
     a0e:	4505                	li	a0,1
     a10:	4ee040ef          	jal	4efe <exit>

0000000000000a14 <writebig>:
{
     a14:	7139                	addi	sp,sp,-64
     a16:	fc06                	sd	ra,56(sp)
     a18:	f822                	sd	s0,48(sp)
     a1a:	f426                	sd	s1,40(sp)
     a1c:	f04a                	sd	s2,32(sp)
     a1e:	ec4e                	sd	s3,24(sp)
     a20:	e852                	sd	s4,16(sp)
     a22:	e456                	sd	s5,8(sp)
     a24:	e05a                	sd	s6,0(sp)
     a26:	0080                	addi	s0,sp,64
     a28:	8b2a                	mv	s6,a0
  fd = open("big", O_CREATE|O_RDWR);
     a2a:	20200593          	li	a1,514
     a2e:	00005517          	auipc	a0,0x5
     a32:	f4250513          	addi	a0,a0,-190 # 5970 <malloc+0x536>
     a36:	508040ef          	jal	4f3e <open>
  if(fd < 0){
     a3a:	06054b63          	bltz	a0,ab0 <writebig+0x9c>
     a3e:	8a2a                	mv	s4,a0
     a40:	4481                	li	s1,0
    ((int*)buf)[0] = i;
     a42:	0000b997          	auipc	s3,0xb
     a46:	26698993          	addi	s3,s3,614 # bca8 <buf>
    if(write(fd, buf, BSIZE) != BSIZE){
     a4a:	40000913          	li	s2,1024
  for(i = 0; i < MAXFILE; i++){
     a4e:	6ac1                	lui	s5,0x10
     a50:	10ba8a93          	addi	s5,s5,267 # 1010b <base+0x1463>
    ((int*)buf)[0] = i;
     a54:	0099a023          	sw	s1,0(s3)
    if(write(fd, buf, BSIZE) != BSIZE){
     a58:	864a                	mv	a2,s2
     a5a:	85ce                	mv	a1,s3
     a5c:	8552                	mv	a0,s4
     a5e:	4c0040ef          	jal	4f1e <write>
     a62:	07251163          	bne	a0,s2,ac4 <writebig+0xb0>
  for(i = 0; i < MAXFILE; i++){
     a66:	2485                	addiw	s1,s1,1
     a68:	ff5496e3          	bne	s1,s5,a54 <writebig+0x40>
  close(fd);
     a6c:	8552                	mv	a0,s4
     a6e:	4b8040ef          	jal	4f26 <close>
  fd = open("big", O_RDONLY);
     a72:	4581                	li	a1,0
     a74:	00005517          	auipc	a0,0x5
     a78:	efc50513          	addi	a0,a0,-260 # 5970 <malloc+0x536>
     a7c:	4c2040ef          	jal	4f3e <open>
     a80:	8a2a                	mv	s4,a0
  n = 0;
     a82:	4481                	li	s1,0
    i = read(fd, buf, BSIZE);
     a84:	40000993          	li	s3,1024
     a88:	0000b917          	auipc	s2,0xb
     a8c:	22090913          	addi	s2,s2,544 # bca8 <buf>
  if(fd < 0){
     a90:	04054563          	bltz	a0,ada <writebig+0xc6>
    i = read(fd, buf, BSIZE);
     a94:	864e                	mv	a2,s3
     a96:	85ca                	mv	a1,s2
     a98:	8552                	mv	a0,s4
     a9a:	47c040ef          	jal	4f16 <read>
    if(i == 0){
     a9e:	c921                	beqz	a0,aee <writebig+0xda>
    } else if(i != BSIZE){
     aa0:	09351c63          	bne	a0,s3,b38 <writebig+0x124>
    if(((int*)buf)[0] != n){
     aa4:	00092683          	lw	a3,0(s2)
     aa8:	0a969363          	bne	a3,s1,b4e <writebig+0x13a>
    n++;
     aac:	2485                	addiw	s1,s1,1
    i = read(fd, buf, BSIZE);
     aae:	b7dd                	j	a94 <writebig+0x80>
    printf("%s: error: creat big failed!\n", s);
     ab0:	85da                	mv	a1,s6
     ab2:	00005517          	auipc	a0,0x5
     ab6:	ec650513          	addi	a0,a0,-314 # 5978 <malloc+0x53e>
     aba:	0c9040ef          	jal	5382 <printf>
    exit(1);
     abe:	4505                	li	a0,1
     ac0:	43e040ef          	jal	4efe <exit>
      printf("%s: error: write big file failed i=%d\n", s, i);
     ac4:	8626                	mv	a2,s1
     ac6:	85da                	mv	a1,s6
     ac8:	00005517          	auipc	a0,0x5
     acc:	ed050513          	addi	a0,a0,-304 # 5998 <malloc+0x55e>
     ad0:	0b3040ef          	jal	5382 <printf>
      exit(1);
     ad4:	4505                	li	a0,1
     ad6:	428040ef          	jal	4efe <exit>
    printf("%s: error: open big failed!\n", s);
     ada:	85da                	mv	a1,s6
     adc:	00005517          	auipc	a0,0x5
     ae0:	ee450513          	addi	a0,a0,-284 # 59c0 <malloc+0x586>
     ae4:	09f040ef          	jal	5382 <printf>
    exit(1);
     ae8:	4505                	li	a0,1
     aea:	414040ef          	jal	4efe <exit>
      if(n != MAXFILE){
     aee:	67c1                	lui	a5,0x10
     af0:	10b78793          	addi	a5,a5,267 # 1010b <base+0x1463>
     af4:	02f49763          	bne	s1,a5,b22 <writebig+0x10e>
  close(fd);
     af8:	8552                	mv	a0,s4
     afa:	42c040ef          	jal	4f26 <close>
  if(unlink("big") < 0){
     afe:	00005517          	auipc	a0,0x5
     b02:	e7250513          	addi	a0,a0,-398 # 5970 <malloc+0x536>
     b06:	448040ef          	jal	4f4e <unlink>
     b0a:	04054d63          	bltz	a0,b64 <writebig+0x150>
}
     b0e:	70e2                	ld	ra,56(sp)
     b10:	7442                	ld	s0,48(sp)
     b12:	74a2                	ld	s1,40(sp)
     b14:	7902                	ld	s2,32(sp)
     b16:	69e2                	ld	s3,24(sp)
     b18:	6a42                	ld	s4,16(sp)
     b1a:	6aa2                	ld	s5,8(sp)
     b1c:	6b02                	ld	s6,0(sp)
     b1e:	6121                	addi	sp,sp,64
     b20:	8082                	ret
        printf("%s: read only %d blocks from big", s, n);
     b22:	8626                	mv	a2,s1
     b24:	85da                	mv	a1,s6
     b26:	00005517          	auipc	a0,0x5
     b2a:	eba50513          	addi	a0,a0,-326 # 59e0 <malloc+0x5a6>
     b2e:	055040ef          	jal	5382 <printf>
        exit(1);
     b32:	4505                	li	a0,1
     b34:	3ca040ef          	jal	4efe <exit>
      printf("%s: read failed %d\n", s, i);
     b38:	862a                	mv	a2,a0
     b3a:	85da                	mv	a1,s6
     b3c:	00005517          	auipc	a0,0x5
     b40:	ecc50513          	addi	a0,a0,-308 # 5a08 <malloc+0x5ce>
     b44:	03f040ef          	jal	5382 <printf>
      exit(1);
     b48:	4505                	li	a0,1
     b4a:	3b4040ef          	jal	4efe <exit>
      printf("%s: read content of block %d is %d\n", s,
     b4e:	8626                	mv	a2,s1
     b50:	85da                	mv	a1,s6
     b52:	00005517          	auipc	a0,0x5
     b56:	ece50513          	addi	a0,a0,-306 # 5a20 <malloc+0x5e6>
     b5a:	029040ef          	jal	5382 <printf>
      exit(1);
     b5e:	4505                	li	a0,1
     b60:	39e040ef          	jal	4efe <exit>
    printf("%s: unlink big failed\n", s);
     b64:	85da                	mv	a1,s6
     b66:	00005517          	auipc	a0,0x5
     b6a:	ee250513          	addi	a0,a0,-286 # 5a48 <malloc+0x60e>
     b6e:	015040ef          	jal	5382 <printf>
    exit(1);
     b72:	4505                	li	a0,1
     b74:	38a040ef          	jal	4efe <exit>

0000000000000b78 <unlinkread>:
{
     b78:	7179                	addi	sp,sp,-48
     b7a:	f406                	sd	ra,40(sp)
     b7c:	f022                	sd	s0,32(sp)
     b7e:	ec26                	sd	s1,24(sp)
     b80:	e84a                	sd	s2,16(sp)
     b82:	e44e                	sd	s3,8(sp)
     b84:	1800                	addi	s0,sp,48
     b86:	89aa                	mv	s3,a0
  fd = open("unlinkread", O_CREATE | O_RDWR);
     b88:	20200593          	li	a1,514
     b8c:	00005517          	auipc	a0,0x5
     b90:	ed450513          	addi	a0,a0,-300 # 5a60 <malloc+0x626>
     b94:	3aa040ef          	jal	4f3e <open>
  if(fd < 0){
     b98:	0a054f63          	bltz	a0,c56 <unlinkread+0xde>
     b9c:	84aa                	mv	s1,a0
  write(fd, "hello", SZ);
     b9e:	4615                	li	a2,5
     ba0:	00005597          	auipc	a1,0x5
     ba4:	ef058593          	addi	a1,a1,-272 # 5a90 <malloc+0x656>
     ba8:	376040ef          	jal	4f1e <write>
  close(fd);
     bac:	8526                	mv	a0,s1
     bae:	378040ef          	jal	4f26 <close>
  fd = open("unlinkread", O_RDWR);
     bb2:	4589                	li	a1,2
     bb4:	00005517          	auipc	a0,0x5
     bb8:	eac50513          	addi	a0,a0,-340 # 5a60 <malloc+0x626>
     bbc:	382040ef          	jal	4f3e <open>
     bc0:	84aa                	mv	s1,a0
  if(fd < 0){
     bc2:	0a054463          	bltz	a0,c6a <unlinkread+0xf2>
  if(unlink("unlinkread") != 0){
     bc6:	00005517          	auipc	a0,0x5
     bca:	e9a50513          	addi	a0,a0,-358 # 5a60 <malloc+0x626>
     bce:	380040ef          	jal	4f4e <unlink>
     bd2:	e555                	bnez	a0,c7e <unlinkread+0x106>
  fd1 = open("unlinkread", O_CREATE | O_RDWR);
     bd4:	20200593          	li	a1,514
     bd8:	00005517          	auipc	a0,0x5
     bdc:	e8850513          	addi	a0,a0,-376 # 5a60 <malloc+0x626>
     be0:	35e040ef          	jal	4f3e <open>
     be4:	892a                	mv	s2,a0
  write(fd1, "yyy", 3);
     be6:	460d                	li	a2,3
     be8:	00005597          	auipc	a1,0x5
     bec:	ef058593          	addi	a1,a1,-272 # 5ad8 <malloc+0x69e>
     bf0:	32e040ef          	jal	4f1e <write>
  close(fd1);
     bf4:	854a                	mv	a0,s2
     bf6:	330040ef          	jal	4f26 <close>
  if(read(fd, buf, sizeof(buf)) != SZ){
     bfa:	660d                	lui	a2,0x3
     bfc:	0000b597          	auipc	a1,0xb
     c00:	0ac58593          	addi	a1,a1,172 # bca8 <buf>
     c04:	8526                	mv	a0,s1
     c06:	310040ef          	jal	4f16 <read>
     c0a:	4795                	li	a5,5
     c0c:	08f51363          	bne	a0,a5,c92 <unlinkread+0x11a>
  if(buf[0] != 'h'){
     c10:	0000b717          	auipc	a4,0xb
     c14:	09874703          	lbu	a4,152(a4) # bca8 <buf>
     c18:	06800793          	li	a5,104
     c1c:	08f71563          	bne	a4,a5,ca6 <unlinkread+0x12e>
  if(write(fd, buf, 10) != 10){
     c20:	4629                	li	a2,10
     c22:	0000b597          	auipc	a1,0xb
     c26:	08658593          	addi	a1,a1,134 # bca8 <buf>
     c2a:	8526                	mv	a0,s1
     c2c:	2f2040ef          	jal	4f1e <write>
     c30:	47a9                	li	a5,10
     c32:	08f51463          	bne	a0,a5,cba <unlinkread+0x142>
  close(fd);
     c36:	8526                	mv	a0,s1
     c38:	2ee040ef          	jal	4f26 <close>
  unlink("unlinkread");
     c3c:	00005517          	auipc	a0,0x5
     c40:	e2450513          	addi	a0,a0,-476 # 5a60 <malloc+0x626>
     c44:	30a040ef          	jal	4f4e <unlink>
}
     c48:	70a2                	ld	ra,40(sp)
     c4a:	7402                	ld	s0,32(sp)
     c4c:	64e2                	ld	s1,24(sp)
     c4e:	6942                	ld	s2,16(sp)
     c50:	69a2                	ld	s3,8(sp)
     c52:	6145                	addi	sp,sp,48
     c54:	8082                	ret
    printf("%s: create unlinkread failed\n", s);
     c56:	85ce                	mv	a1,s3
     c58:	00005517          	auipc	a0,0x5
     c5c:	e1850513          	addi	a0,a0,-488 # 5a70 <malloc+0x636>
     c60:	722040ef          	jal	5382 <printf>
    exit(1);
     c64:	4505                	li	a0,1
     c66:	298040ef          	jal	4efe <exit>
    printf("%s: open unlinkread failed\n", s);
     c6a:	85ce                	mv	a1,s3
     c6c:	00005517          	auipc	a0,0x5
     c70:	e2c50513          	addi	a0,a0,-468 # 5a98 <malloc+0x65e>
     c74:	70e040ef          	jal	5382 <printf>
    exit(1);
     c78:	4505                	li	a0,1
     c7a:	284040ef          	jal	4efe <exit>
    printf("%s: unlink unlinkread failed\n", s);
     c7e:	85ce                	mv	a1,s3
     c80:	00005517          	auipc	a0,0x5
     c84:	e3850513          	addi	a0,a0,-456 # 5ab8 <malloc+0x67e>
     c88:	6fa040ef          	jal	5382 <printf>
    exit(1);
     c8c:	4505                	li	a0,1
     c8e:	270040ef          	jal	4efe <exit>
    printf("%s: unlinkread read failed", s);
     c92:	85ce                	mv	a1,s3
     c94:	00005517          	auipc	a0,0x5
     c98:	e4c50513          	addi	a0,a0,-436 # 5ae0 <malloc+0x6a6>
     c9c:	6e6040ef          	jal	5382 <printf>
    exit(1);
     ca0:	4505                	li	a0,1
     ca2:	25c040ef          	jal	4efe <exit>
    printf("%s: unlinkread wrong data\n", s);
     ca6:	85ce                	mv	a1,s3
     ca8:	00005517          	auipc	a0,0x5
     cac:	e5850513          	addi	a0,a0,-424 # 5b00 <malloc+0x6c6>
     cb0:	6d2040ef          	jal	5382 <printf>
    exit(1);
     cb4:	4505                	li	a0,1
     cb6:	248040ef          	jal	4efe <exit>
    printf("%s: unlinkread write failed\n", s);
     cba:	85ce                	mv	a1,s3
     cbc:	00005517          	auipc	a0,0x5
     cc0:	e6450513          	addi	a0,a0,-412 # 5b20 <malloc+0x6e6>
     cc4:	6be040ef          	jal	5382 <printf>
    exit(1);
     cc8:	4505                	li	a0,1
     cca:	234040ef          	jal	4efe <exit>

0000000000000cce <linktest>:
{
     cce:	1101                	addi	sp,sp,-32
     cd0:	ec06                	sd	ra,24(sp)
     cd2:	e822                	sd	s0,16(sp)
     cd4:	e426                	sd	s1,8(sp)
     cd6:	e04a                	sd	s2,0(sp)
     cd8:	1000                	addi	s0,sp,32
     cda:	892a                	mv	s2,a0
  unlink("lf1");
     cdc:	00005517          	auipc	a0,0x5
     ce0:	e6450513          	addi	a0,a0,-412 # 5b40 <malloc+0x706>
     ce4:	26a040ef          	jal	4f4e <unlink>
  unlink("lf2");
     ce8:	00005517          	auipc	a0,0x5
     cec:	e6050513          	addi	a0,a0,-416 # 5b48 <malloc+0x70e>
     cf0:	25e040ef          	jal	4f4e <unlink>
  fd = open("lf1", O_CREATE|O_RDWR);
     cf4:	20200593          	li	a1,514
     cf8:	00005517          	auipc	a0,0x5
     cfc:	e4850513          	addi	a0,a0,-440 # 5b40 <malloc+0x706>
     d00:	23e040ef          	jal	4f3e <open>
  if(fd < 0){
     d04:	0c054f63          	bltz	a0,de2 <linktest+0x114>
     d08:	84aa                	mv	s1,a0
  if(write(fd, "hello", SZ) != SZ){
     d0a:	4615                	li	a2,5
     d0c:	00005597          	auipc	a1,0x5
     d10:	d8458593          	addi	a1,a1,-636 # 5a90 <malloc+0x656>
     d14:	20a040ef          	jal	4f1e <write>
     d18:	4795                	li	a5,5
     d1a:	0cf51e63          	bne	a0,a5,df6 <linktest+0x128>
  close(fd);
     d1e:	8526                	mv	a0,s1
     d20:	206040ef          	jal	4f26 <close>
  if(link("lf1", "lf2") < 0){
     d24:	00005597          	auipc	a1,0x5
     d28:	e2458593          	addi	a1,a1,-476 # 5b48 <malloc+0x70e>
     d2c:	00005517          	auipc	a0,0x5
     d30:	e1450513          	addi	a0,a0,-492 # 5b40 <malloc+0x706>
     d34:	22a040ef          	jal	4f5e <link>
     d38:	0c054963          	bltz	a0,e0a <linktest+0x13c>
  unlink("lf1");
     d3c:	00005517          	auipc	a0,0x5
     d40:	e0450513          	addi	a0,a0,-508 # 5b40 <malloc+0x706>
     d44:	20a040ef          	jal	4f4e <unlink>
  if(open("lf1", 0) >= 0){
     d48:	4581                	li	a1,0
     d4a:	00005517          	auipc	a0,0x5
     d4e:	df650513          	addi	a0,a0,-522 # 5b40 <malloc+0x706>
     d52:	1ec040ef          	jal	4f3e <open>
     d56:	0c055463          	bgez	a0,e1e <linktest+0x150>
  fd = open("lf2", 0);
     d5a:	4581                	li	a1,0
     d5c:	00005517          	auipc	a0,0x5
     d60:	dec50513          	addi	a0,a0,-532 # 5b48 <malloc+0x70e>
     d64:	1da040ef          	jal	4f3e <open>
     d68:	84aa                	mv	s1,a0
  if(fd < 0){
     d6a:	0c054463          	bltz	a0,e32 <linktest+0x164>
  if(read(fd, buf, sizeof(buf)) != SZ){
     d6e:	660d                	lui	a2,0x3
     d70:	0000b597          	auipc	a1,0xb
     d74:	f3858593          	addi	a1,a1,-200 # bca8 <buf>
     d78:	19e040ef          	jal	4f16 <read>
     d7c:	4795                	li	a5,5
     d7e:	0cf51463          	bne	a0,a5,e46 <linktest+0x178>
  close(fd);
     d82:	8526                	mv	a0,s1
     d84:	1a2040ef          	jal	4f26 <close>
  if(link("lf2", "lf2") >= 0){
     d88:	00005597          	auipc	a1,0x5
     d8c:	dc058593          	addi	a1,a1,-576 # 5b48 <malloc+0x70e>
     d90:	852e                	mv	a0,a1
     d92:	1cc040ef          	jal	4f5e <link>
     d96:	0c055263          	bgez	a0,e5a <linktest+0x18c>
  unlink("lf2");
     d9a:	00005517          	auipc	a0,0x5
     d9e:	dae50513          	addi	a0,a0,-594 # 5b48 <malloc+0x70e>
     da2:	1ac040ef          	jal	4f4e <unlink>
  if(link("lf2", "lf1") >= 0){
     da6:	00005597          	auipc	a1,0x5
     daa:	d9a58593          	addi	a1,a1,-614 # 5b40 <malloc+0x706>
     dae:	00005517          	auipc	a0,0x5
     db2:	d9a50513          	addi	a0,a0,-614 # 5b48 <malloc+0x70e>
     db6:	1a8040ef          	jal	4f5e <link>
     dba:	0a055a63          	bgez	a0,e6e <linktest+0x1a0>
  if(link(".", "lf1") >= 0){
     dbe:	00005597          	auipc	a1,0x5
     dc2:	d8258593          	addi	a1,a1,-638 # 5b40 <malloc+0x706>
     dc6:	00005517          	auipc	a0,0x5
     dca:	e8a50513          	addi	a0,a0,-374 # 5c50 <malloc+0x816>
     dce:	190040ef          	jal	4f5e <link>
     dd2:	0a055863          	bgez	a0,e82 <linktest+0x1b4>
}
     dd6:	60e2                	ld	ra,24(sp)
     dd8:	6442                	ld	s0,16(sp)
     dda:	64a2                	ld	s1,8(sp)
     ddc:	6902                	ld	s2,0(sp)
     dde:	6105                	addi	sp,sp,32
     de0:	8082                	ret
    printf("%s: create lf1 failed\n", s);
     de2:	85ca                	mv	a1,s2
     de4:	00005517          	auipc	a0,0x5
     de8:	d6c50513          	addi	a0,a0,-660 # 5b50 <malloc+0x716>
     dec:	596040ef          	jal	5382 <printf>
    exit(1);
     df0:	4505                	li	a0,1
     df2:	10c040ef          	jal	4efe <exit>
    printf("%s: write lf1 failed\n", s);
     df6:	85ca                	mv	a1,s2
     df8:	00005517          	auipc	a0,0x5
     dfc:	d7050513          	addi	a0,a0,-656 # 5b68 <malloc+0x72e>
     e00:	582040ef          	jal	5382 <printf>
    exit(1);
     e04:	4505                	li	a0,1
     e06:	0f8040ef          	jal	4efe <exit>
    printf("%s: link lf1 lf2 failed\n", s);
     e0a:	85ca                	mv	a1,s2
     e0c:	00005517          	auipc	a0,0x5
     e10:	d7450513          	addi	a0,a0,-652 # 5b80 <malloc+0x746>
     e14:	56e040ef          	jal	5382 <printf>
    exit(1);
     e18:	4505                	li	a0,1
     e1a:	0e4040ef          	jal	4efe <exit>
    printf("%s: unlinked lf1 but it is still there!\n", s);
     e1e:	85ca                	mv	a1,s2
     e20:	00005517          	auipc	a0,0x5
     e24:	d8050513          	addi	a0,a0,-640 # 5ba0 <malloc+0x766>
     e28:	55a040ef          	jal	5382 <printf>
    exit(1);
     e2c:	4505                	li	a0,1
     e2e:	0d0040ef          	jal	4efe <exit>
    printf("%s: open lf2 failed\n", s);
     e32:	85ca                	mv	a1,s2
     e34:	00005517          	auipc	a0,0x5
     e38:	d9c50513          	addi	a0,a0,-612 # 5bd0 <malloc+0x796>
     e3c:	546040ef          	jal	5382 <printf>
    exit(1);
     e40:	4505                	li	a0,1
     e42:	0bc040ef          	jal	4efe <exit>
    printf("%s: read lf2 failed\n", s);
     e46:	85ca                	mv	a1,s2
     e48:	00005517          	auipc	a0,0x5
     e4c:	da050513          	addi	a0,a0,-608 # 5be8 <malloc+0x7ae>
     e50:	532040ef          	jal	5382 <printf>
    exit(1);
     e54:	4505                	li	a0,1
     e56:	0a8040ef          	jal	4efe <exit>
    printf("%s: link lf2 lf2 succeeded! oops\n", s);
     e5a:	85ca                	mv	a1,s2
     e5c:	00005517          	auipc	a0,0x5
     e60:	da450513          	addi	a0,a0,-604 # 5c00 <malloc+0x7c6>
     e64:	51e040ef          	jal	5382 <printf>
    exit(1);
     e68:	4505                	li	a0,1
     e6a:	094040ef          	jal	4efe <exit>
    printf("%s: link non-existent succeeded! oops\n", s);
     e6e:	85ca                	mv	a1,s2
     e70:	00005517          	auipc	a0,0x5
     e74:	db850513          	addi	a0,a0,-584 # 5c28 <malloc+0x7ee>
     e78:	50a040ef          	jal	5382 <printf>
    exit(1);
     e7c:	4505                	li	a0,1
     e7e:	080040ef          	jal	4efe <exit>
    printf("%s: link . lf1 succeeded! oops\n", s);
     e82:	85ca                	mv	a1,s2
     e84:	00005517          	auipc	a0,0x5
     e88:	dd450513          	addi	a0,a0,-556 # 5c58 <malloc+0x81e>
     e8c:	4f6040ef          	jal	5382 <printf>
    exit(1);
     e90:	4505                	li	a0,1
     e92:	06c040ef          	jal	4efe <exit>

0000000000000e96 <validatetest>:
{
     e96:	7139                	addi	sp,sp,-64
     e98:	fc06                	sd	ra,56(sp)
     e9a:	f822                	sd	s0,48(sp)
     e9c:	f426                	sd	s1,40(sp)
     e9e:	f04a                	sd	s2,32(sp)
     ea0:	ec4e                	sd	s3,24(sp)
     ea2:	e852                	sd	s4,16(sp)
     ea4:	e456                	sd	s5,8(sp)
     ea6:	e05a                	sd	s6,0(sp)
     ea8:	0080                	addi	s0,sp,64
     eaa:	8b2a                	mv	s6,a0
  for(p = 0; p <= (uint)hi; p += PGSIZE){
     eac:	4481                	li	s1,0
    if(link("nosuchfile", (char*)p) != -1){
     eae:	00005997          	auipc	s3,0x5
     eb2:	dca98993          	addi	s3,s3,-566 # 5c78 <malloc+0x83e>
     eb6:	597d                	li	s2,-1
  for(p = 0; p <= (uint)hi; p += PGSIZE){
     eb8:	6a85                	lui	s5,0x1
     eba:	00114a37          	lui	s4,0x114
    if(link("nosuchfile", (char*)p) != -1){
     ebe:	85a6                	mv	a1,s1
     ec0:	854e                	mv	a0,s3
     ec2:	09c040ef          	jal	4f5e <link>
     ec6:	01251f63          	bne	a0,s2,ee4 <validatetest+0x4e>
  for(p = 0; p <= (uint)hi; p += PGSIZE){
     eca:	94d6                	add	s1,s1,s5
     ecc:	ff4499e3          	bne	s1,s4,ebe <validatetest+0x28>
}
     ed0:	70e2                	ld	ra,56(sp)
     ed2:	7442                	ld	s0,48(sp)
     ed4:	74a2                	ld	s1,40(sp)
     ed6:	7902                	ld	s2,32(sp)
     ed8:	69e2                	ld	s3,24(sp)
     eda:	6a42                	ld	s4,16(sp)
     edc:	6aa2                	ld	s5,8(sp)
     ede:	6b02                	ld	s6,0(sp)
     ee0:	6121                	addi	sp,sp,64
     ee2:	8082                	ret
      printf("%s: link should not succeed\n", s);
     ee4:	85da                	mv	a1,s6
     ee6:	00005517          	auipc	a0,0x5
     eea:	da250513          	addi	a0,a0,-606 # 5c88 <malloc+0x84e>
     eee:	494040ef          	jal	5382 <printf>
      exit(1);
     ef2:	4505                	li	a0,1
     ef4:	00a040ef          	jal	4efe <exit>

0000000000000ef8 <bigdir>:
{
     ef8:	711d                	addi	sp,sp,-96
     efa:	ec86                	sd	ra,88(sp)
     efc:	e8a2                	sd	s0,80(sp)
     efe:	e4a6                	sd	s1,72(sp)
     f00:	e0ca                	sd	s2,64(sp)
     f02:	fc4e                	sd	s3,56(sp)
     f04:	f852                	sd	s4,48(sp)
     f06:	f456                	sd	s5,40(sp)
     f08:	f05a                	sd	s6,32(sp)
     f0a:	ec5e                	sd	s7,24(sp)
     f0c:	1080                	addi	s0,sp,96
     f0e:	8baa                	mv	s7,a0
  unlink("bd");
     f10:	00005517          	auipc	a0,0x5
     f14:	d9850513          	addi	a0,a0,-616 # 5ca8 <malloc+0x86e>
     f18:	036040ef          	jal	4f4e <unlink>
  fd = open("bd", O_CREATE);
     f1c:	20000593          	li	a1,512
     f20:	00005517          	auipc	a0,0x5
     f24:	d8850513          	addi	a0,a0,-632 # 5ca8 <malloc+0x86e>
     f28:	016040ef          	jal	4f3e <open>
  if(fd < 0){
     f2c:	0c054463          	bltz	a0,ff4 <bigdir+0xfc>
  close(fd);
     f30:	7f7030ef          	jal	4f26 <close>
  for(i = 0; i < N; i++){
     f34:	4901                	li	s2,0
    name[0] = 'x';
     f36:	07800a93          	li	s5,120
    if(link("bd", name) != 0){
     f3a:	fa040a13          	addi	s4,s0,-96
     f3e:	00005997          	auipc	s3,0x5
     f42:	d6a98993          	addi	s3,s3,-662 # 5ca8 <malloc+0x86e>
  for(i = 0; i < N; i++){
     f46:	1f400b13          	li	s6,500
    name[0] = 'x';
     f4a:	fb540023          	sb	s5,-96(s0)
    name[1] = '0' + (i / 64);
     f4e:	41f9571b          	sraiw	a4,s2,0x1f
     f52:	01a7571b          	srliw	a4,a4,0x1a
     f56:	012707bb          	addw	a5,a4,s2
     f5a:	4067d69b          	sraiw	a3,a5,0x6
     f5e:	0306869b          	addiw	a3,a3,48
     f62:	fad400a3          	sb	a3,-95(s0)
    name[2] = '0' + (i % 64);
     f66:	03f7f793          	andi	a5,a5,63
     f6a:	9f99                	subw	a5,a5,a4
     f6c:	0307879b          	addiw	a5,a5,48
     f70:	faf40123          	sb	a5,-94(s0)
    name[3] = '\0';
     f74:	fa0401a3          	sb	zero,-93(s0)
    if(link("bd", name) != 0){
     f78:	85d2                	mv	a1,s4
     f7a:	854e                	mv	a0,s3
     f7c:	7e3030ef          	jal	4f5e <link>
     f80:	84aa                	mv	s1,a0
     f82:	e159                	bnez	a0,1008 <bigdir+0x110>
  for(i = 0; i < N; i++){
     f84:	2905                	addiw	s2,s2,1
     f86:	fd6912e3          	bne	s2,s6,f4a <bigdir+0x52>
  unlink("bd");
     f8a:	00005517          	auipc	a0,0x5
     f8e:	d1e50513          	addi	a0,a0,-738 # 5ca8 <malloc+0x86e>
     f92:	7bd030ef          	jal	4f4e <unlink>
    name[0] = 'x';
     f96:	07800993          	li	s3,120
    if(unlink(name) != 0){
     f9a:	fa040913          	addi	s2,s0,-96
  for(i = 0; i < N; i++){
     f9e:	1f400a13          	li	s4,500
    name[0] = 'x';
     fa2:	fb340023          	sb	s3,-96(s0)
    name[1] = '0' + (i / 64);
     fa6:	41f4d71b          	sraiw	a4,s1,0x1f
     faa:	01a7571b          	srliw	a4,a4,0x1a
     fae:	009707bb          	addw	a5,a4,s1
     fb2:	4067d69b          	sraiw	a3,a5,0x6
     fb6:	0306869b          	addiw	a3,a3,48
     fba:	fad400a3          	sb	a3,-95(s0)
    name[2] = '0' + (i % 64);
     fbe:	03f7f793          	andi	a5,a5,63
     fc2:	9f99                	subw	a5,a5,a4
     fc4:	0307879b          	addiw	a5,a5,48
     fc8:	faf40123          	sb	a5,-94(s0)
    name[3] = '\0';
     fcc:	fa0401a3          	sb	zero,-93(s0)
    if(unlink(name) != 0){
     fd0:	854a                	mv	a0,s2
     fd2:	77d030ef          	jal	4f4e <unlink>
     fd6:	e531                	bnez	a0,1022 <bigdir+0x12a>
  for(i = 0; i < N; i++){
     fd8:	2485                	addiw	s1,s1,1
     fda:	fd4494e3          	bne	s1,s4,fa2 <bigdir+0xaa>
}
     fde:	60e6                	ld	ra,88(sp)
     fe0:	6446                	ld	s0,80(sp)
     fe2:	64a6                	ld	s1,72(sp)
     fe4:	6906                	ld	s2,64(sp)
     fe6:	79e2                	ld	s3,56(sp)
     fe8:	7a42                	ld	s4,48(sp)
     fea:	7aa2                	ld	s5,40(sp)
     fec:	7b02                	ld	s6,32(sp)
     fee:	6be2                	ld	s7,24(sp)
     ff0:	6125                	addi	sp,sp,96
     ff2:	8082                	ret
    printf("%s: bigdir create failed\n", s);
     ff4:	85de                	mv	a1,s7
     ff6:	00005517          	auipc	a0,0x5
     ffa:	cba50513          	addi	a0,a0,-838 # 5cb0 <malloc+0x876>
     ffe:	384040ef          	jal	5382 <printf>
    exit(1);
    1002:	4505                	li	a0,1
    1004:	6fb030ef          	jal	4efe <exit>
      printf("%s: bigdir i=%d link(bd, %s) failed\n", s, i, name);
    1008:	fa040693          	addi	a3,s0,-96
    100c:	864a                	mv	a2,s2
    100e:	85de                	mv	a1,s7
    1010:	00005517          	auipc	a0,0x5
    1014:	cc050513          	addi	a0,a0,-832 # 5cd0 <malloc+0x896>
    1018:	36a040ef          	jal	5382 <printf>
      exit(1);
    101c:	4505                	li	a0,1
    101e:	6e1030ef          	jal	4efe <exit>
      printf("%s: bigdir unlink failed", s);
    1022:	85de                	mv	a1,s7
    1024:	00005517          	auipc	a0,0x5
    1028:	cd450513          	addi	a0,a0,-812 # 5cf8 <malloc+0x8be>
    102c:	356040ef          	jal	5382 <printf>
      exit(1);
    1030:	4505                	li	a0,1
    1032:	6cd030ef          	jal	4efe <exit>

0000000000001036 <pgbug>:
{
    1036:	7179                	addi	sp,sp,-48
    1038:	f406                	sd	ra,40(sp)
    103a:	f022                	sd	s0,32(sp)
    103c:	ec26                	sd	s1,24(sp)
    103e:	1800                	addi	s0,sp,48
  argv[0] = 0;
    1040:	fc043c23          	sd	zero,-40(s0)
  exec(big, argv);
    1044:	00007497          	auipc	s1,0x7
    1048:	fbc48493          	addi	s1,s1,-68 # 8000 <big>
    104c:	fd840593          	addi	a1,s0,-40
    1050:	6088                	ld	a0,0(s1)
    1052:	6e5030ef          	jal	4f36 <exec>
  pipe(big);
    1056:	6088                	ld	a0,0(s1)
    1058:	6b7030ef          	jal	4f0e <pipe>
  exit(0);
    105c:	4501                	li	a0,0
    105e:	6a1030ef          	jal	4efe <exit>

0000000000001062 <badarg>:
{
    1062:	7139                	addi	sp,sp,-64
    1064:	fc06                	sd	ra,56(sp)
    1066:	f822                	sd	s0,48(sp)
    1068:	f426                	sd	s1,40(sp)
    106a:	f04a                	sd	s2,32(sp)
    106c:	ec4e                	sd	s3,24(sp)
    106e:	e852                	sd	s4,16(sp)
    1070:	0080                	addi	s0,sp,64
    1072:	64b1                	lui	s1,0xc
    1074:	35048493          	addi	s1,s1,848 # c350 <buf+0x6a8>
    argv[0] = (char*)0xffffffff;
    1078:	597d                	li	s2,-1
    107a:	02095913          	srli	s2,s2,0x20
    exec("echo", argv);
    107e:	fc040a13          	addi	s4,s0,-64
    1082:	00004997          	auipc	s3,0x4
    1086:	4e698993          	addi	s3,s3,1254 # 5568 <malloc+0x12e>
    argv[0] = (char*)0xffffffff;
    108a:	fd243023          	sd	s2,-64(s0)
    argv[1] = 0;
    108e:	fc043423          	sd	zero,-56(s0)
    exec("echo", argv);
    1092:	85d2                	mv	a1,s4
    1094:	854e                	mv	a0,s3
    1096:	6a1030ef          	jal	4f36 <exec>
  for(int i = 0; i < 50000; i++){
    109a:	34fd                	addiw	s1,s1,-1
    109c:	f4fd                	bnez	s1,108a <badarg+0x28>
  exit(0);
    109e:	4501                	li	a0,0
    10a0:	65f030ef          	jal	4efe <exit>

00000000000010a4 <copyinstr2>:
{
    10a4:	7155                	addi	sp,sp,-208
    10a6:	e586                	sd	ra,200(sp)
    10a8:	e1a2                	sd	s0,192(sp)
    10aa:	0980                	addi	s0,sp,208
  for(int i = 0; i < MAXPATH; i++)
    10ac:	f6840793          	addi	a5,s0,-152
    10b0:	fe840693          	addi	a3,s0,-24
    b[i] = 'x';
    10b4:	07800713          	li	a4,120
    10b8:	00e78023          	sb	a4,0(a5)
  for(int i = 0; i < MAXPATH; i++)
    10bc:	0785                	addi	a5,a5,1
    10be:	fed79de3          	bne	a5,a3,10b8 <copyinstr2+0x14>
  b[MAXPATH] = '\0';
    10c2:	fe040423          	sb	zero,-24(s0)
  int ret = unlink(b);
    10c6:	f6840513          	addi	a0,s0,-152
    10ca:	685030ef          	jal	4f4e <unlink>
  if(ret != -1){
    10ce:	57fd                	li	a5,-1
    10d0:	0cf51263          	bne	a0,a5,1194 <copyinstr2+0xf0>
  int fd = open(b, O_CREATE | O_WRONLY);
    10d4:	20100593          	li	a1,513
    10d8:	f6840513          	addi	a0,s0,-152
    10dc:	663030ef          	jal	4f3e <open>
  if(fd != -1){
    10e0:	57fd                	li	a5,-1
    10e2:	0cf51563          	bne	a0,a5,11ac <copyinstr2+0x108>
  ret = link(b, b);
    10e6:	f6840513          	addi	a0,s0,-152
    10ea:	85aa                	mv	a1,a0
    10ec:	673030ef          	jal	4f5e <link>
  if(ret != -1){
    10f0:	57fd                	li	a5,-1
    10f2:	0cf51963          	bne	a0,a5,11c4 <copyinstr2+0x120>
  char *args[] = { "xx", 0 };
    10f6:	00006797          	auipc	a5,0x6
    10fa:	d5278793          	addi	a5,a5,-686 # 6e48 <malloc+0x1a0e>
    10fe:	f4f43c23          	sd	a5,-168(s0)
    1102:	f6043023          	sd	zero,-160(s0)
  ret = exec(b, args);
    1106:	f5840593          	addi	a1,s0,-168
    110a:	f6840513          	addi	a0,s0,-152
    110e:	629030ef          	jal	4f36 <exec>
  if(ret != -1){
    1112:	57fd                	li	a5,-1
    1114:	0cf51563          	bne	a0,a5,11de <copyinstr2+0x13a>
  int pid = fork();
    1118:	5df030ef          	jal	4ef6 <fork>
  if(pid < 0){
    111c:	0c054d63          	bltz	a0,11f6 <copyinstr2+0x152>
  if(pid == 0){
    1120:	0e051863          	bnez	a0,1210 <copyinstr2+0x16c>
    1124:	00007797          	auipc	a5,0x7
    1128:	46c78793          	addi	a5,a5,1132 # 8590 <big.0>
    112c:	00008697          	auipc	a3,0x8
    1130:	46468693          	addi	a3,a3,1124 # 9590 <big.0+0x1000>
      big[i] = 'x';
    1134:	07800713          	li	a4,120
    1138:	00e78023          	sb	a4,0(a5)
    for(int i = 0; i < PGSIZE; i++)
    113c:	0785                	addi	a5,a5,1
    113e:	fed79de3          	bne	a5,a3,1138 <copyinstr2+0x94>
    big[PGSIZE] = '\0';
    1142:	00008797          	auipc	a5,0x8
    1146:	44078723          	sb	zero,1102(a5) # 9590 <big.0+0x1000>
    char *args2[] = { big, big, big, 0 };
    114a:	00007797          	auipc	a5,0x7
    114e:	86e78793          	addi	a5,a5,-1938 # 79b8 <malloc+0x257e>
    1152:	6fb0                	ld	a2,88(a5)
    1154:	73b4                	ld	a3,96(a5)
    1156:	77b8                	ld	a4,104(a5)
    1158:	f2c43823          	sd	a2,-208(s0)
    115c:	f2d43c23          	sd	a3,-200(s0)
    1160:	f4e43023          	sd	a4,-192(s0)
    1164:	7bbc                	ld	a5,112(a5)
    1166:	f4f43423          	sd	a5,-184(s0)
    ret = exec("echo", args2);
    116a:	f3040593          	addi	a1,s0,-208
    116e:	00004517          	auipc	a0,0x4
    1172:	3fa50513          	addi	a0,a0,1018 # 5568 <malloc+0x12e>
    1176:	5c1030ef          	jal	4f36 <exec>
    if(ret != -1){
    117a:	57fd                	li	a5,-1
    117c:	08f50663          	beq	a0,a5,1208 <copyinstr2+0x164>
      printf("exec(echo, BIG) returned %d, not -1\n", fd);
    1180:	85be                	mv	a1,a5
    1182:	00005517          	auipc	a0,0x5
    1186:	c1e50513          	addi	a0,a0,-994 # 5da0 <malloc+0x966>
    118a:	1f8040ef          	jal	5382 <printf>
      exit(1);
    118e:	4505                	li	a0,1
    1190:	56f030ef          	jal	4efe <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    1194:	862a                	mv	a2,a0
    1196:	f6840593          	addi	a1,s0,-152
    119a:	00005517          	auipc	a0,0x5
    119e:	b7e50513          	addi	a0,a0,-1154 # 5d18 <malloc+0x8de>
    11a2:	1e0040ef          	jal	5382 <printf>
    exit(1);
    11a6:	4505                	li	a0,1
    11a8:	557030ef          	jal	4efe <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    11ac:	862a                	mv	a2,a0
    11ae:	f6840593          	addi	a1,s0,-152
    11b2:	00005517          	auipc	a0,0x5
    11b6:	b8650513          	addi	a0,a0,-1146 # 5d38 <malloc+0x8fe>
    11ba:	1c8040ef          	jal	5382 <printf>
    exit(1);
    11be:	4505                	li	a0,1
    11c0:	53f030ef          	jal	4efe <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    11c4:	f6840593          	addi	a1,s0,-152
    11c8:	86aa                	mv	a3,a0
    11ca:	862e                	mv	a2,a1
    11cc:	00005517          	auipc	a0,0x5
    11d0:	b8c50513          	addi	a0,a0,-1140 # 5d58 <malloc+0x91e>
    11d4:	1ae040ef          	jal	5382 <printf>
    exit(1);
    11d8:	4505                	li	a0,1
    11da:	525030ef          	jal	4efe <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    11de:	863e                	mv	a2,a5
    11e0:	f6840593          	addi	a1,s0,-152
    11e4:	00005517          	auipc	a0,0x5
    11e8:	b9c50513          	addi	a0,a0,-1124 # 5d80 <malloc+0x946>
    11ec:	196040ef          	jal	5382 <printf>
    exit(1);
    11f0:	4505                	li	a0,1
    11f2:	50d030ef          	jal	4efe <exit>
    printf("fork failed\n");
    11f6:	00006517          	auipc	a0,0x6
    11fa:	1aa50513          	addi	a0,a0,426 # 73a0 <malloc+0x1f66>
    11fe:	184040ef          	jal	5382 <printf>
    exit(1);
    1202:	4505                	li	a0,1
    1204:	4fb030ef          	jal	4efe <exit>
    exit(747); // OK
    1208:	2eb00513          	li	a0,747
    120c:	4f3030ef          	jal	4efe <exit>
  int st = 0;
    1210:	f4042a23          	sw	zero,-172(s0)
  wait(&st);
    1214:	f5440513          	addi	a0,s0,-172
    1218:	4ef030ef          	jal	4f06 <wait>
  if(st != 747){
    121c:	f5442703          	lw	a4,-172(s0)
    1220:	2eb00793          	li	a5,747
    1224:	00f71663          	bne	a4,a5,1230 <copyinstr2+0x18c>
}
    1228:	60ae                	ld	ra,200(sp)
    122a:	640e                	ld	s0,192(sp)
    122c:	6169                	addi	sp,sp,208
    122e:	8082                	ret
    printf("exec(echo, BIG) succeeded, should have failed\n");
    1230:	00005517          	auipc	a0,0x5
    1234:	b9850513          	addi	a0,a0,-1128 # 5dc8 <malloc+0x98e>
    1238:	14a040ef          	jal	5382 <printf>
    exit(1);
    123c:	4505                	li	a0,1
    123e:	4c1030ef          	jal	4efe <exit>

0000000000001242 <truncate3>:
{
    1242:	7175                	addi	sp,sp,-144
    1244:	e506                	sd	ra,136(sp)
    1246:	e122                	sd	s0,128(sp)
    1248:	fc66                	sd	s9,56(sp)
    124a:	0900                	addi	s0,sp,144
    124c:	8caa                	mv	s9,a0
  close(open("truncfile", O_CREATE|O_TRUNC|O_WRONLY));
    124e:	60100593          	li	a1,1537
    1252:	00004517          	auipc	a0,0x4
    1256:	36e50513          	addi	a0,a0,878 # 55c0 <malloc+0x186>
    125a:	4e5030ef          	jal	4f3e <open>
    125e:	4c9030ef          	jal	4f26 <close>
  pid = fork();
    1262:	495030ef          	jal	4ef6 <fork>
  if(pid < 0){
    1266:	06054d63          	bltz	a0,12e0 <truncate3+0x9e>
  if(pid == 0){
    126a:	e171                	bnez	a0,132e <truncate3+0xec>
    126c:	fca6                	sd	s1,120(sp)
    126e:	f8ca                	sd	s2,112(sp)
    1270:	f4ce                	sd	s3,104(sp)
    1272:	f0d2                	sd	s4,96(sp)
    1274:	ecd6                	sd	s5,88(sp)
    1276:	e8da                	sd	s6,80(sp)
    1278:	e4de                	sd	s7,72(sp)
    127a:	e0e2                	sd	s8,64(sp)
    127c:	06400913          	li	s2,100
      int fd = open("truncfile", O_WRONLY);
    1280:	4a85                	li	s5,1
    1282:	00004997          	auipc	s3,0x4
    1286:	33e98993          	addi	s3,s3,830 # 55c0 <malloc+0x186>
      int n = write(fd, "1234567890", 10);
    128a:	4a29                	li	s4,10
    128c:	00005b17          	auipc	s6,0x5
    1290:	b9cb0b13          	addi	s6,s6,-1124 # 5e28 <malloc+0x9ee>
      read(fd, buf, sizeof(buf));
    1294:	f7840c13          	addi	s8,s0,-136
    1298:	02000b93          	li	s7,32
      int fd = open("truncfile", O_WRONLY);
    129c:	85d6                	mv	a1,s5
    129e:	854e                	mv	a0,s3
    12a0:	49f030ef          	jal	4f3e <open>
    12a4:	84aa                	mv	s1,a0
      if(fd < 0){
    12a6:	04054f63          	bltz	a0,1304 <truncate3+0xc2>
      int n = write(fd, "1234567890", 10);
    12aa:	8652                	mv	a2,s4
    12ac:	85da                	mv	a1,s6
    12ae:	471030ef          	jal	4f1e <write>
      if(n != 10){
    12b2:	07451363          	bne	a0,s4,1318 <truncate3+0xd6>
      close(fd);
    12b6:	8526                	mv	a0,s1
    12b8:	46f030ef          	jal	4f26 <close>
      fd = open("truncfile", O_RDONLY);
    12bc:	4581                	li	a1,0
    12be:	854e                	mv	a0,s3
    12c0:	47f030ef          	jal	4f3e <open>
    12c4:	84aa                	mv	s1,a0
      read(fd, buf, sizeof(buf));
    12c6:	865e                	mv	a2,s7
    12c8:	85e2                	mv	a1,s8
    12ca:	44d030ef          	jal	4f16 <read>
      close(fd);
    12ce:	8526                	mv	a0,s1
    12d0:	457030ef          	jal	4f26 <close>
    for(int i = 0; i < 100; i++){
    12d4:	397d                	addiw	s2,s2,-1
    12d6:	fc0913e3          	bnez	s2,129c <truncate3+0x5a>
    exit(0);
    12da:	4501                	li	a0,0
    12dc:	423030ef          	jal	4efe <exit>
    12e0:	fca6                	sd	s1,120(sp)
    12e2:	f8ca                	sd	s2,112(sp)
    12e4:	f4ce                	sd	s3,104(sp)
    12e6:	f0d2                	sd	s4,96(sp)
    12e8:	ecd6                	sd	s5,88(sp)
    12ea:	e8da                	sd	s6,80(sp)
    12ec:	e4de                	sd	s7,72(sp)
    12ee:	e0e2                	sd	s8,64(sp)
    printf("%s: fork failed\n", s);
    12f0:	85e6                	mv	a1,s9
    12f2:	00005517          	auipc	a0,0x5
    12f6:	b0650513          	addi	a0,a0,-1274 # 5df8 <malloc+0x9be>
    12fa:	088040ef          	jal	5382 <printf>
    exit(1);
    12fe:	4505                	li	a0,1
    1300:	3ff030ef          	jal	4efe <exit>
        printf("%s: open failed\n", s);
    1304:	85e6                	mv	a1,s9
    1306:	00005517          	auipc	a0,0x5
    130a:	b0a50513          	addi	a0,a0,-1270 # 5e10 <malloc+0x9d6>
    130e:	074040ef          	jal	5382 <printf>
        exit(1);
    1312:	4505                	li	a0,1
    1314:	3eb030ef          	jal	4efe <exit>
        printf("%s: write got %d, expected 10\n", s, n);
    1318:	862a                	mv	a2,a0
    131a:	85e6                	mv	a1,s9
    131c:	00005517          	auipc	a0,0x5
    1320:	b1c50513          	addi	a0,a0,-1252 # 5e38 <malloc+0x9fe>
    1324:	05e040ef          	jal	5382 <printf>
        exit(1);
    1328:	4505                	li	a0,1
    132a:	3d5030ef          	jal	4efe <exit>
    132e:	fca6                	sd	s1,120(sp)
    1330:	f8ca                	sd	s2,112(sp)
    1332:	f4ce                	sd	s3,104(sp)
    1334:	f0d2                	sd	s4,96(sp)
    1336:	ecd6                	sd	s5,88(sp)
    1338:	e8da                	sd	s6,80(sp)
    133a:	09600913          	li	s2,150
    int fd = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
    133e:	60100a93          	li	s5,1537
    1342:	00004a17          	auipc	s4,0x4
    1346:	27ea0a13          	addi	s4,s4,638 # 55c0 <malloc+0x186>
    int n = write(fd, "xxx", 3);
    134a:	498d                	li	s3,3
    134c:	00005b17          	auipc	s6,0x5
    1350:	b0cb0b13          	addi	s6,s6,-1268 # 5e58 <malloc+0xa1e>
    int fd = open("truncfile", O_CREATE|O_WRONLY|O_TRUNC);
    1354:	85d6                	mv	a1,s5
    1356:	8552                	mv	a0,s4
    1358:	3e7030ef          	jal	4f3e <open>
    135c:	84aa                	mv	s1,a0
    if(fd < 0){
    135e:	02054e63          	bltz	a0,139a <truncate3+0x158>
    int n = write(fd, "xxx", 3);
    1362:	864e                	mv	a2,s3
    1364:	85da                	mv	a1,s6
    1366:	3b9030ef          	jal	4f1e <write>
    if(n != 3){
    136a:	05351463          	bne	a0,s3,13b2 <truncate3+0x170>
    close(fd);
    136e:	8526                	mv	a0,s1
    1370:	3b7030ef          	jal	4f26 <close>
  for(int i = 0; i < 150; i++){
    1374:	397d                	addiw	s2,s2,-1
    1376:	fc091fe3          	bnez	s2,1354 <truncate3+0x112>
    137a:	e4de                	sd	s7,72(sp)
    137c:	e0e2                	sd	s8,64(sp)
  wait(&xstatus);
    137e:	f9c40513          	addi	a0,s0,-100
    1382:	385030ef          	jal	4f06 <wait>
  unlink("truncfile");
    1386:	00004517          	auipc	a0,0x4
    138a:	23a50513          	addi	a0,a0,570 # 55c0 <malloc+0x186>
    138e:	3c1030ef          	jal	4f4e <unlink>
  exit(xstatus);
    1392:	f9c42503          	lw	a0,-100(s0)
    1396:	369030ef          	jal	4efe <exit>
    139a:	e4de                	sd	s7,72(sp)
    139c:	e0e2                	sd	s8,64(sp)
      printf("%s: open failed\n", s);
    139e:	85e6                	mv	a1,s9
    13a0:	00005517          	auipc	a0,0x5
    13a4:	a7050513          	addi	a0,a0,-1424 # 5e10 <malloc+0x9d6>
    13a8:	7db030ef          	jal	5382 <printf>
      exit(1);
    13ac:	4505                	li	a0,1
    13ae:	351030ef          	jal	4efe <exit>
    13b2:	e4de                	sd	s7,72(sp)
    13b4:	e0e2                	sd	s8,64(sp)
      printf("%s: write got %d, expected 3\n", s, n);
    13b6:	862a                	mv	a2,a0
    13b8:	85e6                	mv	a1,s9
    13ba:	00005517          	auipc	a0,0x5
    13be:	aa650513          	addi	a0,a0,-1370 # 5e60 <malloc+0xa26>
    13c2:	7c1030ef          	jal	5382 <printf>
      exit(1);
    13c6:	4505                	li	a0,1
    13c8:	337030ef          	jal	4efe <exit>

00000000000013cc <exectest>:
{
    13cc:	715d                	addi	sp,sp,-80
    13ce:	e486                	sd	ra,72(sp)
    13d0:	e0a2                	sd	s0,64(sp)
    13d2:	f84a                	sd	s2,48(sp)
    13d4:	0880                	addi	s0,sp,80
    13d6:	892a                	mv	s2,a0
  char *echoargv[] = { "echo", "OK", 0 };
    13d8:	00004797          	auipc	a5,0x4
    13dc:	19078793          	addi	a5,a5,400 # 5568 <malloc+0x12e>
    13e0:	fcf43023          	sd	a5,-64(s0)
    13e4:	00005797          	auipc	a5,0x5
    13e8:	a9c78793          	addi	a5,a5,-1380 # 5e80 <malloc+0xa46>
    13ec:	fcf43423          	sd	a5,-56(s0)
    13f0:	fc043823          	sd	zero,-48(s0)
  unlink("echo-ok");
    13f4:	00005517          	auipc	a0,0x5
    13f8:	a9450513          	addi	a0,a0,-1388 # 5e88 <malloc+0xa4e>
    13fc:	353030ef          	jal	4f4e <unlink>
  pid = fork();
    1400:	2f7030ef          	jal	4ef6 <fork>
  if(pid < 0) {
    1404:	02054f63          	bltz	a0,1442 <exectest+0x76>
    1408:	fc26                	sd	s1,56(sp)
    140a:	84aa                	mv	s1,a0
  if(pid == 0) {
    140c:	e935                	bnez	a0,1480 <exectest+0xb4>
    close(1);
    140e:	4505                	li	a0,1
    1410:	317030ef          	jal	4f26 <close>
    fd = open("echo-ok", O_CREATE|O_WRONLY);
    1414:	20100593          	li	a1,513
    1418:	00005517          	auipc	a0,0x5
    141c:	a7050513          	addi	a0,a0,-1424 # 5e88 <malloc+0xa4e>
    1420:	31f030ef          	jal	4f3e <open>
    if(fd < 0) {
    1424:	02054a63          	bltz	a0,1458 <exectest+0x8c>
    if(fd != 1) {
    1428:	4785                	li	a5,1
    142a:	04f50163          	beq	a0,a5,146c <exectest+0xa0>
      printf("%s: wrong fd\n", s);
    142e:	85ca                	mv	a1,s2
    1430:	00005517          	auipc	a0,0x5
    1434:	a7850513          	addi	a0,a0,-1416 # 5ea8 <malloc+0xa6e>
    1438:	74b030ef          	jal	5382 <printf>
      exit(1);
    143c:	4505                	li	a0,1
    143e:	2c1030ef          	jal	4efe <exit>
    1442:	fc26                	sd	s1,56(sp)
     printf("%s: fork failed\n", s);
    1444:	85ca                	mv	a1,s2
    1446:	00005517          	auipc	a0,0x5
    144a:	9b250513          	addi	a0,a0,-1614 # 5df8 <malloc+0x9be>
    144e:	735030ef          	jal	5382 <printf>
     exit(1);
    1452:	4505                	li	a0,1
    1454:	2ab030ef          	jal	4efe <exit>
      printf("%s: create failed\n", s);
    1458:	85ca                	mv	a1,s2
    145a:	00005517          	auipc	a0,0x5
    145e:	a3650513          	addi	a0,a0,-1482 # 5e90 <malloc+0xa56>
    1462:	721030ef          	jal	5382 <printf>
      exit(1);
    1466:	4505                	li	a0,1
    1468:	297030ef          	jal	4efe <exit>
    if(exec("echo", echoargv) < 0){
    146c:	fc040593          	addi	a1,s0,-64
    1470:	00004517          	auipc	a0,0x4
    1474:	0f850513          	addi	a0,a0,248 # 5568 <malloc+0x12e>
    1478:	2bf030ef          	jal	4f36 <exec>
    147c:	00054d63          	bltz	a0,1496 <exectest+0xca>
  if (wait(&xstatus) != pid) {
    1480:	fdc40513          	addi	a0,s0,-36
    1484:	283030ef          	jal	4f06 <wait>
    1488:	02951163          	bne	a0,s1,14aa <exectest+0xde>
  if(xstatus != 0)
    148c:	fdc42503          	lw	a0,-36(s0)
    1490:	c50d                	beqz	a0,14ba <exectest+0xee>
    exit(xstatus);
    1492:	26d030ef          	jal	4efe <exit>
      printf("%s: exec echo failed\n", s);
    1496:	85ca                	mv	a1,s2
    1498:	00005517          	auipc	a0,0x5
    149c:	a2050513          	addi	a0,a0,-1504 # 5eb8 <malloc+0xa7e>
    14a0:	6e3030ef          	jal	5382 <printf>
      exit(1);
    14a4:	4505                	li	a0,1
    14a6:	259030ef          	jal	4efe <exit>
    printf("%s: wait failed!\n", s);
    14aa:	85ca                	mv	a1,s2
    14ac:	00005517          	auipc	a0,0x5
    14b0:	a2450513          	addi	a0,a0,-1500 # 5ed0 <malloc+0xa96>
    14b4:	6cf030ef          	jal	5382 <printf>
    14b8:	bfd1                	j	148c <exectest+0xc0>
  fd = open("echo-ok", O_RDONLY);
    14ba:	4581                	li	a1,0
    14bc:	00005517          	auipc	a0,0x5
    14c0:	9cc50513          	addi	a0,a0,-1588 # 5e88 <malloc+0xa4e>
    14c4:	27b030ef          	jal	4f3e <open>
  if(fd < 0) {
    14c8:	02054463          	bltz	a0,14f0 <exectest+0x124>
  if (read(fd, buf, 2) != 2) {
    14cc:	4609                	li	a2,2
    14ce:	fb840593          	addi	a1,s0,-72
    14d2:	245030ef          	jal	4f16 <read>
    14d6:	4789                	li	a5,2
    14d8:	02f50663          	beq	a0,a5,1504 <exectest+0x138>
    printf("%s: read failed\n", s);
    14dc:	85ca                	mv	a1,s2
    14de:	00004517          	auipc	a0,0x4
    14e2:	45a50513          	addi	a0,a0,1114 # 5938 <malloc+0x4fe>
    14e6:	69d030ef          	jal	5382 <printf>
    exit(1);
    14ea:	4505                	li	a0,1
    14ec:	213030ef          	jal	4efe <exit>
    printf("%s: open failed\n", s);
    14f0:	85ca                	mv	a1,s2
    14f2:	00005517          	auipc	a0,0x5
    14f6:	91e50513          	addi	a0,a0,-1762 # 5e10 <malloc+0x9d6>
    14fa:	689030ef          	jal	5382 <printf>
    exit(1);
    14fe:	4505                	li	a0,1
    1500:	1ff030ef          	jal	4efe <exit>
  unlink("echo-ok");
    1504:	00005517          	auipc	a0,0x5
    1508:	98450513          	addi	a0,a0,-1660 # 5e88 <malloc+0xa4e>
    150c:	243030ef          	jal	4f4e <unlink>
  if(buf[0] == 'O' && buf[1] == 'K')
    1510:	fb844703          	lbu	a4,-72(s0)
    1514:	04f00793          	li	a5,79
    1518:	00f71863          	bne	a4,a5,1528 <exectest+0x15c>
    151c:	fb944703          	lbu	a4,-71(s0)
    1520:	04b00793          	li	a5,75
    1524:	00f70c63          	beq	a4,a5,153c <exectest+0x170>
    printf("%s: wrong output\n", s);
    1528:	85ca                	mv	a1,s2
    152a:	00005517          	auipc	a0,0x5
    152e:	9be50513          	addi	a0,a0,-1602 # 5ee8 <malloc+0xaae>
    1532:	651030ef          	jal	5382 <printf>
    exit(1);
    1536:	4505                	li	a0,1
    1538:	1c7030ef          	jal	4efe <exit>
    exit(0);
    153c:	4501                	li	a0,0
    153e:	1c1030ef          	jal	4efe <exit>

0000000000001542 <pipe1>:
{
    1542:	711d                	addi	sp,sp,-96
    1544:	ec86                	sd	ra,88(sp)
    1546:	e8a2                	sd	s0,80(sp)
    1548:	e862                	sd	s8,16(sp)
    154a:	1080                	addi	s0,sp,96
    154c:	8c2a                	mv	s8,a0
  if(pipe(fds) != 0){
    154e:	fa840513          	addi	a0,s0,-88
    1552:	1bd030ef          	jal	4f0e <pipe>
    1556:	e925                	bnez	a0,15c6 <pipe1+0x84>
    1558:	e4a6                	sd	s1,72(sp)
    155a:	fc4e                	sd	s3,56(sp)
    155c:	84aa                	mv	s1,a0
  pid = fork();
    155e:	199030ef          	jal	4ef6 <fork>
    1562:	89aa                	mv	s3,a0
  if(pid == 0){
    1564:	c151                	beqz	a0,15e8 <pipe1+0xa6>
  } else if(pid > 0){
    1566:	16a05063          	blez	a0,16c6 <pipe1+0x184>
    156a:	e0ca                	sd	s2,64(sp)
    156c:	f852                	sd	s4,48(sp)
    close(fds[1]);
    156e:	fac42503          	lw	a0,-84(s0)
    1572:	1b5030ef          	jal	4f26 <close>
    total = 0;
    1576:	89a6                	mv	s3,s1
    cc = 1;
    1578:	4905                	li	s2,1
    while((n = read(fds[0], buf, cc)) > 0){
    157a:	0000aa17          	auipc	s4,0xa
    157e:	72ea0a13          	addi	s4,s4,1838 # bca8 <buf>
    1582:	864a                	mv	a2,s2
    1584:	85d2                	mv	a1,s4
    1586:	fa842503          	lw	a0,-88(s0)
    158a:	18d030ef          	jal	4f16 <read>
    158e:	85aa                	mv	a1,a0
    1590:	0ea05963          	blez	a0,1682 <pipe1+0x140>
    1594:	0000a797          	auipc	a5,0xa
    1598:	71478793          	addi	a5,a5,1812 # bca8 <buf>
    159c:	00b4863b          	addw	a2,s1,a1
        if((buf[i] & 0xff) != (seq++ & 0xff)){
    15a0:	0007c683          	lbu	a3,0(a5)
    15a4:	0ff4f713          	zext.b	a4,s1
    15a8:	0ae69d63          	bne	a3,a4,1662 <pipe1+0x120>
    15ac:	2485                	addiw	s1,s1,1
      for(i = 0; i < n; i++){
    15ae:	0785                	addi	a5,a5,1
    15b0:	fec498e3          	bne	s1,a2,15a0 <pipe1+0x5e>
      total += n;
    15b4:	00b989bb          	addw	s3,s3,a1
      cc = cc * 2;
    15b8:	0019191b          	slliw	s2,s2,0x1
      if(cc > sizeof(buf))
    15bc:	678d                	lui	a5,0x3
    15be:	fd27f2e3          	bgeu	a5,s2,1582 <pipe1+0x40>
        cc = sizeof(buf);
    15c2:	893e                	mv	s2,a5
    15c4:	bf7d                	j	1582 <pipe1+0x40>
    15c6:	e4a6                	sd	s1,72(sp)
    15c8:	e0ca                	sd	s2,64(sp)
    15ca:	fc4e                	sd	s3,56(sp)
    15cc:	f852                	sd	s4,48(sp)
    15ce:	f456                	sd	s5,40(sp)
    15d0:	f05a                	sd	s6,32(sp)
    15d2:	ec5e                	sd	s7,24(sp)
    printf("%s: pipe() failed\n", s);
    15d4:	85e2                	mv	a1,s8
    15d6:	00005517          	auipc	a0,0x5
    15da:	92a50513          	addi	a0,a0,-1750 # 5f00 <malloc+0xac6>
    15de:	5a5030ef          	jal	5382 <printf>
    exit(1);
    15e2:	4505                	li	a0,1
    15e4:	11b030ef          	jal	4efe <exit>
    15e8:	e0ca                	sd	s2,64(sp)
    15ea:	f852                	sd	s4,48(sp)
    15ec:	f456                	sd	s5,40(sp)
    15ee:	f05a                	sd	s6,32(sp)
    15f0:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    15f2:	fa842503          	lw	a0,-88(s0)
    15f6:	131030ef          	jal	4f26 <close>
    for(n = 0; n < N; n++){
    15fa:	0000ab17          	auipc	s6,0xa
    15fe:	6aeb0b13          	addi	s6,s6,1710 # bca8 <buf>
    1602:	416004bb          	negw	s1,s6
    1606:	0ff4f493          	zext.b	s1,s1
    160a:	409b0913          	addi	s2,s6,1033
      if(write(fds[1], buf, SZ) != SZ){
    160e:	40900a13          	li	s4,1033
    1612:	8bda                	mv	s7,s6
    for(n = 0; n < N; n++){
    1614:	6a85                	lui	s5,0x1
    1616:	42da8a93          	addi	s5,s5,1069 # 142d <exectest+0x61>
{
    161a:	87da                	mv	a5,s6
        buf[i] = seq++;
    161c:	0097873b          	addw	a4,a5,s1
    1620:	00e78023          	sb	a4,0(a5) # 3000 <subdir+0x2fa>
      for(i = 0; i < SZ; i++)
    1624:	0785                	addi	a5,a5,1
    1626:	ff279be3          	bne	a5,s2,161c <pipe1+0xda>
      if(write(fds[1], buf, SZ) != SZ){
    162a:	8652                	mv	a2,s4
    162c:	85de                	mv	a1,s7
    162e:	fac42503          	lw	a0,-84(s0)
    1632:	0ed030ef          	jal	4f1e <write>
    1636:	01451c63          	bne	a0,s4,164e <pipe1+0x10c>
    163a:	4099899b          	addiw	s3,s3,1033
    for(n = 0; n < N; n++){
    163e:	24a5                	addiw	s1,s1,9
    1640:	0ff4f493          	zext.b	s1,s1
    1644:	fd599be3          	bne	s3,s5,161a <pipe1+0xd8>
    exit(0);
    1648:	4501                	li	a0,0
    164a:	0b5030ef          	jal	4efe <exit>
        printf("%s: pipe1 oops 1\n", s);
    164e:	85e2                	mv	a1,s8
    1650:	00005517          	auipc	a0,0x5
    1654:	8c850513          	addi	a0,a0,-1848 # 5f18 <malloc+0xade>
    1658:	52b030ef          	jal	5382 <printf>
        exit(1);
    165c:	4505                	li	a0,1
    165e:	0a1030ef          	jal	4efe <exit>
          printf("%s: pipe1 oops 2\n", s);
    1662:	85e2                	mv	a1,s8
    1664:	00005517          	auipc	a0,0x5
    1668:	8cc50513          	addi	a0,a0,-1844 # 5f30 <malloc+0xaf6>
    166c:	517030ef          	jal	5382 <printf>
          return;
    1670:	64a6                	ld	s1,72(sp)
    1672:	6906                	ld	s2,64(sp)
    1674:	79e2                	ld	s3,56(sp)
    1676:	7a42                	ld	s4,48(sp)
}
    1678:	60e6                	ld	ra,88(sp)
    167a:	6446                	ld	s0,80(sp)
    167c:	6c42                	ld	s8,16(sp)
    167e:	6125                	addi	sp,sp,96
    1680:	8082                	ret
    if(total != N * SZ){
    1682:	6785                	lui	a5,0x1
    1684:	42d78793          	addi	a5,a5,1069 # 142d <exectest+0x61>
    1688:	02f98063          	beq	s3,a5,16a8 <pipe1+0x166>
    168c:	f456                	sd	s5,40(sp)
    168e:	f05a                	sd	s6,32(sp)
    1690:	ec5e                	sd	s7,24(sp)
      printf("%s: pipe1 oops 3 total %d\n", s, total);
    1692:	864e                	mv	a2,s3
    1694:	85e2                	mv	a1,s8
    1696:	00005517          	auipc	a0,0x5
    169a:	8b250513          	addi	a0,a0,-1870 # 5f48 <malloc+0xb0e>
    169e:	4e5030ef          	jal	5382 <printf>
      exit(1);
    16a2:	4505                	li	a0,1
    16a4:	05b030ef          	jal	4efe <exit>
    16a8:	f456                	sd	s5,40(sp)
    16aa:	f05a                	sd	s6,32(sp)
    16ac:	ec5e                	sd	s7,24(sp)
    close(fds[0]);
    16ae:	fa842503          	lw	a0,-88(s0)
    16b2:	075030ef          	jal	4f26 <close>
    wait(&xstatus);
    16b6:	fa440513          	addi	a0,s0,-92
    16ba:	04d030ef          	jal	4f06 <wait>
    exit(xstatus);
    16be:	fa442503          	lw	a0,-92(s0)
    16c2:	03d030ef          	jal	4efe <exit>
    16c6:	e0ca                	sd	s2,64(sp)
    16c8:	f852                	sd	s4,48(sp)
    16ca:	f456                	sd	s5,40(sp)
    16cc:	f05a                	sd	s6,32(sp)
    16ce:	ec5e                	sd	s7,24(sp)
    printf("%s: fork() failed\n", s);
    16d0:	85e2                	mv	a1,s8
    16d2:	00005517          	auipc	a0,0x5
    16d6:	89650513          	addi	a0,a0,-1898 # 5f68 <malloc+0xb2e>
    16da:	4a9030ef          	jal	5382 <printf>
    exit(1);
    16de:	4505                	li	a0,1
    16e0:	01f030ef          	jal	4efe <exit>

00000000000016e4 <exitwait>:
{
    16e4:	715d                	addi	sp,sp,-80
    16e6:	e486                	sd	ra,72(sp)
    16e8:	e0a2                	sd	s0,64(sp)
    16ea:	fc26                	sd	s1,56(sp)
    16ec:	f84a                	sd	s2,48(sp)
    16ee:	f44e                	sd	s3,40(sp)
    16f0:	f052                	sd	s4,32(sp)
    16f2:	ec56                	sd	s5,24(sp)
    16f4:	0880                	addi	s0,sp,80
    16f6:	8aaa                	mv	s5,a0
  for(i = 0; i < 100; i++){
    16f8:	4901                	li	s2,0
      if(wait(&xstate) != pid){
    16fa:	fbc40993          	addi	s3,s0,-68
  for(i = 0; i < 100; i++){
    16fe:	06400a13          	li	s4,100
    pid = fork();
    1702:	7f4030ef          	jal	4ef6 <fork>
    1706:	84aa                	mv	s1,a0
    if(pid < 0){
    1708:	02054863          	bltz	a0,1738 <exitwait+0x54>
    if(pid){
    170c:	c525                	beqz	a0,1774 <exitwait+0x90>
      if(wait(&xstate) != pid){
    170e:	854e                	mv	a0,s3
    1710:	7f6030ef          	jal	4f06 <wait>
    1714:	02951c63          	bne	a0,s1,174c <exitwait+0x68>
      if(i != xstate) {
    1718:	fbc42783          	lw	a5,-68(s0)
    171c:	05279263          	bne	a5,s2,1760 <exitwait+0x7c>
  for(i = 0; i < 100; i++){
    1720:	2905                	addiw	s2,s2,1
    1722:	ff4910e3          	bne	s2,s4,1702 <exitwait+0x1e>
}
    1726:	60a6                	ld	ra,72(sp)
    1728:	6406                	ld	s0,64(sp)
    172a:	74e2                	ld	s1,56(sp)
    172c:	7942                	ld	s2,48(sp)
    172e:	79a2                	ld	s3,40(sp)
    1730:	7a02                	ld	s4,32(sp)
    1732:	6ae2                	ld	s5,24(sp)
    1734:	6161                	addi	sp,sp,80
    1736:	8082                	ret
      printf("%s: fork failed\n", s);
    1738:	85d6                	mv	a1,s5
    173a:	00004517          	auipc	a0,0x4
    173e:	6be50513          	addi	a0,a0,1726 # 5df8 <malloc+0x9be>
    1742:	441030ef          	jal	5382 <printf>
      exit(1);
    1746:	4505                	li	a0,1
    1748:	7b6030ef          	jal	4efe <exit>
        printf("%s: wait wrong pid\n", s);
    174c:	85d6                	mv	a1,s5
    174e:	00005517          	auipc	a0,0x5
    1752:	83250513          	addi	a0,a0,-1998 # 5f80 <malloc+0xb46>
    1756:	42d030ef          	jal	5382 <printf>
        exit(1);
    175a:	4505                	li	a0,1
    175c:	7a2030ef          	jal	4efe <exit>
        printf("%s: wait wrong exit status\n", s);
    1760:	85d6                	mv	a1,s5
    1762:	00005517          	auipc	a0,0x5
    1766:	83650513          	addi	a0,a0,-1994 # 5f98 <malloc+0xb5e>
    176a:	419030ef          	jal	5382 <printf>
        exit(1);
    176e:	4505                	li	a0,1
    1770:	78e030ef          	jal	4efe <exit>
      exit(i);
    1774:	854a                	mv	a0,s2
    1776:	788030ef          	jal	4efe <exit>

000000000000177a <twochildren>:
{
    177a:	1101                	addi	sp,sp,-32
    177c:	ec06                	sd	ra,24(sp)
    177e:	e822                	sd	s0,16(sp)
    1780:	e426                	sd	s1,8(sp)
    1782:	e04a                	sd	s2,0(sp)
    1784:	1000                	addi	s0,sp,32
    1786:	892a                	mv	s2,a0
    1788:	3e800493          	li	s1,1000
    int pid1 = fork();
    178c:	76a030ef          	jal	4ef6 <fork>
    if(pid1 < 0){
    1790:	02054663          	bltz	a0,17bc <twochildren+0x42>
    if(pid1 == 0){
    1794:	cd15                	beqz	a0,17d0 <twochildren+0x56>
      int pid2 = fork();
    1796:	760030ef          	jal	4ef6 <fork>
      if(pid2 < 0){
    179a:	02054d63          	bltz	a0,17d4 <twochildren+0x5a>
      if(pid2 == 0){
    179e:	c529                	beqz	a0,17e8 <twochildren+0x6e>
        wait(0);
    17a0:	4501                	li	a0,0
    17a2:	764030ef          	jal	4f06 <wait>
        wait(0);
    17a6:	4501                	li	a0,0
    17a8:	75e030ef          	jal	4f06 <wait>
  for(int i = 0; i < 1000; i++){
    17ac:	34fd                	addiw	s1,s1,-1
    17ae:	fcf9                	bnez	s1,178c <twochildren+0x12>
}
    17b0:	60e2                	ld	ra,24(sp)
    17b2:	6442                	ld	s0,16(sp)
    17b4:	64a2                	ld	s1,8(sp)
    17b6:	6902                	ld	s2,0(sp)
    17b8:	6105                	addi	sp,sp,32
    17ba:	8082                	ret
      printf("%s: fork failed\n", s);
    17bc:	85ca                	mv	a1,s2
    17be:	00004517          	auipc	a0,0x4
    17c2:	63a50513          	addi	a0,a0,1594 # 5df8 <malloc+0x9be>
    17c6:	3bd030ef          	jal	5382 <printf>
      exit(1);
    17ca:	4505                	li	a0,1
    17cc:	732030ef          	jal	4efe <exit>
      exit(0);
    17d0:	72e030ef          	jal	4efe <exit>
        printf("%s: fork failed\n", s);
    17d4:	85ca                	mv	a1,s2
    17d6:	00004517          	auipc	a0,0x4
    17da:	62250513          	addi	a0,a0,1570 # 5df8 <malloc+0x9be>
    17de:	3a5030ef          	jal	5382 <printf>
        exit(1);
    17e2:	4505                	li	a0,1
    17e4:	71a030ef          	jal	4efe <exit>
        exit(0);
    17e8:	716030ef          	jal	4efe <exit>

00000000000017ec <forkfork>:
{
    17ec:	7179                	addi	sp,sp,-48
    17ee:	f406                	sd	ra,40(sp)
    17f0:	f022                	sd	s0,32(sp)
    17f2:	ec26                	sd	s1,24(sp)
    17f4:	1800                	addi	s0,sp,48
    17f6:	84aa                	mv	s1,a0
    int pid = fork();
    17f8:	6fe030ef          	jal	4ef6 <fork>
    if(pid < 0){
    17fc:	02054b63          	bltz	a0,1832 <forkfork+0x46>
    if(pid == 0){
    1800:	c139                	beqz	a0,1846 <forkfork+0x5a>
    int pid = fork();
    1802:	6f4030ef          	jal	4ef6 <fork>
    if(pid < 0){
    1806:	02054663          	bltz	a0,1832 <forkfork+0x46>
    if(pid == 0){
    180a:	cd15                	beqz	a0,1846 <forkfork+0x5a>
    wait(&xstatus);
    180c:	fdc40513          	addi	a0,s0,-36
    1810:	6f6030ef          	jal	4f06 <wait>
    if(xstatus != 0) {
    1814:	fdc42783          	lw	a5,-36(s0)
    1818:	ebb9                	bnez	a5,186e <forkfork+0x82>
    wait(&xstatus);
    181a:	fdc40513          	addi	a0,s0,-36
    181e:	6e8030ef          	jal	4f06 <wait>
    if(xstatus != 0) {
    1822:	fdc42783          	lw	a5,-36(s0)
    1826:	e7a1                	bnez	a5,186e <forkfork+0x82>
}
    1828:	70a2                	ld	ra,40(sp)
    182a:	7402                	ld	s0,32(sp)
    182c:	64e2                	ld	s1,24(sp)
    182e:	6145                	addi	sp,sp,48
    1830:	8082                	ret
      printf("%s: fork failed", s);
    1832:	85a6                	mv	a1,s1
    1834:	00004517          	auipc	a0,0x4
    1838:	78450513          	addi	a0,a0,1924 # 5fb8 <malloc+0xb7e>
    183c:	347030ef          	jal	5382 <printf>
      exit(1);
    1840:	4505                	li	a0,1
    1842:	6bc030ef          	jal	4efe <exit>
{
    1846:	0c800493          	li	s1,200
        int pid1 = fork();
    184a:	6ac030ef          	jal	4ef6 <fork>
        if(pid1 < 0){
    184e:	00054b63          	bltz	a0,1864 <forkfork+0x78>
        if(pid1 == 0){
    1852:	cd01                	beqz	a0,186a <forkfork+0x7e>
        wait(0);
    1854:	4501                	li	a0,0
    1856:	6b0030ef          	jal	4f06 <wait>
      for(int j = 0; j < 200; j++){
    185a:	34fd                	addiw	s1,s1,-1
    185c:	f4fd                	bnez	s1,184a <forkfork+0x5e>
      exit(0);
    185e:	4501                	li	a0,0
    1860:	69e030ef          	jal	4efe <exit>
          exit(1);
    1864:	4505                	li	a0,1
    1866:	698030ef          	jal	4efe <exit>
          exit(0);
    186a:	694030ef          	jal	4efe <exit>
      printf("%s: fork in child failed", s);
    186e:	85a6                	mv	a1,s1
    1870:	00004517          	auipc	a0,0x4
    1874:	75850513          	addi	a0,a0,1880 # 5fc8 <malloc+0xb8e>
    1878:	30b030ef          	jal	5382 <printf>
      exit(1);
    187c:	4505                	li	a0,1
    187e:	680030ef          	jal	4efe <exit>

0000000000001882 <reparent2>:
{
    1882:	1101                	addi	sp,sp,-32
    1884:	ec06                	sd	ra,24(sp)
    1886:	e822                	sd	s0,16(sp)
    1888:	e426                	sd	s1,8(sp)
    188a:	1000                	addi	s0,sp,32
    188c:	32000493          	li	s1,800
    int pid1 = fork();
    1890:	666030ef          	jal	4ef6 <fork>
    if(pid1 < 0){
    1894:	00054b63          	bltz	a0,18aa <reparent2+0x28>
    if(pid1 == 0){
    1898:	c115                	beqz	a0,18bc <reparent2+0x3a>
    wait(0);
    189a:	4501                	li	a0,0
    189c:	66a030ef          	jal	4f06 <wait>
  for(int i = 0; i < 800; i++){
    18a0:	34fd                	addiw	s1,s1,-1
    18a2:	f4fd                	bnez	s1,1890 <reparent2+0xe>
  exit(0);
    18a4:	4501                	li	a0,0
    18a6:	658030ef          	jal	4efe <exit>
      printf("fork failed\n");
    18aa:	00006517          	auipc	a0,0x6
    18ae:	af650513          	addi	a0,a0,-1290 # 73a0 <malloc+0x1f66>
    18b2:	2d1030ef          	jal	5382 <printf>
      exit(1);
    18b6:	4505                	li	a0,1
    18b8:	646030ef          	jal	4efe <exit>
      fork();
    18bc:	63a030ef          	jal	4ef6 <fork>
      fork();
    18c0:	636030ef          	jal	4ef6 <fork>
      exit(0);
    18c4:	4501                	li	a0,0
    18c6:	638030ef          	jal	4efe <exit>

00000000000018ca <createdelete>:
{
    18ca:	7135                	addi	sp,sp,-160
    18cc:	ed06                	sd	ra,152(sp)
    18ce:	e922                	sd	s0,144(sp)
    18d0:	e526                	sd	s1,136(sp)
    18d2:	e14a                	sd	s2,128(sp)
    18d4:	fcce                	sd	s3,120(sp)
    18d6:	f8d2                	sd	s4,112(sp)
    18d8:	f4d6                	sd	s5,104(sp)
    18da:	f0da                	sd	s6,96(sp)
    18dc:	ecde                	sd	s7,88(sp)
    18de:	e8e2                	sd	s8,80(sp)
    18e0:	e4e6                	sd	s9,72(sp)
    18e2:	e0ea                	sd	s10,64(sp)
    18e4:	fc6e                	sd	s11,56(sp)
    18e6:	1100                	addi	s0,sp,160
    18e8:	8daa                	mv	s11,a0
  for(pi = 0; pi < NCHILD; pi++){
    18ea:	4901                	li	s2,0
    18ec:	4991                	li	s3,4
    pid = fork();
    18ee:	608030ef          	jal	4ef6 <fork>
    18f2:	84aa                	mv	s1,a0
    if(pid < 0){
    18f4:	04054063          	bltz	a0,1934 <createdelete+0x6a>
    if(pid == 0){
    18f8:	c921                	beqz	a0,1948 <createdelete+0x7e>
  for(pi = 0; pi < NCHILD; pi++){
    18fa:	2905                	addiw	s2,s2,1
    18fc:	ff3919e3          	bne	s2,s3,18ee <createdelete+0x24>
    1900:	4491                	li	s1,4
    wait(&xstatus);
    1902:	f6c40913          	addi	s2,s0,-148
    1906:	854a                	mv	a0,s2
    1908:	5fe030ef          	jal	4f06 <wait>
    if(xstatus != 0)
    190c:	f6c42a83          	lw	s5,-148(s0)
    1910:	0c0a9263          	bnez	s5,19d4 <createdelete+0x10a>
  for(pi = 0; pi < NCHILD; pi++){
    1914:	34fd                	addiw	s1,s1,-1
    1916:	f8e5                	bnez	s1,1906 <createdelete+0x3c>
  name[0] = name[1] = name[2] = 0;
    1918:	f6040923          	sb	zero,-142(s0)
    191c:	03000913          	li	s2,48
    1920:	5a7d                	li	s4,-1
      if((i == 0 || i >= N/2) && fd < 0){
    1922:	4d25                	li	s10,9
    1924:	07000c93          	li	s9,112
      fd = open(name, 0);
    1928:	f7040c13          	addi	s8,s0,-144
      } else if((i >= 1 && i < N/2) && fd >= 0){
    192c:	4ba1                	li	s7,8
    for(pi = 0; pi < NCHILD; pi++){
    192e:	07400b13          	li	s6,116
    1932:	aa39                	j	1a50 <createdelete+0x186>
      printf("%s: fork failed\n", s);
    1934:	85ee                	mv	a1,s11
    1936:	00004517          	auipc	a0,0x4
    193a:	4c250513          	addi	a0,a0,1218 # 5df8 <malloc+0x9be>
    193e:	245030ef          	jal	5382 <printf>
      exit(1);
    1942:	4505                	li	a0,1
    1944:	5ba030ef          	jal	4efe <exit>
      name[0] = 'p' + pi;
    1948:	0709091b          	addiw	s2,s2,112
    194c:	f7240823          	sb	s2,-144(s0)
      name[2] = '\0';
    1950:	f6040923          	sb	zero,-142(s0)
        fd = open(name, O_CREATE | O_RDWR);
    1954:	f7040913          	addi	s2,s0,-144
    1958:	20200993          	li	s3,514
      for(i = 0; i < N; i++){
    195c:	4a51                	li	s4,20
    195e:	a815                	j	1992 <createdelete+0xc8>
          printf("%s: create failed\n", s);
    1960:	85ee                	mv	a1,s11
    1962:	00004517          	auipc	a0,0x4
    1966:	52e50513          	addi	a0,a0,1326 # 5e90 <malloc+0xa56>
    196a:	219030ef          	jal	5382 <printf>
          exit(1);
    196e:	4505                	li	a0,1
    1970:	58e030ef          	jal	4efe <exit>
          name[1] = '0' + (i / 2);
    1974:	01f4d79b          	srliw	a5,s1,0x1f
    1978:	9fa5                	addw	a5,a5,s1
    197a:	4017d79b          	sraiw	a5,a5,0x1
    197e:	0307879b          	addiw	a5,a5,48
    1982:	f6f408a3          	sb	a5,-143(s0)
          if(unlink(name) < 0){
    1986:	854a                	mv	a0,s2
    1988:	5c6030ef          	jal	4f4e <unlink>
    198c:	02054a63          	bltz	a0,19c0 <createdelete+0xf6>
      for(i = 0; i < N; i++){
    1990:	2485                	addiw	s1,s1,1
        name[1] = '0' + i;
    1992:	0304879b          	addiw	a5,s1,48
    1996:	f6f408a3          	sb	a5,-143(s0)
        fd = open(name, O_CREATE | O_RDWR);
    199a:	85ce                	mv	a1,s3
    199c:	854a                	mv	a0,s2
    199e:	5a0030ef          	jal	4f3e <open>
        if(fd < 0){
    19a2:	fa054fe3          	bltz	a0,1960 <createdelete+0x96>
        close(fd);
    19a6:	580030ef          	jal	4f26 <close>
        if(i > 0 && (i % 2 ) == 0){
    19aa:	fe9053e3          	blez	s1,1990 <createdelete+0xc6>
    19ae:	0014f793          	andi	a5,s1,1
    19b2:	d3e9                	beqz	a5,1974 <createdelete+0xaa>
      for(i = 0; i < N; i++){
    19b4:	2485                	addiw	s1,s1,1
    19b6:	fd449ee3          	bne	s1,s4,1992 <createdelete+0xc8>
      exit(0);
    19ba:	4501                	li	a0,0
    19bc:	542030ef          	jal	4efe <exit>
            printf("%s: unlink failed\n", s);
    19c0:	85ee                	mv	a1,s11
    19c2:	00004517          	auipc	a0,0x4
    19c6:	62650513          	addi	a0,a0,1574 # 5fe8 <malloc+0xbae>
    19ca:	1b9030ef          	jal	5382 <printf>
            exit(1);
    19ce:	4505                	li	a0,1
    19d0:	52e030ef          	jal	4efe <exit>
      exit(1);
    19d4:	4505                	li	a0,1
    19d6:	528030ef          	jal	4efe <exit>
      } else if((i >= 1 && i < N/2) && fd >= 0){
    19da:	054bf263          	bgeu	s7,s4,1a1e <createdelete+0x154>
      if(fd >= 0)
    19de:	04055e63          	bgez	a0,1a3a <createdelete+0x170>
    for(pi = 0; pi < NCHILD; pi++){
    19e2:	2485                	addiw	s1,s1,1
    19e4:	0ff4f493          	zext.b	s1,s1
    19e8:	05648c63          	beq	s1,s6,1a40 <createdelete+0x176>
      name[0] = 'p' + pi;
    19ec:	f6940823          	sb	s1,-144(s0)
      name[1] = '0' + i;
    19f0:	f72408a3          	sb	s2,-143(s0)
      fd = open(name, 0);
    19f4:	4581                	li	a1,0
    19f6:	8562                	mv	a0,s8
    19f8:	546030ef          	jal	4f3e <open>
      if((i == 0 || i >= N/2) && fd < 0){
    19fc:	01f5579b          	srliw	a5,a0,0x1f
    1a00:	dfe9                	beqz	a5,19da <createdelete+0x110>
    1a02:	fc098ce3          	beqz	s3,19da <createdelete+0x110>
        printf("%s: oops createdelete %s didn't exist\n", s, name);
    1a06:	f7040613          	addi	a2,s0,-144
    1a0a:	85ee                	mv	a1,s11
    1a0c:	00004517          	auipc	a0,0x4
    1a10:	5f450513          	addi	a0,a0,1524 # 6000 <malloc+0xbc6>
    1a14:	16f030ef          	jal	5382 <printf>
        exit(1);
    1a18:	4505                	li	a0,1
    1a1a:	4e4030ef          	jal	4efe <exit>
      } else if((i >= 1 && i < N/2) && fd >= 0){
    1a1e:	fc0542e3          	bltz	a0,19e2 <createdelete+0x118>
        printf("%s: oops createdelete %s did exist\n", s, name);
    1a22:	f7040613          	addi	a2,s0,-144
    1a26:	85ee                	mv	a1,s11
    1a28:	00004517          	auipc	a0,0x4
    1a2c:	60050513          	addi	a0,a0,1536 # 6028 <malloc+0xbee>
    1a30:	153030ef          	jal	5382 <printf>
        exit(1);
    1a34:	4505                	li	a0,1
    1a36:	4c8030ef          	jal	4efe <exit>
        close(fd);
    1a3a:	4ec030ef          	jal	4f26 <close>
    1a3e:	b755                	j	19e2 <createdelete+0x118>
  for(i = 0; i < N; i++){
    1a40:	2a85                	addiw	s5,s5,1
    1a42:	2a05                	addiw	s4,s4,1
    1a44:	2905                	addiw	s2,s2,1
    1a46:	0ff97913          	zext.b	s2,s2
    1a4a:	47d1                	li	a5,20
    1a4c:	00fa8a63          	beq	s5,a5,1a60 <createdelete+0x196>
      if((i == 0 || i >= N/2) && fd < 0){
    1a50:	001ab993          	seqz	s3,s5
    1a54:	015d27b3          	slt	a5,s10,s5
    1a58:	00f9e9b3          	or	s3,s3,a5
    1a5c:	84e6                	mv	s1,s9
    1a5e:	b779                	j	19ec <createdelete+0x122>
    1a60:	03000913          	li	s2,48
  name[0] = name[1] = name[2] = 0;
    1a64:	07000b13          	li	s6,112
      unlink(name);
    1a68:	f7040a13          	addi	s4,s0,-144
    for(pi = 0; pi < NCHILD; pi++){
    1a6c:	07400993          	li	s3,116
  for(i = 0; i < N; i++){
    1a70:	04400a93          	li	s5,68
  name[0] = name[1] = name[2] = 0;
    1a74:	84da                	mv	s1,s6
      name[0] = 'p' + pi;
    1a76:	f6940823          	sb	s1,-144(s0)
      name[1] = '0' + i;
    1a7a:	f72408a3          	sb	s2,-143(s0)
      unlink(name);
    1a7e:	8552                	mv	a0,s4
    1a80:	4ce030ef          	jal	4f4e <unlink>
    for(pi = 0; pi < NCHILD; pi++){
    1a84:	2485                	addiw	s1,s1,1
    1a86:	0ff4f493          	zext.b	s1,s1
    1a8a:	ff3496e3          	bne	s1,s3,1a76 <createdelete+0x1ac>
  for(i = 0; i < N; i++){
    1a8e:	2905                	addiw	s2,s2,1
    1a90:	0ff97913          	zext.b	s2,s2
    1a94:	ff5910e3          	bne	s2,s5,1a74 <createdelete+0x1aa>
}
    1a98:	60ea                	ld	ra,152(sp)
    1a9a:	644a                	ld	s0,144(sp)
    1a9c:	64aa                	ld	s1,136(sp)
    1a9e:	690a                	ld	s2,128(sp)
    1aa0:	79e6                	ld	s3,120(sp)
    1aa2:	7a46                	ld	s4,112(sp)
    1aa4:	7aa6                	ld	s5,104(sp)
    1aa6:	7b06                	ld	s6,96(sp)
    1aa8:	6be6                	ld	s7,88(sp)
    1aaa:	6c46                	ld	s8,80(sp)
    1aac:	6ca6                	ld	s9,72(sp)
    1aae:	6d06                	ld	s10,64(sp)
    1ab0:	7de2                	ld	s11,56(sp)
    1ab2:	610d                	addi	sp,sp,160
    1ab4:	8082                	ret

0000000000001ab6 <linkunlink>:
{
    1ab6:	711d                	addi	sp,sp,-96
    1ab8:	ec86                	sd	ra,88(sp)
    1aba:	e8a2                	sd	s0,80(sp)
    1abc:	e4a6                	sd	s1,72(sp)
    1abe:	e0ca                	sd	s2,64(sp)
    1ac0:	fc4e                	sd	s3,56(sp)
    1ac2:	f852                	sd	s4,48(sp)
    1ac4:	f456                	sd	s5,40(sp)
    1ac6:	f05a                	sd	s6,32(sp)
    1ac8:	ec5e                	sd	s7,24(sp)
    1aca:	e862                	sd	s8,16(sp)
    1acc:	e466                	sd	s9,8(sp)
    1ace:	e06a                	sd	s10,0(sp)
    1ad0:	1080                	addi	s0,sp,96
    1ad2:	84aa                	mv	s1,a0
  unlink("x");
    1ad4:	00004517          	auipc	a0,0x4
    1ad8:	b0450513          	addi	a0,a0,-1276 # 55d8 <malloc+0x19e>
    1adc:	472030ef          	jal	4f4e <unlink>
  pid = fork();
    1ae0:	416030ef          	jal	4ef6 <fork>
  if(pid < 0){
    1ae4:	04054363          	bltz	a0,1b2a <linkunlink+0x74>
    1ae8:	8d2a                	mv	s10,a0
  unsigned int x = (pid ? 1 : 97);
    1aea:	06100913          	li	s2,97
    1aee:	c111                	beqz	a0,1af2 <linkunlink+0x3c>
    1af0:	4905                	li	s2,1
    1af2:	06400493          	li	s1,100
    x = x * 1103515245 + 12345;
    1af6:	41c65ab7          	lui	s5,0x41c65
    1afa:	e6da8a9b          	addiw	s5,s5,-403 # 41c64e6d <base+0x41c561c5>
    1afe:	6a0d                	lui	s4,0x3
    1b00:	039a0a1b          	addiw	s4,s4,57 # 3039 <subdir+0x333>
    if((x % 3) == 0){
    1b04:	000ab9b7          	lui	s3,0xab
    1b08:	aab98993          	addi	s3,s3,-1365 # aaaab <base+0x9be03>
    1b0c:	09b2                	slli	s3,s3,0xc
    1b0e:	aab98993          	addi	s3,s3,-1365
    } else if((x % 3) == 1){
    1b12:	4b85                	li	s7,1
      unlink("x");
    1b14:	00004b17          	auipc	s6,0x4
    1b18:	ac4b0b13          	addi	s6,s6,-1340 # 55d8 <malloc+0x19e>
      link("cat", "x");
    1b1c:	00004c97          	auipc	s9,0x4
    1b20:	534c8c93          	addi	s9,s9,1332 # 6050 <malloc+0xc16>
      close(open("x", O_RDWR | O_CREATE));
    1b24:	20200c13          	li	s8,514
    1b28:	a03d                	j	1b56 <linkunlink+0xa0>
    printf("%s: fork failed\n", s);
    1b2a:	85a6                	mv	a1,s1
    1b2c:	00004517          	auipc	a0,0x4
    1b30:	2cc50513          	addi	a0,a0,716 # 5df8 <malloc+0x9be>
    1b34:	04f030ef          	jal	5382 <printf>
    exit(1);
    1b38:	4505                	li	a0,1
    1b3a:	3c4030ef          	jal	4efe <exit>
      close(open("x", O_RDWR | O_CREATE));
    1b3e:	85e2                	mv	a1,s8
    1b40:	855a                	mv	a0,s6
    1b42:	3fc030ef          	jal	4f3e <open>
    1b46:	3e0030ef          	jal	4f26 <close>
    1b4a:	a021                	j	1b52 <linkunlink+0x9c>
      unlink("x");
    1b4c:	855a                	mv	a0,s6
    1b4e:	400030ef          	jal	4f4e <unlink>
  for(i = 0; i < 100; i++){
    1b52:	34fd                	addiw	s1,s1,-1
    1b54:	c885                	beqz	s1,1b84 <linkunlink+0xce>
    x = x * 1103515245 + 12345;
    1b56:	035907bb          	mulw	a5,s2,s5
    1b5a:	00fa07bb          	addw	a5,s4,a5
    1b5e:	893e                	mv	s2,a5
    if((x % 3) == 0){
    1b60:	02079713          	slli	a4,a5,0x20
    1b64:	9301                	srli	a4,a4,0x20
    1b66:	03370733          	mul	a4,a4,s3
    1b6a:	9305                	srli	a4,a4,0x21
    1b6c:	0017169b          	slliw	a3,a4,0x1
    1b70:	9f35                	addw	a4,a4,a3
    1b72:	9f99                	subw	a5,a5,a4
    1b74:	d7e9                	beqz	a5,1b3e <linkunlink+0x88>
    } else if((x % 3) == 1){
    1b76:	fd779be3          	bne	a5,s7,1b4c <linkunlink+0x96>
      link("cat", "x");
    1b7a:	85da                	mv	a1,s6
    1b7c:	8566                	mv	a0,s9
    1b7e:	3e0030ef          	jal	4f5e <link>
    1b82:	bfc1                	j	1b52 <linkunlink+0x9c>
  if(pid)
    1b84:	020d0363          	beqz	s10,1baa <linkunlink+0xf4>
    wait(0);
    1b88:	4501                	li	a0,0
    1b8a:	37c030ef          	jal	4f06 <wait>
}
    1b8e:	60e6                	ld	ra,88(sp)
    1b90:	6446                	ld	s0,80(sp)
    1b92:	64a6                	ld	s1,72(sp)
    1b94:	6906                	ld	s2,64(sp)
    1b96:	79e2                	ld	s3,56(sp)
    1b98:	7a42                	ld	s4,48(sp)
    1b9a:	7aa2                	ld	s5,40(sp)
    1b9c:	7b02                	ld	s6,32(sp)
    1b9e:	6be2                	ld	s7,24(sp)
    1ba0:	6c42                	ld	s8,16(sp)
    1ba2:	6ca2                	ld	s9,8(sp)
    1ba4:	6d02                	ld	s10,0(sp)
    1ba6:	6125                	addi	sp,sp,96
    1ba8:	8082                	ret
    exit(0);
    1baa:	4501                	li	a0,0
    1bac:	352030ef          	jal	4efe <exit>

0000000000001bb0 <forktest>:
{
    1bb0:	7179                	addi	sp,sp,-48
    1bb2:	f406                	sd	ra,40(sp)
    1bb4:	f022                	sd	s0,32(sp)
    1bb6:	ec26                	sd	s1,24(sp)
    1bb8:	e84a                	sd	s2,16(sp)
    1bba:	e44e                	sd	s3,8(sp)
    1bbc:	1800                	addi	s0,sp,48
    1bbe:	89aa                	mv	s3,a0
  for(n=0; n<N; n++){
    1bc0:	4481                	li	s1,0
    1bc2:	3e800913          	li	s2,1000
    pid = fork();
    1bc6:	330030ef          	jal	4ef6 <fork>
    if(pid < 0)
    1bca:	06054063          	bltz	a0,1c2a <forktest+0x7a>
    if(pid == 0)
    1bce:	cd11                	beqz	a0,1bea <forktest+0x3a>
  for(n=0; n<N; n++){
    1bd0:	2485                	addiw	s1,s1,1
    1bd2:	ff249ae3          	bne	s1,s2,1bc6 <forktest+0x16>
    printf("%s: fork claimed to work 1000 times!\n", s);
    1bd6:	85ce                	mv	a1,s3
    1bd8:	00004517          	auipc	a0,0x4
    1bdc:	4c850513          	addi	a0,a0,1224 # 60a0 <malloc+0xc66>
    1be0:	7a2030ef          	jal	5382 <printf>
    exit(1);
    1be4:	4505                	li	a0,1
    1be6:	318030ef          	jal	4efe <exit>
      exit(0);
    1bea:	314030ef          	jal	4efe <exit>
    printf("%s: no fork at all!\n", s);
    1bee:	85ce                	mv	a1,s3
    1bf0:	00004517          	auipc	a0,0x4
    1bf4:	46850513          	addi	a0,a0,1128 # 6058 <malloc+0xc1e>
    1bf8:	78a030ef          	jal	5382 <printf>
    exit(1);
    1bfc:	4505                	li	a0,1
    1bfe:	300030ef          	jal	4efe <exit>
      printf("%s: wait stopped early\n", s);
    1c02:	85ce                	mv	a1,s3
    1c04:	00004517          	auipc	a0,0x4
    1c08:	46c50513          	addi	a0,a0,1132 # 6070 <malloc+0xc36>
    1c0c:	776030ef          	jal	5382 <printf>
      exit(1);
    1c10:	4505                	li	a0,1
    1c12:	2ec030ef          	jal	4efe <exit>
    printf("%s: wait got too many\n", s);
    1c16:	85ce                	mv	a1,s3
    1c18:	00004517          	auipc	a0,0x4
    1c1c:	47050513          	addi	a0,a0,1136 # 6088 <malloc+0xc4e>
    1c20:	762030ef          	jal	5382 <printf>
    exit(1);
    1c24:	4505                	li	a0,1
    1c26:	2d8030ef          	jal	4efe <exit>
  if (n == 0) {
    1c2a:	d0f1                	beqz	s1,1bee <forktest+0x3e>
  for(; n > 0; n--){
    1c2c:	00905963          	blez	s1,1c3e <forktest+0x8e>
    if(wait(0) < 0){
    1c30:	4501                	li	a0,0
    1c32:	2d4030ef          	jal	4f06 <wait>
    1c36:	fc0546e3          	bltz	a0,1c02 <forktest+0x52>
  for(; n > 0; n--){
    1c3a:	34fd                	addiw	s1,s1,-1
    1c3c:	f8f5                	bnez	s1,1c30 <forktest+0x80>
  if(wait(0) != -1){
    1c3e:	4501                	li	a0,0
    1c40:	2c6030ef          	jal	4f06 <wait>
    1c44:	57fd                	li	a5,-1
    1c46:	fcf518e3          	bne	a0,a5,1c16 <forktest+0x66>
}
    1c4a:	70a2                	ld	ra,40(sp)
    1c4c:	7402                	ld	s0,32(sp)
    1c4e:	64e2                	ld	s1,24(sp)
    1c50:	6942                	ld	s2,16(sp)
    1c52:	69a2                	ld	s3,8(sp)
    1c54:	6145                	addi	sp,sp,48
    1c56:	8082                	ret

0000000000001c58 <kernmem>:
{
    1c58:	715d                	addi	sp,sp,-80
    1c5a:	e486                	sd	ra,72(sp)
    1c5c:	e0a2                	sd	s0,64(sp)
    1c5e:	fc26                	sd	s1,56(sp)
    1c60:	f84a                	sd	s2,48(sp)
    1c62:	f44e                	sd	s3,40(sp)
    1c64:	f052                	sd	s4,32(sp)
    1c66:	ec56                	sd	s5,24(sp)
    1c68:	e85a                	sd	s6,16(sp)
    1c6a:	0880                	addi	s0,sp,80
    1c6c:	8b2a                	mv	s6,a0
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    1c6e:	4485                	li	s1,1
    1c70:	04fe                	slli	s1,s1,0x1f
    wait(&xstatus);
    1c72:	fbc40a93          	addi	s5,s0,-68
    if(xstatus != -1)  // did kernel kill child?
    1c76:	5a7d                	li	s4,-1
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    1c78:	69b1                	lui	s3,0xc
    1c7a:	35098993          	addi	s3,s3,848 # c350 <buf+0x6a8>
    1c7e:	1003d937          	lui	s2,0x1003d
    1c82:	090e                	slli	s2,s2,0x3
    1c84:	48090913          	addi	s2,s2,1152 # 1003d480 <base+0x1002e7d8>
    pid = fork();
    1c88:	26e030ef          	jal	4ef6 <fork>
    if(pid < 0){
    1c8c:	02054763          	bltz	a0,1cba <kernmem+0x62>
    if(pid == 0){
    1c90:	cd1d                	beqz	a0,1cce <kernmem+0x76>
    wait(&xstatus);
    1c92:	8556                	mv	a0,s5
    1c94:	272030ef          	jal	4f06 <wait>
    if(xstatus != -1)  // did kernel kill child?
    1c98:	fbc42783          	lw	a5,-68(s0)
    1c9c:	05479663          	bne	a5,s4,1ce8 <kernmem+0x90>
  for(a = (char*)(KERNBASE); a < (char*) (KERNBASE+2000000); a += 50000){
    1ca0:	94ce                	add	s1,s1,s3
    1ca2:	ff2493e3          	bne	s1,s2,1c88 <kernmem+0x30>
}
    1ca6:	60a6                	ld	ra,72(sp)
    1ca8:	6406                	ld	s0,64(sp)
    1caa:	74e2                	ld	s1,56(sp)
    1cac:	7942                	ld	s2,48(sp)
    1cae:	79a2                	ld	s3,40(sp)
    1cb0:	7a02                	ld	s4,32(sp)
    1cb2:	6ae2                	ld	s5,24(sp)
    1cb4:	6b42                	ld	s6,16(sp)
    1cb6:	6161                	addi	sp,sp,80
    1cb8:	8082                	ret
      printf("%s: fork failed\n", s);
    1cba:	85da                	mv	a1,s6
    1cbc:	00004517          	auipc	a0,0x4
    1cc0:	13c50513          	addi	a0,a0,316 # 5df8 <malloc+0x9be>
    1cc4:	6be030ef          	jal	5382 <printf>
      exit(1);
    1cc8:	4505                	li	a0,1
    1cca:	234030ef          	jal	4efe <exit>
      printf("%s: oops could read %p = %x\n", s, a, *a);
    1cce:	0004c683          	lbu	a3,0(s1)
    1cd2:	8626                	mv	a2,s1
    1cd4:	85da                	mv	a1,s6
    1cd6:	00004517          	auipc	a0,0x4
    1cda:	3f250513          	addi	a0,a0,1010 # 60c8 <malloc+0xc8e>
    1cde:	6a4030ef          	jal	5382 <printf>
      exit(1);
    1ce2:	4505                	li	a0,1
    1ce4:	21a030ef          	jal	4efe <exit>
      exit(1);
    1ce8:	4505                	li	a0,1
    1cea:	214030ef          	jal	4efe <exit>

0000000000001cee <MAXVAplus>:
{
    1cee:	7139                	addi	sp,sp,-64
    1cf0:	fc06                	sd	ra,56(sp)
    1cf2:	f822                	sd	s0,48(sp)
    1cf4:	0080                	addi	s0,sp,64
  volatile uint64 a = MAXVA;
    1cf6:	4785                	li	a5,1
    1cf8:	179a                	slli	a5,a5,0x26
    1cfa:	fcf43423          	sd	a5,-56(s0)
  for( ; a != 0; a <<= 1){
    1cfe:	fc843783          	ld	a5,-56(s0)
    1d02:	cf9d                	beqz	a5,1d40 <MAXVAplus+0x52>
    1d04:	f426                	sd	s1,40(sp)
    1d06:	f04a                	sd	s2,32(sp)
    1d08:	ec4e                	sd	s3,24(sp)
    1d0a:	89aa                	mv	s3,a0
    wait(&xstatus);
    1d0c:	fc440913          	addi	s2,s0,-60
    if(xstatus != -1)  // did kernel kill child?
    1d10:	54fd                	li	s1,-1
    pid = fork();
    1d12:	1e4030ef          	jal	4ef6 <fork>
    if(pid < 0){
    1d16:	02054963          	bltz	a0,1d48 <MAXVAplus+0x5a>
    if(pid == 0){
    1d1a:	c129                	beqz	a0,1d5c <MAXVAplus+0x6e>
    wait(&xstatus);
    1d1c:	854a                	mv	a0,s2
    1d1e:	1e8030ef          	jal	4f06 <wait>
    if(xstatus != -1)  // did kernel kill child?
    1d22:	fc442783          	lw	a5,-60(s0)
    1d26:	04979d63          	bne	a5,s1,1d80 <MAXVAplus+0x92>
  for( ; a != 0; a <<= 1){
    1d2a:	fc843783          	ld	a5,-56(s0)
    1d2e:	0786                	slli	a5,a5,0x1
    1d30:	fcf43423          	sd	a5,-56(s0)
    1d34:	fc843783          	ld	a5,-56(s0)
    1d38:	ffe9                	bnez	a5,1d12 <MAXVAplus+0x24>
    1d3a:	74a2                	ld	s1,40(sp)
    1d3c:	7902                	ld	s2,32(sp)
    1d3e:	69e2                	ld	s3,24(sp)
}
    1d40:	70e2                	ld	ra,56(sp)
    1d42:	7442                	ld	s0,48(sp)
    1d44:	6121                	addi	sp,sp,64
    1d46:	8082                	ret
      printf("%s: fork failed\n", s);
    1d48:	85ce                	mv	a1,s3
    1d4a:	00004517          	auipc	a0,0x4
    1d4e:	0ae50513          	addi	a0,a0,174 # 5df8 <malloc+0x9be>
    1d52:	630030ef          	jal	5382 <printf>
      exit(1);
    1d56:	4505                	li	a0,1
    1d58:	1a6030ef          	jal	4efe <exit>
      *(char*)a = 99;
    1d5c:	fc843783          	ld	a5,-56(s0)
    1d60:	06300713          	li	a4,99
    1d64:	00e78023          	sb	a4,0(a5)
      printf("%s: oops wrote %p\n", s, (void*)a);
    1d68:	fc843603          	ld	a2,-56(s0)
    1d6c:	85ce                	mv	a1,s3
    1d6e:	00004517          	auipc	a0,0x4
    1d72:	37a50513          	addi	a0,a0,890 # 60e8 <malloc+0xcae>
    1d76:	60c030ef          	jal	5382 <printf>
      exit(1);
    1d7a:	4505                	li	a0,1
    1d7c:	182030ef          	jal	4efe <exit>
      exit(1);
    1d80:	4505                	li	a0,1
    1d82:	17c030ef          	jal	4efe <exit>

0000000000001d86 <stacktest>:
{
    1d86:	7179                	addi	sp,sp,-48
    1d88:	f406                	sd	ra,40(sp)
    1d8a:	f022                	sd	s0,32(sp)
    1d8c:	ec26                	sd	s1,24(sp)
    1d8e:	1800                	addi	s0,sp,48
    1d90:	84aa                	mv	s1,a0
  pid = fork();
    1d92:	164030ef          	jal	4ef6 <fork>
  if(pid == 0) {
    1d96:	cd11                	beqz	a0,1db2 <stacktest+0x2c>
  } else if(pid < 0){
    1d98:	02054c63          	bltz	a0,1dd0 <stacktest+0x4a>
  wait(&xstatus);
    1d9c:	fdc40513          	addi	a0,s0,-36
    1da0:	166030ef          	jal	4f06 <wait>
  if(xstatus == -1)  // kernel killed child?
    1da4:	fdc42503          	lw	a0,-36(s0)
    1da8:	57fd                	li	a5,-1
    1daa:	02f50d63          	beq	a0,a5,1de4 <stacktest+0x5e>
    exit(xstatus);
    1dae:	150030ef          	jal	4efe <exit>

static inline uint64
r_sp()
{
  uint64 x;
  asm volatile("mv %0, sp" : "=r" (x) );
    1db2:	878a                	mv	a5,sp
    printf("%s: stacktest: read below stack %d\n", s, *sp);
    1db4:	80078793          	addi	a5,a5,-2048
    1db8:	8007c603          	lbu	a2,-2048(a5)
    1dbc:	85a6                	mv	a1,s1
    1dbe:	00004517          	auipc	a0,0x4
    1dc2:	34250513          	addi	a0,a0,834 # 6100 <malloc+0xcc6>
    1dc6:	5bc030ef          	jal	5382 <printf>
    exit(1);
    1dca:	4505                	li	a0,1
    1dcc:	132030ef          	jal	4efe <exit>
    printf("%s: fork failed\n", s);
    1dd0:	85a6                	mv	a1,s1
    1dd2:	00004517          	auipc	a0,0x4
    1dd6:	02650513          	addi	a0,a0,38 # 5df8 <malloc+0x9be>
    1dda:	5a8030ef          	jal	5382 <printf>
    exit(1);
    1dde:	4505                	li	a0,1
    1de0:	11e030ef          	jal	4efe <exit>
    exit(0);
    1de4:	4501                	li	a0,0
    1de6:	118030ef          	jal	4efe <exit>

0000000000001dea <nowrite>:
{
    1dea:	7159                	addi	sp,sp,-112
    1dec:	f486                	sd	ra,104(sp)
    1dee:	f0a2                	sd	s0,96(sp)
    1df0:	eca6                	sd	s1,88(sp)
    1df2:	e8ca                	sd	s2,80(sp)
    1df4:	e4ce                	sd	s3,72(sp)
    1df6:	e0d2                	sd	s4,64(sp)
    1df8:	1880                	addi	s0,sp,112
    1dfa:	8a2a                	mv	s4,a0
  uint64 addrs[] = { 0, 0x80000000LL, 0x3fffffe000, 0x3ffffff000, 0x4000000000,
    1dfc:	00006797          	auipc	a5,0x6
    1e00:	bbc78793          	addi	a5,a5,-1092 # 79b8 <malloc+0x257e>
    1e04:	7788                	ld	a0,40(a5)
    1e06:	7b8c                	ld	a1,48(a5)
    1e08:	7f90                	ld	a2,56(a5)
    1e0a:	63b4                	ld	a3,64(a5)
    1e0c:	67b8                	ld	a4,72(a5)
    1e0e:	f8a43c23          	sd	a0,-104(s0)
    1e12:	fab43023          	sd	a1,-96(s0)
    1e16:	fac43423          	sd	a2,-88(s0)
    1e1a:	fad43823          	sd	a3,-80(s0)
    1e1e:	fae43c23          	sd	a4,-72(s0)
    1e22:	6bbc                	ld	a5,80(a5)
    1e24:	fcf43023          	sd	a5,-64(s0)
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
    1e28:	4481                	li	s1,0
    wait(&xstatus);
    1e2a:	fcc40913          	addi	s2,s0,-52
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
    1e2e:	4999                	li	s3,6
    pid = fork();
    1e30:	0c6030ef          	jal	4ef6 <fork>
    if(pid == 0) {
    1e34:	cd19                	beqz	a0,1e52 <nowrite+0x68>
    } else if(pid < 0){
    1e36:	04054163          	bltz	a0,1e78 <nowrite+0x8e>
    wait(&xstatus);
    1e3a:	854a                	mv	a0,s2
    1e3c:	0ca030ef          	jal	4f06 <wait>
    if(xstatus == 0){
    1e40:	fcc42783          	lw	a5,-52(s0)
    1e44:	c7a1                	beqz	a5,1e8c <nowrite+0xa2>
  for(int ai = 0; ai < sizeof(addrs)/sizeof(addrs[0]); ai++){
    1e46:	2485                	addiw	s1,s1,1
    1e48:	ff3494e3          	bne	s1,s3,1e30 <nowrite+0x46>
  exit(0);
    1e4c:	4501                	li	a0,0
    1e4e:	0b0030ef          	jal	4efe <exit>
      volatile int *addr = (int *) addrs[ai];
    1e52:	048e                	slli	s1,s1,0x3
    1e54:	fd048793          	addi	a5,s1,-48
    1e58:	008784b3          	add	s1,a5,s0
    1e5c:	fc84b603          	ld	a2,-56(s1)
      *addr = 10;
    1e60:	47a9                	li	a5,10
    1e62:	c21c                	sw	a5,0(a2)
      printf("%s: write to %p did not fail!\n", s, addr);
    1e64:	85d2                	mv	a1,s4
    1e66:	00004517          	auipc	a0,0x4
    1e6a:	2c250513          	addi	a0,a0,706 # 6128 <malloc+0xcee>
    1e6e:	514030ef          	jal	5382 <printf>
      exit(0);
    1e72:	4501                	li	a0,0
    1e74:	08a030ef          	jal	4efe <exit>
      printf("%s: fork failed\n", s);
    1e78:	85d2                	mv	a1,s4
    1e7a:	00004517          	auipc	a0,0x4
    1e7e:	f7e50513          	addi	a0,a0,-130 # 5df8 <malloc+0x9be>
    1e82:	500030ef          	jal	5382 <printf>
      exit(1);
    1e86:	4505                	li	a0,1
    1e88:	076030ef          	jal	4efe <exit>
      exit(1);
    1e8c:	4505                	li	a0,1
    1e8e:	070030ef          	jal	4efe <exit>

0000000000001e92 <manywrites>:
{
    1e92:	7159                	addi	sp,sp,-112
    1e94:	f486                	sd	ra,104(sp)
    1e96:	f0a2                	sd	s0,96(sp)
    1e98:	eca6                	sd	s1,88(sp)
    1e9a:	e8ca                	sd	s2,80(sp)
    1e9c:	e4ce                	sd	s3,72(sp)
    1e9e:	ec66                	sd	s9,24(sp)
    1ea0:	1880                	addi	s0,sp,112
    1ea2:	8caa                	mv	s9,a0
  for(int ci = 0; ci < nchildren; ci++){
    1ea4:	4901                	li	s2,0
    1ea6:	4991                	li	s3,4
    int pid = fork();
    1ea8:	04e030ef          	jal	4ef6 <fork>
    1eac:	84aa                	mv	s1,a0
    if(pid < 0){
    1eae:	02054c63          	bltz	a0,1ee6 <manywrites+0x54>
    if(pid == 0){
    1eb2:	c929                	beqz	a0,1f04 <manywrites+0x72>
  for(int ci = 0; ci < nchildren; ci++){
    1eb4:	2905                	addiw	s2,s2,1
    1eb6:	ff3919e3          	bne	s2,s3,1ea8 <manywrites+0x16>
    1eba:	4491                	li	s1,4
    wait(&st);
    1ebc:	f9840913          	addi	s2,s0,-104
    int st = 0;
    1ec0:	f8042c23          	sw	zero,-104(s0)
    wait(&st);
    1ec4:	854a                	mv	a0,s2
    1ec6:	040030ef          	jal	4f06 <wait>
    if(st != 0)
    1eca:	f9842503          	lw	a0,-104(s0)
    1ece:	0e051763          	bnez	a0,1fbc <manywrites+0x12a>
  for(int ci = 0; ci < nchildren; ci++){
    1ed2:	34fd                	addiw	s1,s1,-1
    1ed4:	f4f5                	bnez	s1,1ec0 <manywrites+0x2e>
    1ed6:	e0d2                	sd	s4,64(sp)
    1ed8:	fc56                	sd	s5,56(sp)
    1eda:	f85a                	sd	s6,48(sp)
    1edc:	f45e                	sd	s7,40(sp)
    1ede:	f062                	sd	s8,32(sp)
    1ee0:	e86a                	sd	s10,16(sp)
  exit(0);
    1ee2:	01c030ef          	jal	4efe <exit>
    1ee6:	e0d2                	sd	s4,64(sp)
    1ee8:	fc56                	sd	s5,56(sp)
    1eea:	f85a                	sd	s6,48(sp)
    1eec:	f45e                	sd	s7,40(sp)
    1eee:	f062                	sd	s8,32(sp)
    1ef0:	e86a                	sd	s10,16(sp)
      printf("fork failed\n");
    1ef2:	00005517          	auipc	a0,0x5
    1ef6:	4ae50513          	addi	a0,a0,1198 # 73a0 <malloc+0x1f66>
    1efa:	488030ef          	jal	5382 <printf>
      exit(1);
    1efe:	4505                	li	a0,1
    1f00:	7ff020ef          	jal	4efe <exit>
    1f04:	e0d2                	sd	s4,64(sp)
    1f06:	fc56                	sd	s5,56(sp)
    1f08:	f85a                	sd	s6,48(sp)
    1f0a:	f45e                	sd	s7,40(sp)
    1f0c:	f062                	sd	s8,32(sp)
    1f0e:	e86a                	sd	s10,16(sp)
      name[0] = 'b';
    1f10:	06200793          	li	a5,98
    1f14:	f8f40c23          	sb	a5,-104(s0)
      name[1] = 'a' + ci;
    1f18:	0619079b          	addiw	a5,s2,97
    1f1c:	f8f40ca3          	sb	a5,-103(s0)
      name[2] = '\0';
    1f20:	f8040d23          	sb	zero,-102(s0)
      unlink(name);
    1f24:	f9840513          	addi	a0,s0,-104
    1f28:	026030ef          	jal	4f4e <unlink>
    1f2c:	47f9                	li	a5,30
    1f2e:	8d3e                	mv	s10,a5
          int fd = open(name, O_CREATE | O_RDWR);
    1f30:	f9840b93          	addi	s7,s0,-104
    1f34:	20200b13          	li	s6,514
          int cc = write(fd, buf, sz);
    1f38:	6a8d                	lui	s5,0x3
    1f3a:	0000ac17          	auipc	s8,0xa
    1f3e:	d6ec0c13          	addi	s8,s8,-658 # bca8 <buf>
        for(int i = 0; i < ci+1; i++){
    1f42:	8a26                	mv	s4,s1
    1f44:	02094563          	bltz	s2,1f6e <manywrites+0xdc>
          int fd = open(name, O_CREATE | O_RDWR);
    1f48:	85da                	mv	a1,s6
    1f4a:	855e                	mv	a0,s7
    1f4c:	7f3020ef          	jal	4f3e <open>
    1f50:	89aa                	mv	s3,a0
          if(fd < 0){
    1f52:	02054d63          	bltz	a0,1f8c <manywrites+0xfa>
          int cc = write(fd, buf, sz);
    1f56:	8656                	mv	a2,s5
    1f58:	85e2                	mv	a1,s8
    1f5a:	7c5020ef          	jal	4f1e <write>
          if(cc != sz){
    1f5e:	05551363          	bne	a0,s5,1fa4 <manywrites+0x112>
          close(fd);
    1f62:	854e                	mv	a0,s3
    1f64:	7c3020ef          	jal	4f26 <close>
        for(int i = 0; i < ci+1; i++){
    1f68:	2a05                	addiw	s4,s4,1
    1f6a:	fd495fe3          	bge	s2,s4,1f48 <manywrites+0xb6>
        unlink(name);
    1f6e:	f9840513          	addi	a0,s0,-104
    1f72:	7dd020ef          	jal	4f4e <unlink>
      for(int iters = 0; iters < howmany; iters++){
    1f76:	fffd079b          	addiw	a5,s10,-1
    1f7a:	8d3e                	mv	s10,a5
    1f7c:	f3f9                	bnez	a5,1f42 <manywrites+0xb0>
      unlink(name);
    1f7e:	f9840513          	addi	a0,s0,-104
    1f82:	7cd020ef          	jal	4f4e <unlink>
      exit(0);
    1f86:	4501                	li	a0,0
    1f88:	777020ef          	jal	4efe <exit>
            printf("%s: cannot create %s\n", s, name);
    1f8c:	f9840613          	addi	a2,s0,-104
    1f90:	85e6                	mv	a1,s9
    1f92:	00004517          	auipc	a0,0x4
    1f96:	1b650513          	addi	a0,a0,438 # 6148 <malloc+0xd0e>
    1f9a:	3e8030ef          	jal	5382 <printf>
            exit(1);
    1f9e:	4505                	li	a0,1
    1fa0:	75f020ef          	jal	4efe <exit>
            printf("%s: write(%d) ret %d\n", s, sz, cc);
    1fa4:	86aa                	mv	a3,a0
    1fa6:	660d                	lui	a2,0x3
    1fa8:	85e6                	mv	a1,s9
    1faa:	00003517          	auipc	a0,0x3
    1fae:	68e50513          	addi	a0,a0,1678 # 5638 <malloc+0x1fe>
    1fb2:	3d0030ef          	jal	5382 <printf>
            exit(1);
    1fb6:	4505                	li	a0,1
    1fb8:	747020ef          	jal	4efe <exit>
    1fbc:	e0d2                	sd	s4,64(sp)
    1fbe:	fc56                	sd	s5,56(sp)
    1fc0:	f85a                	sd	s6,48(sp)
    1fc2:	f45e                	sd	s7,40(sp)
    1fc4:	f062                	sd	s8,32(sp)
    1fc6:	e86a                	sd	s10,16(sp)
      exit(st);
    1fc8:	737020ef          	jal	4efe <exit>

0000000000001fcc <copyinstr3>:
{
    1fcc:	7179                	addi	sp,sp,-48
    1fce:	f406                	sd	ra,40(sp)
    1fd0:	f022                	sd	s0,32(sp)
    1fd2:	ec26                	sd	s1,24(sp)
    1fd4:	1800                	addi	s0,sp,48
  sbrk(8192);
    1fd6:	6509                	lui	a0,0x2
    1fd8:	6f3020ef          	jal	4eca <sbrk>
  uint64 top = (uint64) sbrk(0);
    1fdc:	4501                	li	a0,0
    1fde:	6ed020ef          	jal	4eca <sbrk>
  if((top % PGSIZE) != 0){
    1fe2:	03451793          	slli	a5,a0,0x34
    1fe6:	e7bd                	bnez	a5,2054 <copyinstr3+0x88>
  top = (uint64) sbrk(0);
    1fe8:	4501                	li	a0,0
    1fea:	6e1020ef          	jal	4eca <sbrk>
  if(top % PGSIZE){
    1fee:	03451793          	slli	a5,a0,0x34
    1ff2:	ebad                	bnez	a5,2064 <copyinstr3+0x98>
  char *b = (char *) (top - 1);
    1ff4:	fff50493          	addi	s1,a0,-1 # 1fff <copyinstr3+0x33>
  *b = 'x';
    1ff8:	07800793          	li	a5,120
    1ffc:	fef50fa3          	sb	a5,-1(a0)
  int ret = unlink(b);
    2000:	8526                	mv	a0,s1
    2002:	74d020ef          	jal	4f4e <unlink>
  if(ret != -1){
    2006:	57fd                	li	a5,-1
    2008:	06f51763          	bne	a0,a5,2076 <copyinstr3+0xaa>
  int fd = open(b, O_CREATE | O_WRONLY);
    200c:	20100593          	li	a1,513
    2010:	8526                	mv	a0,s1
    2012:	72d020ef          	jal	4f3e <open>
  if(fd != -1){
    2016:	57fd                	li	a5,-1
    2018:	06f51a63          	bne	a0,a5,208c <copyinstr3+0xc0>
  ret = link(b, b);
    201c:	85a6                	mv	a1,s1
    201e:	8526                	mv	a0,s1
    2020:	73f020ef          	jal	4f5e <link>
  if(ret != -1){
    2024:	57fd                	li	a5,-1
    2026:	06f51e63          	bne	a0,a5,20a2 <copyinstr3+0xd6>
  char *args[] = { "xx", 0 };
    202a:	00005797          	auipc	a5,0x5
    202e:	e1e78793          	addi	a5,a5,-482 # 6e48 <malloc+0x1a0e>
    2032:	fcf43823          	sd	a5,-48(s0)
    2036:	fc043c23          	sd	zero,-40(s0)
  ret = exec(b, args);
    203a:	fd040593          	addi	a1,s0,-48
    203e:	8526                	mv	a0,s1
    2040:	6f7020ef          	jal	4f36 <exec>
  if(ret != -1){
    2044:	57fd                	li	a5,-1
    2046:	06f51a63          	bne	a0,a5,20ba <copyinstr3+0xee>
}
    204a:	70a2                	ld	ra,40(sp)
    204c:	7402                	ld	s0,32(sp)
    204e:	64e2                	ld	s1,24(sp)
    2050:	6145                	addi	sp,sp,48
    2052:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    2054:	0347d513          	srli	a0,a5,0x34
    2058:	6785                	lui	a5,0x1
    205a:	40a7853b          	subw	a0,a5,a0
    205e:	66d020ef          	jal	4eca <sbrk>
    2062:	b759                	j	1fe8 <copyinstr3+0x1c>
    printf("oops\n");
    2064:	00004517          	auipc	a0,0x4
    2068:	0fc50513          	addi	a0,a0,252 # 6160 <malloc+0xd26>
    206c:	316030ef          	jal	5382 <printf>
    exit(1);
    2070:	4505                	li	a0,1
    2072:	68d020ef          	jal	4efe <exit>
    printf("unlink(%s) returned %d, not -1\n", b, ret);
    2076:	862a                	mv	a2,a0
    2078:	85a6                	mv	a1,s1
    207a:	00004517          	auipc	a0,0x4
    207e:	c9e50513          	addi	a0,a0,-866 # 5d18 <malloc+0x8de>
    2082:	300030ef          	jal	5382 <printf>
    exit(1);
    2086:	4505                	li	a0,1
    2088:	677020ef          	jal	4efe <exit>
    printf("open(%s) returned %d, not -1\n", b, fd);
    208c:	862a                	mv	a2,a0
    208e:	85a6                	mv	a1,s1
    2090:	00004517          	auipc	a0,0x4
    2094:	ca850513          	addi	a0,a0,-856 # 5d38 <malloc+0x8fe>
    2098:	2ea030ef          	jal	5382 <printf>
    exit(1);
    209c:	4505                	li	a0,1
    209e:	661020ef          	jal	4efe <exit>
    printf("link(%s, %s) returned %d, not -1\n", b, b, ret);
    20a2:	86aa                	mv	a3,a0
    20a4:	8626                	mv	a2,s1
    20a6:	85a6                	mv	a1,s1
    20a8:	00004517          	auipc	a0,0x4
    20ac:	cb050513          	addi	a0,a0,-848 # 5d58 <malloc+0x91e>
    20b0:	2d2030ef          	jal	5382 <printf>
    exit(1);
    20b4:	4505                	li	a0,1
    20b6:	649020ef          	jal	4efe <exit>
    printf("exec(%s) returned %d, not -1\n", b, fd);
    20ba:	863e                	mv	a2,a5
    20bc:	85a6                	mv	a1,s1
    20be:	00004517          	auipc	a0,0x4
    20c2:	cc250513          	addi	a0,a0,-830 # 5d80 <malloc+0x946>
    20c6:	2bc030ef          	jal	5382 <printf>
    exit(1);
    20ca:	4505                	li	a0,1
    20cc:	633020ef          	jal	4efe <exit>

00000000000020d0 <rwsbrk>:
{
    20d0:	1101                	addi	sp,sp,-32
    20d2:	ec06                	sd	ra,24(sp)
    20d4:	e822                	sd	s0,16(sp)
    20d6:	1000                	addi	s0,sp,32
  uint64 a = (uint64) sbrk(8192);
    20d8:	6509                	lui	a0,0x2
    20da:	5f1020ef          	jal	4eca <sbrk>
  if(a == (uint64) SBRK_ERROR) {
    20de:	57fd                	li	a5,-1
    20e0:	04f50a63          	beq	a0,a5,2134 <rwsbrk+0x64>
    20e4:	e426                	sd	s1,8(sp)
    20e6:	84aa                	mv	s1,a0
  if (sbrk(-8192) == SBRK_ERROR) {
    20e8:	7579                	lui	a0,0xffffe
    20ea:	5e1020ef          	jal	4eca <sbrk>
    20ee:	57fd                	li	a5,-1
    20f0:	04f50d63          	beq	a0,a5,214a <rwsbrk+0x7a>
    20f4:	e04a                	sd	s2,0(sp)
  fd = open("rwsbrk", O_CREATE|O_WRONLY);
    20f6:	20100593          	li	a1,513
    20fa:	00004517          	auipc	a0,0x4
    20fe:	0a650513          	addi	a0,a0,166 # 61a0 <malloc+0xd66>
    2102:	63d020ef          	jal	4f3e <open>
    2106:	892a                	mv	s2,a0
  if(fd < 0){
    2108:	04054b63          	bltz	a0,215e <rwsbrk+0x8e>
  n = write(fd, (void*)(a+PGSIZE), 1024);
    210c:	6785                	lui	a5,0x1
    210e:	94be                	add	s1,s1,a5
    2110:	40000613          	li	a2,1024
    2114:	85a6                	mv	a1,s1
    2116:	609020ef          	jal	4f1e <write>
    211a:	862a                	mv	a2,a0
  if(n >= 0){
    211c:	04054a63          	bltz	a0,2170 <rwsbrk+0xa0>
    printf("write(fd, %p, 1024) returned %d, not -1\n", (void*)a+PGSIZE, n);
    2120:	85a6                	mv	a1,s1
    2122:	00004517          	auipc	a0,0x4
    2126:	09e50513          	addi	a0,a0,158 # 61c0 <malloc+0xd86>
    212a:	258030ef          	jal	5382 <printf>
    exit(1);
    212e:	4505                	li	a0,1
    2130:	5cf020ef          	jal	4efe <exit>
    2134:	e426                	sd	s1,8(sp)
    2136:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) failed\n");
    2138:	00004517          	auipc	a0,0x4
    213c:	03050513          	addi	a0,a0,48 # 6168 <malloc+0xd2e>
    2140:	242030ef          	jal	5382 <printf>
    exit(1);
    2144:	4505                	li	a0,1
    2146:	5b9020ef          	jal	4efe <exit>
    214a:	e04a                	sd	s2,0(sp)
    printf("sbrk(rwsbrk) shrink failed\n");
    214c:	00004517          	auipc	a0,0x4
    2150:	03450513          	addi	a0,a0,52 # 6180 <malloc+0xd46>
    2154:	22e030ef          	jal	5382 <printf>
    exit(1);
    2158:	4505                	li	a0,1
    215a:	5a5020ef          	jal	4efe <exit>
    printf("open(rwsbrk) failed\n");
    215e:	00004517          	auipc	a0,0x4
    2162:	04a50513          	addi	a0,a0,74 # 61a8 <malloc+0xd6e>
    2166:	21c030ef          	jal	5382 <printf>
    exit(1);
    216a:	4505                	li	a0,1
    216c:	593020ef          	jal	4efe <exit>
  close(fd);
    2170:	854a                	mv	a0,s2
    2172:	5b5020ef          	jal	4f26 <close>
  unlink("rwsbrk");
    2176:	00004517          	auipc	a0,0x4
    217a:	02a50513          	addi	a0,a0,42 # 61a0 <malloc+0xd66>
    217e:	5d1020ef          	jal	4f4e <unlink>
  fd = open("README", O_RDONLY);
    2182:	4581                	li	a1,0
    2184:	00003517          	auipc	a0,0x3
    2188:	5bc50513          	addi	a0,a0,1468 # 5740 <malloc+0x306>
    218c:	5b3020ef          	jal	4f3e <open>
    2190:	892a                	mv	s2,a0
  if(fd < 0){
    2192:	02054363          	bltz	a0,21b8 <rwsbrk+0xe8>
  n = read(fd, (void*)(a+PGSIZE), 10);
    2196:	4629                	li	a2,10
    2198:	85a6                	mv	a1,s1
    219a:	57d020ef          	jal	4f16 <read>
    219e:	862a                	mv	a2,a0
  if(n >= 0){
    21a0:	02054563          	bltz	a0,21ca <rwsbrk+0xfa>
    printf("read(fd, %p, 10) returned %d, not -1\n", (void*)a+PGSIZE, n);
    21a4:	85a6                	mv	a1,s1
    21a6:	00004517          	auipc	a0,0x4
    21aa:	04a50513          	addi	a0,a0,74 # 61f0 <malloc+0xdb6>
    21ae:	1d4030ef          	jal	5382 <printf>
    exit(1);
    21b2:	4505                	li	a0,1
    21b4:	54b020ef          	jal	4efe <exit>
    printf("open(README) failed\n");
    21b8:	00003517          	auipc	a0,0x3
    21bc:	59050513          	addi	a0,a0,1424 # 5748 <malloc+0x30e>
    21c0:	1c2030ef          	jal	5382 <printf>
    exit(1);
    21c4:	4505                	li	a0,1
    21c6:	539020ef          	jal	4efe <exit>
  close(fd);
    21ca:	854a                	mv	a0,s2
    21cc:	55b020ef          	jal	4f26 <close>
  exit(0);
    21d0:	4501                	li	a0,0
    21d2:	52d020ef          	jal	4efe <exit>

00000000000021d6 <sbrkbasic>:
{
    21d6:	715d                	addi	sp,sp,-80
    21d8:	e486                	sd	ra,72(sp)
    21da:	e0a2                	sd	s0,64(sp)
    21dc:	ec56                	sd	s5,24(sp)
    21de:	0880                	addi	s0,sp,80
    21e0:	8aaa                	mv	s5,a0
  pid = fork();
    21e2:	515020ef          	jal	4ef6 <fork>
  if(pid < 0){
    21e6:	02054c63          	bltz	a0,221e <sbrkbasic+0x48>
  if(pid == 0){
    21ea:	ed31                	bnez	a0,2246 <sbrkbasic+0x70>
    a = sbrk(TOOMUCH);
    21ec:	40000537          	lui	a0,0x40000
    21f0:	4db020ef          	jal	4eca <sbrk>
    if(a == (char*)SBRK_ERROR){
    21f4:	57fd                	li	a5,-1
    21f6:	04f50163          	beq	a0,a5,2238 <sbrkbasic+0x62>
    21fa:	fc26                	sd	s1,56(sp)
    21fc:	f84a                	sd	s2,48(sp)
    21fe:	f44e                	sd	s3,40(sp)
    2200:	f052                	sd	s4,32(sp)
    for(b = a; b < a+TOOMUCH; b += PGSIZE){
    2202:	400007b7          	lui	a5,0x40000
    2206:	97aa                	add	a5,a5,a0
      *b = 99;
    2208:	06300693          	li	a3,99
    for(b = a; b < a+TOOMUCH; b += PGSIZE){
    220c:	6705                	lui	a4,0x1
      *b = 99;
    220e:	00d50023          	sb	a3,0(a0) # 40000000 <base+0x3fff1358>
    for(b = a; b < a+TOOMUCH; b += PGSIZE){
    2212:	953a                	add	a0,a0,a4
    2214:	fef51de3          	bne	a0,a5,220e <sbrkbasic+0x38>
    exit(1);
    2218:	4505                	li	a0,1
    221a:	4e5020ef          	jal	4efe <exit>
    221e:	fc26                	sd	s1,56(sp)
    2220:	f84a                	sd	s2,48(sp)
    2222:	f44e                	sd	s3,40(sp)
    2224:	f052                	sd	s4,32(sp)
    printf("fork failed in sbrkbasic\n");
    2226:	00004517          	auipc	a0,0x4
    222a:	ff250513          	addi	a0,a0,-14 # 6218 <malloc+0xdde>
    222e:	154030ef          	jal	5382 <printf>
    exit(1);
    2232:	4505                	li	a0,1
    2234:	4cb020ef          	jal	4efe <exit>
    2238:	fc26                	sd	s1,56(sp)
    223a:	f84a                	sd	s2,48(sp)
    223c:	f44e                	sd	s3,40(sp)
    223e:	f052                	sd	s4,32(sp)
      exit(0);
    2240:	4501                	li	a0,0
    2242:	4bd020ef          	jal	4efe <exit>
  wait(&xstatus);
    2246:	fbc40513          	addi	a0,s0,-68
    224a:	4bd020ef          	jal	4f06 <wait>
  if(xstatus == 1){
    224e:	fbc42703          	lw	a4,-68(s0)
    2252:	4785                	li	a5,1
    2254:	02f70063          	beq	a4,a5,2274 <sbrkbasic+0x9e>
    2258:	fc26                	sd	s1,56(sp)
    225a:	f84a                	sd	s2,48(sp)
    225c:	f44e                	sd	s3,40(sp)
    225e:	f052                	sd	s4,32(sp)
  a = sbrk(0);
    2260:	4501                	li	a0,0
    2262:	469020ef          	jal	4eca <sbrk>
    2266:	84aa                	mv	s1,a0
  for(i = 0; i < 5000; i++){
    2268:	4901                	li	s2,0
    b = sbrk(1);
    226a:	4985                	li	s3,1
  for(i = 0; i < 5000; i++){
    226c:	6a05                	lui	s4,0x1
    226e:	388a0a13          	addi	s4,s4,904 # 1388 <truncate3+0x146>
    2272:	a005                	j	2292 <sbrkbasic+0xbc>
    2274:	fc26                	sd	s1,56(sp)
    2276:	f84a                	sd	s2,48(sp)
    2278:	f44e                	sd	s3,40(sp)
    227a:	f052                	sd	s4,32(sp)
    printf("%s: too much memory allocated!\n", s);
    227c:	85d6                	mv	a1,s5
    227e:	00004517          	auipc	a0,0x4
    2282:	fba50513          	addi	a0,a0,-70 # 6238 <malloc+0xdfe>
    2286:	0fc030ef          	jal	5382 <printf>
    exit(1);
    228a:	4505                	li	a0,1
    228c:	473020ef          	jal	4efe <exit>
    2290:	84be                	mv	s1,a5
    b = sbrk(1);
    2292:	854e                	mv	a0,s3
    2294:	437020ef          	jal	4eca <sbrk>
    if(b != a){
    2298:	04951163          	bne	a0,s1,22da <sbrkbasic+0x104>
    *b = 1;
    229c:	01348023          	sb	s3,0(s1)
    a = b + 1;
    22a0:	00148793          	addi	a5,s1,1
  for(i = 0; i < 5000; i++){
    22a4:	2905                	addiw	s2,s2,1
    22a6:	ff4915e3          	bne	s2,s4,2290 <sbrkbasic+0xba>
  pid = fork();
    22aa:	44d020ef          	jal	4ef6 <fork>
    22ae:	892a                	mv	s2,a0
  if(pid < 0){
    22b0:	04054263          	bltz	a0,22f4 <sbrkbasic+0x11e>
  c = sbrk(1);
    22b4:	4505                	li	a0,1
    22b6:	415020ef          	jal	4eca <sbrk>
  c = sbrk(1);
    22ba:	4505                	li	a0,1
    22bc:	40f020ef          	jal	4eca <sbrk>
  if(c != a + 1){
    22c0:	0489                	addi	s1,s1,2
    22c2:	04950363          	beq	a0,s1,2308 <sbrkbasic+0x132>
    printf("%s: sbrk test failed post-fork\n", s);
    22c6:	85d6                	mv	a1,s5
    22c8:	00004517          	auipc	a0,0x4
    22cc:	fd050513          	addi	a0,a0,-48 # 6298 <malloc+0xe5e>
    22d0:	0b2030ef          	jal	5382 <printf>
    exit(1);
    22d4:	4505                	li	a0,1
    22d6:	429020ef          	jal	4efe <exit>
      printf("%s: sbrk test failed %d %p %p\n", s, i, a, b);
    22da:	872a                	mv	a4,a0
    22dc:	86a6                	mv	a3,s1
    22de:	864a                	mv	a2,s2
    22e0:	85d6                	mv	a1,s5
    22e2:	00004517          	auipc	a0,0x4
    22e6:	f7650513          	addi	a0,a0,-138 # 6258 <malloc+0xe1e>
    22ea:	098030ef          	jal	5382 <printf>
      exit(1);
    22ee:	4505                	li	a0,1
    22f0:	40f020ef          	jal	4efe <exit>
    printf("%s: sbrk test fork failed\n", s);
    22f4:	85d6                	mv	a1,s5
    22f6:	00004517          	auipc	a0,0x4
    22fa:	f8250513          	addi	a0,a0,-126 # 6278 <malloc+0xe3e>
    22fe:	084030ef          	jal	5382 <printf>
    exit(1);
    2302:	4505                	li	a0,1
    2304:	3fb020ef          	jal	4efe <exit>
  if(pid == 0)
    2308:	00091563          	bnez	s2,2312 <sbrkbasic+0x13c>
    exit(0);
    230c:	4501                	li	a0,0
    230e:	3f1020ef          	jal	4efe <exit>
  wait(&xstatus);
    2312:	fbc40513          	addi	a0,s0,-68
    2316:	3f1020ef          	jal	4f06 <wait>
  exit(xstatus);
    231a:	fbc42503          	lw	a0,-68(s0)
    231e:	3e1020ef          	jal	4efe <exit>

0000000000002322 <sbrkmuch>:
{
    2322:	7179                	addi	sp,sp,-48
    2324:	f406                	sd	ra,40(sp)
    2326:	f022                	sd	s0,32(sp)
    2328:	ec26                	sd	s1,24(sp)
    232a:	e84a                	sd	s2,16(sp)
    232c:	e44e                	sd	s3,8(sp)
    232e:	e052                	sd	s4,0(sp)
    2330:	1800                	addi	s0,sp,48
    2332:	89aa                	mv	s3,a0
  oldbrk = sbrk(0);
    2334:	4501                	li	a0,0
    2336:	395020ef          	jal	4eca <sbrk>
    233a:	892a                	mv	s2,a0
  a = sbrk(0);
    233c:	4501                	li	a0,0
    233e:	38d020ef          	jal	4eca <sbrk>
    2342:	84aa                	mv	s1,a0
  p = sbrk(amt);
    2344:	06400537          	lui	a0,0x6400
    2348:	9d05                	subw	a0,a0,s1
    234a:	381020ef          	jal	4eca <sbrk>
  if (p != a) {
    234e:	08a49963          	bne	s1,a0,23e0 <sbrkmuch+0xbe>
  *lastaddr = 99;
    2352:	064007b7          	lui	a5,0x6400
    2356:	06300713          	li	a4,99
    235a:	fee78fa3          	sb	a4,-1(a5) # 63fffff <base+0x63f1357>
  a = sbrk(0);
    235e:	4501                	li	a0,0
    2360:	36b020ef          	jal	4eca <sbrk>
    2364:	84aa                	mv	s1,a0
  c = sbrk(-PGSIZE);
    2366:	757d                	lui	a0,0xfffff
    2368:	363020ef          	jal	4eca <sbrk>
  if(c == (char*)SBRK_ERROR){
    236c:	57fd                	li	a5,-1
    236e:	08f50363          	beq	a0,a5,23f4 <sbrkmuch+0xd2>
  c = sbrk(0);
    2372:	4501                	li	a0,0
    2374:	357020ef          	jal	4eca <sbrk>
  if(c != a - PGSIZE){
    2378:	80048793          	addi	a5,s1,-2048
    237c:	80078793          	addi	a5,a5,-2048
    2380:	08f51463          	bne	a0,a5,2408 <sbrkmuch+0xe6>
  a = sbrk(0);
    2384:	4501                	li	a0,0
    2386:	345020ef          	jal	4eca <sbrk>
    238a:	84aa                	mv	s1,a0
  c = sbrk(PGSIZE);
    238c:	6505                	lui	a0,0x1
    238e:	33d020ef          	jal	4eca <sbrk>
    2392:	8a2a                	mv	s4,a0
  if(c != a || sbrk(0) != a + PGSIZE){
    2394:	08a49663          	bne	s1,a0,2420 <sbrkmuch+0xfe>
    2398:	4501                	li	a0,0
    239a:	331020ef          	jal	4eca <sbrk>
    239e:	6785                	lui	a5,0x1
    23a0:	97a6                	add	a5,a5,s1
    23a2:	06f51f63          	bne	a0,a5,2420 <sbrkmuch+0xfe>
  if(*lastaddr == 99){
    23a6:	064007b7          	lui	a5,0x6400
    23aa:	fff7c703          	lbu	a4,-1(a5) # 63fffff <base+0x63f1357>
    23ae:	06300793          	li	a5,99
    23b2:	08f70363          	beq	a4,a5,2438 <sbrkmuch+0x116>
  a = sbrk(0);
    23b6:	4501                	li	a0,0
    23b8:	313020ef          	jal	4eca <sbrk>
    23bc:	84aa                	mv	s1,a0
  c = sbrk(-(sbrk(0) - oldbrk));
    23be:	4501                	li	a0,0
    23c0:	30b020ef          	jal	4eca <sbrk>
    23c4:	40a9053b          	subw	a0,s2,a0
    23c8:	303020ef          	jal	4eca <sbrk>
  if(c != a){
    23cc:	08a49063          	bne	s1,a0,244c <sbrkmuch+0x12a>
}
    23d0:	70a2                	ld	ra,40(sp)
    23d2:	7402                	ld	s0,32(sp)
    23d4:	64e2                	ld	s1,24(sp)
    23d6:	6942                	ld	s2,16(sp)
    23d8:	69a2                	ld	s3,8(sp)
    23da:	6a02                	ld	s4,0(sp)
    23dc:	6145                	addi	sp,sp,48
    23de:	8082                	ret
    printf("%s: sbrk test failed to grow big address space; enough phys mem?\n", s);
    23e0:	85ce                	mv	a1,s3
    23e2:	00004517          	auipc	a0,0x4
    23e6:	ed650513          	addi	a0,a0,-298 # 62b8 <malloc+0xe7e>
    23ea:	799020ef          	jal	5382 <printf>
    exit(1);
    23ee:	4505                	li	a0,1
    23f0:	30f020ef          	jal	4efe <exit>
    printf("%s: sbrk could not deallocate\n", s);
    23f4:	85ce                	mv	a1,s3
    23f6:	00004517          	auipc	a0,0x4
    23fa:	f0a50513          	addi	a0,a0,-246 # 6300 <malloc+0xec6>
    23fe:	785020ef          	jal	5382 <printf>
    exit(1);
    2402:	4505                	li	a0,1
    2404:	2fb020ef          	jal	4efe <exit>
    printf("%s: sbrk deallocation produced wrong address, a %p c %p\n", s, a, c);
    2408:	86aa                	mv	a3,a0
    240a:	8626                	mv	a2,s1
    240c:	85ce                	mv	a1,s3
    240e:	00004517          	auipc	a0,0x4
    2412:	f1250513          	addi	a0,a0,-238 # 6320 <malloc+0xee6>
    2416:	76d020ef          	jal	5382 <printf>
    exit(1);
    241a:	4505                	li	a0,1
    241c:	2e3020ef          	jal	4efe <exit>
    printf("%s: sbrk re-allocation failed, a %p c %p\n", s, a, c);
    2420:	86d2                	mv	a3,s4
    2422:	8626                	mv	a2,s1
    2424:	85ce                	mv	a1,s3
    2426:	00004517          	auipc	a0,0x4
    242a:	f3a50513          	addi	a0,a0,-198 # 6360 <malloc+0xf26>
    242e:	755020ef          	jal	5382 <printf>
    exit(1);
    2432:	4505                	li	a0,1
    2434:	2cb020ef          	jal	4efe <exit>
    printf("%s: sbrk de-allocation didn't really deallocate\n", s);
    2438:	85ce                	mv	a1,s3
    243a:	00004517          	auipc	a0,0x4
    243e:	f5650513          	addi	a0,a0,-170 # 6390 <malloc+0xf56>
    2442:	741020ef          	jal	5382 <printf>
    exit(1);
    2446:	4505                	li	a0,1
    2448:	2b7020ef          	jal	4efe <exit>
    printf("%s: sbrk downsize failed, a %p c %p\n", s, a, c);
    244c:	86aa                	mv	a3,a0
    244e:	8626                	mv	a2,s1
    2450:	85ce                	mv	a1,s3
    2452:	00004517          	auipc	a0,0x4
    2456:	f7650513          	addi	a0,a0,-138 # 63c8 <malloc+0xf8e>
    245a:	729020ef          	jal	5382 <printf>
    exit(1);
    245e:	4505                	li	a0,1
    2460:	29f020ef          	jal	4efe <exit>

0000000000002464 <sbrkarg>:
{
    2464:	7179                	addi	sp,sp,-48
    2466:	f406                	sd	ra,40(sp)
    2468:	f022                	sd	s0,32(sp)
    246a:	ec26                	sd	s1,24(sp)
    246c:	e84a                	sd	s2,16(sp)
    246e:	e44e                	sd	s3,8(sp)
    2470:	1800                	addi	s0,sp,48
    2472:	89aa                	mv	s3,a0
  a = sbrk(PGSIZE);
    2474:	6505                	lui	a0,0x1
    2476:	255020ef          	jal	4eca <sbrk>
    247a:	892a                	mv	s2,a0
  fd = open("sbrk", O_CREATE|O_WRONLY);
    247c:	20100593          	li	a1,513
    2480:	00004517          	auipc	a0,0x4
    2484:	f7050513          	addi	a0,a0,-144 # 63f0 <malloc+0xfb6>
    2488:	2b7020ef          	jal	4f3e <open>
    248c:	84aa                	mv	s1,a0
  unlink("sbrk");
    248e:	00004517          	auipc	a0,0x4
    2492:	f6250513          	addi	a0,a0,-158 # 63f0 <malloc+0xfb6>
    2496:	2b9020ef          	jal	4f4e <unlink>
  if(fd < 0)  {
    249a:	0204c963          	bltz	s1,24cc <sbrkarg+0x68>
  if ((n = write(fd, a, PGSIZE)) < 0) {
    249e:	6605                	lui	a2,0x1
    24a0:	85ca                	mv	a1,s2
    24a2:	8526                	mv	a0,s1
    24a4:	27b020ef          	jal	4f1e <write>
    24a8:	02054c63          	bltz	a0,24e0 <sbrkarg+0x7c>
  close(fd);
    24ac:	8526                	mv	a0,s1
    24ae:	279020ef          	jal	4f26 <close>
  a = sbrk(PGSIZE);
    24b2:	6505                	lui	a0,0x1
    24b4:	217020ef          	jal	4eca <sbrk>
  if(pipe((int *) a) != 0){
    24b8:	257020ef          	jal	4f0e <pipe>
    24bc:	ed05                	bnez	a0,24f4 <sbrkarg+0x90>
}
    24be:	70a2                	ld	ra,40(sp)
    24c0:	7402                	ld	s0,32(sp)
    24c2:	64e2                	ld	s1,24(sp)
    24c4:	6942                	ld	s2,16(sp)
    24c6:	69a2                	ld	s3,8(sp)
    24c8:	6145                	addi	sp,sp,48
    24ca:	8082                	ret
    printf("%s: open sbrk failed\n", s);
    24cc:	85ce                	mv	a1,s3
    24ce:	00004517          	auipc	a0,0x4
    24d2:	f2a50513          	addi	a0,a0,-214 # 63f8 <malloc+0xfbe>
    24d6:	6ad020ef          	jal	5382 <printf>
    exit(1);
    24da:	4505                	li	a0,1
    24dc:	223020ef          	jal	4efe <exit>
    printf("%s: write sbrk failed\n", s);
    24e0:	85ce                	mv	a1,s3
    24e2:	00004517          	auipc	a0,0x4
    24e6:	f2e50513          	addi	a0,a0,-210 # 6410 <malloc+0xfd6>
    24ea:	699020ef          	jal	5382 <printf>
    exit(1);
    24ee:	4505                	li	a0,1
    24f0:	20f020ef          	jal	4efe <exit>
    printf("%s: pipe() failed\n", s);
    24f4:	85ce                	mv	a1,s3
    24f6:	00004517          	auipc	a0,0x4
    24fa:	a0a50513          	addi	a0,a0,-1526 # 5f00 <malloc+0xac6>
    24fe:	685020ef          	jal	5382 <printf>
    exit(1);
    2502:	4505                	li	a0,1
    2504:	1fb020ef          	jal	4efe <exit>

0000000000002508 <argptest>:
{
    2508:	1101                	addi	sp,sp,-32
    250a:	ec06                	sd	ra,24(sp)
    250c:	e822                	sd	s0,16(sp)
    250e:	e426                	sd	s1,8(sp)
    2510:	e04a                	sd	s2,0(sp)
    2512:	1000                	addi	s0,sp,32
    2514:	892a                	mv	s2,a0
  fd = open("init", O_RDONLY);
    2516:	4581                	li	a1,0
    2518:	00004517          	auipc	a0,0x4
    251c:	f1050513          	addi	a0,a0,-240 # 6428 <malloc+0xfee>
    2520:	21f020ef          	jal	4f3e <open>
  if (fd < 0) {
    2524:	02054563          	bltz	a0,254e <argptest+0x46>
    2528:	84aa                	mv	s1,a0
  read(fd, sbrk(0) - 1, -1);
    252a:	4501                	li	a0,0
    252c:	19f020ef          	jal	4eca <sbrk>
    2530:	567d                	li	a2,-1
    2532:	00c505b3          	add	a1,a0,a2
    2536:	8526                	mv	a0,s1
    2538:	1df020ef          	jal	4f16 <read>
  close(fd);
    253c:	8526                	mv	a0,s1
    253e:	1e9020ef          	jal	4f26 <close>
}
    2542:	60e2                	ld	ra,24(sp)
    2544:	6442                	ld	s0,16(sp)
    2546:	64a2                	ld	s1,8(sp)
    2548:	6902                	ld	s2,0(sp)
    254a:	6105                	addi	sp,sp,32
    254c:	8082                	ret
    printf("%s: open failed\n", s);
    254e:	85ca                	mv	a1,s2
    2550:	00004517          	auipc	a0,0x4
    2554:	8c050513          	addi	a0,a0,-1856 # 5e10 <malloc+0x9d6>
    2558:	62b020ef          	jal	5382 <printf>
    exit(1);
    255c:	4505                	li	a0,1
    255e:	1a1020ef          	jal	4efe <exit>

0000000000002562 <sbrkbugs>:
{
    2562:	1141                	addi	sp,sp,-16
    2564:	e406                	sd	ra,8(sp)
    2566:	e022                	sd	s0,0(sp)
    2568:	0800                	addi	s0,sp,16
  int pid = fork();
    256a:	18d020ef          	jal	4ef6 <fork>
  if(pid < 0){
    256e:	00054c63          	bltz	a0,2586 <sbrkbugs+0x24>
  if(pid == 0){
    2572:	e11d                	bnez	a0,2598 <sbrkbugs+0x36>
    int sz = (uint64) sbrk(0);
    2574:	157020ef          	jal	4eca <sbrk>
    sbrk(-sz);
    2578:	40a0053b          	negw	a0,a0
    257c:	14f020ef          	jal	4eca <sbrk>
    exit(0);
    2580:	4501                	li	a0,0
    2582:	17d020ef          	jal	4efe <exit>
    printf("fork failed\n");
    2586:	00005517          	auipc	a0,0x5
    258a:	e1a50513          	addi	a0,a0,-486 # 73a0 <malloc+0x1f66>
    258e:	5f5020ef          	jal	5382 <printf>
    exit(1);
    2592:	4505                	li	a0,1
    2594:	16b020ef          	jal	4efe <exit>
  wait(0);
    2598:	4501                	li	a0,0
    259a:	16d020ef          	jal	4f06 <wait>
  pid = fork();
    259e:	159020ef          	jal	4ef6 <fork>
  if(pid < 0){
    25a2:	00054f63          	bltz	a0,25c0 <sbrkbugs+0x5e>
  if(pid == 0){
    25a6:	e515                	bnez	a0,25d2 <sbrkbugs+0x70>
    int sz = (uint64) sbrk(0);
    25a8:	123020ef          	jal	4eca <sbrk>
    sbrk(-(sz - 3500));
    25ac:	6785                	lui	a5,0x1
    25ae:	dac7879b          	addiw	a5,a5,-596 # dac <linktest+0xde>
    25b2:	40a7853b          	subw	a0,a5,a0
    25b6:	115020ef          	jal	4eca <sbrk>
    exit(0);
    25ba:	4501                	li	a0,0
    25bc:	143020ef          	jal	4efe <exit>
    printf("fork failed\n");
    25c0:	00005517          	auipc	a0,0x5
    25c4:	de050513          	addi	a0,a0,-544 # 73a0 <malloc+0x1f66>
    25c8:	5bb020ef          	jal	5382 <printf>
    exit(1);
    25cc:	4505                	li	a0,1
    25ce:	131020ef          	jal	4efe <exit>
  wait(0);
    25d2:	4501                	li	a0,0
    25d4:	133020ef          	jal	4f06 <wait>
  pid = fork();
    25d8:	11f020ef          	jal	4ef6 <fork>
  if(pid < 0){
    25dc:	02054263          	bltz	a0,2600 <sbrkbugs+0x9e>
  if(pid == 0){
    25e0:	e90d                	bnez	a0,2612 <sbrkbugs+0xb0>
    sbrk((10*PGSIZE + 2048) - (uint64)sbrk(0));
    25e2:	0e9020ef          	jal	4eca <sbrk>
    25e6:	67ad                	lui	a5,0xb
    25e8:	8007879b          	addiw	a5,a5,-2048 # a800 <uninit+0x1268>
    25ec:	40a7853b          	subw	a0,a5,a0
    25f0:	0db020ef          	jal	4eca <sbrk>
    sbrk(-10);
    25f4:	5559                	li	a0,-10
    25f6:	0d5020ef          	jal	4eca <sbrk>
    exit(0);
    25fa:	4501                	li	a0,0
    25fc:	103020ef          	jal	4efe <exit>
    printf("fork failed\n");
    2600:	00005517          	auipc	a0,0x5
    2604:	da050513          	addi	a0,a0,-608 # 73a0 <malloc+0x1f66>
    2608:	57b020ef          	jal	5382 <printf>
    exit(1);
    260c:	4505                	li	a0,1
    260e:	0f1020ef          	jal	4efe <exit>
  wait(0);
    2612:	4501                	li	a0,0
    2614:	0f3020ef          	jal	4f06 <wait>
  exit(0);
    2618:	4501                	li	a0,0
    261a:	0e5020ef          	jal	4efe <exit>

000000000000261e <sbrklast>:
{
    261e:	7179                	addi	sp,sp,-48
    2620:	f406                	sd	ra,40(sp)
    2622:	f022                	sd	s0,32(sp)
    2624:	ec26                	sd	s1,24(sp)
    2626:	e84a                	sd	s2,16(sp)
    2628:	e44e                	sd	s3,8(sp)
    262a:	e052                	sd	s4,0(sp)
    262c:	1800                	addi	s0,sp,48
  uint64 top = (uint64) sbrk(0);
    262e:	4501                	li	a0,0
    2630:	09b020ef          	jal	4eca <sbrk>
  if((top % PGSIZE) != 0)
    2634:	03451793          	slli	a5,a0,0x34
    2638:	ebad                	bnez	a5,26aa <sbrklast+0x8c>
  sbrk(PGSIZE);
    263a:	6505                	lui	a0,0x1
    263c:	08f020ef          	jal	4eca <sbrk>
  sbrk(10);
    2640:	4529                	li	a0,10
    2642:	089020ef          	jal	4eca <sbrk>
  sbrk(-20);
    2646:	5531                	li	a0,-20
    2648:	083020ef          	jal	4eca <sbrk>
  top = (uint64) sbrk(0);
    264c:	4501                	li	a0,0
    264e:	07d020ef          	jal	4eca <sbrk>
    2652:	84aa                	mv	s1,a0
  char *p = (char *) (top - 64);
    2654:	fc050913          	addi	s2,a0,-64 # fc0 <bigdir+0xc8>
  p[0] = 'x';
    2658:	07800993          	li	s3,120
    265c:	fd350023          	sb	s3,-64(a0)
  p[1] = '\0';
    2660:	fc0500a3          	sb	zero,-63(a0)
  int fd = open(p, O_RDWR|O_CREATE);
    2664:	20200593          	li	a1,514
    2668:	854a                	mv	a0,s2
    266a:	0d5020ef          	jal	4f3e <open>
    266e:	8a2a                	mv	s4,a0
  write(fd, p, 1);
    2670:	4605                	li	a2,1
    2672:	85ca                	mv	a1,s2
    2674:	0ab020ef          	jal	4f1e <write>
  close(fd);
    2678:	8552                	mv	a0,s4
    267a:	0ad020ef          	jal	4f26 <close>
  fd = open(p, O_RDWR);
    267e:	4589                	li	a1,2
    2680:	854a                	mv	a0,s2
    2682:	0bd020ef          	jal	4f3e <open>
  p[0] = '\0';
    2686:	fc048023          	sb	zero,-64(s1)
  read(fd, p, 1);
    268a:	4605                	li	a2,1
    268c:	85ca                	mv	a1,s2
    268e:	089020ef          	jal	4f16 <read>
  if(p[0] != 'x')
    2692:	fc04c783          	lbu	a5,-64(s1)
    2696:	03379263          	bne	a5,s3,26ba <sbrklast+0x9c>
}
    269a:	70a2                	ld	ra,40(sp)
    269c:	7402                	ld	s0,32(sp)
    269e:	64e2                	ld	s1,24(sp)
    26a0:	6942                	ld	s2,16(sp)
    26a2:	69a2                	ld	s3,8(sp)
    26a4:	6a02                	ld	s4,0(sp)
    26a6:	6145                	addi	sp,sp,48
    26a8:	8082                	ret
    sbrk(PGSIZE - (top % PGSIZE));
    26aa:	0347d513          	srli	a0,a5,0x34
    26ae:	6785                	lui	a5,0x1
    26b0:	40a7853b          	subw	a0,a5,a0
    26b4:	017020ef          	jal	4eca <sbrk>
    26b8:	b749                	j	263a <sbrklast+0x1c>
    exit(1);
    26ba:	4505                	li	a0,1
    26bc:	043020ef          	jal	4efe <exit>

00000000000026c0 <sbrk8000>:
{
    26c0:	1141                	addi	sp,sp,-16
    26c2:	e406                	sd	ra,8(sp)
    26c4:	e022                	sd	s0,0(sp)
    26c6:	0800                	addi	s0,sp,16
  sbrk(0x80000004);
    26c8:	80000537          	lui	a0,0x80000
    26cc:	0511                	addi	a0,a0,4 # ffffffff80000004 <base+0xffffffff7fff135c>
    26ce:	7fc020ef          	jal	4eca <sbrk>
  volatile char *top = sbrk(0);
    26d2:	4501                	li	a0,0
    26d4:	7f6020ef          	jal	4eca <sbrk>
  *(top-1) = *(top-1) + 1;
    26d8:	fff54783          	lbu	a5,-1(a0)
    26dc:	0785                	addi	a5,a5,1 # 1001 <bigdir+0x109>
    26de:	0ff7f793          	zext.b	a5,a5
    26e2:	fef50fa3          	sb	a5,-1(a0)
}
    26e6:	60a2                	ld	ra,8(sp)
    26e8:	6402                	ld	s0,0(sp)
    26ea:	0141                	addi	sp,sp,16
    26ec:	8082                	ret

00000000000026ee <execout>:
{
    26ee:	711d                	addi	sp,sp,-96
    26f0:	ec86                	sd	ra,88(sp)
    26f2:	e8a2                	sd	s0,80(sp)
    26f4:	e4a6                	sd	s1,72(sp)
    26f6:	e0ca                	sd	s2,64(sp)
    26f8:	fc4e                	sd	s3,56(sp)
    26fa:	1080                	addi	s0,sp,96
  for(int avail = 0; avail < 15; avail++){
    26fc:	4901                	li	s2,0
    26fe:	49bd                	li	s3,15
    int pid = fork();
    2700:	7f6020ef          	jal	4ef6 <fork>
    2704:	84aa                	mv	s1,a0
    if(pid < 0){
    2706:	00054e63          	bltz	a0,2722 <execout+0x34>
    } else if(pid == 0){
    270a:	c51d                	beqz	a0,2738 <execout+0x4a>
      wait((int*)0);
    270c:	4501                	li	a0,0
    270e:	7f8020ef          	jal	4f06 <wait>
  for(int avail = 0; avail < 15; avail++){
    2712:	2905                	addiw	s2,s2,1
    2714:	ff3916e3          	bne	s2,s3,2700 <execout+0x12>
    2718:	f852                	sd	s4,48(sp)
    271a:	f456                	sd	s5,40(sp)
  exit(0);
    271c:	4501                	li	a0,0
    271e:	7e0020ef          	jal	4efe <exit>
    2722:	f852                	sd	s4,48(sp)
    2724:	f456                	sd	s5,40(sp)
      printf("fork failed\n");
    2726:	00005517          	auipc	a0,0x5
    272a:	c7a50513          	addi	a0,a0,-902 # 73a0 <malloc+0x1f66>
    272e:	455020ef          	jal	5382 <printf>
      exit(1);
    2732:	4505                	li	a0,1
    2734:	7ca020ef          	jal	4efe <exit>
    2738:	f852                	sd	s4,48(sp)
    273a:	f456                	sd	s5,40(sp)
        char *a = sbrk(PGSIZE);
    273c:	6985                	lui	s3,0x1
        if(a == SBRK_ERROR)
    273e:	5a7d                	li	s4,-1
        *(a + PGSIZE - 1) = 1;
    2740:	4a85                	li	s5,1
        char *a = sbrk(PGSIZE);
    2742:	854e                	mv	a0,s3
    2744:	786020ef          	jal	4eca <sbrk>
        if(a == SBRK_ERROR)
    2748:	01450663          	beq	a0,s4,2754 <execout+0x66>
        *(a + PGSIZE - 1) = 1;
    274c:	954e                	add	a0,a0,s3
    274e:	ff550fa3          	sb	s5,-1(a0)
      while(1){
    2752:	bfc5                	j	2742 <execout+0x54>
        sbrk(-PGSIZE);
    2754:	79fd                	lui	s3,0xfffff
      for(int i = 0; i < avail; i++)
    2756:	01205863          	blez	s2,2766 <execout+0x78>
        sbrk(-PGSIZE);
    275a:	854e                	mv	a0,s3
    275c:	76e020ef          	jal	4eca <sbrk>
      for(int i = 0; i < avail; i++)
    2760:	2485                	addiw	s1,s1,1
    2762:	ff249ce3          	bne	s1,s2,275a <execout+0x6c>
      close(1);
    2766:	4505                	li	a0,1
    2768:	7be020ef          	jal	4f26 <close>
      char *args[] = { "echo", "x", 0 };
    276c:	00003797          	auipc	a5,0x3
    2770:	dfc78793          	addi	a5,a5,-516 # 5568 <malloc+0x12e>
    2774:	faf43423          	sd	a5,-88(s0)
    2778:	00003797          	auipc	a5,0x3
    277c:	e6078793          	addi	a5,a5,-416 # 55d8 <malloc+0x19e>
    2780:	faf43823          	sd	a5,-80(s0)
    2784:	fa043c23          	sd	zero,-72(s0)
      exec("echo", args);
    2788:	fa840593          	addi	a1,s0,-88
    278c:	00003517          	auipc	a0,0x3
    2790:	ddc50513          	addi	a0,a0,-548 # 5568 <malloc+0x12e>
    2794:	7a2020ef          	jal	4f36 <exec>
      exit(0);
    2798:	4501                	li	a0,0
    279a:	764020ef          	jal	4efe <exit>

000000000000279e <fourteen>:
{
    279e:	1101                	addi	sp,sp,-32
    27a0:	ec06                	sd	ra,24(sp)
    27a2:	e822                	sd	s0,16(sp)
    27a4:	e426                	sd	s1,8(sp)
    27a6:	1000                	addi	s0,sp,32
    27a8:	84aa                	mv	s1,a0
  if(mkdir("12345678901234") != 0){
    27aa:	00004517          	auipc	a0,0x4
    27ae:	e5650513          	addi	a0,a0,-426 # 6600 <malloc+0x11c6>
    27b2:	7b4020ef          	jal	4f66 <mkdir>
    27b6:	e555                	bnez	a0,2862 <fourteen+0xc4>
  if(mkdir("12345678901234/123456789012345") != 0){
    27b8:	00004517          	auipc	a0,0x4
    27bc:	ca050513          	addi	a0,a0,-864 # 6458 <malloc+0x101e>
    27c0:	7a6020ef          	jal	4f66 <mkdir>
    27c4:	e94d                	bnez	a0,2876 <fourteen+0xd8>
  fd = open("123456789012345/123456789012345/123456789012345", O_CREATE);
    27c6:	20000593          	li	a1,512
    27ca:	00004517          	auipc	a0,0x4
    27ce:	ce650513          	addi	a0,a0,-794 # 64b0 <malloc+0x1076>
    27d2:	76c020ef          	jal	4f3e <open>
  if(fd < 0){
    27d6:	0a054a63          	bltz	a0,288a <fourteen+0xec>
  close(fd);
    27da:	74c020ef          	jal	4f26 <close>
  fd = open("12345678901234/12345678901234/12345678901234", 0);
    27de:	4581                	li	a1,0
    27e0:	00004517          	auipc	a0,0x4
    27e4:	d4850513          	addi	a0,a0,-696 # 6528 <malloc+0x10ee>
    27e8:	756020ef          	jal	4f3e <open>
  if(fd < 0){
    27ec:	0a054963          	bltz	a0,289e <fourteen+0x100>
  close(fd);
    27f0:	736020ef          	jal	4f26 <close>
  if(mkdir("12345678901234/12345678901234") == 0){
    27f4:	00004517          	auipc	a0,0x4
    27f8:	da450513          	addi	a0,a0,-604 # 6598 <malloc+0x115e>
    27fc:	76a020ef          	jal	4f66 <mkdir>
    2800:	c94d                	beqz	a0,28b2 <fourteen+0x114>
  if(mkdir("123456789012345/12345678901234") == 0){
    2802:	00004517          	auipc	a0,0x4
    2806:	dee50513          	addi	a0,a0,-530 # 65f0 <malloc+0x11b6>
    280a:	75c020ef          	jal	4f66 <mkdir>
    280e:	cd45                	beqz	a0,28c6 <fourteen+0x128>
  unlink("123456789012345/12345678901234");
    2810:	00004517          	auipc	a0,0x4
    2814:	de050513          	addi	a0,a0,-544 # 65f0 <malloc+0x11b6>
    2818:	736020ef          	jal	4f4e <unlink>
  unlink("12345678901234/12345678901234");
    281c:	00004517          	auipc	a0,0x4
    2820:	d7c50513          	addi	a0,a0,-644 # 6598 <malloc+0x115e>
    2824:	72a020ef          	jal	4f4e <unlink>
  unlink("12345678901234/12345678901234/12345678901234");
    2828:	00004517          	auipc	a0,0x4
    282c:	d0050513          	addi	a0,a0,-768 # 6528 <malloc+0x10ee>
    2830:	71e020ef          	jal	4f4e <unlink>
  unlink("123456789012345/123456789012345/123456789012345");
    2834:	00004517          	auipc	a0,0x4
    2838:	c7c50513          	addi	a0,a0,-900 # 64b0 <malloc+0x1076>
    283c:	712020ef          	jal	4f4e <unlink>
  unlink("12345678901234/123456789012345");
    2840:	00004517          	auipc	a0,0x4
    2844:	c1850513          	addi	a0,a0,-1000 # 6458 <malloc+0x101e>
    2848:	706020ef          	jal	4f4e <unlink>
  unlink("12345678901234");
    284c:	00004517          	auipc	a0,0x4
    2850:	db450513          	addi	a0,a0,-588 # 6600 <malloc+0x11c6>
    2854:	6fa020ef          	jal	4f4e <unlink>
}
    2858:	60e2                	ld	ra,24(sp)
    285a:	6442                	ld	s0,16(sp)
    285c:	64a2                	ld	s1,8(sp)
    285e:	6105                	addi	sp,sp,32
    2860:	8082                	ret
    printf("%s: mkdir 12345678901234 failed\n", s);
    2862:	85a6                	mv	a1,s1
    2864:	00004517          	auipc	a0,0x4
    2868:	bcc50513          	addi	a0,a0,-1076 # 6430 <malloc+0xff6>
    286c:	317020ef          	jal	5382 <printf>
    exit(1);
    2870:	4505                	li	a0,1
    2872:	68c020ef          	jal	4efe <exit>
    printf("%s: mkdir 12345678901234/123456789012345 failed\n", s);
    2876:	85a6                	mv	a1,s1
    2878:	00004517          	auipc	a0,0x4
    287c:	c0050513          	addi	a0,a0,-1024 # 6478 <malloc+0x103e>
    2880:	303020ef          	jal	5382 <printf>
    exit(1);
    2884:	4505                	li	a0,1
    2886:	678020ef          	jal	4efe <exit>
    printf("%s: create 123456789012345/123456789012345/123456789012345 failed\n", s);
    288a:	85a6                	mv	a1,s1
    288c:	00004517          	auipc	a0,0x4
    2890:	c5450513          	addi	a0,a0,-940 # 64e0 <malloc+0x10a6>
    2894:	2ef020ef          	jal	5382 <printf>
    exit(1);
    2898:	4505                	li	a0,1
    289a:	664020ef          	jal	4efe <exit>
    printf("%s: open 12345678901234/12345678901234/12345678901234 failed\n", s);
    289e:	85a6                	mv	a1,s1
    28a0:	00004517          	auipc	a0,0x4
    28a4:	cb850513          	addi	a0,a0,-840 # 6558 <malloc+0x111e>
    28a8:	2db020ef          	jal	5382 <printf>
    exit(1);
    28ac:	4505                	li	a0,1
    28ae:	650020ef          	jal	4efe <exit>
    printf("%s: mkdir 12345678901234/12345678901234 succeeded!\n", s);
    28b2:	85a6                	mv	a1,s1
    28b4:	00004517          	auipc	a0,0x4
    28b8:	d0450513          	addi	a0,a0,-764 # 65b8 <malloc+0x117e>
    28bc:	2c7020ef          	jal	5382 <printf>
    exit(1);
    28c0:	4505                	li	a0,1
    28c2:	63c020ef          	jal	4efe <exit>
    printf("%s: mkdir 12345678901234/123456789012345 succeeded!\n", s);
    28c6:	85a6                	mv	a1,s1
    28c8:	00004517          	auipc	a0,0x4
    28cc:	d4850513          	addi	a0,a0,-696 # 6610 <malloc+0x11d6>
    28d0:	2b3020ef          	jal	5382 <printf>
    exit(1);
    28d4:	4505                	li	a0,1
    28d6:	628020ef          	jal	4efe <exit>

00000000000028da <diskfull>:
{
    28da:	b6010113          	addi	sp,sp,-1184
    28de:	48113c23          	sd	ra,1176(sp)
    28e2:	48813823          	sd	s0,1168(sp)
    28e6:	48913423          	sd	s1,1160(sp)
    28ea:	49213023          	sd	s2,1152(sp)
    28ee:	47313c23          	sd	s3,1144(sp)
    28f2:	47413823          	sd	s4,1136(sp)
    28f6:	47513423          	sd	s5,1128(sp)
    28fa:	47613023          	sd	s6,1120(sp)
    28fe:	45713c23          	sd	s7,1112(sp)
    2902:	45813823          	sd	s8,1104(sp)
    2906:	45913423          	sd	s9,1096(sp)
    290a:	45a13023          	sd	s10,1088(sp)
    290e:	43b13c23          	sd	s11,1080(sp)
    2912:	4a010413          	addi	s0,sp,1184
    2916:	b6a43423          	sd	a0,-1176(s0)
  unlink("diskfulldir");
    291a:	00004517          	auipc	a0,0x4
    291e:	d2e50513          	addi	a0,a0,-722 # 6648 <malloc+0x120e>
    2922:	62c020ef          	jal	4f4e <unlink>
    2926:	03000a93          	li	s5,48
    name[0] = 'b';
    292a:	06200d93          	li	s11,98
    name[1] = 'i';
    292e:	06900d13          	li	s10,105
    name[2] = 'g';
    2932:	06700c93          	li	s9,103
    unlink(name);
    2936:	b7040b13          	addi	s6,s0,-1168
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
    293a:	60200c13          	li	s8,1538
    293e:	6bc1                	lui	s7,0x10
    2940:	10bb8b93          	addi	s7,s7,267 # 1010b <base+0x1463>
      if(write(fd, buf, BSIZE) != BSIZE){
    2944:	b9040a13          	addi	s4,s0,-1136
    2948:	aa8d                	j	2aba <diskfull+0x1e0>
      printf("%s: could not create file %s\n", s, name);
    294a:	b7040613          	addi	a2,s0,-1168
    294e:	b6843583          	ld	a1,-1176(s0)
    2952:	00004517          	auipc	a0,0x4
    2956:	d0650513          	addi	a0,a0,-762 # 6658 <malloc+0x121e>
    295a:	229020ef          	jal	5382 <printf>
      break;
    295e:	a039                	j	296c <diskfull+0x92>
        close(fd);
    2960:	854e                	mv	a0,s3
    2962:	5c4020ef          	jal	4f26 <close>
    close(fd);
    2966:	854e                	mv	a0,s3
    2968:	5be020ef          	jal	4f26 <close>
  for(int i = 0; i < nzz; i++){
    296c:	4481                	li	s1,0
    name[0] = 'z';
    296e:	07a00993          	li	s3,122
    unlink(name);
    2972:	b9040913          	addi	s2,s0,-1136
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
    2976:	60200a13          	li	s4,1538
  for(int i = 0; i < nzz; i++){
    297a:	08000a93          	li	s5,128
    name[0] = 'z';
    297e:	b9340823          	sb	s3,-1136(s0)
    name[1] = 'z';
    2982:	b93408a3          	sb	s3,-1135(s0)
    name[2] = '0' + (i / 32);
    2986:	41f4d71b          	sraiw	a4,s1,0x1f
    298a:	01b7571b          	srliw	a4,a4,0x1b
    298e:	009707bb          	addw	a5,a4,s1
    2992:	4057d69b          	sraiw	a3,a5,0x5
    2996:	0306869b          	addiw	a3,a3,48
    299a:	b8d40923          	sb	a3,-1134(s0)
    name[3] = '0' + (i % 32);
    299e:	8bfd                	andi	a5,a5,31
    29a0:	9f99                	subw	a5,a5,a4
    29a2:	0307879b          	addiw	a5,a5,48
    29a6:	b8f409a3          	sb	a5,-1133(s0)
    name[4] = '\0';
    29aa:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    29ae:	854a                	mv	a0,s2
    29b0:	59e020ef          	jal	4f4e <unlink>
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
    29b4:	85d2                	mv	a1,s4
    29b6:	854a                	mv	a0,s2
    29b8:	586020ef          	jal	4f3e <open>
    if(fd < 0)
    29bc:	00054763          	bltz	a0,29ca <diskfull+0xf0>
    close(fd);
    29c0:	566020ef          	jal	4f26 <close>
  for(int i = 0; i < nzz; i++){
    29c4:	2485                	addiw	s1,s1,1
    29c6:	fb549ce3          	bne	s1,s5,297e <diskfull+0xa4>
  if(mkdir("diskfulldir") == 0)
    29ca:	00004517          	auipc	a0,0x4
    29ce:	c7e50513          	addi	a0,a0,-898 # 6648 <malloc+0x120e>
    29d2:	594020ef          	jal	4f66 <mkdir>
    29d6:	12050363          	beqz	a0,2afc <diskfull+0x222>
  unlink("diskfulldir");
    29da:	00004517          	auipc	a0,0x4
    29de:	c6e50513          	addi	a0,a0,-914 # 6648 <malloc+0x120e>
    29e2:	56c020ef          	jal	4f4e <unlink>
  for(int i = 0; i < nzz; i++){
    29e6:	4481                	li	s1,0
    name[0] = 'z';
    29e8:	07a00913          	li	s2,122
    unlink(name);
    29ec:	b9040a13          	addi	s4,s0,-1136
  for(int i = 0; i < nzz; i++){
    29f0:	08000993          	li	s3,128
    name[0] = 'z';
    29f4:	b9240823          	sb	s2,-1136(s0)
    name[1] = 'z';
    29f8:	b92408a3          	sb	s2,-1135(s0)
    name[2] = '0' + (i / 32);
    29fc:	41f4d71b          	sraiw	a4,s1,0x1f
    2a00:	01b7571b          	srliw	a4,a4,0x1b
    2a04:	009707bb          	addw	a5,a4,s1
    2a08:	4057d69b          	sraiw	a3,a5,0x5
    2a0c:	0306869b          	addiw	a3,a3,48
    2a10:	b8d40923          	sb	a3,-1134(s0)
    name[3] = '0' + (i % 32);
    2a14:	8bfd                	andi	a5,a5,31
    2a16:	9f99                	subw	a5,a5,a4
    2a18:	0307879b          	addiw	a5,a5,48
    2a1c:	b8f409a3          	sb	a5,-1133(s0)
    name[4] = '\0';
    2a20:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    2a24:	8552                	mv	a0,s4
    2a26:	528020ef          	jal	4f4e <unlink>
  for(int i = 0; i < nzz; i++){
    2a2a:	2485                	addiw	s1,s1,1
    2a2c:	fd3494e3          	bne	s1,s3,29f4 <diskfull+0x11a>
    2a30:	03000493          	li	s1,48
    name[0] = 'b';
    2a34:	06200b13          	li	s6,98
    name[1] = 'i';
    2a38:	06900a93          	li	s5,105
    name[2] = 'g';
    2a3c:	06700a13          	li	s4,103
    unlink(name);
    2a40:	b9040993          	addi	s3,s0,-1136
  for(int i = 0; '0' + i < 0177; i++){
    2a44:	07f00913          	li	s2,127
    name[0] = 'b';
    2a48:	b9640823          	sb	s6,-1136(s0)
    name[1] = 'i';
    2a4c:	b95408a3          	sb	s5,-1135(s0)
    name[2] = 'g';
    2a50:	b9440923          	sb	s4,-1134(s0)
    name[3] = '0' + i;
    2a54:	b89409a3          	sb	s1,-1133(s0)
    name[4] = '\0';
    2a58:	b8040a23          	sb	zero,-1132(s0)
    unlink(name);
    2a5c:	854e                	mv	a0,s3
    2a5e:	4f0020ef          	jal	4f4e <unlink>
  for(int i = 0; '0' + i < 0177; i++){
    2a62:	2485                	addiw	s1,s1,1
    2a64:	0ff4f493          	zext.b	s1,s1
    2a68:	ff2490e3          	bne	s1,s2,2a48 <diskfull+0x16e>
}
    2a6c:	49813083          	ld	ra,1176(sp)
    2a70:	49013403          	ld	s0,1168(sp)
    2a74:	48813483          	ld	s1,1160(sp)
    2a78:	48013903          	ld	s2,1152(sp)
    2a7c:	47813983          	ld	s3,1144(sp)
    2a80:	47013a03          	ld	s4,1136(sp)
    2a84:	46813a83          	ld	s5,1128(sp)
    2a88:	46013b03          	ld	s6,1120(sp)
    2a8c:	45813b83          	ld	s7,1112(sp)
    2a90:	45013c03          	ld	s8,1104(sp)
    2a94:	44813c83          	ld	s9,1096(sp)
    2a98:	44013d03          	ld	s10,1088(sp)
    2a9c:	43813d83          	ld	s11,1080(sp)
    2aa0:	4a010113          	addi	sp,sp,1184
    2aa4:	8082                	ret
    close(fd);
    2aa6:	854e                	mv	a0,s3
    2aa8:	47e020ef          	jal	4f26 <close>
  for(fi = 0; done == 0 && '0' + fi < 0177; fi++){
    2aac:	2a85                	addiw	s5,s5,1 # 3001 <subdir+0x2fb>
    2aae:	0ffafa93          	zext.b	s5,s5
    2ab2:	07f00793          	li	a5,127
    2ab6:	eafa8be3          	beq	s5,a5,296c <diskfull+0x92>
    name[0] = 'b';
    2aba:	b7b40823          	sb	s11,-1168(s0)
    name[1] = 'i';
    2abe:	b7a408a3          	sb	s10,-1167(s0)
    name[2] = 'g';
    2ac2:	b7940923          	sb	s9,-1166(s0)
    name[3] = '0' + fi;
    2ac6:	b75409a3          	sb	s5,-1165(s0)
    name[4] = '\0';
    2aca:	b6040a23          	sb	zero,-1164(s0)
    unlink(name);
    2ace:	855a                	mv	a0,s6
    2ad0:	47e020ef          	jal	4f4e <unlink>
    int fd = open(name, O_CREATE|O_RDWR|O_TRUNC);
    2ad4:	85e2                	mv	a1,s8
    2ad6:	855a                	mv	a0,s6
    2ad8:	466020ef          	jal	4f3e <open>
    2adc:	89aa                	mv	s3,a0
    if(fd < 0){
    2ade:	e60546e3          	bltz	a0,294a <diskfull+0x70>
    2ae2:	84de                	mv	s1,s7
      if(write(fd, buf, BSIZE) != BSIZE){
    2ae4:	40000913          	li	s2,1024
    2ae8:	864a                	mv	a2,s2
    2aea:	85d2                	mv	a1,s4
    2aec:	854e                	mv	a0,s3
    2aee:	430020ef          	jal	4f1e <write>
    2af2:	e72517e3          	bne	a0,s2,2960 <diskfull+0x86>
    for(int i = 0; i < MAXFILE; i++){
    2af6:	34fd                	addiw	s1,s1,-1
    2af8:	f8e5                	bnez	s1,2ae8 <diskfull+0x20e>
    2afa:	b775                	j	2aa6 <diskfull+0x1cc>
    printf("%s: mkdir(diskfulldir) unexpectedly succeeded!\n", s);
    2afc:	b6843583          	ld	a1,-1176(s0)
    2b00:	00004517          	auipc	a0,0x4
    2b04:	b7850513          	addi	a0,a0,-1160 # 6678 <malloc+0x123e>
    2b08:	07b020ef          	jal	5382 <printf>
    2b0c:	b5f9                	j	29da <diskfull+0x100>

0000000000002b0e <iputtest>:
{
    2b0e:	1101                	addi	sp,sp,-32
    2b10:	ec06                	sd	ra,24(sp)
    2b12:	e822                	sd	s0,16(sp)
    2b14:	e426                	sd	s1,8(sp)
    2b16:	1000                	addi	s0,sp,32
    2b18:	84aa                	mv	s1,a0
  if(mkdir("iputdir") < 0){
    2b1a:	00004517          	auipc	a0,0x4
    2b1e:	b8e50513          	addi	a0,a0,-1138 # 66a8 <malloc+0x126e>
    2b22:	444020ef          	jal	4f66 <mkdir>
    2b26:	02054f63          	bltz	a0,2b64 <iputtest+0x56>
  if(chdir("iputdir") < 0){
    2b2a:	00004517          	auipc	a0,0x4
    2b2e:	b7e50513          	addi	a0,a0,-1154 # 66a8 <malloc+0x126e>
    2b32:	43c020ef          	jal	4f6e <chdir>
    2b36:	04054163          	bltz	a0,2b78 <iputtest+0x6a>
  if(unlink("../iputdir") < 0){
    2b3a:	00004517          	auipc	a0,0x4
    2b3e:	bae50513          	addi	a0,a0,-1106 # 66e8 <malloc+0x12ae>
    2b42:	40c020ef          	jal	4f4e <unlink>
    2b46:	04054363          	bltz	a0,2b8c <iputtest+0x7e>
  if(chdir("/") < 0){
    2b4a:	00004517          	auipc	a0,0x4
    2b4e:	bce50513          	addi	a0,a0,-1074 # 6718 <malloc+0x12de>
    2b52:	41c020ef          	jal	4f6e <chdir>
    2b56:	04054563          	bltz	a0,2ba0 <iputtest+0x92>
}
    2b5a:	60e2                	ld	ra,24(sp)
    2b5c:	6442                	ld	s0,16(sp)
    2b5e:	64a2                	ld	s1,8(sp)
    2b60:	6105                	addi	sp,sp,32
    2b62:	8082                	ret
    printf("%s: mkdir failed\n", s);
    2b64:	85a6                	mv	a1,s1
    2b66:	00004517          	auipc	a0,0x4
    2b6a:	b4a50513          	addi	a0,a0,-1206 # 66b0 <malloc+0x1276>
    2b6e:	015020ef          	jal	5382 <printf>
    exit(1);
    2b72:	4505                	li	a0,1
    2b74:	38a020ef          	jal	4efe <exit>
    printf("%s: chdir iputdir failed\n", s);
    2b78:	85a6                	mv	a1,s1
    2b7a:	00004517          	auipc	a0,0x4
    2b7e:	b4e50513          	addi	a0,a0,-1202 # 66c8 <malloc+0x128e>
    2b82:	001020ef          	jal	5382 <printf>
    exit(1);
    2b86:	4505                	li	a0,1
    2b88:	376020ef          	jal	4efe <exit>
    printf("%s: unlink ../iputdir failed\n", s);
    2b8c:	85a6                	mv	a1,s1
    2b8e:	00004517          	auipc	a0,0x4
    2b92:	b6a50513          	addi	a0,a0,-1174 # 66f8 <malloc+0x12be>
    2b96:	7ec020ef          	jal	5382 <printf>
    exit(1);
    2b9a:	4505                	li	a0,1
    2b9c:	362020ef          	jal	4efe <exit>
    printf("%s: chdir / failed\n", s);
    2ba0:	85a6                	mv	a1,s1
    2ba2:	00004517          	auipc	a0,0x4
    2ba6:	b7e50513          	addi	a0,a0,-1154 # 6720 <malloc+0x12e6>
    2baa:	7d8020ef          	jal	5382 <printf>
    exit(1);
    2bae:	4505                	li	a0,1
    2bb0:	34e020ef          	jal	4efe <exit>

0000000000002bb4 <exitiputtest>:
{
    2bb4:	7179                	addi	sp,sp,-48
    2bb6:	f406                	sd	ra,40(sp)
    2bb8:	f022                	sd	s0,32(sp)
    2bba:	ec26                	sd	s1,24(sp)
    2bbc:	1800                	addi	s0,sp,48
    2bbe:	84aa                	mv	s1,a0
  pid = fork();
    2bc0:	336020ef          	jal	4ef6 <fork>
  if(pid < 0){
    2bc4:	02054e63          	bltz	a0,2c00 <exitiputtest+0x4c>
  if(pid == 0){
    2bc8:	e541                	bnez	a0,2c50 <exitiputtest+0x9c>
    if(mkdir("iputdir") < 0){
    2bca:	00004517          	auipc	a0,0x4
    2bce:	ade50513          	addi	a0,a0,-1314 # 66a8 <malloc+0x126e>
    2bd2:	394020ef          	jal	4f66 <mkdir>
    2bd6:	02054f63          	bltz	a0,2c14 <exitiputtest+0x60>
    if(chdir("iputdir") < 0){
    2bda:	00004517          	auipc	a0,0x4
    2bde:	ace50513          	addi	a0,a0,-1330 # 66a8 <malloc+0x126e>
    2be2:	38c020ef          	jal	4f6e <chdir>
    2be6:	04054163          	bltz	a0,2c28 <exitiputtest+0x74>
    if(unlink("../iputdir") < 0){
    2bea:	00004517          	auipc	a0,0x4
    2bee:	afe50513          	addi	a0,a0,-1282 # 66e8 <malloc+0x12ae>
    2bf2:	35c020ef          	jal	4f4e <unlink>
    2bf6:	04054363          	bltz	a0,2c3c <exitiputtest+0x88>
    exit(0);
    2bfa:	4501                	li	a0,0
    2bfc:	302020ef          	jal	4efe <exit>
    printf("%s: fork failed\n", s);
    2c00:	85a6                	mv	a1,s1
    2c02:	00003517          	auipc	a0,0x3
    2c06:	1f650513          	addi	a0,a0,502 # 5df8 <malloc+0x9be>
    2c0a:	778020ef          	jal	5382 <printf>
    exit(1);
    2c0e:	4505                	li	a0,1
    2c10:	2ee020ef          	jal	4efe <exit>
      printf("%s: mkdir failed\n", s);
    2c14:	85a6                	mv	a1,s1
    2c16:	00004517          	auipc	a0,0x4
    2c1a:	a9a50513          	addi	a0,a0,-1382 # 66b0 <malloc+0x1276>
    2c1e:	764020ef          	jal	5382 <printf>
      exit(1);
    2c22:	4505                	li	a0,1
    2c24:	2da020ef          	jal	4efe <exit>
      printf("%s: child chdir failed\n", s);
    2c28:	85a6                	mv	a1,s1
    2c2a:	00004517          	auipc	a0,0x4
    2c2e:	b0e50513          	addi	a0,a0,-1266 # 6738 <malloc+0x12fe>
    2c32:	750020ef          	jal	5382 <printf>
      exit(1);
    2c36:	4505                	li	a0,1
    2c38:	2c6020ef          	jal	4efe <exit>
      printf("%s: unlink ../iputdir failed\n", s);
    2c3c:	85a6                	mv	a1,s1
    2c3e:	00004517          	auipc	a0,0x4
    2c42:	aba50513          	addi	a0,a0,-1350 # 66f8 <malloc+0x12be>
    2c46:	73c020ef          	jal	5382 <printf>
      exit(1);
    2c4a:	4505                	li	a0,1
    2c4c:	2b2020ef          	jal	4efe <exit>
  wait(&xstatus);
    2c50:	fdc40513          	addi	a0,s0,-36
    2c54:	2b2020ef          	jal	4f06 <wait>
  exit(xstatus);
    2c58:	fdc42503          	lw	a0,-36(s0)
    2c5c:	2a2020ef          	jal	4efe <exit>

0000000000002c60 <dirtest>:
{
    2c60:	1101                	addi	sp,sp,-32
    2c62:	ec06                	sd	ra,24(sp)
    2c64:	e822                	sd	s0,16(sp)
    2c66:	e426                	sd	s1,8(sp)
    2c68:	1000                	addi	s0,sp,32
    2c6a:	84aa                	mv	s1,a0
  if(mkdir("dir0") < 0){
    2c6c:	00004517          	auipc	a0,0x4
    2c70:	ae450513          	addi	a0,a0,-1308 # 6750 <malloc+0x1316>
    2c74:	2f2020ef          	jal	4f66 <mkdir>
    2c78:	02054f63          	bltz	a0,2cb6 <dirtest+0x56>
  if(chdir("dir0") < 0){
    2c7c:	00004517          	auipc	a0,0x4
    2c80:	ad450513          	addi	a0,a0,-1324 # 6750 <malloc+0x1316>
    2c84:	2ea020ef          	jal	4f6e <chdir>
    2c88:	04054163          	bltz	a0,2cca <dirtest+0x6a>
  if(chdir("..") < 0){
    2c8c:	00004517          	auipc	a0,0x4
    2c90:	ae450513          	addi	a0,a0,-1308 # 6770 <malloc+0x1336>
    2c94:	2da020ef          	jal	4f6e <chdir>
    2c98:	04054363          	bltz	a0,2cde <dirtest+0x7e>
  if(unlink("dir0") < 0){
    2c9c:	00004517          	auipc	a0,0x4
    2ca0:	ab450513          	addi	a0,a0,-1356 # 6750 <malloc+0x1316>
    2ca4:	2aa020ef          	jal	4f4e <unlink>
    2ca8:	04054563          	bltz	a0,2cf2 <dirtest+0x92>
}
    2cac:	60e2                	ld	ra,24(sp)
    2cae:	6442                	ld	s0,16(sp)
    2cb0:	64a2                	ld	s1,8(sp)
    2cb2:	6105                	addi	sp,sp,32
    2cb4:	8082                	ret
    printf("%s: mkdir failed\n", s);
    2cb6:	85a6                	mv	a1,s1
    2cb8:	00004517          	auipc	a0,0x4
    2cbc:	9f850513          	addi	a0,a0,-1544 # 66b0 <malloc+0x1276>
    2cc0:	6c2020ef          	jal	5382 <printf>
    exit(1);
    2cc4:	4505                	li	a0,1
    2cc6:	238020ef          	jal	4efe <exit>
    printf("%s: chdir dir0 failed\n", s);
    2cca:	85a6                	mv	a1,s1
    2ccc:	00004517          	auipc	a0,0x4
    2cd0:	a8c50513          	addi	a0,a0,-1396 # 6758 <malloc+0x131e>
    2cd4:	6ae020ef          	jal	5382 <printf>
    exit(1);
    2cd8:	4505                	li	a0,1
    2cda:	224020ef          	jal	4efe <exit>
    printf("%s: chdir .. failed\n", s);
    2cde:	85a6                	mv	a1,s1
    2ce0:	00004517          	auipc	a0,0x4
    2ce4:	a9850513          	addi	a0,a0,-1384 # 6778 <malloc+0x133e>
    2ce8:	69a020ef          	jal	5382 <printf>
    exit(1);
    2cec:	4505                	li	a0,1
    2cee:	210020ef          	jal	4efe <exit>
    printf("%s: unlink dir0 failed\n", s);
    2cf2:	85a6                	mv	a1,s1
    2cf4:	00004517          	auipc	a0,0x4
    2cf8:	a9c50513          	addi	a0,a0,-1380 # 6790 <malloc+0x1356>
    2cfc:	686020ef          	jal	5382 <printf>
    exit(1);
    2d00:	4505                	li	a0,1
    2d02:	1fc020ef          	jal	4efe <exit>

0000000000002d06 <subdir>:
{
    2d06:	1101                	addi	sp,sp,-32
    2d08:	ec06                	sd	ra,24(sp)
    2d0a:	e822                	sd	s0,16(sp)
    2d0c:	e426                	sd	s1,8(sp)
    2d0e:	e04a                	sd	s2,0(sp)
    2d10:	1000                	addi	s0,sp,32
    2d12:	892a                	mv	s2,a0
  unlink("ff");
    2d14:	00004517          	auipc	a0,0x4
    2d18:	bc450513          	addi	a0,a0,-1084 # 68d8 <malloc+0x149e>
    2d1c:	232020ef          	jal	4f4e <unlink>
  if(mkdir("dd") != 0){
    2d20:	00004517          	auipc	a0,0x4
    2d24:	a8850513          	addi	a0,a0,-1400 # 67a8 <malloc+0x136e>
    2d28:	23e020ef          	jal	4f66 <mkdir>
    2d2c:	2e051263          	bnez	a0,3010 <subdir+0x30a>
  fd = open("dd/ff", O_CREATE | O_RDWR);
    2d30:	20200593          	li	a1,514
    2d34:	00004517          	auipc	a0,0x4
    2d38:	a9450513          	addi	a0,a0,-1388 # 67c8 <malloc+0x138e>
    2d3c:	202020ef          	jal	4f3e <open>
    2d40:	84aa                	mv	s1,a0
  if(fd < 0){
    2d42:	2e054163          	bltz	a0,3024 <subdir+0x31e>
  write(fd, "ff", 2);
    2d46:	4609                	li	a2,2
    2d48:	00004597          	auipc	a1,0x4
    2d4c:	b9058593          	addi	a1,a1,-1136 # 68d8 <malloc+0x149e>
    2d50:	1ce020ef          	jal	4f1e <write>
  close(fd);
    2d54:	8526                	mv	a0,s1
    2d56:	1d0020ef          	jal	4f26 <close>
  if(unlink("dd") >= 0){
    2d5a:	00004517          	auipc	a0,0x4
    2d5e:	a4e50513          	addi	a0,a0,-1458 # 67a8 <malloc+0x136e>
    2d62:	1ec020ef          	jal	4f4e <unlink>
    2d66:	2c055963          	bgez	a0,3038 <subdir+0x332>
  if(mkdir("/dd/dd") != 0){
    2d6a:	00004517          	auipc	a0,0x4
    2d6e:	ab650513          	addi	a0,a0,-1354 # 6820 <malloc+0x13e6>
    2d72:	1f4020ef          	jal	4f66 <mkdir>
    2d76:	2c051b63          	bnez	a0,304c <subdir+0x346>
  fd = open("dd/dd/ff", O_CREATE | O_RDWR);
    2d7a:	20200593          	li	a1,514
    2d7e:	00004517          	auipc	a0,0x4
    2d82:	aca50513          	addi	a0,a0,-1334 # 6848 <malloc+0x140e>
    2d86:	1b8020ef          	jal	4f3e <open>
    2d8a:	84aa                	mv	s1,a0
  if(fd < 0){
    2d8c:	2c054a63          	bltz	a0,3060 <subdir+0x35a>
  write(fd, "FF", 2);
    2d90:	4609                	li	a2,2
    2d92:	00004597          	auipc	a1,0x4
    2d96:	ae658593          	addi	a1,a1,-1306 # 6878 <malloc+0x143e>
    2d9a:	184020ef          	jal	4f1e <write>
  close(fd);
    2d9e:	8526                	mv	a0,s1
    2da0:	186020ef          	jal	4f26 <close>
  fd = open("dd/dd/../ff", 0);
    2da4:	4581                	li	a1,0
    2da6:	00004517          	auipc	a0,0x4
    2daa:	ada50513          	addi	a0,a0,-1318 # 6880 <malloc+0x1446>
    2dae:	190020ef          	jal	4f3e <open>
    2db2:	84aa                	mv	s1,a0
  if(fd < 0){
    2db4:	2c054063          	bltz	a0,3074 <subdir+0x36e>
  cc = read(fd, buf, sizeof(buf));
    2db8:	660d                	lui	a2,0x3
    2dba:	00009597          	auipc	a1,0x9
    2dbe:	eee58593          	addi	a1,a1,-274 # bca8 <buf>
    2dc2:	154020ef          	jal	4f16 <read>
  if(cc != 2 || buf[0] != 'f'){
    2dc6:	4789                	li	a5,2
    2dc8:	2cf51063          	bne	a0,a5,3088 <subdir+0x382>
    2dcc:	00009717          	auipc	a4,0x9
    2dd0:	edc74703          	lbu	a4,-292(a4) # bca8 <buf>
    2dd4:	06600793          	li	a5,102
    2dd8:	2af71863          	bne	a4,a5,3088 <subdir+0x382>
  close(fd);
    2ddc:	8526                	mv	a0,s1
    2dde:	148020ef          	jal	4f26 <close>
  if(link("dd/dd/ff", "dd/dd/ffff") != 0){
    2de2:	00004597          	auipc	a1,0x4
    2de6:	aee58593          	addi	a1,a1,-1298 # 68d0 <malloc+0x1496>
    2dea:	00004517          	auipc	a0,0x4
    2dee:	a5e50513          	addi	a0,a0,-1442 # 6848 <malloc+0x140e>
    2df2:	16c020ef          	jal	4f5e <link>
    2df6:	2a051363          	bnez	a0,309c <subdir+0x396>
  if(unlink("dd/dd/ff") != 0){
    2dfa:	00004517          	auipc	a0,0x4
    2dfe:	a4e50513          	addi	a0,a0,-1458 # 6848 <malloc+0x140e>
    2e02:	14c020ef          	jal	4f4e <unlink>
    2e06:	2a051563          	bnez	a0,30b0 <subdir+0x3aa>
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    2e0a:	4581                	li	a1,0
    2e0c:	00004517          	auipc	a0,0x4
    2e10:	a3c50513          	addi	a0,a0,-1476 # 6848 <malloc+0x140e>
    2e14:	12a020ef          	jal	4f3e <open>
    2e18:	2a055663          	bgez	a0,30c4 <subdir+0x3be>
  if(chdir("dd") != 0){
    2e1c:	00004517          	auipc	a0,0x4
    2e20:	98c50513          	addi	a0,a0,-1652 # 67a8 <malloc+0x136e>
    2e24:	14a020ef          	jal	4f6e <chdir>
    2e28:	2a051863          	bnez	a0,30d8 <subdir+0x3d2>
  if(chdir("dd/../../dd") != 0){
    2e2c:	00004517          	auipc	a0,0x4
    2e30:	b3c50513          	addi	a0,a0,-1220 # 6968 <malloc+0x152e>
    2e34:	13a020ef          	jal	4f6e <chdir>
    2e38:	2a051a63          	bnez	a0,30ec <subdir+0x3e6>
  if(chdir("dd/../../../dd") != 0){
    2e3c:	00004517          	auipc	a0,0x4
    2e40:	b5c50513          	addi	a0,a0,-1188 # 6998 <malloc+0x155e>
    2e44:	12a020ef          	jal	4f6e <chdir>
    2e48:	2a051c63          	bnez	a0,3100 <subdir+0x3fa>
  if(chdir("./..") != 0){
    2e4c:	00004517          	auipc	a0,0x4
    2e50:	b8450513          	addi	a0,a0,-1148 # 69d0 <malloc+0x1596>
    2e54:	11a020ef          	jal	4f6e <chdir>
    2e58:	2a051e63          	bnez	a0,3114 <subdir+0x40e>
  fd = open("dd/dd/ffff", 0);
    2e5c:	4581                	li	a1,0
    2e5e:	00004517          	auipc	a0,0x4
    2e62:	a7250513          	addi	a0,a0,-1422 # 68d0 <malloc+0x1496>
    2e66:	0d8020ef          	jal	4f3e <open>
    2e6a:	84aa                	mv	s1,a0
  if(fd < 0){
    2e6c:	2a054e63          	bltz	a0,3128 <subdir+0x422>
  if(read(fd, buf, sizeof(buf)) != 2){
    2e70:	660d                	lui	a2,0x3
    2e72:	00009597          	auipc	a1,0x9
    2e76:	e3658593          	addi	a1,a1,-458 # bca8 <buf>
    2e7a:	09c020ef          	jal	4f16 <read>
    2e7e:	4789                	li	a5,2
    2e80:	2af51e63          	bne	a0,a5,313c <subdir+0x436>
  close(fd);
    2e84:	8526                	mv	a0,s1
    2e86:	0a0020ef          	jal	4f26 <close>
  if(open("dd/dd/ff", O_RDONLY) >= 0){
    2e8a:	4581                	li	a1,0
    2e8c:	00004517          	auipc	a0,0x4
    2e90:	9bc50513          	addi	a0,a0,-1604 # 6848 <malloc+0x140e>
    2e94:	0aa020ef          	jal	4f3e <open>
    2e98:	2a055c63          	bgez	a0,3150 <subdir+0x44a>
  if(open("dd/ff/ff", O_CREATE|O_RDWR) >= 0){
    2e9c:	20200593          	li	a1,514
    2ea0:	00004517          	auipc	a0,0x4
    2ea4:	bc050513          	addi	a0,a0,-1088 # 6a60 <malloc+0x1626>
    2ea8:	096020ef          	jal	4f3e <open>
    2eac:	2a055c63          	bgez	a0,3164 <subdir+0x45e>
  if(open("dd/xx/ff", O_CREATE|O_RDWR) >= 0){
    2eb0:	20200593          	li	a1,514
    2eb4:	00004517          	auipc	a0,0x4
    2eb8:	bdc50513          	addi	a0,a0,-1060 # 6a90 <malloc+0x1656>
    2ebc:	082020ef          	jal	4f3e <open>
    2ec0:	2a055c63          	bgez	a0,3178 <subdir+0x472>
  if(open("dd", O_CREATE) >= 0){
    2ec4:	20000593          	li	a1,512
    2ec8:	00004517          	auipc	a0,0x4
    2ecc:	8e050513          	addi	a0,a0,-1824 # 67a8 <malloc+0x136e>
    2ed0:	06e020ef          	jal	4f3e <open>
    2ed4:	2a055c63          	bgez	a0,318c <subdir+0x486>
  if(open("dd", O_RDWR) >= 0){
    2ed8:	4589                	li	a1,2
    2eda:	00004517          	auipc	a0,0x4
    2ede:	8ce50513          	addi	a0,a0,-1842 # 67a8 <malloc+0x136e>
    2ee2:	05c020ef          	jal	4f3e <open>
    2ee6:	2a055d63          	bgez	a0,31a0 <subdir+0x49a>
  if(open("dd", O_WRONLY) >= 0){
    2eea:	4585                	li	a1,1
    2eec:	00004517          	auipc	a0,0x4
    2ef0:	8bc50513          	addi	a0,a0,-1860 # 67a8 <malloc+0x136e>
    2ef4:	04a020ef          	jal	4f3e <open>
    2ef8:	2a055e63          	bgez	a0,31b4 <subdir+0x4ae>
  if(link("dd/ff/ff", "dd/dd/xx") == 0){
    2efc:	00004597          	auipc	a1,0x4
    2f00:	c2458593          	addi	a1,a1,-988 # 6b20 <malloc+0x16e6>
    2f04:	00004517          	auipc	a0,0x4
    2f08:	b5c50513          	addi	a0,a0,-1188 # 6a60 <malloc+0x1626>
    2f0c:	052020ef          	jal	4f5e <link>
    2f10:	2a050c63          	beqz	a0,31c8 <subdir+0x4c2>
  if(link("dd/xx/ff", "dd/dd/xx") == 0){
    2f14:	00004597          	auipc	a1,0x4
    2f18:	c0c58593          	addi	a1,a1,-1012 # 6b20 <malloc+0x16e6>
    2f1c:	00004517          	auipc	a0,0x4
    2f20:	b7450513          	addi	a0,a0,-1164 # 6a90 <malloc+0x1656>
    2f24:	03a020ef          	jal	4f5e <link>
    2f28:	2a050a63          	beqz	a0,31dc <subdir+0x4d6>
  if(link("dd/ff", "dd/dd/ffff") == 0){
    2f2c:	00004597          	auipc	a1,0x4
    2f30:	9a458593          	addi	a1,a1,-1628 # 68d0 <malloc+0x1496>
    2f34:	00004517          	auipc	a0,0x4
    2f38:	89450513          	addi	a0,a0,-1900 # 67c8 <malloc+0x138e>
    2f3c:	022020ef          	jal	4f5e <link>
    2f40:	2a050863          	beqz	a0,31f0 <subdir+0x4ea>
  if(mkdir("dd/ff/ff") == 0){
    2f44:	00004517          	auipc	a0,0x4
    2f48:	b1c50513          	addi	a0,a0,-1252 # 6a60 <malloc+0x1626>
    2f4c:	01a020ef          	jal	4f66 <mkdir>
    2f50:	2a050a63          	beqz	a0,3204 <subdir+0x4fe>
  if(mkdir("dd/xx/ff") == 0){
    2f54:	00004517          	auipc	a0,0x4
    2f58:	b3c50513          	addi	a0,a0,-1220 # 6a90 <malloc+0x1656>
    2f5c:	00a020ef          	jal	4f66 <mkdir>
    2f60:	2a050c63          	beqz	a0,3218 <subdir+0x512>
  if(mkdir("dd/dd/ffff") == 0){
    2f64:	00004517          	auipc	a0,0x4
    2f68:	96c50513          	addi	a0,a0,-1684 # 68d0 <malloc+0x1496>
    2f6c:	7fb010ef          	jal	4f66 <mkdir>
    2f70:	2a050e63          	beqz	a0,322c <subdir+0x526>
  if(unlink("dd/xx/ff") == 0){
    2f74:	00004517          	auipc	a0,0x4
    2f78:	b1c50513          	addi	a0,a0,-1252 # 6a90 <malloc+0x1656>
    2f7c:	7d3010ef          	jal	4f4e <unlink>
    2f80:	2c050063          	beqz	a0,3240 <subdir+0x53a>
  if(unlink("dd/ff/ff") == 0){
    2f84:	00004517          	auipc	a0,0x4
    2f88:	adc50513          	addi	a0,a0,-1316 # 6a60 <malloc+0x1626>
    2f8c:	7c3010ef          	jal	4f4e <unlink>
    2f90:	2c050263          	beqz	a0,3254 <subdir+0x54e>
  if(chdir("dd/ff") == 0){
    2f94:	00004517          	auipc	a0,0x4
    2f98:	83450513          	addi	a0,a0,-1996 # 67c8 <malloc+0x138e>
    2f9c:	7d3010ef          	jal	4f6e <chdir>
    2fa0:	2c050463          	beqz	a0,3268 <subdir+0x562>
  if(chdir("dd/xx") == 0){
    2fa4:	00004517          	auipc	a0,0x4
    2fa8:	ccc50513          	addi	a0,a0,-820 # 6c70 <malloc+0x1836>
    2fac:	7c3010ef          	jal	4f6e <chdir>
    2fb0:	2c050663          	beqz	a0,327c <subdir+0x576>
  if(unlink("dd/dd/ffff") != 0){
    2fb4:	00004517          	auipc	a0,0x4
    2fb8:	91c50513          	addi	a0,a0,-1764 # 68d0 <malloc+0x1496>
    2fbc:	793010ef          	jal	4f4e <unlink>
    2fc0:	2c051863          	bnez	a0,3290 <subdir+0x58a>
  if(unlink("dd/ff") != 0){
    2fc4:	00004517          	auipc	a0,0x4
    2fc8:	80450513          	addi	a0,a0,-2044 # 67c8 <malloc+0x138e>
    2fcc:	783010ef          	jal	4f4e <unlink>
    2fd0:	2c051a63          	bnez	a0,32a4 <subdir+0x59e>
  if(unlink("dd") == 0){
    2fd4:	00003517          	auipc	a0,0x3
    2fd8:	7d450513          	addi	a0,a0,2004 # 67a8 <malloc+0x136e>
    2fdc:	773010ef          	jal	4f4e <unlink>
    2fe0:	2c050c63          	beqz	a0,32b8 <subdir+0x5b2>
  if(unlink("dd/dd") < 0){
    2fe4:	00004517          	auipc	a0,0x4
    2fe8:	cfc50513          	addi	a0,a0,-772 # 6ce0 <malloc+0x18a6>
    2fec:	763010ef          	jal	4f4e <unlink>
    2ff0:	2c054e63          	bltz	a0,32cc <subdir+0x5c6>
  if(unlink("dd") < 0){
    2ff4:	00003517          	auipc	a0,0x3
    2ff8:	7b450513          	addi	a0,a0,1972 # 67a8 <malloc+0x136e>
    2ffc:	753010ef          	jal	4f4e <unlink>
    3000:	2e054063          	bltz	a0,32e0 <subdir+0x5da>
}
    3004:	60e2                	ld	ra,24(sp)
    3006:	6442                	ld	s0,16(sp)
    3008:	64a2                	ld	s1,8(sp)
    300a:	6902                	ld	s2,0(sp)
    300c:	6105                	addi	sp,sp,32
    300e:	8082                	ret
    printf("%s: mkdir dd failed\n", s);
    3010:	85ca                	mv	a1,s2
    3012:	00003517          	auipc	a0,0x3
    3016:	79e50513          	addi	a0,a0,1950 # 67b0 <malloc+0x1376>
    301a:	368020ef          	jal	5382 <printf>
    exit(1);
    301e:	4505                	li	a0,1
    3020:	6df010ef          	jal	4efe <exit>
    printf("%s: create dd/ff failed\n", s);
    3024:	85ca                	mv	a1,s2
    3026:	00003517          	auipc	a0,0x3
    302a:	7aa50513          	addi	a0,a0,1962 # 67d0 <malloc+0x1396>
    302e:	354020ef          	jal	5382 <printf>
    exit(1);
    3032:	4505                	li	a0,1
    3034:	6cb010ef          	jal	4efe <exit>
    printf("%s: unlink dd (non-empty dir) succeeded!\n", s);
    3038:	85ca                	mv	a1,s2
    303a:	00003517          	auipc	a0,0x3
    303e:	7b650513          	addi	a0,a0,1974 # 67f0 <malloc+0x13b6>
    3042:	340020ef          	jal	5382 <printf>
    exit(1);
    3046:	4505                	li	a0,1
    3048:	6b7010ef          	jal	4efe <exit>
    printf("%s: subdir mkdir dd/dd failed\n", s);
    304c:	85ca                	mv	a1,s2
    304e:	00003517          	auipc	a0,0x3
    3052:	7da50513          	addi	a0,a0,2010 # 6828 <malloc+0x13ee>
    3056:	32c020ef          	jal	5382 <printf>
    exit(1);
    305a:	4505                	li	a0,1
    305c:	6a3010ef          	jal	4efe <exit>
    printf("%s: create dd/dd/ff failed\n", s);
    3060:	85ca                	mv	a1,s2
    3062:	00003517          	auipc	a0,0x3
    3066:	7f650513          	addi	a0,a0,2038 # 6858 <malloc+0x141e>
    306a:	318020ef          	jal	5382 <printf>
    exit(1);
    306e:	4505                	li	a0,1
    3070:	68f010ef          	jal	4efe <exit>
    printf("%s: open dd/dd/../ff failed\n", s);
    3074:	85ca                	mv	a1,s2
    3076:	00004517          	auipc	a0,0x4
    307a:	81a50513          	addi	a0,a0,-2022 # 6890 <malloc+0x1456>
    307e:	304020ef          	jal	5382 <printf>
    exit(1);
    3082:	4505                	li	a0,1
    3084:	67b010ef          	jal	4efe <exit>
    printf("%s: dd/dd/../ff wrong content\n", s);
    3088:	85ca                	mv	a1,s2
    308a:	00004517          	auipc	a0,0x4
    308e:	82650513          	addi	a0,a0,-2010 # 68b0 <malloc+0x1476>
    3092:	2f0020ef          	jal	5382 <printf>
    exit(1);
    3096:	4505                	li	a0,1
    3098:	667010ef          	jal	4efe <exit>
    printf("%s: link dd/dd/ff dd/dd/ffff failed\n", s);
    309c:	85ca                	mv	a1,s2
    309e:	00004517          	auipc	a0,0x4
    30a2:	84250513          	addi	a0,a0,-1982 # 68e0 <malloc+0x14a6>
    30a6:	2dc020ef          	jal	5382 <printf>
    exit(1);
    30aa:	4505                	li	a0,1
    30ac:	653010ef          	jal	4efe <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    30b0:	85ca                	mv	a1,s2
    30b2:	00004517          	auipc	a0,0x4
    30b6:	85650513          	addi	a0,a0,-1962 # 6908 <malloc+0x14ce>
    30ba:	2c8020ef          	jal	5382 <printf>
    exit(1);
    30be:	4505                	li	a0,1
    30c0:	63f010ef          	jal	4efe <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded\n", s);
    30c4:	85ca                	mv	a1,s2
    30c6:	00004517          	auipc	a0,0x4
    30ca:	86250513          	addi	a0,a0,-1950 # 6928 <malloc+0x14ee>
    30ce:	2b4020ef          	jal	5382 <printf>
    exit(1);
    30d2:	4505                	li	a0,1
    30d4:	62b010ef          	jal	4efe <exit>
    printf("%s: chdir dd failed\n", s);
    30d8:	85ca                	mv	a1,s2
    30da:	00004517          	auipc	a0,0x4
    30de:	87650513          	addi	a0,a0,-1930 # 6950 <malloc+0x1516>
    30e2:	2a0020ef          	jal	5382 <printf>
    exit(1);
    30e6:	4505                	li	a0,1
    30e8:	617010ef          	jal	4efe <exit>
    printf("%s: chdir dd/../../dd failed\n", s);
    30ec:	85ca                	mv	a1,s2
    30ee:	00004517          	auipc	a0,0x4
    30f2:	88a50513          	addi	a0,a0,-1910 # 6978 <malloc+0x153e>
    30f6:	28c020ef          	jal	5382 <printf>
    exit(1);
    30fa:	4505                	li	a0,1
    30fc:	603010ef          	jal	4efe <exit>
    printf("%s: chdir dd/../../../dd failed\n", s);
    3100:	85ca                	mv	a1,s2
    3102:	00004517          	auipc	a0,0x4
    3106:	8a650513          	addi	a0,a0,-1882 # 69a8 <malloc+0x156e>
    310a:	278020ef          	jal	5382 <printf>
    exit(1);
    310e:	4505                	li	a0,1
    3110:	5ef010ef          	jal	4efe <exit>
    printf("%s: chdir ./.. failed\n", s);
    3114:	85ca                	mv	a1,s2
    3116:	00004517          	auipc	a0,0x4
    311a:	8c250513          	addi	a0,a0,-1854 # 69d8 <malloc+0x159e>
    311e:	264020ef          	jal	5382 <printf>
    exit(1);
    3122:	4505                	li	a0,1
    3124:	5db010ef          	jal	4efe <exit>
    printf("%s: open dd/dd/ffff failed\n", s);
    3128:	85ca                	mv	a1,s2
    312a:	00004517          	auipc	a0,0x4
    312e:	8c650513          	addi	a0,a0,-1850 # 69f0 <malloc+0x15b6>
    3132:	250020ef          	jal	5382 <printf>
    exit(1);
    3136:	4505                	li	a0,1
    3138:	5c7010ef          	jal	4efe <exit>
    printf("%s: read dd/dd/ffff wrong len\n", s);
    313c:	85ca                	mv	a1,s2
    313e:	00004517          	auipc	a0,0x4
    3142:	8d250513          	addi	a0,a0,-1838 # 6a10 <malloc+0x15d6>
    3146:	23c020ef          	jal	5382 <printf>
    exit(1);
    314a:	4505                	li	a0,1
    314c:	5b3010ef          	jal	4efe <exit>
    printf("%s: open (unlinked) dd/dd/ff succeeded!\n", s);
    3150:	85ca                	mv	a1,s2
    3152:	00004517          	auipc	a0,0x4
    3156:	8de50513          	addi	a0,a0,-1826 # 6a30 <malloc+0x15f6>
    315a:	228020ef          	jal	5382 <printf>
    exit(1);
    315e:	4505                	li	a0,1
    3160:	59f010ef          	jal	4efe <exit>
    printf("%s: create dd/ff/ff succeeded!\n", s);
    3164:	85ca                	mv	a1,s2
    3166:	00004517          	auipc	a0,0x4
    316a:	90a50513          	addi	a0,a0,-1782 # 6a70 <malloc+0x1636>
    316e:	214020ef          	jal	5382 <printf>
    exit(1);
    3172:	4505                	li	a0,1
    3174:	58b010ef          	jal	4efe <exit>
    printf("%s: create dd/xx/ff succeeded!\n", s);
    3178:	85ca                	mv	a1,s2
    317a:	00004517          	auipc	a0,0x4
    317e:	92650513          	addi	a0,a0,-1754 # 6aa0 <malloc+0x1666>
    3182:	200020ef          	jal	5382 <printf>
    exit(1);
    3186:	4505                	li	a0,1
    3188:	577010ef          	jal	4efe <exit>
    printf("%s: create dd succeeded!\n", s);
    318c:	85ca                	mv	a1,s2
    318e:	00004517          	auipc	a0,0x4
    3192:	93250513          	addi	a0,a0,-1742 # 6ac0 <malloc+0x1686>
    3196:	1ec020ef          	jal	5382 <printf>
    exit(1);
    319a:	4505                	li	a0,1
    319c:	563010ef          	jal	4efe <exit>
    printf("%s: open dd rdwr succeeded!\n", s);
    31a0:	85ca                	mv	a1,s2
    31a2:	00004517          	auipc	a0,0x4
    31a6:	93e50513          	addi	a0,a0,-1730 # 6ae0 <malloc+0x16a6>
    31aa:	1d8020ef          	jal	5382 <printf>
    exit(1);
    31ae:	4505                	li	a0,1
    31b0:	54f010ef          	jal	4efe <exit>
    printf("%s: open dd wronly succeeded!\n", s);
    31b4:	85ca                	mv	a1,s2
    31b6:	00004517          	auipc	a0,0x4
    31ba:	94a50513          	addi	a0,a0,-1718 # 6b00 <malloc+0x16c6>
    31be:	1c4020ef          	jal	5382 <printf>
    exit(1);
    31c2:	4505                	li	a0,1
    31c4:	53b010ef          	jal	4efe <exit>
    printf("%s: link dd/ff/ff dd/dd/xx succeeded!\n", s);
    31c8:	85ca                	mv	a1,s2
    31ca:	00004517          	auipc	a0,0x4
    31ce:	96650513          	addi	a0,a0,-1690 # 6b30 <malloc+0x16f6>
    31d2:	1b0020ef          	jal	5382 <printf>
    exit(1);
    31d6:	4505                	li	a0,1
    31d8:	527010ef          	jal	4efe <exit>
    printf("%s: link dd/xx/ff dd/dd/xx succeeded!\n", s);
    31dc:	85ca                	mv	a1,s2
    31de:	00004517          	auipc	a0,0x4
    31e2:	97a50513          	addi	a0,a0,-1670 # 6b58 <malloc+0x171e>
    31e6:	19c020ef          	jal	5382 <printf>
    exit(1);
    31ea:	4505                	li	a0,1
    31ec:	513010ef          	jal	4efe <exit>
    printf("%s: link dd/ff dd/dd/ffff succeeded!\n", s);
    31f0:	85ca                	mv	a1,s2
    31f2:	00004517          	auipc	a0,0x4
    31f6:	98e50513          	addi	a0,a0,-1650 # 6b80 <malloc+0x1746>
    31fa:	188020ef          	jal	5382 <printf>
    exit(1);
    31fe:	4505                	li	a0,1
    3200:	4ff010ef          	jal	4efe <exit>
    printf("%s: mkdir dd/ff/ff succeeded!\n", s);
    3204:	85ca                	mv	a1,s2
    3206:	00004517          	auipc	a0,0x4
    320a:	9a250513          	addi	a0,a0,-1630 # 6ba8 <malloc+0x176e>
    320e:	174020ef          	jal	5382 <printf>
    exit(1);
    3212:	4505                	li	a0,1
    3214:	4eb010ef          	jal	4efe <exit>
    printf("%s: mkdir dd/xx/ff succeeded!\n", s);
    3218:	85ca                	mv	a1,s2
    321a:	00004517          	auipc	a0,0x4
    321e:	9ae50513          	addi	a0,a0,-1618 # 6bc8 <malloc+0x178e>
    3222:	160020ef          	jal	5382 <printf>
    exit(1);
    3226:	4505                	li	a0,1
    3228:	4d7010ef          	jal	4efe <exit>
    printf("%s: mkdir dd/dd/ffff succeeded!\n", s);
    322c:	85ca                	mv	a1,s2
    322e:	00004517          	auipc	a0,0x4
    3232:	9ba50513          	addi	a0,a0,-1606 # 6be8 <malloc+0x17ae>
    3236:	14c020ef          	jal	5382 <printf>
    exit(1);
    323a:	4505                	li	a0,1
    323c:	4c3010ef          	jal	4efe <exit>
    printf("%s: unlink dd/xx/ff succeeded!\n", s);
    3240:	85ca                	mv	a1,s2
    3242:	00004517          	auipc	a0,0x4
    3246:	9ce50513          	addi	a0,a0,-1586 # 6c10 <malloc+0x17d6>
    324a:	138020ef          	jal	5382 <printf>
    exit(1);
    324e:	4505                	li	a0,1
    3250:	4af010ef          	jal	4efe <exit>
    printf("%s: unlink dd/ff/ff succeeded!\n", s);
    3254:	85ca                	mv	a1,s2
    3256:	00004517          	auipc	a0,0x4
    325a:	9da50513          	addi	a0,a0,-1574 # 6c30 <malloc+0x17f6>
    325e:	124020ef          	jal	5382 <printf>
    exit(1);
    3262:	4505                	li	a0,1
    3264:	49b010ef          	jal	4efe <exit>
    printf("%s: chdir dd/ff succeeded!\n", s);
    3268:	85ca                	mv	a1,s2
    326a:	00004517          	auipc	a0,0x4
    326e:	9e650513          	addi	a0,a0,-1562 # 6c50 <malloc+0x1816>
    3272:	110020ef          	jal	5382 <printf>
    exit(1);
    3276:	4505                	li	a0,1
    3278:	487010ef          	jal	4efe <exit>
    printf("%s: chdir dd/xx succeeded!\n", s);
    327c:	85ca                	mv	a1,s2
    327e:	00004517          	auipc	a0,0x4
    3282:	9fa50513          	addi	a0,a0,-1542 # 6c78 <malloc+0x183e>
    3286:	0fc020ef          	jal	5382 <printf>
    exit(1);
    328a:	4505                	li	a0,1
    328c:	473010ef          	jal	4efe <exit>
    printf("%s: unlink dd/dd/ff failed\n", s);
    3290:	85ca                	mv	a1,s2
    3292:	00003517          	auipc	a0,0x3
    3296:	67650513          	addi	a0,a0,1654 # 6908 <malloc+0x14ce>
    329a:	0e8020ef          	jal	5382 <printf>
    exit(1);
    329e:	4505                	li	a0,1
    32a0:	45f010ef          	jal	4efe <exit>
    printf("%s: unlink dd/ff failed\n", s);
    32a4:	85ca                	mv	a1,s2
    32a6:	00004517          	auipc	a0,0x4
    32aa:	9f250513          	addi	a0,a0,-1550 # 6c98 <malloc+0x185e>
    32ae:	0d4020ef          	jal	5382 <printf>
    exit(1);
    32b2:	4505                	li	a0,1
    32b4:	44b010ef          	jal	4efe <exit>
    printf("%s: unlink non-empty dd succeeded!\n", s);
    32b8:	85ca                	mv	a1,s2
    32ba:	00004517          	auipc	a0,0x4
    32be:	9fe50513          	addi	a0,a0,-1538 # 6cb8 <malloc+0x187e>
    32c2:	0c0020ef          	jal	5382 <printf>
    exit(1);
    32c6:	4505                	li	a0,1
    32c8:	437010ef          	jal	4efe <exit>
    printf("%s: unlink dd/dd failed\n", s);
    32cc:	85ca                	mv	a1,s2
    32ce:	00004517          	auipc	a0,0x4
    32d2:	a1a50513          	addi	a0,a0,-1510 # 6ce8 <malloc+0x18ae>
    32d6:	0ac020ef          	jal	5382 <printf>
    exit(1);
    32da:	4505                	li	a0,1
    32dc:	423010ef          	jal	4efe <exit>
    printf("%s: unlink dd failed\n", s);
    32e0:	85ca                	mv	a1,s2
    32e2:	00004517          	auipc	a0,0x4
    32e6:	a2650513          	addi	a0,a0,-1498 # 6d08 <malloc+0x18ce>
    32ea:	098020ef          	jal	5382 <printf>
    exit(1);
    32ee:	4505                	li	a0,1
    32f0:	40f010ef          	jal	4efe <exit>

00000000000032f4 <rmdot>:
{
    32f4:	1101                	addi	sp,sp,-32
    32f6:	ec06                	sd	ra,24(sp)
    32f8:	e822                	sd	s0,16(sp)
    32fa:	e426                	sd	s1,8(sp)
    32fc:	1000                	addi	s0,sp,32
    32fe:	84aa                	mv	s1,a0
  if(mkdir("dots") != 0){
    3300:	00004517          	auipc	a0,0x4
    3304:	a2050513          	addi	a0,a0,-1504 # 6d20 <malloc+0x18e6>
    3308:	45f010ef          	jal	4f66 <mkdir>
    330c:	e53d                	bnez	a0,337a <rmdot+0x86>
  if(chdir("dots") != 0){
    330e:	00004517          	auipc	a0,0x4
    3312:	a1250513          	addi	a0,a0,-1518 # 6d20 <malloc+0x18e6>
    3316:	459010ef          	jal	4f6e <chdir>
    331a:	e935                	bnez	a0,338e <rmdot+0x9a>
  if(unlink(".") == 0){
    331c:	00003517          	auipc	a0,0x3
    3320:	93450513          	addi	a0,a0,-1740 # 5c50 <malloc+0x816>
    3324:	42b010ef          	jal	4f4e <unlink>
    3328:	cd2d                	beqz	a0,33a2 <rmdot+0xae>
  if(unlink("..") == 0){
    332a:	00003517          	auipc	a0,0x3
    332e:	44650513          	addi	a0,a0,1094 # 6770 <malloc+0x1336>
    3332:	41d010ef          	jal	4f4e <unlink>
    3336:	c141                	beqz	a0,33b6 <rmdot+0xc2>
  if(chdir("/") != 0){
    3338:	00003517          	auipc	a0,0x3
    333c:	3e050513          	addi	a0,a0,992 # 6718 <malloc+0x12de>
    3340:	42f010ef          	jal	4f6e <chdir>
    3344:	e159                	bnez	a0,33ca <rmdot+0xd6>
  if(unlink("dots/.") == 0){
    3346:	00004517          	auipc	a0,0x4
    334a:	a4250513          	addi	a0,a0,-1470 # 6d88 <malloc+0x194e>
    334e:	401010ef          	jal	4f4e <unlink>
    3352:	c551                	beqz	a0,33de <rmdot+0xea>
  if(unlink("dots/..") == 0){
    3354:	00004517          	auipc	a0,0x4
    3358:	a5c50513          	addi	a0,a0,-1444 # 6db0 <malloc+0x1976>
    335c:	3f3010ef          	jal	4f4e <unlink>
    3360:	c949                	beqz	a0,33f2 <rmdot+0xfe>
  if(unlink("dots") != 0){
    3362:	00004517          	auipc	a0,0x4
    3366:	9be50513          	addi	a0,a0,-1602 # 6d20 <malloc+0x18e6>
    336a:	3e5010ef          	jal	4f4e <unlink>
    336e:	ed41                	bnez	a0,3406 <rmdot+0x112>
}
    3370:	60e2                	ld	ra,24(sp)
    3372:	6442                	ld	s0,16(sp)
    3374:	64a2                	ld	s1,8(sp)
    3376:	6105                	addi	sp,sp,32
    3378:	8082                	ret
    printf("%s: mkdir dots failed\n", s);
    337a:	85a6                	mv	a1,s1
    337c:	00004517          	auipc	a0,0x4
    3380:	9ac50513          	addi	a0,a0,-1620 # 6d28 <malloc+0x18ee>
    3384:	7ff010ef          	jal	5382 <printf>
    exit(1);
    3388:	4505                	li	a0,1
    338a:	375010ef          	jal	4efe <exit>
    printf("%s: chdir dots failed\n", s);
    338e:	85a6                	mv	a1,s1
    3390:	00004517          	auipc	a0,0x4
    3394:	9b050513          	addi	a0,a0,-1616 # 6d40 <malloc+0x1906>
    3398:	7eb010ef          	jal	5382 <printf>
    exit(1);
    339c:	4505                	li	a0,1
    339e:	361010ef          	jal	4efe <exit>
    printf("%s: rm . worked!\n", s);
    33a2:	85a6                	mv	a1,s1
    33a4:	00004517          	auipc	a0,0x4
    33a8:	9b450513          	addi	a0,a0,-1612 # 6d58 <malloc+0x191e>
    33ac:	7d7010ef          	jal	5382 <printf>
    exit(1);
    33b0:	4505                	li	a0,1
    33b2:	34d010ef          	jal	4efe <exit>
    printf("%s: rm .. worked!\n", s);
    33b6:	85a6                	mv	a1,s1
    33b8:	00004517          	auipc	a0,0x4
    33bc:	9b850513          	addi	a0,a0,-1608 # 6d70 <malloc+0x1936>
    33c0:	7c3010ef          	jal	5382 <printf>
    exit(1);
    33c4:	4505                	li	a0,1
    33c6:	339010ef          	jal	4efe <exit>
    printf("%s: chdir / failed\n", s);
    33ca:	85a6                	mv	a1,s1
    33cc:	00003517          	auipc	a0,0x3
    33d0:	35450513          	addi	a0,a0,852 # 6720 <malloc+0x12e6>
    33d4:	7af010ef          	jal	5382 <printf>
    exit(1);
    33d8:	4505                	li	a0,1
    33da:	325010ef          	jal	4efe <exit>
    printf("%s: unlink dots/. worked!\n", s);
    33de:	85a6                	mv	a1,s1
    33e0:	00004517          	auipc	a0,0x4
    33e4:	9b050513          	addi	a0,a0,-1616 # 6d90 <malloc+0x1956>
    33e8:	79b010ef          	jal	5382 <printf>
    exit(1);
    33ec:	4505                	li	a0,1
    33ee:	311010ef          	jal	4efe <exit>
    printf("%s: unlink dots/.. worked!\n", s);
    33f2:	85a6                	mv	a1,s1
    33f4:	00004517          	auipc	a0,0x4
    33f8:	9c450513          	addi	a0,a0,-1596 # 6db8 <malloc+0x197e>
    33fc:	787010ef          	jal	5382 <printf>
    exit(1);
    3400:	4505                	li	a0,1
    3402:	2fd010ef          	jal	4efe <exit>
    printf("%s: unlink dots failed!\n", s);
    3406:	85a6                	mv	a1,s1
    3408:	00004517          	auipc	a0,0x4
    340c:	9d050513          	addi	a0,a0,-1584 # 6dd8 <malloc+0x199e>
    3410:	773010ef          	jal	5382 <printf>
    exit(1);
    3414:	4505                	li	a0,1
    3416:	2e9010ef          	jal	4efe <exit>

000000000000341a <dirfile>:
{
    341a:	1101                	addi	sp,sp,-32
    341c:	ec06                	sd	ra,24(sp)
    341e:	e822                	sd	s0,16(sp)
    3420:	e426                	sd	s1,8(sp)
    3422:	e04a                	sd	s2,0(sp)
    3424:	1000                	addi	s0,sp,32
    3426:	892a                	mv	s2,a0
  fd = open("dirfile", O_CREATE);
    3428:	20000593          	li	a1,512
    342c:	00004517          	auipc	a0,0x4
    3430:	9cc50513          	addi	a0,a0,-1588 # 6df8 <malloc+0x19be>
    3434:	30b010ef          	jal	4f3e <open>
  if(fd < 0){
    3438:	0c054563          	bltz	a0,3502 <dirfile+0xe8>
  close(fd);
    343c:	2eb010ef          	jal	4f26 <close>
  if(chdir("dirfile") == 0){
    3440:	00004517          	auipc	a0,0x4
    3444:	9b850513          	addi	a0,a0,-1608 # 6df8 <malloc+0x19be>
    3448:	327010ef          	jal	4f6e <chdir>
    344c:	c569                	beqz	a0,3516 <dirfile+0xfc>
  fd = open("dirfile/xx", 0);
    344e:	4581                	li	a1,0
    3450:	00004517          	auipc	a0,0x4
    3454:	9f050513          	addi	a0,a0,-1552 # 6e40 <malloc+0x1a06>
    3458:	2e7010ef          	jal	4f3e <open>
  if(fd >= 0){
    345c:	0c055763          	bgez	a0,352a <dirfile+0x110>
  fd = open("dirfile/xx", O_CREATE);
    3460:	20000593          	li	a1,512
    3464:	00004517          	auipc	a0,0x4
    3468:	9dc50513          	addi	a0,a0,-1572 # 6e40 <malloc+0x1a06>
    346c:	2d3010ef          	jal	4f3e <open>
  if(fd >= 0){
    3470:	0c055763          	bgez	a0,353e <dirfile+0x124>
  if(mkdir("dirfile/xx") == 0){
    3474:	00004517          	auipc	a0,0x4
    3478:	9cc50513          	addi	a0,a0,-1588 # 6e40 <malloc+0x1a06>
    347c:	2eb010ef          	jal	4f66 <mkdir>
    3480:	0c050963          	beqz	a0,3552 <dirfile+0x138>
  if(unlink("dirfile/xx") == 0){
    3484:	00004517          	auipc	a0,0x4
    3488:	9bc50513          	addi	a0,a0,-1604 # 6e40 <malloc+0x1a06>
    348c:	2c3010ef          	jal	4f4e <unlink>
    3490:	0c050b63          	beqz	a0,3566 <dirfile+0x14c>
  if(link("README", "dirfile/xx") == 0){
    3494:	00004597          	auipc	a1,0x4
    3498:	9ac58593          	addi	a1,a1,-1620 # 6e40 <malloc+0x1a06>
    349c:	00002517          	auipc	a0,0x2
    34a0:	2a450513          	addi	a0,a0,676 # 5740 <malloc+0x306>
    34a4:	2bb010ef          	jal	4f5e <link>
    34a8:	0c050963          	beqz	a0,357a <dirfile+0x160>
  if(unlink("dirfile") != 0){
    34ac:	00004517          	auipc	a0,0x4
    34b0:	94c50513          	addi	a0,a0,-1716 # 6df8 <malloc+0x19be>
    34b4:	29b010ef          	jal	4f4e <unlink>
    34b8:	0c051b63          	bnez	a0,358e <dirfile+0x174>
  fd = open(".", O_RDWR);
    34bc:	4589                	li	a1,2
    34be:	00002517          	auipc	a0,0x2
    34c2:	79250513          	addi	a0,a0,1938 # 5c50 <malloc+0x816>
    34c6:	279010ef          	jal	4f3e <open>
  if(fd >= 0){
    34ca:	0c055c63          	bgez	a0,35a2 <dirfile+0x188>
  fd = open(".", 0);
    34ce:	4581                	li	a1,0
    34d0:	00002517          	auipc	a0,0x2
    34d4:	78050513          	addi	a0,a0,1920 # 5c50 <malloc+0x816>
    34d8:	267010ef          	jal	4f3e <open>
    34dc:	84aa                	mv	s1,a0
  if(write(fd, "x", 1) > 0){
    34de:	4605                	li	a2,1
    34e0:	00002597          	auipc	a1,0x2
    34e4:	0f858593          	addi	a1,a1,248 # 55d8 <malloc+0x19e>
    34e8:	237010ef          	jal	4f1e <write>
    34ec:	0ca04563          	bgtz	a0,35b6 <dirfile+0x19c>
  close(fd);
    34f0:	8526                	mv	a0,s1
    34f2:	235010ef          	jal	4f26 <close>
}
    34f6:	60e2                	ld	ra,24(sp)
    34f8:	6442                	ld	s0,16(sp)
    34fa:	64a2                	ld	s1,8(sp)
    34fc:	6902                	ld	s2,0(sp)
    34fe:	6105                	addi	sp,sp,32
    3500:	8082                	ret
    printf("%s: create dirfile failed\n", s);
    3502:	85ca                	mv	a1,s2
    3504:	00004517          	auipc	a0,0x4
    3508:	8fc50513          	addi	a0,a0,-1796 # 6e00 <malloc+0x19c6>
    350c:	677010ef          	jal	5382 <printf>
    exit(1);
    3510:	4505                	li	a0,1
    3512:	1ed010ef          	jal	4efe <exit>
    printf("%s: chdir dirfile succeeded!\n", s);
    3516:	85ca                	mv	a1,s2
    3518:	00004517          	auipc	a0,0x4
    351c:	90850513          	addi	a0,a0,-1784 # 6e20 <malloc+0x19e6>
    3520:	663010ef          	jal	5382 <printf>
    exit(1);
    3524:	4505                	li	a0,1
    3526:	1d9010ef          	jal	4efe <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    352a:	85ca                	mv	a1,s2
    352c:	00004517          	auipc	a0,0x4
    3530:	92450513          	addi	a0,a0,-1756 # 6e50 <malloc+0x1a16>
    3534:	64f010ef          	jal	5382 <printf>
    exit(1);
    3538:	4505                	li	a0,1
    353a:	1c5010ef          	jal	4efe <exit>
    printf("%s: create dirfile/xx succeeded!\n", s);
    353e:	85ca                	mv	a1,s2
    3540:	00004517          	auipc	a0,0x4
    3544:	91050513          	addi	a0,a0,-1776 # 6e50 <malloc+0x1a16>
    3548:	63b010ef          	jal	5382 <printf>
    exit(1);
    354c:	4505                	li	a0,1
    354e:	1b1010ef          	jal	4efe <exit>
    printf("%s: mkdir dirfile/xx succeeded!\n", s);
    3552:	85ca                	mv	a1,s2
    3554:	00004517          	auipc	a0,0x4
    3558:	92450513          	addi	a0,a0,-1756 # 6e78 <malloc+0x1a3e>
    355c:	627010ef          	jal	5382 <printf>
    exit(1);
    3560:	4505                	li	a0,1
    3562:	19d010ef          	jal	4efe <exit>
    printf("%s: unlink dirfile/xx succeeded!\n", s);
    3566:	85ca                	mv	a1,s2
    3568:	00004517          	auipc	a0,0x4
    356c:	93850513          	addi	a0,a0,-1736 # 6ea0 <malloc+0x1a66>
    3570:	613010ef          	jal	5382 <printf>
    exit(1);
    3574:	4505                	li	a0,1
    3576:	189010ef          	jal	4efe <exit>
    printf("%s: link to dirfile/xx succeeded!\n", s);
    357a:	85ca                	mv	a1,s2
    357c:	00004517          	auipc	a0,0x4
    3580:	94c50513          	addi	a0,a0,-1716 # 6ec8 <malloc+0x1a8e>
    3584:	5ff010ef          	jal	5382 <printf>
    exit(1);
    3588:	4505                	li	a0,1
    358a:	175010ef          	jal	4efe <exit>
    printf("%s: unlink dirfile failed!\n", s);
    358e:	85ca                	mv	a1,s2
    3590:	00004517          	auipc	a0,0x4
    3594:	96050513          	addi	a0,a0,-1696 # 6ef0 <malloc+0x1ab6>
    3598:	5eb010ef          	jal	5382 <printf>
    exit(1);
    359c:	4505                	li	a0,1
    359e:	161010ef          	jal	4efe <exit>
    printf("%s: open . for writing succeeded!\n", s);
    35a2:	85ca                	mv	a1,s2
    35a4:	00004517          	auipc	a0,0x4
    35a8:	96c50513          	addi	a0,a0,-1684 # 6f10 <malloc+0x1ad6>
    35ac:	5d7010ef          	jal	5382 <printf>
    exit(1);
    35b0:	4505                	li	a0,1
    35b2:	14d010ef          	jal	4efe <exit>
    printf("%s: write . succeeded!\n", s);
    35b6:	85ca                	mv	a1,s2
    35b8:	00004517          	auipc	a0,0x4
    35bc:	98050513          	addi	a0,a0,-1664 # 6f38 <malloc+0x1afe>
    35c0:	5c3010ef          	jal	5382 <printf>
    exit(1);
    35c4:	4505                	li	a0,1
    35c6:	139010ef          	jal	4efe <exit>

00000000000035ca <iref>:
{
    35ca:	715d                	addi	sp,sp,-80
    35cc:	e486                	sd	ra,72(sp)
    35ce:	e0a2                	sd	s0,64(sp)
    35d0:	fc26                	sd	s1,56(sp)
    35d2:	f84a                	sd	s2,48(sp)
    35d4:	f44e                	sd	s3,40(sp)
    35d6:	f052                	sd	s4,32(sp)
    35d8:	ec56                	sd	s5,24(sp)
    35da:	e85a                	sd	s6,16(sp)
    35dc:	e45e                	sd	s7,8(sp)
    35de:	0880                	addi	s0,sp,80
    35e0:	8baa                	mv	s7,a0
    35e2:	03300913          	li	s2,51
    if(mkdir("irefd") != 0){
    35e6:	00004a97          	auipc	s5,0x4
    35ea:	96aa8a93          	addi	s5,s5,-1686 # 6f50 <malloc+0x1b16>
    mkdir("");
    35ee:	00003497          	auipc	s1,0x3
    35f2:	46a48493          	addi	s1,s1,1130 # 6a58 <malloc+0x161e>
    link("README", "");
    35f6:	00002b17          	auipc	s6,0x2
    35fa:	14ab0b13          	addi	s6,s6,330 # 5740 <malloc+0x306>
    fd = open("", O_CREATE);
    35fe:	20000a13          	li	s4,512
    fd = open("xx", O_CREATE);
    3602:	00004997          	auipc	s3,0x4
    3606:	84698993          	addi	s3,s3,-1978 # 6e48 <malloc+0x1a0e>
    360a:	a835                	j	3646 <iref+0x7c>
      printf("%s: mkdir irefd failed\n", s);
    360c:	85de                	mv	a1,s7
    360e:	00004517          	auipc	a0,0x4
    3612:	94a50513          	addi	a0,a0,-1718 # 6f58 <malloc+0x1b1e>
    3616:	56d010ef          	jal	5382 <printf>
      exit(1);
    361a:	4505                	li	a0,1
    361c:	0e3010ef          	jal	4efe <exit>
      printf("%s: chdir irefd failed\n", s);
    3620:	85de                	mv	a1,s7
    3622:	00004517          	auipc	a0,0x4
    3626:	94e50513          	addi	a0,a0,-1714 # 6f70 <malloc+0x1b36>
    362a:	559010ef          	jal	5382 <printf>
      exit(1);
    362e:	4505                	li	a0,1
    3630:	0cf010ef          	jal	4efe <exit>
      close(fd);
    3634:	0f3010ef          	jal	4f26 <close>
    3638:	a825                	j	3670 <iref+0xa6>
    unlink("xx");
    363a:	854e                	mv	a0,s3
    363c:	113010ef          	jal	4f4e <unlink>
  for(i = 0; i < NINODE + 1; i++){
    3640:	397d                	addiw	s2,s2,-1
    3642:	04090063          	beqz	s2,3682 <iref+0xb8>
    if(mkdir("irefd") != 0){
    3646:	8556                	mv	a0,s5
    3648:	11f010ef          	jal	4f66 <mkdir>
    364c:	f161                	bnez	a0,360c <iref+0x42>
    if(chdir("irefd") != 0){
    364e:	8556                	mv	a0,s5
    3650:	11f010ef          	jal	4f6e <chdir>
    3654:	f571                	bnez	a0,3620 <iref+0x56>
    mkdir("");
    3656:	8526                	mv	a0,s1
    3658:	10f010ef          	jal	4f66 <mkdir>
    link("README", "");
    365c:	85a6                	mv	a1,s1
    365e:	855a                	mv	a0,s6
    3660:	0ff010ef          	jal	4f5e <link>
    fd = open("", O_CREATE);
    3664:	85d2                	mv	a1,s4
    3666:	8526                	mv	a0,s1
    3668:	0d7010ef          	jal	4f3e <open>
    if(fd >= 0)
    366c:	fc0554e3          	bgez	a0,3634 <iref+0x6a>
    fd = open("xx", O_CREATE);
    3670:	85d2                	mv	a1,s4
    3672:	854e                	mv	a0,s3
    3674:	0cb010ef          	jal	4f3e <open>
    if(fd >= 0)
    3678:	fc0541e3          	bltz	a0,363a <iref+0x70>
      close(fd);
    367c:	0ab010ef          	jal	4f26 <close>
    3680:	bf6d                	j	363a <iref+0x70>
    3682:	03300493          	li	s1,51
    chdir("..");
    3686:	00003997          	auipc	s3,0x3
    368a:	0ea98993          	addi	s3,s3,234 # 6770 <malloc+0x1336>
    unlink("irefd");
    368e:	00004917          	auipc	s2,0x4
    3692:	8c290913          	addi	s2,s2,-1854 # 6f50 <malloc+0x1b16>
    chdir("..");
    3696:	854e                	mv	a0,s3
    3698:	0d7010ef          	jal	4f6e <chdir>
    unlink("irefd");
    369c:	854a                	mv	a0,s2
    369e:	0b1010ef          	jal	4f4e <unlink>
  for(i = 0; i < NINODE + 1; i++){
    36a2:	34fd                	addiw	s1,s1,-1
    36a4:	f8ed                	bnez	s1,3696 <iref+0xcc>
  chdir("/");
    36a6:	00003517          	auipc	a0,0x3
    36aa:	07250513          	addi	a0,a0,114 # 6718 <malloc+0x12de>
    36ae:	0c1010ef          	jal	4f6e <chdir>
}
    36b2:	60a6                	ld	ra,72(sp)
    36b4:	6406                	ld	s0,64(sp)
    36b6:	74e2                	ld	s1,56(sp)
    36b8:	7942                	ld	s2,48(sp)
    36ba:	79a2                	ld	s3,40(sp)
    36bc:	7a02                	ld	s4,32(sp)
    36be:	6ae2                	ld	s5,24(sp)
    36c0:	6b42                	ld	s6,16(sp)
    36c2:	6ba2                	ld	s7,8(sp)
    36c4:	6161                	addi	sp,sp,80
    36c6:	8082                	ret

00000000000036c8 <openiputtest>:
{
    36c8:	7179                	addi	sp,sp,-48
    36ca:	f406                	sd	ra,40(sp)
    36cc:	f022                	sd	s0,32(sp)
    36ce:	ec26                	sd	s1,24(sp)
    36d0:	1800                	addi	s0,sp,48
    36d2:	84aa                	mv	s1,a0
  if(mkdir("oidir") < 0){
    36d4:	00004517          	auipc	a0,0x4
    36d8:	8b450513          	addi	a0,a0,-1868 # 6f88 <malloc+0x1b4e>
    36dc:	08b010ef          	jal	4f66 <mkdir>
    36e0:	02054a63          	bltz	a0,3714 <openiputtest+0x4c>
  pid = fork();
    36e4:	013010ef          	jal	4ef6 <fork>
  if(pid < 0){
    36e8:	04054063          	bltz	a0,3728 <openiputtest+0x60>
  if(pid == 0){
    36ec:	e939                	bnez	a0,3742 <openiputtest+0x7a>
    int fd = open("oidir", O_RDWR);
    36ee:	4589                	li	a1,2
    36f0:	00004517          	auipc	a0,0x4
    36f4:	89850513          	addi	a0,a0,-1896 # 6f88 <malloc+0x1b4e>
    36f8:	047010ef          	jal	4f3e <open>
    if(fd >= 0){
    36fc:	04054063          	bltz	a0,373c <openiputtest+0x74>
      printf("%s: open directory for write succeeded\n", s);
    3700:	85a6                	mv	a1,s1
    3702:	00004517          	auipc	a0,0x4
    3706:	8a650513          	addi	a0,a0,-1882 # 6fa8 <malloc+0x1b6e>
    370a:	479010ef          	jal	5382 <printf>
      exit(1);
    370e:	4505                	li	a0,1
    3710:	7ee010ef          	jal	4efe <exit>
    printf("%s: mkdir oidir failed\n", s);
    3714:	85a6                	mv	a1,s1
    3716:	00004517          	auipc	a0,0x4
    371a:	87a50513          	addi	a0,a0,-1926 # 6f90 <malloc+0x1b56>
    371e:	465010ef          	jal	5382 <printf>
    exit(1);
    3722:	4505                	li	a0,1
    3724:	7da010ef          	jal	4efe <exit>
    printf("%s: fork failed\n", s);
    3728:	85a6                	mv	a1,s1
    372a:	00002517          	auipc	a0,0x2
    372e:	6ce50513          	addi	a0,a0,1742 # 5df8 <malloc+0x9be>
    3732:	451010ef          	jal	5382 <printf>
    exit(1);
    3736:	4505                	li	a0,1
    3738:	7c6010ef          	jal	4efe <exit>
    exit(0);
    373c:	4501                	li	a0,0
    373e:	7c0010ef          	jal	4efe <exit>
  pause(1);
    3742:	4505                	li	a0,1
    3744:	04b010ef          	jal	4f8e <pause>
  if(unlink("oidir") != 0){
    3748:	00004517          	auipc	a0,0x4
    374c:	84050513          	addi	a0,a0,-1984 # 6f88 <malloc+0x1b4e>
    3750:	7fe010ef          	jal	4f4e <unlink>
    3754:	c919                	beqz	a0,376a <openiputtest+0xa2>
    printf("%s: unlink failed\n", s);
    3756:	85a6                	mv	a1,s1
    3758:	00003517          	auipc	a0,0x3
    375c:	89050513          	addi	a0,a0,-1904 # 5fe8 <malloc+0xbae>
    3760:	423010ef          	jal	5382 <printf>
    exit(1);
    3764:	4505                	li	a0,1
    3766:	798010ef          	jal	4efe <exit>
  wait(&xstatus);
    376a:	fdc40513          	addi	a0,s0,-36
    376e:	798010ef          	jal	4f06 <wait>
  exit(xstatus);
    3772:	fdc42503          	lw	a0,-36(s0)
    3776:	788010ef          	jal	4efe <exit>

000000000000377a <forkforkfork>:
{
    377a:	1101                	addi	sp,sp,-32
    377c:	ec06                	sd	ra,24(sp)
    377e:	e822                	sd	s0,16(sp)
    3780:	e426                	sd	s1,8(sp)
    3782:	1000                	addi	s0,sp,32
    3784:	84aa                	mv	s1,a0
  unlink("stopforking");
    3786:	00004517          	auipc	a0,0x4
    378a:	84a50513          	addi	a0,a0,-1974 # 6fd0 <malloc+0x1b96>
    378e:	7c0010ef          	jal	4f4e <unlink>
  int pid = fork();
    3792:	764010ef          	jal	4ef6 <fork>
  if(pid < 0){
    3796:	02054b63          	bltz	a0,37cc <forkforkfork+0x52>
  if(pid == 0){
    379a:	c139                	beqz	a0,37e0 <forkforkfork+0x66>
  pause(20); // two seconds
    379c:	4551                	li	a0,20
    379e:	7f0010ef          	jal	4f8e <pause>
  close(open("stopforking", O_CREATE|O_RDWR));
    37a2:	20200593          	li	a1,514
    37a6:	00004517          	auipc	a0,0x4
    37aa:	82a50513          	addi	a0,a0,-2006 # 6fd0 <malloc+0x1b96>
    37ae:	790010ef          	jal	4f3e <open>
    37b2:	774010ef          	jal	4f26 <close>
  wait(0);
    37b6:	4501                	li	a0,0
    37b8:	74e010ef          	jal	4f06 <wait>
  pause(10); // one second
    37bc:	4529                	li	a0,10
    37be:	7d0010ef          	jal	4f8e <pause>
}
    37c2:	60e2                	ld	ra,24(sp)
    37c4:	6442                	ld	s0,16(sp)
    37c6:	64a2                	ld	s1,8(sp)
    37c8:	6105                	addi	sp,sp,32
    37ca:	8082                	ret
    printf("%s: fork failed", s);
    37cc:	85a6                	mv	a1,s1
    37ce:	00002517          	auipc	a0,0x2
    37d2:	7ea50513          	addi	a0,a0,2026 # 5fb8 <malloc+0xb7e>
    37d6:	3ad010ef          	jal	5382 <printf>
    exit(1);
    37da:	4505                	li	a0,1
    37dc:	722010ef          	jal	4efe <exit>
      int fd = open("stopforking", 0);
    37e0:	4581                	li	a1,0
    37e2:	00003517          	auipc	a0,0x3
    37e6:	7ee50513          	addi	a0,a0,2030 # 6fd0 <malloc+0x1b96>
    37ea:	754010ef          	jal	4f3e <open>
      if(fd >= 0){
    37ee:	02055163          	bgez	a0,3810 <forkforkfork+0x96>
      if(fork() < 0){
    37f2:	704010ef          	jal	4ef6 <fork>
    37f6:	fe0555e3          	bgez	a0,37e0 <forkforkfork+0x66>
        close(open("stopforking", O_CREATE|O_RDWR));
    37fa:	20200593          	li	a1,514
    37fe:	00003517          	auipc	a0,0x3
    3802:	7d250513          	addi	a0,a0,2002 # 6fd0 <malloc+0x1b96>
    3806:	738010ef          	jal	4f3e <open>
    380a:	71c010ef          	jal	4f26 <close>
    380e:	bfc9                	j	37e0 <forkforkfork+0x66>
        exit(0);
    3810:	4501                	li	a0,0
    3812:	6ec010ef          	jal	4efe <exit>

0000000000003816 <killstatus>:
{
    3816:	715d                	addi	sp,sp,-80
    3818:	e486                	sd	ra,72(sp)
    381a:	e0a2                	sd	s0,64(sp)
    381c:	fc26                	sd	s1,56(sp)
    381e:	f84a                	sd	s2,48(sp)
    3820:	f44e                	sd	s3,40(sp)
    3822:	f052                	sd	s4,32(sp)
    3824:	ec56                	sd	s5,24(sp)
    3826:	e85a                	sd	s6,16(sp)
    3828:	0880                	addi	s0,sp,80
    382a:	8b2a                	mv	s6,a0
    382c:	06400913          	li	s2,100
    pause(1);
    3830:	4a85                	li	s5,1
    wait(&xst);
    3832:	fbc40a13          	addi	s4,s0,-68
    if(xst != -1) {
    3836:	59fd                	li	s3,-1
    int pid1 = fork();
    3838:	6be010ef          	jal	4ef6 <fork>
    383c:	84aa                	mv	s1,a0
    if(pid1 < 0){
    383e:	02054663          	bltz	a0,386a <killstatus+0x54>
    if(pid1 == 0){
    3842:	cd15                	beqz	a0,387e <killstatus+0x68>
    pause(1);
    3844:	8556                	mv	a0,s5
    3846:	748010ef          	jal	4f8e <pause>
    kill(pid1);
    384a:	8526                	mv	a0,s1
    384c:	6e2010ef          	jal	4f2e <kill>
    wait(&xst);
    3850:	8552                	mv	a0,s4
    3852:	6b4010ef          	jal	4f06 <wait>
    if(xst != -1) {
    3856:	fbc42783          	lw	a5,-68(s0)
    385a:	03379563          	bne	a5,s3,3884 <killstatus+0x6e>
  for(int i = 0; i < 100; i++){
    385e:	397d                	addiw	s2,s2,-1
    3860:	fc091ce3          	bnez	s2,3838 <killstatus+0x22>
  exit(0);
    3864:	4501                	li	a0,0
    3866:	698010ef          	jal	4efe <exit>
      printf("%s: fork failed\n", s);
    386a:	85da                	mv	a1,s6
    386c:	00002517          	auipc	a0,0x2
    3870:	58c50513          	addi	a0,a0,1420 # 5df8 <malloc+0x9be>
    3874:	30f010ef          	jal	5382 <printf>
      exit(1);
    3878:	4505                	li	a0,1
    387a:	684010ef          	jal	4efe <exit>
        getpid();
    387e:	700010ef          	jal	4f7e <getpid>
      while(1) {
    3882:	bff5                	j	387e <killstatus+0x68>
       printf("%s: status should be -1\n", s);
    3884:	85da                	mv	a1,s6
    3886:	00003517          	auipc	a0,0x3
    388a:	75a50513          	addi	a0,a0,1882 # 6fe0 <malloc+0x1ba6>
    388e:	2f5010ef          	jal	5382 <printf>
       exit(1);
    3892:	4505                	li	a0,1
    3894:	66a010ef          	jal	4efe <exit>

0000000000003898 <preempt>:
{
    3898:	7139                	addi	sp,sp,-64
    389a:	fc06                	sd	ra,56(sp)
    389c:	f822                	sd	s0,48(sp)
    389e:	f426                	sd	s1,40(sp)
    38a0:	f04a                	sd	s2,32(sp)
    38a2:	ec4e                	sd	s3,24(sp)
    38a4:	e852                	sd	s4,16(sp)
    38a6:	0080                	addi	s0,sp,64
    38a8:	892a                	mv	s2,a0
  pid1 = fork();
    38aa:	64c010ef          	jal	4ef6 <fork>
  if(pid1 < 0) {
    38ae:	00054563          	bltz	a0,38b8 <preempt+0x20>
    38b2:	84aa                	mv	s1,a0
  if(pid1 == 0)
    38b4:	ed01                	bnez	a0,38cc <preempt+0x34>
    for(;;)
    38b6:	a001                	j	38b6 <preempt+0x1e>
    printf("%s: fork failed", s);
    38b8:	85ca                	mv	a1,s2
    38ba:	00002517          	auipc	a0,0x2
    38be:	6fe50513          	addi	a0,a0,1790 # 5fb8 <malloc+0xb7e>
    38c2:	2c1010ef          	jal	5382 <printf>
    exit(1);
    38c6:	4505                	li	a0,1
    38c8:	636010ef          	jal	4efe <exit>
  pid2 = fork();
    38cc:	62a010ef          	jal	4ef6 <fork>
    38d0:	89aa                	mv	s3,a0
  if(pid2 < 0) {
    38d2:	00054463          	bltz	a0,38da <preempt+0x42>
  if(pid2 == 0)
    38d6:	ed01                	bnez	a0,38ee <preempt+0x56>
    for(;;)
    38d8:	a001                	j	38d8 <preempt+0x40>
    printf("%s: fork failed\n", s);
    38da:	85ca                	mv	a1,s2
    38dc:	00002517          	auipc	a0,0x2
    38e0:	51c50513          	addi	a0,a0,1308 # 5df8 <malloc+0x9be>
    38e4:	29f010ef          	jal	5382 <printf>
    exit(1);
    38e8:	4505                	li	a0,1
    38ea:	614010ef          	jal	4efe <exit>
  pipe(pfds);
    38ee:	fc840513          	addi	a0,s0,-56
    38f2:	61c010ef          	jal	4f0e <pipe>
  pid3 = fork();
    38f6:	600010ef          	jal	4ef6 <fork>
    38fa:	8a2a                	mv	s4,a0
  if(pid3 < 0) {
    38fc:	02054863          	bltz	a0,392c <preempt+0x94>
  if(pid3 == 0){
    3900:	e921                	bnez	a0,3950 <preempt+0xb8>
    close(pfds[0]);
    3902:	fc842503          	lw	a0,-56(s0)
    3906:	620010ef          	jal	4f26 <close>
    if(write(pfds[1], "x", 1) != 1)
    390a:	4605                	li	a2,1
    390c:	00002597          	auipc	a1,0x2
    3910:	ccc58593          	addi	a1,a1,-820 # 55d8 <malloc+0x19e>
    3914:	fcc42503          	lw	a0,-52(s0)
    3918:	606010ef          	jal	4f1e <write>
    391c:	4785                	li	a5,1
    391e:	02f51163          	bne	a0,a5,3940 <preempt+0xa8>
    close(pfds[1]);
    3922:	fcc42503          	lw	a0,-52(s0)
    3926:	600010ef          	jal	4f26 <close>
    for(;;)
    392a:	a001                	j	392a <preempt+0x92>
     printf("%s: fork failed\n", s);
    392c:	85ca                	mv	a1,s2
    392e:	00002517          	auipc	a0,0x2
    3932:	4ca50513          	addi	a0,a0,1226 # 5df8 <malloc+0x9be>
    3936:	24d010ef          	jal	5382 <printf>
     exit(1);
    393a:	4505                	li	a0,1
    393c:	5c2010ef          	jal	4efe <exit>
      printf("%s: preempt write error", s);
    3940:	85ca                	mv	a1,s2
    3942:	00003517          	auipc	a0,0x3
    3946:	6be50513          	addi	a0,a0,1726 # 7000 <malloc+0x1bc6>
    394a:	239010ef          	jal	5382 <printf>
    394e:	bfd1                	j	3922 <preempt+0x8a>
  close(pfds[1]);
    3950:	fcc42503          	lw	a0,-52(s0)
    3954:	5d2010ef          	jal	4f26 <close>
  if(read(pfds[0], buf, sizeof(buf)) != 1){
    3958:	660d                	lui	a2,0x3
    395a:	00008597          	auipc	a1,0x8
    395e:	34e58593          	addi	a1,a1,846 # bca8 <buf>
    3962:	fc842503          	lw	a0,-56(s0)
    3966:	5b0010ef          	jal	4f16 <read>
    396a:	4785                	li	a5,1
    396c:	02f50163          	beq	a0,a5,398e <preempt+0xf6>
    printf("%s: preempt read error", s);
    3970:	85ca                	mv	a1,s2
    3972:	00003517          	auipc	a0,0x3
    3976:	6a650513          	addi	a0,a0,1702 # 7018 <malloc+0x1bde>
    397a:	209010ef          	jal	5382 <printf>
}
    397e:	70e2                	ld	ra,56(sp)
    3980:	7442                	ld	s0,48(sp)
    3982:	74a2                	ld	s1,40(sp)
    3984:	7902                	ld	s2,32(sp)
    3986:	69e2                	ld	s3,24(sp)
    3988:	6a42                	ld	s4,16(sp)
    398a:	6121                	addi	sp,sp,64
    398c:	8082                	ret
  close(pfds[0]);
    398e:	fc842503          	lw	a0,-56(s0)
    3992:	594010ef          	jal	4f26 <close>
  printf("kill... ");
    3996:	00003517          	auipc	a0,0x3
    399a:	69a50513          	addi	a0,a0,1690 # 7030 <malloc+0x1bf6>
    399e:	1e5010ef          	jal	5382 <printf>
  kill(pid1);
    39a2:	8526                	mv	a0,s1
    39a4:	58a010ef          	jal	4f2e <kill>
  kill(pid2);
    39a8:	854e                	mv	a0,s3
    39aa:	584010ef          	jal	4f2e <kill>
  kill(pid3);
    39ae:	8552                	mv	a0,s4
    39b0:	57e010ef          	jal	4f2e <kill>
  printf("wait... ");
    39b4:	00003517          	auipc	a0,0x3
    39b8:	68c50513          	addi	a0,a0,1676 # 7040 <malloc+0x1c06>
    39bc:	1c7010ef          	jal	5382 <printf>
  wait(0);
    39c0:	4501                	li	a0,0
    39c2:	544010ef          	jal	4f06 <wait>
  wait(0);
    39c6:	4501                	li	a0,0
    39c8:	53e010ef          	jal	4f06 <wait>
  wait(0);
    39cc:	4501                	li	a0,0
    39ce:	538010ef          	jal	4f06 <wait>
    39d2:	b775                	j	397e <preempt+0xe6>

00000000000039d4 <reparent>:
{
    39d4:	7179                	addi	sp,sp,-48
    39d6:	f406                	sd	ra,40(sp)
    39d8:	f022                	sd	s0,32(sp)
    39da:	ec26                	sd	s1,24(sp)
    39dc:	e84a                	sd	s2,16(sp)
    39de:	e44e                	sd	s3,8(sp)
    39e0:	e052                	sd	s4,0(sp)
    39e2:	1800                	addi	s0,sp,48
    39e4:	89aa                	mv	s3,a0
  int master_pid = getpid();
    39e6:	598010ef          	jal	4f7e <getpid>
    39ea:	8a2a                	mv	s4,a0
    39ec:	0c800913          	li	s2,200
    int pid = fork();
    39f0:	506010ef          	jal	4ef6 <fork>
    39f4:	84aa                	mv	s1,a0
    if(pid < 0){
    39f6:	00054e63          	bltz	a0,3a12 <reparent+0x3e>
    if(pid){
    39fa:	c121                	beqz	a0,3a3a <reparent+0x66>
      if(wait(0) != pid){
    39fc:	4501                	li	a0,0
    39fe:	508010ef          	jal	4f06 <wait>
    3a02:	02951263          	bne	a0,s1,3a26 <reparent+0x52>
  for(int i = 0; i < 200; i++){
    3a06:	397d                	addiw	s2,s2,-1
    3a08:	fe0914e3          	bnez	s2,39f0 <reparent+0x1c>
  exit(0);
    3a0c:	4501                	li	a0,0
    3a0e:	4f0010ef          	jal	4efe <exit>
      printf("%s: fork failed\n", s);
    3a12:	85ce                	mv	a1,s3
    3a14:	00002517          	auipc	a0,0x2
    3a18:	3e450513          	addi	a0,a0,996 # 5df8 <malloc+0x9be>
    3a1c:	167010ef          	jal	5382 <printf>
      exit(1);
    3a20:	4505                	li	a0,1
    3a22:	4dc010ef          	jal	4efe <exit>
        printf("%s: wait wrong pid\n", s);
    3a26:	85ce                	mv	a1,s3
    3a28:	00002517          	auipc	a0,0x2
    3a2c:	55850513          	addi	a0,a0,1368 # 5f80 <malloc+0xb46>
    3a30:	153010ef          	jal	5382 <printf>
        exit(1);
    3a34:	4505                	li	a0,1
    3a36:	4c8010ef          	jal	4efe <exit>
      int pid2 = fork();
    3a3a:	4bc010ef          	jal	4ef6 <fork>
      if(pid2 < 0){
    3a3e:	00054563          	bltz	a0,3a48 <reparent+0x74>
      exit(0);
    3a42:	4501                	li	a0,0
    3a44:	4ba010ef          	jal	4efe <exit>
        kill(master_pid);
    3a48:	8552                	mv	a0,s4
    3a4a:	4e4010ef          	jal	4f2e <kill>
        exit(1);
    3a4e:	4505                	li	a0,1
    3a50:	4ae010ef          	jal	4efe <exit>

0000000000003a54 <sbrkfail>:
{
    3a54:	7175                	addi	sp,sp,-144
    3a56:	e506                	sd	ra,136(sp)
    3a58:	e122                	sd	s0,128(sp)
    3a5a:	fca6                	sd	s1,120(sp)
    3a5c:	f8ca                	sd	s2,112(sp)
    3a5e:	f4ce                	sd	s3,104(sp)
    3a60:	f0d2                	sd	s4,96(sp)
    3a62:	ecd6                	sd	s5,88(sp)
    3a64:	e8da                	sd	s6,80(sp)
    3a66:	e4de                	sd	s7,72(sp)
    3a68:	e0e2                	sd	s8,64(sp)
    3a6a:	0900                	addi	s0,sp,144
    3a6c:	8c2a                	mv	s8,a0
  if(pipe(fds) != 0){
    3a6e:	fa040513          	addi	a0,s0,-96
    3a72:	49c010ef          	jal	4f0e <pipe>
    3a76:	ed01                	bnez	a0,3a8e <sbrkfail+0x3a>
    3a78:	8baa                	mv	s7,a0
    3a7a:	f7040493          	addi	s1,s0,-144
    3a7e:	f9840993          	addi	s3,s0,-104
    3a82:	8926                	mv	s2,s1
    if(pids[i] != -1) {
    3a84:	5a7d                	li	s4,-1
      read(fds[0], &scratch, 1);
    3a86:	f9f40b13          	addi	s6,s0,-97
    3a8a:	4a85                	li	s5,1
    3a8c:	a095                	j	3af0 <sbrkfail+0x9c>
    printf("%s: pipe() failed\n", s);
    3a8e:	85e2                	mv	a1,s8
    3a90:	00002517          	auipc	a0,0x2
    3a94:	47050513          	addi	a0,a0,1136 # 5f00 <malloc+0xac6>
    3a98:	0eb010ef          	jal	5382 <printf>
    exit(1);
    3a9c:	4505                	li	a0,1
    3a9e:	460010ef          	jal	4efe <exit>
      if (sbrk(BIG - (uint64)sbrk(0)) ==  (char*)SBRK_ERROR)
    3aa2:	428010ef          	jal	4eca <sbrk>
    3aa6:	064007b7          	lui	a5,0x6400
    3aaa:	40a7853b          	subw	a0,a5,a0
    3aae:	41c010ef          	jal	4eca <sbrk>
    3ab2:	57fd                	li	a5,-1
    3ab4:	02f50163          	beq	a0,a5,3ad6 <sbrkfail+0x82>
        write(fds[1], "1", 1);
    3ab8:	4605                	li	a2,1
    3aba:	00004597          	auipc	a1,0x4
    3abe:	c2658593          	addi	a1,a1,-986 # 76e0 <malloc+0x22a6>
    3ac2:	fa442503          	lw	a0,-92(s0)
    3ac6:	458010ef          	jal	4f1e <write>
      for(;;) pause(1000);
    3aca:	3e800493          	li	s1,1000
    3ace:	8526                	mv	a0,s1
    3ad0:	4be010ef          	jal	4f8e <pause>
    3ad4:	bfed                	j	3ace <sbrkfail+0x7a>
        write(fds[1], "0", 1);
    3ad6:	4605                	li	a2,1
    3ad8:	00003597          	auipc	a1,0x3
    3adc:	57858593          	addi	a1,a1,1400 # 7050 <malloc+0x1c16>
    3ae0:	fa442503          	lw	a0,-92(s0)
    3ae4:	43a010ef          	jal	4f1e <write>
    3ae8:	b7cd                	j	3aca <sbrkfail+0x76>
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3aea:	0911                	addi	s2,s2,4
    3aec:	03390a63          	beq	s2,s3,3b20 <sbrkfail+0xcc>
    if((pids[i] = fork()) == 0){
    3af0:	406010ef          	jal	4ef6 <fork>
    3af4:	00a92023          	sw	a0,0(s2)
    3af8:	d54d                	beqz	a0,3aa2 <sbrkfail+0x4e>
    if(pids[i] != -1) {
    3afa:	ff4508e3          	beq	a0,s4,3aea <sbrkfail+0x96>
      read(fds[0], &scratch, 1);
    3afe:	8656                	mv	a2,s5
    3b00:	85da                	mv	a1,s6
    3b02:	fa042503          	lw	a0,-96(s0)
    3b06:	410010ef          	jal	4f16 <read>
      if(scratch == '0')
    3b0a:	f9f44783          	lbu	a5,-97(s0)
    3b0e:	fd078793          	addi	a5,a5,-48 # 63fffd0 <base+0x63f1328>
    3b12:	0017b793          	seqz	a5,a5
    3b16:	00fbe7b3          	or	a5,s7,a5
    3b1a:	00078b9b          	sext.w	s7,a5
    3b1e:	b7f1                	j	3aea <sbrkfail+0x96>
  if(!failed) {
    3b20:	000b8863          	beqz	s7,3b30 <sbrkfail+0xdc>
  c = sbrk(PGSIZE);
    3b24:	6505                	lui	a0,0x1
    3b26:	3a4010ef          	jal	4eca <sbrk>
    3b2a:	8a2a                	mv	s4,a0
    if(pids[i] == -1)
    3b2c:	597d                	li	s2,-1
    3b2e:	a821                	j	3b46 <sbrkfail+0xf2>
    printf("%s: no allocation failed; allocate more?\n", s);
    3b30:	85e2                	mv	a1,s8
    3b32:	00003517          	auipc	a0,0x3
    3b36:	52650513          	addi	a0,a0,1318 # 7058 <malloc+0x1c1e>
    3b3a:	049010ef          	jal	5382 <printf>
    3b3e:	b7dd                	j	3b24 <sbrkfail+0xd0>
  for(i = 0; i < sizeof(pids)/sizeof(pids[0]); i++){
    3b40:	0491                	addi	s1,s1,4
    3b42:	01348b63          	beq	s1,s3,3b58 <sbrkfail+0x104>
    if(pids[i] == -1)
    3b46:	4088                	lw	a0,0(s1)
    3b48:	ff250ce3          	beq	a0,s2,3b40 <sbrkfail+0xec>
    kill(pids[i]);
    3b4c:	3e2010ef          	jal	4f2e <kill>
    wait(0);
    3b50:	4501                	li	a0,0
    3b52:	3b4010ef          	jal	4f06 <wait>
    3b56:	b7ed                	j	3b40 <sbrkfail+0xec>
  if(c == (char*)SBRK_ERROR){
    3b58:	57fd                	li	a5,-1
    3b5a:	02fa0a63          	beq	s4,a5,3b8e <sbrkfail+0x13a>
  pid = fork();
    3b5e:	398010ef          	jal	4ef6 <fork>
  if(pid < 0){
    3b62:	04054063          	bltz	a0,3ba2 <sbrkfail+0x14e>
  if(pid == 0){
    3b66:	e939                	bnez	a0,3bbc <sbrkfail+0x168>
    a = sbrk(10*BIG);
    3b68:	3e800537          	lui	a0,0x3e800
    3b6c:	35e010ef          	jal	4eca <sbrk>
    if(a == (char*)SBRK_ERROR){
    3b70:	57fd                	li	a5,-1
    3b72:	04f50263          	beq	a0,a5,3bb6 <sbrkfail+0x162>
    printf("%s: allocate a lot of memory succeeded %d\n", s, 10*BIG);
    3b76:	3e800637          	lui	a2,0x3e800
    3b7a:	85e2                	mv	a1,s8
    3b7c:	00003517          	auipc	a0,0x3
    3b80:	52c50513          	addi	a0,a0,1324 # 70a8 <malloc+0x1c6e>
    3b84:	7fe010ef          	jal	5382 <printf>
    exit(1);
    3b88:	4505                	li	a0,1
    3b8a:	374010ef          	jal	4efe <exit>
    printf("%s: failed sbrk leaked memory\n", s);
    3b8e:	85e2                	mv	a1,s8
    3b90:	00003517          	auipc	a0,0x3
    3b94:	4f850513          	addi	a0,a0,1272 # 7088 <malloc+0x1c4e>
    3b98:	7ea010ef          	jal	5382 <printf>
    exit(1);
    3b9c:	4505                	li	a0,1
    3b9e:	360010ef          	jal	4efe <exit>
    printf("%s: fork failed\n", s);
    3ba2:	85e2                	mv	a1,s8
    3ba4:	00002517          	auipc	a0,0x2
    3ba8:	25450513          	addi	a0,a0,596 # 5df8 <malloc+0x9be>
    3bac:	7d6010ef          	jal	5382 <printf>
    exit(1);
    3bb0:	4505                	li	a0,1
    3bb2:	34c010ef          	jal	4efe <exit>
      exit(0);
    3bb6:	4501                	li	a0,0
    3bb8:	346010ef          	jal	4efe <exit>
  wait(&xstatus);
    3bbc:	fac40513          	addi	a0,s0,-84
    3bc0:	346010ef          	jal	4f06 <wait>
  if(xstatus != 0)
    3bc4:	fac42783          	lw	a5,-84(s0)
    3bc8:	ef89                	bnez	a5,3be2 <sbrkfail+0x18e>
}
    3bca:	60aa                	ld	ra,136(sp)
    3bcc:	640a                	ld	s0,128(sp)
    3bce:	74e6                	ld	s1,120(sp)
    3bd0:	7946                	ld	s2,112(sp)
    3bd2:	79a6                	ld	s3,104(sp)
    3bd4:	7a06                	ld	s4,96(sp)
    3bd6:	6ae6                	ld	s5,88(sp)
    3bd8:	6b46                	ld	s6,80(sp)
    3bda:	6ba6                	ld	s7,72(sp)
    3bdc:	6c06                	ld	s8,64(sp)
    3bde:	6149                	addi	sp,sp,144
    3be0:	8082                	ret
    exit(1);
    3be2:	4505                	li	a0,1
    3be4:	31a010ef          	jal	4efe <exit>

0000000000003be8 <mem>:
{
    3be8:	7139                	addi	sp,sp,-64
    3bea:	fc06                	sd	ra,56(sp)
    3bec:	f822                	sd	s0,48(sp)
    3bee:	f426                	sd	s1,40(sp)
    3bf0:	f04a                	sd	s2,32(sp)
    3bf2:	ec4e                	sd	s3,24(sp)
    3bf4:	0080                	addi	s0,sp,64
    3bf6:	89aa                	mv	s3,a0
  if((pid = fork()) == 0){
    3bf8:	2fe010ef          	jal	4ef6 <fork>
    m1 = 0;
    3bfc:	4481                	li	s1,0
    while((m2 = malloc(10001)) != 0){
    3bfe:	6909                	lui	s2,0x2
    3c00:	71190913          	addi	s2,s2,1809 # 2711 <execout+0x23>
  if((pid = fork()) == 0){
    3c04:	cd11                	beqz	a0,3c20 <mem+0x38>
    wait(&xstatus);
    3c06:	fcc40513          	addi	a0,s0,-52
    3c0a:	2fc010ef          	jal	4f06 <wait>
    if(xstatus == -1){
    3c0e:	fcc42503          	lw	a0,-52(s0)
    3c12:	57fd                	li	a5,-1
    3c14:	04f50363          	beq	a0,a5,3c5a <mem+0x72>
    exit(xstatus);
    3c18:	2e6010ef          	jal	4efe <exit>
      *(char**)m2 = m1;
    3c1c:	e104                	sd	s1,0(a0)
      m1 = m2;
    3c1e:	84aa                	mv	s1,a0
    while((m2 = malloc(10001)) != 0){
    3c20:	854a                	mv	a0,s2
    3c22:	019010ef          	jal	543a <malloc>
    3c26:	f97d                	bnez	a0,3c1c <mem+0x34>
    while(m1){
    3c28:	c491                	beqz	s1,3c34 <mem+0x4c>
      m2 = *(char**)m1;
    3c2a:	8526                	mv	a0,s1
    3c2c:	6084                	ld	s1,0(s1)
      free(m1);
    3c2e:	786010ef          	jal	53b4 <free>
    while(m1){
    3c32:	fce5                	bnez	s1,3c2a <mem+0x42>
    m1 = malloc(1024*20);
    3c34:	6515                	lui	a0,0x5
    3c36:	005010ef          	jal	543a <malloc>
    if(m1 == 0){
    3c3a:	c511                	beqz	a0,3c46 <mem+0x5e>
    free(m1);
    3c3c:	778010ef          	jal	53b4 <free>
    exit(0);
    3c40:	4501                	li	a0,0
    3c42:	2bc010ef          	jal	4efe <exit>
      printf("%s: couldn't allocate mem?!!\n", s);
    3c46:	85ce                	mv	a1,s3
    3c48:	00003517          	auipc	a0,0x3
    3c4c:	49050513          	addi	a0,a0,1168 # 70d8 <malloc+0x1c9e>
    3c50:	732010ef          	jal	5382 <printf>
      exit(1);
    3c54:	4505                	li	a0,1
    3c56:	2a8010ef          	jal	4efe <exit>
      exit(0);
    3c5a:	4501                	li	a0,0
    3c5c:	2a2010ef          	jal	4efe <exit>

0000000000003c60 <sharedfd>:
{
    3c60:	7159                	addi	sp,sp,-112
    3c62:	f486                	sd	ra,104(sp)
    3c64:	f0a2                	sd	s0,96(sp)
    3c66:	eca6                	sd	s1,88(sp)
    3c68:	f85a                	sd	s6,48(sp)
    3c6a:	1880                	addi	s0,sp,112
    3c6c:	84aa                	mv	s1,a0
    3c6e:	8b2a                	mv	s6,a0
  unlink("sharedfd");
    3c70:	00003517          	auipc	a0,0x3
    3c74:	48850513          	addi	a0,a0,1160 # 70f8 <malloc+0x1cbe>
    3c78:	2d6010ef          	jal	4f4e <unlink>
  fd = open("sharedfd", O_CREATE|O_RDWR);
    3c7c:	20200593          	li	a1,514
    3c80:	00003517          	auipc	a0,0x3
    3c84:	47850513          	addi	a0,a0,1144 # 70f8 <malloc+0x1cbe>
    3c88:	2b6010ef          	jal	4f3e <open>
  if(fd < 0){
    3c8c:	04054863          	bltz	a0,3cdc <sharedfd+0x7c>
    3c90:	e8ca                	sd	s2,80(sp)
    3c92:	e4ce                	sd	s3,72(sp)
    3c94:	e0d2                	sd	s4,64(sp)
    3c96:	fc56                	sd	s5,56(sp)
    3c98:	89aa                	mv	s3,a0
  pid = fork();
    3c9a:	25c010ef          	jal	4ef6 <fork>
    3c9e:	8aaa                	mv	s5,a0
  memset(buf, pid==0?'c':'p', sizeof(buf));
    3ca0:	07000593          	li	a1,112
    3ca4:	e119                	bnez	a0,3caa <sharedfd+0x4a>
    3ca6:	06300593          	li	a1,99
    3caa:	4629                	li	a2,10
    3cac:	fa040513          	addi	a0,s0,-96
    3cb0:	024010ef          	jal	4cd4 <memset>
    3cb4:	3e800493          	li	s1,1000
    if(write(fd, buf, sizeof(buf)) != sizeof(buf)){
    3cb8:	fa040a13          	addi	s4,s0,-96
    3cbc:	4929                	li	s2,10
    3cbe:	864a                	mv	a2,s2
    3cc0:	85d2                	mv	a1,s4
    3cc2:	854e                	mv	a0,s3
    3cc4:	25a010ef          	jal	4f1e <write>
    3cc8:	03251963          	bne	a0,s2,3cfa <sharedfd+0x9a>
  for(i = 0; i < N; i++){
    3ccc:	34fd                	addiw	s1,s1,-1
    3cce:	f8e5                	bnez	s1,3cbe <sharedfd+0x5e>
  if(pid == 0) {
    3cd0:	040a9063          	bnez	s5,3d10 <sharedfd+0xb0>
    3cd4:	f45e                	sd	s7,40(sp)
    exit(0);
    3cd6:	4501                	li	a0,0
    3cd8:	226010ef          	jal	4efe <exit>
    3cdc:	e8ca                	sd	s2,80(sp)
    3cde:	e4ce                	sd	s3,72(sp)
    3ce0:	e0d2                	sd	s4,64(sp)
    3ce2:	fc56                	sd	s5,56(sp)
    3ce4:	f45e                	sd	s7,40(sp)
    printf("%s: cannot open sharedfd for writing", s);
    3ce6:	85a6                	mv	a1,s1
    3ce8:	00003517          	auipc	a0,0x3
    3cec:	42050513          	addi	a0,a0,1056 # 7108 <malloc+0x1cce>
    3cf0:	692010ef          	jal	5382 <printf>
    exit(1);
    3cf4:	4505                	li	a0,1
    3cf6:	208010ef          	jal	4efe <exit>
    3cfa:	f45e                	sd	s7,40(sp)
      printf("%s: write sharedfd failed\n", s);
    3cfc:	85da                	mv	a1,s6
    3cfe:	00003517          	auipc	a0,0x3
    3d02:	43250513          	addi	a0,a0,1074 # 7130 <malloc+0x1cf6>
    3d06:	67c010ef          	jal	5382 <printf>
      exit(1);
    3d0a:	4505                	li	a0,1
    3d0c:	1f2010ef          	jal	4efe <exit>
    wait(&xstatus);
    3d10:	f9c40513          	addi	a0,s0,-100
    3d14:	1f2010ef          	jal	4f06 <wait>
    if(xstatus != 0)
    3d18:	f9c42a03          	lw	s4,-100(s0)
    3d1c:	000a0663          	beqz	s4,3d28 <sharedfd+0xc8>
    3d20:	f45e                	sd	s7,40(sp)
      exit(xstatus);
    3d22:	8552                	mv	a0,s4
    3d24:	1da010ef          	jal	4efe <exit>
    3d28:	f45e                	sd	s7,40(sp)
  close(fd);
    3d2a:	854e                	mv	a0,s3
    3d2c:	1fa010ef          	jal	4f26 <close>
  fd = open("sharedfd", 0);
    3d30:	4581                	li	a1,0
    3d32:	00003517          	auipc	a0,0x3
    3d36:	3c650513          	addi	a0,a0,966 # 70f8 <malloc+0x1cbe>
    3d3a:	204010ef          	jal	4f3e <open>
    3d3e:	8baa                	mv	s7,a0
  nc = np = 0;
    3d40:	89d2                	mv	s3,s4
  if(fd < 0){
    3d42:	02054363          	bltz	a0,3d68 <sharedfd+0x108>
    3d46:	faa40913          	addi	s2,s0,-86
      if(buf[i] == 'c')
    3d4a:	06300493          	li	s1,99
      if(buf[i] == 'p')
    3d4e:	07000a93          	li	s5,112
  while((n = read(fd, buf, sizeof(buf))) > 0){
    3d52:	4629                	li	a2,10
    3d54:	fa040593          	addi	a1,s0,-96
    3d58:	855e                	mv	a0,s7
    3d5a:	1bc010ef          	jal	4f16 <read>
    3d5e:	02a05b63          	blez	a0,3d94 <sharedfd+0x134>
    3d62:	fa040793          	addi	a5,s0,-96
    3d66:	a839                	j	3d84 <sharedfd+0x124>
    printf("%s: cannot open sharedfd for reading\n", s);
    3d68:	85da                	mv	a1,s6
    3d6a:	00003517          	auipc	a0,0x3
    3d6e:	3e650513          	addi	a0,a0,998 # 7150 <malloc+0x1d16>
    3d72:	610010ef          	jal	5382 <printf>
    exit(1);
    3d76:	4505                	li	a0,1
    3d78:	186010ef          	jal	4efe <exit>
        nc++;
    3d7c:	2a05                	addiw	s4,s4,1
    for(i = 0; i < sizeof(buf); i++){
    3d7e:	0785                	addi	a5,a5,1
    3d80:	fd2789e3          	beq	a5,s2,3d52 <sharedfd+0xf2>
      if(buf[i] == 'c')
    3d84:	0007c703          	lbu	a4,0(a5)
    3d88:	fe970ae3          	beq	a4,s1,3d7c <sharedfd+0x11c>
      if(buf[i] == 'p')
    3d8c:	ff5719e3          	bne	a4,s5,3d7e <sharedfd+0x11e>
        np++;
    3d90:	2985                	addiw	s3,s3,1
    3d92:	b7f5                	j	3d7e <sharedfd+0x11e>
  close(fd);
    3d94:	855e                	mv	a0,s7
    3d96:	190010ef          	jal	4f26 <close>
  unlink("sharedfd");
    3d9a:	00003517          	auipc	a0,0x3
    3d9e:	35e50513          	addi	a0,a0,862 # 70f8 <malloc+0x1cbe>
    3da2:	1ac010ef          	jal	4f4e <unlink>
  if(nc == N*SZ && np == N*SZ){
    3da6:	6789                	lui	a5,0x2
    3da8:	71078793          	addi	a5,a5,1808 # 2710 <execout+0x22>
    3dac:	00fa1763          	bne	s4,a5,3dba <sharedfd+0x15a>
    3db0:	01499563          	bne	s3,s4,3dba <sharedfd+0x15a>
    exit(0);
    3db4:	4501                	li	a0,0
    3db6:	148010ef          	jal	4efe <exit>
    printf("%s: nc/np test fails\n", s);
    3dba:	85da                	mv	a1,s6
    3dbc:	00003517          	auipc	a0,0x3
    3dc0:	3bc50513          	addi	a0,a0,956 # 7178 <malloc+0x1d3e>
    3dc4:	5be010ef          	jal	5382 <printf>
    exit(1);
    3dc8:	4505                	li	a0,1
    3dca:	134010ef          	jal	4efe <exit>

0000000000003dce <fourfiles>:
{
    3dce:	7135                	addi	sp,sp,-160
    3dd0:	ed06                	sd	ra,152(sp)
    3dd2:	e922                	sd	s0,144(sp)
    3dd4:	e526                	sd	s1,136(sp)
    3dd6:	e14a                	sd	s2,128(sp)
    3dd8:	fcce                	sd	s3,120(sp)
    3dda:	f8d2                	sd	s4,112(sp)
    3ddc:	f4d6                	sd	s5,104(sp)
    3dde:	f0da                	sd	s6,96(sp)
    3de0:	ecde                	sd	s7,88(sp)
    3de2:	e8e2                	sd	s8,80(sp)
    3de4:	e4e6                	sd	s9,72(sp)
    3de6:	e0ea                	sd	s10,64(sp)
    3de8:	fc6e                	sd	s11,56(sp)
    3dea:	1100                	addi	s0,sp,160
    3dec:	8caa                	mv	s9,a0
  char *names[] = { "f0", "f1", "f2", "f3" };
    3dee:	00003797          	auipc	a5,0x3
    3df2:	3a278793          	addi	a5,a5,930 # 7190 <malloc+0x1d56>
    3df6:	f6f43823          	sd	a5,-144(s0)
    3dfa:	00003797          	auipc	a5,0x3
    3dfe:	39e78793          	addi	a5,a5,926 # 7198 <malloc+0x1d5e>
    3e02:	f6f43c23          	sd	a5,-136(s0)
    3e06:	00003797          	auipc	a5,0x3
    3e0a:	39a78793          	addi	a5,a5,922 # 71a0 <malloc+0x1d66>
    3e0e:	f8f43023          	sd	a5,-128(s0)
    3e12:	00003797          	auipc	a5,0x3
    3e16:	39678793          	addi	a5,a5,918 # 71a8 <malloc+0x1d6e>
    3e1a:	f8f43423          	sd	a5,-120(s0)
  for(pi = 0; pi < NCHILD; pi++){
    3e1e:	f7040b93          	addi	s7,s0,-144
  char *names[] = { "f0", "f1", "f2", "f3" };
    3e22:	895e                	mv	s2,s7
  for(pi = 0; pi < NCHILD; pi++){
    3e24:	4481                	li	s1,0
    3e26:	4a11                	li	s4,4
    fname = names[pi];
    3e28:	00093983          	ld	s3,0(s2)
    unlink(fname);
    3e2c:	854e                	mv	a0,s3
    3e2e:	120010ef          	jal	4f4e <unlink>
    pid = fork();
    3e32:	0c4010ef          	jal	4ef6 <fork>
    if(pid < 0){
    3e36:	04054063          	bltz	a0,3e76 <fourfiles+0xa8>
    if(pid == 0){
    3e3a:	c921                	beqz	a0,3e8a <fourfiles+0xbc>
  for(pi = 0; pi < NCHILD; pi++){
    3e3c:	2485                	addiw	s1,s1,1
    3e3e:	0921                	addi	s2,s2,8
    3e40:	ff4494e3          	bne	s1,s4,3e28 <fourfiles+0x5a>
    3e44:	4491                	li	s1,4
    wait(&xstatus);
    3e46:	f6c40913          	addi	s2,s0,-148
    3e4a:	854a                	mv	a0,s2
    3e4c:	0ba010ef          	jal	4f06 <wait>
    if(xstatus != 0)
    3e50:	f6c42b03          	lw	s6,-148(s0)
    3e54:	0a0b1463          	bnez	s6,3efc <fourfiles+0x12e>
  for(pi = 0; pi < NCHILD; pi++){
    3e58:	34fd                	addiw	s1,s1,-1
    3e5a:	f8e5                	bnez	s1,3e4a <fourfiles+0x7c>
    3e5c:	03000493          	li	s1,48
    while((n = read(fd, buf, sizeof(buf))) > 0){
    3e60:	6a8d                	lui	s5,0x3
    3e62:	00008a17          	auipc	s4,0x8
    3e66:	e46a0a13          	addi	s4,s4,-442 # bca8 <buf>
    if(total != N*SZ){
    3e6a:	6d05                	lui	s10,0x1
    3e6c:	770d0d13          	addi	s10,s10,1904 # 1770 <exitwait+0x8c>
  for(i = 0; i < NCHILD; i++){
    3e70:	03400d93          	li	s11,52
    3e74:	a86d                	j	3f2e <fourfiles+0x160>
      printf("%s: fork failed\n", s);
    3e76:	85e6                	mv	a1,s9
    3e78:	00002517          	auipc	a0,0x2
    3e7c:	f8050513          	addi	a0,a0,-128 # 5df8 <malloc+0x9be>
    3e80:	502010ef          	jal	5382 <printf>
      exit(1);
    3e84:	4505                	li	a0,1
    3e86:	078010ef          	jal	4efe <exit>
      fd = open(fname, O_CREATE | O_RDWR);
    3e8a:	20200593          	li	a1,514
    3e8e:	854e                	mv	a0,s3
    3e90:	0ae010ef          	jal	4f3e <open>
    3e94:	892a                	mv	s2,a0
      if(fd < 0){
    3e96:	04054063          	bltz	a0,3ed6 <fourfiles+0x108>
      memset(buf, '0'+pi, SZ);
    3e9a:	1f400613          	li	a2,500
    3e9e:	0304859b          	addiw	a1,s1,48
    3ea2:	00008517          	auipc	a0,0x8
    3ea6:	e0650513          	addi	a0,a0,-506 # bca8 <buf>
    3eaa:	62b000ef          	jal	4cd4 <memset>
    3eae:	44b1                	li	s1,12
        if((n = write(fd, buf, SZ)) != SZ){
    3eb0:	1f400993          	li	s3,500
    3eb4:	00008a17          	auipc	s4,0x8
    3eb8:	df4a0a13          	addi	s4,s4,-524 # bca8 <buf>
    3ebc:	864e                	mv	a2,s3
    3ebe:	85d2                	mv	a1,s4
    3ec0:	854a                	mv	a0,s2
    3ec2:	05c010ef          	jal	4f1e <write>
    3ec6:	85aa                	mv	a1,a0
    3ec8:	03351163          	bne	a0,s3,3eea <fourfiles+0x11c>
      for(i = 0; i < N; i++){
    3ecc:	34fd                	addiw	s1,s1,-1
    3ece:	f4fd                	bnez	s1,3ebc <fourfiles+0xee>
      exit(0);
    3ed0:	4501                	li	a0,0
    3ed2:	02c010ef          	jal	4efe <exit>
        printf("%s: create failed\n", s);
    3ed6:	85e6                	mv	a1,s9
    3ed8:	00002517          	auipc	a0,0x2
    3edc:	fb850513          	addi	a0,a0,-72 # 5e90 <malloc+0xa56>
    3ee0:	4a2010ef          	jal	5382 <printf>
        exit(1);
    3ee4:	4505                	li	a0,1
    3ee6:	018010ef          	jal	4efe <exit>
          printf("write failed %d\n", n);
    3eea:	00003517          	auipc	a0,0x3
    3eee:	2c650513          	addi	a0,a0,710 # 71b0 <malloc+0x1d76>
    3ef2:	490010ef          	jal	5382 <printf>
          exit(1);
    3ef6:	4505                	li	a0,1
    3ef8:	006010ef          	jal	4efe <exit>
      exit(xstatus);
    3efc:	855a                	mv	a0,s6
    3efe:	000010ef          	jal	4efe <exit>
          printf("%s: wrong char\n", s);
    3f02:	85e6                	mv	a1,s9
    3f04:	00003517          	auipc	a0,0x3
    3f08:	2c450513          	addi	a0,a0,708 # 71c8 <malloc+0x1d8e>
    3f0c:	476010ef          	jal	5382 <printf>
          exit(1);
    3f10:	4505                	li	a0,1
    3f12:	7ed000ef          	jal	4efe <exit>
    close(fd);
    3f16:	854e                	mv	a0,s3
    3f18:	00e010ef          	jal	4f26 <close>
    if(total != N*SZ){
    3f1c:	05a91863          	bne	s2,s10,3f6c <fourfiles+0x19e>
    unlink(fname);
    3f20:	8562                	mv	a0,s8
    3f22:	02c010ef          	jal	4f4e <unlink>
  for(i = 0; i < NCHILD; i++){
    3f26:	0ba1                	addi	s7,s7,8
    3f28:	2485                	addiw	s1,s1,1
    3f2a:	05b48b63          	beq	s1,s11,3f80 <fourfiles+0x1b2>
    fname = names[i];
    3f2e:	000bbc03          	ld	s8,0(s7)
    fd = open(fname, 0);
    3f32:	4581                	li	a1,0
    3f34:	8562                	mv	a0,s8
    3f36:	008010ef          	jal	4f3e <open>
    3f3a:	89aa                	mv	s3,a0
    total = 0;
    3f3c:	895a                	mv	s2,s6
    while((n = read(fd, buf, sizeof(buf))) > 0){
    3f3e:	8656                	mv	a2,s5
    3f40:	85d2                	mv	a1,s4
    3f42:	854e                	mv	a0,s3
    3f44:	7d3000ef          	jal	4f16 <read>
    3f48:	fca057e3          	blez	a0,3f16 <fourfiles+0x148>
    3f4c:	00008797          	auipc	a5,0x8
    3f50:	d5c78793          	addi	a5,a5,-676 # bca8 <buf>
    3f54:	00f506b3          	add	a3,a0,a5
        if(buf[j] != '0'+i){
    3f58:	0007c703          	lbu	a4,0(a5)
    3f5c:	fa9713e3          	bne	a4,s1,3f02 <fourfiles+0x134>
      for(j = 0; j < n; j++){
    3f60:	0785                	addi	a5,a5,1
    3f62:	fed79be3          	bne	a5,a3,3f58 <fourfiles+0x18a>
      total += n;
    3f66:	00a9093b          	addw	s2,s2,a0
    3f6a:	bfd1                	j	3f3e <fourfiles+0x170>
      printf("wrong length %d\n", total);
    3f6c:	85ca                	mv	a1,s2
    3f6e:	00003517          	auipc	a0,0x3
    3f72:	26a50513          	addi	a0,a0,618 # 71d8 <malloc+0x1d9e>
    3f76:	40c010ef          	jal	5382 <printf>
      exit(1);
    3f7a:	4505                	li	a0,1
    3f7c:	783000ef          	jal	4efe <exit>
}
    3f80:	60ea                	ld	ra,152(sp)
    3f82:	644a                	ld	s0,144(sp)
    3f84:	64aa                	ld	s1,136(sp)
    3f86:	690a                	ld	s2,128(sp)
    3f88:	79e6                	ld	s3,120(sp)
    3f8a:	7a46                	ld	s4,112(sp)
    3f8c:	7aa6                	ld	s5,104(sp)
    3f8e:	7b06                	ld	s6,96(sp)
    3f90:	6be6                	ld	s7,88(sp)
    3f92:	6c46                	ld	s8,80(sp)
    3f94:	6ca6                	ld	s9,72(sp)
    3f96:	6d06                	ld	s10,64(sp)
    3f98:	7de2                	ld	s11,56(sp)
    3f9a:	610d                	addi	sp,sp,160
    3f9c:	8082                	ret

0000000000003f9e <concreate>:
{
    3f9e:	7171                	addi	sp,sp,-176
    3fa0:	f506                	sd	ra,168(sp)
    3fa2:	f122                	sd	s0,160(sp)
    3fa4:	ed26                	sd	s1,152(sp)
    3fa6:	e94a                	sd	s2,144(sp)
    3fa8:	e54e                	sd	s3,136(sp)
    3faa:	e152                	sd	s4,128(sp)
    3fac:	fcd6                	sd	s5,120(sp)
    3fae:	f8da                	sd	s6,112(sp)
    3fb0:	f4de                	sd	s7,104(sp)
    3fb2:	f0e2                	sd	s8,96(sp)
    3fb4:	ece6                	sd	s9,88(sp)
    3fb6:	e8ea                	sd	s10,80(sp)
    3fb8:	1900                	addi	s0,sp,176
    3fba:	8d2a                	mv	s10,a0
  file[0] = 'C';
    3fbc:	04300793          	li	a5,67
    3fc0:	f8f40c23          	sb	a5,-104(s0)
  file[2] = '\0';
    3fc4:	f8040d23          	sb	zero,-102(s0)
  for(i = 0; i < N; i++){
    3fc8:	4901                	li	s2,0
    unlink(file);
    3fca:	f9840993          	addi	s3,s0,-104
    if(pid && (i % 3) == 1){
    3fce:	55555b37          	lui	s6,0x55555
    3fd2:	556b0b13          	addi	s6,s6,1366 # 55555556 <base+0x555468ae>
    3fd6:	4b85                	li	s7,1
      fd = open(file, O_CREATE | O_RDWR);
    3fd8:	20200c13          	li	s8,514
      link("C0", file);
    3fdc:	00003c97          	auipc	s9,0x3
    3fe0:	214c8c93          	addi	s9,s9,532 # 71f0 <malloc+0x1db6>
      wait(&xstatus);
    3fe4:	f5c40a93          	addi	s5,s0,-164
  for(i = 0; i < N; i++){
    3fe8:	02800a13          	li	s4,40
    3fec:	ac25                	j	4224 <concreate+0x286>
      link("C0", file);
    3fee:	85ce                	mv	a1,s3
    3ff0:	8566                	mv	a0,s9
    3ff2:	76d000ef          	jal	4f5e <link>
    if(pid == 0) {
    3ff6:	ac29                	j	4210 <concreate+0x272>
    } else if(pid == 0 && (i % 5) == 1){
    3ff8:	666667b7          	lui	a5,0x66666
    3ffc:	66778793          	addi	a5,a5,1639 # 66666667 <base+0x666579bf>
    4000:	02f907b3          	mul	a5,s2,a5
    4004:	9785                	srai	a5,a5,0x21
    4006:	41f9571b          	sraiw	a4,s2,0x1f
    400a:	9f99                	subw	a5,a5,a4
    400c:	0027971b          	slliw	a4,a5,0x2
    4010:	9fb9                	addw	a5,a5,a4
    4012:	40f9093b          	subw	s2,s2,a5
    4016:	4785                	li	a5,1
    4018:	02f90563          	beq	s2,a5,4042 <concreate+0xa4>
      fd = open(file, O_CREATE | O_RDWR);
    401c:	20200593          	li	a1,514
    4020:	f9840513          	addi	a0,s0,-104
    4024:	71b000ef          	jal	4f3e <open>
      if(fd < 0){
    4028:	1c055f63          	bgez	a0,4206 <concreate+0x268>
        printf("concreate create %s failed\n", file);
    402c:	f9840593          	addi	a1,s0,-104
    4030:	00003517          	auipc	a0,0x3
    4034:	1c850513          	addi	a0,a0,456 # 71f8 <malloc+0x1dbe>
    4038:	34a010ef          	jal	5382 <printf>
        exit(1);
    403c:	4505                	li	a0,1
    403e:	6c1000ef          	jal	4efe <exit>
      link("C0", file);
    4042:	f9840593          	addi	a1,s0,-104
    4046:	00003517          	auipc	a0,0x3
    404a:	1aa50513          	addi	a0,a0,426 # 71f0 <malloc+0x1db6>
    404e:	711000ef          	jal	4f5e <link>
      exit(0);
    4052:	4501                	li	a0,0
    4054:	6ab000ef          	jal	4efe <exit>
        exit(1);
    4058:	4505                	li	a0,1
    405a:	6a5000ef          	jal	4efe <exit>
  memset(fa, 0, sizeof(fa));
    405e:	02800613          	li	a2,40
    4062:	4581                	li	a1,0
    4064:	f7040513          	addi	a0,s0,-144
    4068:	46d000ef          	jal	4cd4 <memset>
  fd = open(".", 0);
    406c:	4581                	li	a1,0
    406e:	00002517          	auipc	a0,0x2
    4072:	be250513          	addi	a0,a0,-1054 # 5c50 <malloc+0x816>
    4076:	6c9000ef          	jal	4f3e <open>
    407a:	892a                	mv	s2,a0
  n = 0;
    407c:	8b26                	mv	s6,s1
  while(read(fd, &de, sizeof(de)) > 0){
    407e:	f6040a13          	addi	s4,s0,-160
    4082:	49c1                	li	s3,16
    if(de.name[0] == 'C' && de.name[2] == '\0'){
    4084:	04300a93          	li	s5,67
      if(i < 0 || i >= sizeof(fa)){
    4088:	02700b93          	li	s7,39
      fa[i] = 1;
    408c:	4c05                	li	s8,1
  while(read(fd, &de, sizeof(de)) > 0){
    408e:	864e                	mv	a2,s3
    4090:	85d2                	mv	a1,s4
    4092:	854a                	mv	a0,s2
    4094:	683000ef          	jal	4f16 <read>
    4098:	06a05763          	blez	a0,4106 <concreate+0x168>
    if(de.inum == 0)
    409c:	f6045783          	lhu	a5,-160(s0)
    40a0:	d7fd                	beqz	a5,408e <concreate+0xf0>
    if(de.name[0] == 'C' && de.name[2] == '\0'){
    40a2:	f6244783          	lbu	a5,-158(s0)
    40a6:	ff5794e3          	bne	a5,s5,408e <concreate+0xf0>
    40aa:	f6444783          	lbu	a5,-156(s0)
    40ae:	f3e5                	bnez	a5,408e <concreate+0xf0>
      i = de.name[1] - '0';
    40b0:	f6344783          	lbu	a5,-157(s0)
    40b4:	fd07879b          	addiw	a5,a5,-48
      if(i < 0 || i >= sizeof(fa)){
    40b8:	00fbef63          	bltu	s7,a5,40d6 <concreate+0x138>
      if(fa[i]){
    40bc:	fa078713          	addi	a4,a5,-96
    40c0:	9722                	add	a4,a4,s0
    40c2:	fd074703          	lbu	a4,-48(a4)
    40c6:	e705                	bnez	a4,40ee <concreate+0x150>
      fa[i] = 1;
    40c8:	fa078793          	addi	a5,a5,-96
    40cc:	97a2                	add	a5,a5,s0
    40ce:	fd878823          	sb	s8,-48(a5)
      n++;
    40d2:	2b05                	addiw	s6,s6,1
    40d4:	bf6d                	j	408e <concreate+0xf0>
        printf("%s: concreate weird file %s\n", s, de.name);
    40d6:	f6240613          	addi	a2,s0,-158
    40da:	85ea                	mv	a1,s10
    40dc:	00003517          	auipc	a0,0x3
    40e0:	13c50513          	addi	a0,a0,316 # 7218 <malloc+0x1dde>
    40e4:	29e010ef          	jal	5382 <printf>
        exit(1);
    40e8:	4505                	li	a0,1
    40ea:	615000ef          	jal	4efe <exit>
        printf("%s: concreate duplicate file %s\n", s, de.name);
    40ee:	f6240613          	addi	a2,s0,-158
    40f2:	85ea                	mv	a1,s10
    40f4:	00003517          	auipc	a0,0x3
    40f8:	14450513          	addi	a0,a0,324 # 7238 <malloc+0x1dfe>
    40fc:	286010ef          	jal	5382 <printf>
        exit(1);
    4100:	4505                	li	a0,1
    4102:	5fd000ef          	jal	4efe <exit>
  close(fd);
    4106:	854a                	mv	a0,s2
    4108:	61f000ef          	jal	4f26 <close>
  if(n != N){
    410c:	02800793          	li	a5,40
    4110:	00fb1a63          	bne	s6,a5,4124 <concreate+0x186>
    if(((i % 3) == 0 && pid == 0) ||
    4114:	55555a37          	lui	s4,0x55555
    4118:	556a0a13          	addi	s4,s4,1366 # 55555556 <base+0x555468ae>
      close(open(file, 0));
    411c:	f9840993          	addi	s3,s0,-104
  for(i = 0; i < N; i++){
    4120:	8ada                	mv	s5,s6
    4122:	a049                	j	41a4 <concreate+0x206>
    printf("%s: concreate not enough files in directory listing\n", s);
    4124:	85ea                	mv	a1,s10
    4126:	00003517          	auipc	a0,0x3
    412a:	13a50513          	addi	a0,a0,314 # 7260 <malloc+0x1e26>
    412e:	254010ef          	jal	5382 <printf>
    exit(1);
    4132:	4505                	li	a0,1
    4134:	5cb000ef          	jal	4efe <exit>
      printf("%s: fork failed\n", s);
    4138:	85ea                	mv	a1,s10
    413a:	00002517          	auipc	a0,0x2
    413e:	cbe50513          	addi	a0,a0,-834 # 5df8 <malloc+0x9be>
    4142:	240010ef          	jal	5382 <printf>
      exit(1);
    4146:	4505                	li	a0,1
    4148:	5b7000ef          	jal	4efe <exit>
      close(open(file, 0));
    414c:	4581                	li	a1,0
    414e:	854e                	mv	a0,s3
    4150:	5ef000ef          	jal	4f3e <open>
    4154:	5d3000ef          	jal	4f26 <close>
      close(open(file, 0));
    4158:	4581                	li	a1,0
    415a:	854e                	mv	a0,s3
    415c:	5e3000ef          	jal	4f3e <open>
    4160:	5c7000ef          	jal	4f26 <close>
      close(open(file, 0));
    4164:	4581                	li	a1,0
    4166:	854e                	mv	a0,s3
    4168:	5d7000ef          	jal	4f3e <open>
    416c:	5bb000ef          	jal	4f26 <close>
      close(open(file, 0));
    4170:	4581                	li	a1,0
    4172:	854e                	mv	a0,s3
    4174:	5cb000ef          	jal	4f3e <open>
    4178:	5af000ef          	jal	4f26 <close>
      close(open(file, 0));
    417c:	4581                	li	a1,0
    417e:	854e                	mv	a0,s3
    4180:	5bf000ef          	jal	4f3e <open>
    4184:	5a3000ef          	jal	4f26 <close>
      close(open(file, 0));
    4188:	4581                	li	a1,0
    418a:	854e                	mv	a0,s3
    418c:	5b3000ef          	jal	4f3e <open>
    4190:	597000ef          	jal	4f26 <close>
    if(pid == 0)
    4194:	06090663          	beqz	s2,4200 <concreate+0x262>
      wait(0);
    4198:	4501                	li	a0,0
    419a:	56d000ef          	jal	4f06 <wait>
  for(i = 0; i < N; i++){
    419e:	2485                	addiw	s1,s1,1
    41a0:	0d548163          	beq	s1,s5,4262 <concreate+0x2c4>
    file[1] = '0' + i;
    41a4:	0304879b          	addiw	a5,s1,48
    41a8:	f8f40ca3          	sb	a5,-103(s0)
    pid = fork();
    41ac:	54b000ef          	jal	4ef6 <fork>
    41b0:	892a                	mv	s2,a0
    if(pid < 0){
    41b2:	f80543e3          	bltz	a0,4138 <concreate+0x19a>
    if(((i % 3) == 0 && pid == 0) ||
    41b6:	03448733          	mul	a4,s1,s4
    41ba:	9301                	srli	a4,a4,0x20
    41bc:	41f4d79b          	sraiw	a5,s1,0x1f
    41c0:	9f1d                	subw	a4,a4,a5
    41c2:	0017179b          	slliw	a5,a4,0x1
    41c6:	9fb9                	addw	a5,a5,a4
    41c8:	40f487bb          	subw	a5,s1,a5
    41cc:	00a7e733          	or	a4,a5,a0
    41d0:	2701                	sext.w	a4,a4
    41d2:	df2d                	beqz	a4,414c <concreate+0x1ae>
       ((i % 3) == 1 && pid != 0)){
    41d4:	c119                	beqz	a0,41da <concreate+0x23c>
    if(((i % 3) == 0 && pid == 0) ||
    41d6:	17fd                	addi	a5,a5,-1
       ((i % 3) == 1 && pid != 0)){
    41d8:	dbb5                	beqz	a5,414c <concreate+0x1ae>
      unlink(file);
    41da:	854e                	mv	a0,s3
    41dc:	573000ef          	jal	4f4e <unlink>
      unlink(file);
    41e0:	854e                	mv	a0,s3
    41e2:	56d000ef          	jal	4f4e <unlink>
      unlink(file);
    41e6:	854e                	mv	a0,s3
    41e8:	567000ef          	jal	4f4e <unlink>
      unlink(file);
    41ec:	854e                	mv	a0,s3
    41ee:	561000ef          	jal	4f4e <unlink>
      unlink(file);
    41f2:	854e                	mv	a0,s3
    41f4:	55b000ef          	jal	4f4e <unlink>
      unlink(file);
    41f8:	854e                	mv	a0,s3
    41fa:	555000ef          	jal	4f4e <unlink>
    41fe:	bf59                	j	4194 <concreate+0x1f6>
      exit(0);
    4200:	4501                	li	a0,0
    4202:	4fd000ef          	jal	4efe <exit>
      close(fd);
    4206:	521000ef          	jal	4f26 <close>
    if(pid == 0) {
    420a:	b5a1                	j	4052 <concreate+0xb4>
      close(fd);
    420c:	51b000ef          	jal	4f26 <close>
      wait(&xstatus);
    4210:	8556                	mv	a0,s5
    4212:	4f5000ef          	jal	4f06 <wait>
      if(xstatus != 0)
    4216:	f5c42483          	lw	s1,-164(s0)
    421a:	e2049fe3          	bnez	s1,4058 <concreate+0xba>
  for(i = 0; i < N; i++){
    421e:	2905                	addiw	s2,s2,1
    4220:	e3490fe3          	beq	s2,s4,405e <concreate+0xc0>
    file[1] = '0' + i;
    4224:	0309079b          	addiw	a5,s2,48
    4228:	f8f40ca3          	sb	a5,-103(s0)
    unlink(file);
    422c:	854e                	mv	a0,s3
    422e:	521000ef          	jal	4f4e <unlink>
    pid = fork();
    4232:	4c5000ef          	jal	4ef6 <fork>
    if(pid && (i % 3) == 1){
    4236:	dc0501e3          	beqz	a0,3ff8 <concreate+0x5a>
    423a:	036907b3          	mul	a5,s2,s6
    423e:	9381                	srli	a5,a5,0x20
    4240:	41f9571b          	sraiw	a4,s2,0x1f
    4244:	9f99                	subw	a5,a5,a4
    4246:	0017971b          	slliw	a4,a5,0x1
    424a:	9fb9                	addw	a5,a5,a4
    424c:	40f907bb          	subw	a5,s2,a5
    4250:	d9778fe3          	beq	a5,s7,3fee <concreate+0x50>
      fd = open(file, O_CREATE | O_RDWR);
    4254:	85e2                	mv	a1,s8
    4256:	854e                	mv	a0,s3
    4258:	4e7000ef          	jal	4f3e <open>
      if(fd < 0){
    425c:	fa0558e3          	bgez	a0,420c <concreate+0x26e>
    4260:	b3f1                	j	402c <concreate+0x8e>
}
    4262:	70aa                	ld	ra,168(sp)
    4264:	740a                	ld	s0,160(sp)
    4266:	64ea                	ld	s1,152(sp)
    4268:	694a                	ld	s2,144(sp)
    426a:	69aa                	ld	s3,136(sp)
    426c:	6a0a                	ld	s4,128(sp)
    426e:	7ae6                	ld	s5,120(sp)
    4270:	7b46                	ld	s6,112(sp)
    4272:	7ba6                	ld	s7,104(sp)
    4274:	7c06                	ld	s8,96(sp)
    4276:	6ce6                	ld	s9,88(sp)
    4278:	6d46                	ld	s10,80(sp)
    427a:	614d                	addi	sp,sp,176
    427c:	8082                	ret

000000000000427e <bigfile>:
{
    427e:	7139                	addi	sp,sp,-64
    4280:	fc06                	sd	ra,56(sp)
    4282:	f822                	sd	s0,48(sp)
    4284:	f426                	sd	s1,40(sp)
    4286:	f04a                	sd	s2,32(sp)
    4288:	ec4e                	sd	s3,24(sp)
    428a:	e852                	sd	s4,16(sp)
    428c:	e456                	sd	s5,8(sp)
    428e:	e05a                	sd	s6,0(sp)
    4290:	0080                	addi	s0,sp,64
    4292:	8b2a                	mv	s6,a0
  unlink("bigfile.dat");
    4294:	00003517          	auipc	a0,0x3
    4298:	00450513          	addi	a0,a0,4 # 7298 <malloc+0x1e5e>
    429c:	4b3000ef          	jal	4f4e <unlink>
  fd = open("bigfile.dat", O_CREATE | O_RDWR);
    42a0:	20200593          	li	a1,514
    42a4:	00003517          	auipc	a0,0x3
    42a8:	ff450513          	addi	a0,a0,-12 # 7298 <malloc+0x1e5e>
    42ac:	493000ef          	jal	4f3e <open>
  if(fd < 0){
    42b0:	08054a63          	bltz	a0,4344 <bigfile+0xc6>
    42b4:	8a2a                	mv	s4,a0
    42b6:	4481                	li	s1,0
    memset(buf, i, SZ);
    42b8:	25800913          	li	s2,600
    42bc:	00008997          	auipc	s3,0x8
    42c0:	9ec98993          	addi	s3,s3,-1556 # bca8 <buf>
  for(i = 0; i < N; i++){
    42c4:	4ad1                	li	s5,20
    memset(buf, i, SZ);
    42c6:	864a                	mv	a2,s2
    42c8:	85a6                	mv	a1,s1
    42ca:	854e                	mv	a0,s3
    42cc:	209000ef          	jal	4cd4 <memset>
    if(write(fd, buf, SZ) != SZ){
    42d0:	864a                	mv	a2,s2
    42d2:	85ce                	mv	a1,s3
    42d4:	8552                	mv	a0,s4
    42d6:	449000ef          	jal	4f1e <write>
    42da:	07251f63          	bne	a0,s2,4358 <bigfile+0xda>
  for(i = 0; i < N; i++){
    42de:	2485                	addiw	s1,s1,1
    42e0:	ff5493e3          	bne	s1,s5,42c6 <bigfile+0x48>
  close(fd);
    42e4:	8552                	mv	a0,s4
    42e6:	441000ef          	jal	4f26 <close>
  fd = open("bigfile.dat", 0);
    42ea:	4581                	li	a1,0
    42ec:	00003517          	auipc	a0,0x3
    42f0:	fac50513          	addi	a0,a0,-84 # 7298 <malloc+0x1e5e>
    42f4:	44b000ef          	jal	4f3e <open>
    42f8:	8aaa                	mv	s5,a0
  total = 0;
    42fa:	4a01                	li	s4,0
  for(i = 0; ; i++){
    42fc:	4481                	li	s1,0
    cc = read(fd, buf, SZ/2);
    42fe:	12c00993          	li	s3,300
    4302:	00008917          	auipc	s2,0x8
    4306:	9a690913          	addi	s2,s2,-1626 # bca8 <buf>
  if(fd < 0){
    430a:	06054163          	bltz	a0,436c <bigfile+0xee>
    cc = read(fd, buf, SZ/2);
    430e:	864e                	mv	a2,s3
    4310:	85ca                	mv	a1,s2
    4312:	8556                	mv	a0,s5
    4314:	403000ef          	jal	4f16 <read>
    if(cc < 0){
    4318:	06054463          	bltz	a0,4380 <bigfile+0x102>
    if(cc == 0)
    431c:	c145                	beqz	a0,43bc <bigfile+0x13e>
    if(cc != SZ/2){
    431e:	07351b63          	bne	a0,s3,4394 <bigfile+0x116>
    if(buf[0] != i/2 || buf[SZ/2-1] != i/2){
    4322:	01f4d79b          	srliw	a5,s1,0x1f
    4326:	9fa5                	addw	a5,a5,s1
    4328:	4017d79b          	sraiw	a5,a5,0x1
    432c:	00094703          	lbu	a4,0(s2)
    4330:	06f71c63          	bne	a4,a5,43a8 <bigfile+0x12a>
    4334:	12b94703          	lbu	a4,299(s2)
    4338:	06f71863          	bne	a4,a5,43a8 <bigfile+0x12a>
    total += cc;
    433c:	12ca0a1b          	addiw	s4,s4,300
  for(i = 0; ; i++){
    4340:	2485                	addiw	s1,s1,1
    cc = read(fd, buf, SZ/2);
    4342:	b7f1                	j	430e <bigfile+0x90>
    printf("%s: cannot create bigfile", s);
    4344:	85da                	mv	a1,s6
    4346:	00003517          	auipc	a0,0x3
    434a:	f6250513          	addi	a0,a0,-158 # 72a8 <malloc+0x1e6e>
    434e:	034010ef          	jal	5382 <printf>
    exit(1);
    4352:	4505                	li	a0,1
    4354:	3ab000ef          	jal	4efe <exit>
      printf("%s: write bigfile failed\n", s);
    4358:	85da                	mv	a1,s6
    435a:	00003517          	auipc	a0,0x3
    435e:	f6e50513          	addi	a0,a0,-146 # 72c8 <malloc+0x1e8e>
    4362:	020010ef          	jal	5382 <printf>
      exit(1);
    4366:	4505                	li	a0,1
    4368:	397000ef          	jal	4efe <exit>
    printf("%s: cannot open bigfile\n", s);
    436c:	85da                	mv	a1,s6
    436e:	00003517          	auipc	a0,0x3
    4372:	f7a50513          	addi	a0,a0,-134 # 72e8 <malloc+0x1eae>
    4376:	00c010ef          	jal	5382 <printf>
    exit(1);
    437a:	4505                	li	a0,1
    437c:	383000ef          	jal	4efe <exit>
      printf("%s: read bigfile failed\n", s);
    4380:	85da                	mv	a1,s6
    4382:	00003517          	auipc	a0,0x3
    4386:	f8650513          	addi	a0,a0,-122 # 7308 <malloc+0x1ece>
    438a:	7f9000ef          	jal	5382 <printf>
      exit(1);
    438e:	4505                	li	a0,1
    4390:	36f000ef          	jal	4efe <exit>
      printf("%s: short read bigfile\n", s);
    4394:	85da                	mv	a1,s6
    4396:	00003517          	auipc	a0,0x3
    439a:	f9250513          	addi	a0,a0,-110 # 7328 <malloc+0x1eee>
    439e:	7e5000ef          	jal	5382 <printf>
      exit(1);
    43a2:	4505                	li	a0,1
    43a4:	35b000ef          	jal	4efe <exit>
      printf("%s: read bigfile wrong data\n", s);
    43a8:	85da                	mv	a1,s6
    43aa:	00003517          	auipc	a0,0x3
    43ae:	f9650513          	addi	a0,a0,-106 # 7340 <malloc+0x1f06>
    43b2:	7d1000ef          	jal	5382 <printf>
      exit(1);
    43b6:	4505                	li	a0,1
    43b8:	347000ef          	jal	4efe <exit>
  close(fd);
    43bc:	8556                	mv	a0,s5
    43be:	369000ef          	jal	4f26 <close>
  if(total != N*SZ){
    43c2:	678d                	lui	a5,0x3
    43c4:	ee078793          	addi	a5,a5,-288 # 2ee0 <subdir+0x1da>
    43c8:	02fa1263          	bne	s4,a5,43ec <bigfile+0x16e>
  unlink("bigfile.dat");
    43cc:	00003517          	auipc	a0,0x3
    43d0:	ecc50513          	addi	a0,a0,-308 # 7298 <malloc+0x1e5e>
    43d4:	37b000ef          	jal	4f4e <unlink>
}
    43d8:	70e2                	ld	ra,56(sp)
    43da:	7442                	ld	s0,48(sp)
    43dc:	74a2                	ld	s1,40(sp)
    43de:	7902                	ld	s2,32(sp)
    43e0:	69e2                	ld	s3,24(sp)
    43e2:	6a42                	ld	s4,16(sp)
    43e4:	6aa2                	ld	s5,8(sp)
    43e6:	6b02                	ld	s6,0(sp)
    43e8:	6121                	addi	sp,sp,64
    43ea:	8082                	ret
    printf("%s: read bigfile wrong total\n", s);
    43ec:	85da                	mv	a1,s6
    43ee:	00003517          	auipc	a0,0x3
    43f2:	f7250513          	addi	a0,a0,-142 # 7360 <malloc+0x1f26>
    43f6:	78d000ef          	jal	5382 <printf>
    exit(1);
    43fa:	4505                	li	a0,1
    43fc:	303000ef          	jal	4efe <exit>

0000000000004400 <bigargtest>:
{
    4400:	7121                	addi	sp,sp,-448
    4402:	ff06                	sd	ra,440(sp)
    4404:	fb22                	sd	s0,432(sp)
    4406:	f726                	sd	s1,424(sp)
    4408:	0380                	addi	s0,sp,448
    440a:	84aa                	mv	s1,a0
  unlink("bigarg-ok");
    440c:	00003517          	auipc	a0,0x3
    4410:	f7450513          	addi	a0,a0,-140 # 7380 <malloc+0x1f46>
    4414:	33b000ef          	jal	4f4e <unlink>
  pid = fork();
    4418:	2df000ef          	jal	4ef6 <fork>
  if(pid == 0){
    441c:	c915                	beqz	a0,4450 <bigargtest+0x50>
  } else if(pid < 0){
    441e:	08054c63          	bltz	a0,44b6 <bigargtest+0xb6>
  wait(&xstatus);
    4422:	fdc40513          	addi	a0,s0,-36
    4426:	2e1000ef          	jal	4f06 <wait>
  if(xstatus != 0)
    442a:	fdc42503          	lw	a0,-36(s0)
    442e:	ed51                	bnez	a0,44ca <bigargtest+0xca>
  fd = open("bigarg-ok", 0);
    4430:	4581                	li	a1,0
    4432:	00003517          	auipc	a0,0x3
    4436:	f4e50513          	addi	a0,a0,-178 # 7380 <malloc+0x1f46>
    443a:	305000ef          	jal	4f3e <open>
  if(fd < 0){
    443e:	08054863          	bltz	a0,44ce <bigargtest+0xce>
  close(fd);
    4442:	2e5000ef          	jal	4f26 <close>
}
    4446:	70fa                	ld	ra,440(sp)
    4448:	745a                	ld	s0,432(sp)
    444a:	74ba                	ld	s1,424(sp)
    444c:	6139                	addi	sp,sp,448
    444e:	8082                	ret
    memset(big, ' ', sizeof(big));
    4450:	19000613          	li	a2,400
    4454:	02000593          	li	a1,32
    4458:	e4840513          	addi	a0,s0,-440
    445c:	079000ef          	jal	4cd4 <memset>
    big[sizeof(big)-1] = '\0';
    4460:	fc040ba3          	sb	zero,-41(s0)
    for(i = 0; i < MAXARG-1; i++)
    4464:	00004797          	auipc	a5,0x4
    4468:	02c78793          	addi	a5,a5,44 # 8490 <args.1>
    446c:	00004697          	auipc	a3,0x4
    4470:	11c68693          	addi	a3,a3,284 # 8588 <args.1+0xf8>
      args[i] = big;
    4474:	e4840713          	addi	a4,s0,-440
    4478:	e398                	sd	a4,0(a5)
    for(i = 0; i < MAXARG-1; i++)
    447a:	07a1                	addi	a5,a5,8
    447c:	fed79ee3          	bne	a5,a3,4478 <bigargtest+0x78>
    args[MAXARG-1] = 0;
    4480:	00004797          	auipc	a5,0x4
    4484:	1007b423          	sd	zero,264(a5) # 8588 <args.1+0xf8>
    exec("echo", args);
    4488:	00004597          	auipc	a1,0x4
    448c:	00858593          	addi	a1,a1,8 # 8490 <args.1>
    4490:	00001517          	auipc	a0,0x1
    4494:	0d850513          	addi	a0,a0,216 # 5568 <malloc+0x12e>
    4498:	29f000ef          	jal	4f36 <exec>
    fd = open("bigarg-ok", O_CREATE);
    449c:	20000593          	li	a1,512
    44a0:	00003517          	auipc	a0,0x3
    44a4:	ee050513          	addi	a0,a0,-288 # 7380 <malloc+0x1f46>
    44a8:	297000ef          	jal	4f3e <open>
    close(fd);
    44ac:	27b000ef          	jal	4f26 <close>
    exit(0);
    44b0:	4501                	li	a0,0
    44b2:	24d000ef          	jal	4efe <exit>
    printf("%s: bigargtest: fork failed\n", s);
    44b6:	85a6                	mv	a1,s1
    44b8:	00003517          	auipc	a0,0x3
    44bc:	ed850513          	addi	a0,a0,-296 # 7390 <malloc+0x1f56>
    44c0:	6c3000ef          	jal	5382 <printf>
    exit(1);
    44c4:	4505                	li	a0,1
    44c6:	239000ef          	jal	4efe <exit>
    exit(xstatus);
    44ca:	235000ef          	jal	4efe <exit>
    printf("%s: bigarg test failed!\n", s);
    44ce:	85a6                	mv	a1,s1
    44d0:	00003517          	auipc	a0,0x3
    44d4:	ee050513          	addi	a0,a0,-288 # 73b0 <malloc+0x1f76>
    44d8:	6ab000ef          	jal	5382 <printf>
    exit(1);
    44dc:	4505                	li	a0,1
    44de:	221000ef          	jal	4efe <exit>

00000000000044e2 <lazy_alloc>:
{
    44e2:	1141                	addi	sp,sp,-16
    44e4:	e406                	sd	ra,8(sp)
    44e6:	e022                	sd	s0,0(sp)
    44e8:	0800                	addi	s0,sp,16
  prev_end = sbrklazy(REGION_SZ);
    44ea:	40000537          	lui	a0,0x40000
    44ee:	1f3000ef          	jal	4ee0 <sbrklazy>
  if (prev_end == (char *) SBRK_ERROR) {
    44f2:	57fd                	li	a5,-1
    44f4:	02f50a63          	beq	a0,a5,4528 <lazy_alloc+0x46>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    44f8:	6605                	lui	a2,0x1
    44fa:	962a                	add	a2,a2,a0
    44fc:	400017b7          	lui	a5,0x40001
    4500:	00f50733          	add	a4,a0,a5
    4504:	87b2                	mv	a5,a2
    4506:	000406b7          	lui	a3,0x40
    *(char **)i = i;
    450a:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE)
    450c:	97b6                	add	a5,a5,a3
    450e:	fee79ee3          	bne	a5,a4,450a <lazy_alloc+0x28>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    4512:	000406b7          	lui	a3,0x40
    if (*(char **)i != i) {
    4516:	621c                	ld	a5,0(a2)
    4518:	02c79163          	bne	a5,a2,453a <lazy_alloc+0x58>
  for (i = prev_end + PGSIZE; i < new_end; i += 64 * PGSIZE) {
    451c:	9636                	add	a2,a2,a3
    451e:	fee61ce3          	bne	a2,a4,4516 <lazy_alloc+0x34>
  exit(0);
    4522:	4501                	li	a0,0
    4524:	1db000ef          	jal	4efe <exit>
    printf("sbrklazy() failed\n");
    4528:	00003517          	auipc	a0,0x3
    452c:	ea850513          	addi	a0,a0,-344 # 73d0 <malloc+0x1f96>
    4530:	653000ef          	jal	5382 <printf>
    exit(1);
    4534:	4505                	li	a0,1
    4536:	1c9000ef          	jal	4efe <exit>
      printf("failed to read value from memory\n");
    453a:	00003517          	auipc	a0,0x3
    453e:	eae50513          	addi	a0,a0,-338 # 73e8 <malloc+0x1fae>
    4542:	641000ef          	jal	5382 <printf>
      exit(1);
    4546:	4505                	li	a0,1
    4548:	1b7000ef          	jal	4efe <exit>

000000000000454c <lazy_unmap>:
{
    454c:	7139                	addi	sp,sp,-64
    454e:	fc06                	sd	ra,56(sp)
    4550:	f822                	sd	s0,48(sp)
    4552:	0080                	addi	s0,sp,64
  prev_end = sbrklazy(REGION_SZ);
    4554:	40000537          	lui	a0,0x40000
    4558:	189000ef          	jal	4ee0 <sbrklazy>
  if (prev_end == (char*)SBRK_ERROR) {
    455c:	57fd                	li	a5,-1
    455e:	04f50863          	beq	a0,a5,45ae <lazy_unmap+0x62>
    4562:	f426                	sd	s1,40(sp)
    4564:	f04a                	sd	s2,32(sp)
    4566:	ec4e                	sd	s3,24(sp)
    4568:	e852                	sd	s4,16(sp)
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    456a:	6905                	lui	s2,0x1
    456c:	992a                	add	s2,s2,a0
    456e:	400017b7          	lui	a5,0x40001
    4572:	00f504b3          	add	s1,a0,a5
    4576:	87ca                	mv	a5,s2
    4578:	01000737          	lui	a4,0x1000
    *(char **)i = i;
    457c:	e39c                	sd	a5,0(a5)
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE)
    457e:	97ba                	add	a5,a5,a4
    4580:	fe979ee3          	bne	a5,s1,457c <lazy_unmap+0x30>
      wait(&status);
    4584:	fcc40993          	addi	s3,s0,-52
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    4588:	01000a37          	lui	s4,0x1000
    pid = fork();
    458c:	16b000ef          	jal	4ef6 <fork>
    if (pid < 0) {
    4590:	02054c63          	bltz	a0,45c8 <lazy_unmap+0x7c>
    } else if (pid == 0) {
    4594:	c139                	beqz	a0,45da <lazy_unmap+0x8e>
      wait(&status);
    4596:	854e                	mv	a0,s3
    4598:	16f000ef          	jal	4f06 <wait>
      if (status == 0) {
    459c:	fcc42783          	lw	a5,-52(s0)
    45a0:	c7b1                	beqz	a5,45ec <lazy_unmap+0xa0>
  for (i = prev_end + PGSIZE; i < new_end; i += PGSIZE * PGSIZE) {
    45a2:	9952                	add	s2,s2,s4
    45a4:	fe9914e3          	bne	s2,s1,458c <lazy_unmap+0x40>
  exit(0);
    45a8:	4501                	li	a0,0
    45aa:	155000ef          	jal	4efe <exit>
    45ae:	f426                	sd	s1,40(sp)
    45b0:	f04a                	sd	s2,32(sp)
    45b2:	ec4e                	sd	s3,24(sp)
    45b4:	e852                	sd	s4,16(sp)
    printf("sbrklazy() failed\n");
    45b6:	00003517          	auipc	a0,0x3
    45ba:	e1a50513          	addi	a0,a0,-486 # 73d0 <malloc+0x1f96>
    45be:	5c5000ef          	jal	5382 <printf>
    exit(1);
    45c2:	4505                	li	a0,1
    45c4:	13b000ef          	jal	4efe <exit>
      printf("error forking\n");
    45c8:	00003517          	auipc	a0,0x3
    45cc:	e4850513          	addi	a0,a0,-440 # 7410 <malloc+0x1fd6>
    45d0:	5b3000ef          	jal	5382 <printf>
      exit(1);
    45d4:	4505                	li	a0,1
    45d6:	129000ef          	jal	4efe <exit>
      sbrklazy(-1L * REGION_SZ);
    45da:	c0000537          	lui	a0,0xc0000
    45de:	103000ef          	jal	4ee0 <sbrklazy>
      *(char **)i = i;
    45e2:	01293023          	sd	s2,0(s2) # 1000 <bigdir+0x108>
      exit(0);
    45e6:	4501                	li	a0,0
    45e8:	117000ef          	jal	4efe <exit>
        printf("memory not unmapped\n");
    45ec:	00003517          	auipc	a0,0x3
    45f0:	e3450513          	addi	a0,a0,-460 # 7420 <malloc+0x1fe6>
    45f4:	58f000ef          	jal	5382 <printf>
        exit(1);
    45f8:	4505                	li	a0,1
    45fa:	105000ef          	jal	4efe <exit>

00000000000045fe <lazy_copy>:
{
    45fe:	7119                	addi	sp,sp,-128
    4600:	fc86                	sd	ra,120(sp)
    4602:	f8a2                	sd	s0,112(sp)
    4604:	f4a6                	sd	s1,104(sp)
    4606:	f0ca                	sd	s2,96(sp)
    4608:	ecce                	sd	s3,88(sp)
    460a:	e8d2                	sd	s4,80(sp)
    460c:	e4d6                	sd	s5,72(sp)
    460e:	e0da                	sd	s6,64(sp)
    4610:	fc5e                	sd	s7,56(sp)
    4612:	0100                	addi	s0,sp,128
    char *p = sbrk(0);
    4614:	4501                	li	a0,0
    4616:	0b5000ef          	jal	4eca <sbrk>
    461a:	84aa                	mv	s1,a0
    sbrklazy(4*PGSIZE);
    461c:	6511                	lui	a0,0x4
    461e:	0c3000ef          	jal	4ee0 <sbrklazy>
    open(p + 8192, 0);
    4622:	4581                	li	a1,0
    4624:	6509                	lui	a0,0x2
    4626:	9526                	add	a0,a0,s1
    4628:	117000ef          	jal	4f3e <open>
    void *xx = sbrk(0);
    462c:	4501                	li	a0,0
    462e:	09d000ef          	jal	4eca <sbrk>
    4632:	84aa                	mv	s1,a0
    void *ret = sbrk(-(((uint64) xx)+1));
    4634:	fff54513          	not	a0,a0
    4638:	2501                	sext.w	a0,a0
    463a:	091000ef          	jal	4eca <sbrk>
    if(ret != xx){
    463e:	00a48c63          	beq	s1,a0,4656 <lazy_copy+0x58>
    4642:	85aa                	mv	a1,a0
      printf("sbrk(sbrk(0)+1) returned %p, not old sz\n", ret);
    4644:	00003517          	auipc	a0,0x3
    4648:	df450513          	addi	a0,a0,-524 # 7438 <malloc+0x1ffe>
    464c:	537000ef          	jal	5382 <printf>
      exit(1);
    4650:	4505                	li	a0,1
    4652:	0ad000ef          	jal	4efe <exit>
  unsigned long bad[] = {
    4656:	00003797          	auipc	a5,0x3
    465a:	36278793          	addi	a5,a5,866 # 79b8 <malloc+0x257e>
    465e:	7fa8                	ld	a0,120(a5)
    4660:	63cc                	ld	a1,128(a5)
    4662:	67d0                	ld	a2,136(a5)
    4664:	6bd4                	ld	a3,144(a5)
    4666:	6fd8                	ld	a4,152(a5)
    4668:	f8a43023          	sd	a0,-128(s0)
    466c:	f8b43423          	sd	a1,-120(s0)
    4670:	f8c43823          	sd	a2,-112(s0)
    4674:	f8d43c23          	sd	a3,-104(s0)
    4678:	fae43023          	sd	a4,-96(s0)
    467c:	73dc                	ld	a5,160(a5)
    467e:	faf43423          	sd	a5,-88(s0)
  for(int i = 0; i < sizeof(bad)/sizeof(bad[0]); i++){
    4682:	f8040913          	addi	s2,s0,-128
    int fd = open("README", 0);
    4686:	00001a97          	auipc	s5,0x1
    468a:	0baa8a93          	addi	s5,s5,186 # 5740 <malloc+0x306>
    if(read(fd, (char*)bad[i], 512) >= 0) { printf("read succeeded\n");  exit(1); }
    468e:	20000a13          	li	s4,512
    fd = open("junk", O_CREATE|O_RDWR|O_TRUNC);
    4692:	60200b93          	li	s7,1538
    4696:	00001b17          	auipc	s6,0x1
    469a:	fbab0b13          	addi	s6,s6,-70 # 5650 <malloc+0x216>
    int fd = open("README", 0);
    469e:	4581                	li	a1,0
    46a0:	8556                	mv	a0,s5
    46a2:	09d000ef          	jal	4f3e <open>
    46a6:	84aa                	mv	s1,a0
    if(fd < 0) { printf("cannot open README\n"); exit(1); }
    46a8:	04054563          	bltz	a0,46f2 <lazy_copy+0xf4>
    if(read(fd, (char*)bad[i], 512) >= 0) { printf("read succeeded\n");  exit(1); }
    46ac:	00093983          	ld	s3,0(s2)
    46b0:	8652                	mv	a2,s4
    46b2:	85ce                	mv	a1,s3
    46b4:	063000ef          	jal	4f16 <read>
    46b8:	04055663          	bgez	a0,4704 <lazy_copy+0x106>
    close(fd);
    46bc:	8526                	mv	a0,s1
    46be:	069000ef          	jal	4f26 <close>
    fd = open("junk", O_CREATE|O_RDWR|O_TRUNC);
    46c2:	85de                	mv	a1,s7
    46c4:	855a                	mv	a0,s6
    46c6:	079000ef          	jal	4f3e <open>
    46ca:	84aa                	mv	s1,a0
    if(fd < 0) { printf("cannot open junk\n"); exit(1); }
    46cc:	04054563          	bltz	a0,4716 <lazy_copy+0x118>
    if(write(fd, (char*)bad[i], 512) >= 0) { printf("write succeeded\n"); exit(1); }
    46d0:	8652                	mv	a2,s4
    46d2:	85ce                	mv	a1,s3
    46d4:	04b000ef          	jal	4f1e <write>
    46d8:	04055863          	bgez	a0,4728 <lazy_copy+0x12a>
    close(fd);
    46dc:	8526                	mv	a0,s1
    46de:	049000ef          	jal	4f26 <close>
  for(int i = 0; i < sizeof(bad)/sizeof(bad[0]); i++){
    46e2:	0921                	addi	s2,s2,8
    46e4:	fb040793          	addi	a5,s0,-80
    46e8:	faf91be3          	bne	s2,a5,469e <lazy_copy+0xa0>
  exit(0);
    46ec:	4501                	li	a0,0
    46ee:	011000ef          	jal	4efe <exit>
    if(fd < 0) { printf("cannot open README\n"); exit(1); }
    46f2:	00003517          	auipc	a0,0x3
    46f6:	d7650513          	addi	a0,a0,-650 # 7468 <malloc+0x202e>
    46fa:	489000ef          	jal	5382 <printf>
    46fe:	4505                	li	a0,1
    4700:	7fe000ef          	jal	4efe <exit>
    if(read(fd, (char*)bad[i], 512) >= 0) { printf("read succeeded\n");  exit(1); }
    4704:	00003517          	auipc	a0,0x3
    4708:	d7c50513          	addi	a0,a0,-644 # 7480 <malloc+0x2046>
    470c:	477000ef          	jal	5382 <printf>
    4710:	4505                	li	a0,1
    4712:	7ec000ef          	jal	4efe <exit>
    if(fd < 0) { printf("cannot open junk\n"); exit(1); }
    4716:	00003517          	auipc	a0,0x3
    471a:	d7a50513          	addi	a0,a0,-646 # 7490 <malloc+0x2056>
    471e:	465000ef          	jal	5382 <printf>
    4722:	4505                	li	a0,1
    4724:	7da000ef          	jal	4efe <exit>
    if(write(fd, (char*)bad[i], 512) >= 0) { printf("write succeeded\n"); exit(1); }
    4728:	00003517          	auipc	a0,0x3
    472c:	d8050513          	addi	a0,a0,-640 # 74a8 <malloc+0x206e>
    4730:	453000ef          	jal	5382 <printf>
    4734:	4505                	li	a0,1
    4736:	7c8000ef          	jal	4efe <exit>

000000000000473a <fsfull>:
{
    473a:	7171                	addi	sp,sp,-176
    473c:	f506                	sd	ra,168(sp)
    473e:	f122                	sd	s0,160(sp)
    4740:	ed26                	sd	s1,152(sp)
    4742:	e94a                	sd	s2,144(sp)
    4744:	e54e                	sd	s3,136(sp)
    4746:	e152                	sd	s4,128(sp)
    4748:	fcd6                	sd	s5,120(sp)
    474a:	f8da                	sd	s6,112(sp)
    474c:	f4de                	sd	s7,104(sp)
    474e:	f0e2                	sd	s8,96(sp)
    4750:	ece6                	sd	s9,88(sp)
    4752:	e8ea                	sd	s10,80(sp)
    4754:	e4ee                	sd	s11,72(sp)
    4756:	1900                	addi	s0,sp,176
  printf("fsfull test\n");
    4758:	00003517          	auipc	a0,0x3
    475c:	d6850513          	addi	a0,a0,-664 # 74c0 <malloc+0x2086>
    4760:	423000ef          	jal	5382 <printf>
  for(nfiles = 0; ; nfiles++){
    4764:	4481                	li	s1,0
    name[0] = 'f';
    4766:	06600d93          	li	s11,102
    name[1] = '0' + nfiles / 1000;
    476a:	10625cb7          	lui	s9,0x10625
    476e:	dd3c8c93          	addi	s9,s9,-557 # 10624dd3 <base+0x1061612b>
    name[2] = '0' + (nfiles % 1000) / 100;
    4772:	51eb8ab7          	lui	s5,0x51eb8
    4776:	51fa8a93          	addi	s5,s5,1311 # 51eb851f <base+0x51ea9877>
    name[3] = '0' + (nfiles % 100) / 10;
    477a:	66666a37          	lui	s4,0x66666
    477e:	667a0a13          	addi	s4,s4,1639 # 66666667 <base+0x666579bf>
    printf("writing %s\n", name);
    4782:	f5040d13          	addi	s10,s0,-176
    name[0] = 'f';
    4786:	f5b40823          	sb	s11,-176(s0)
    name[1] = '0' + nfiles / 1000;
    478a:	039487b3          	mul	a5,s1,s9
    478e:	9799                	srai	a5,a5,0x26
    4790:	41f4d69b          	sraiw	a3,s1,0x1f
    4794:	9f95                	subw	a5,a5,a3
    4796:	0307871b          	addiw	a4,a5,48
    479a:	f4e408a3          	sb	a4,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    479e:	3e800713          	li	a4,1000
    47a2:	02f707bb          	mulw	a5,a4,a5
    47a6:	40f487bb          	subw	a5,s1,a5
    47aa:	03578733          	mul	a4,a5,s5
    47ae:	9715                	srai	a4,a4,0x25
    47b0:	41f7d79b          	sraiw	a5,a5,0x1f
    47b4:	40f707bb          	subw	a5,a4,a5
    47b8:	0307879b          	addiw	a5,a5,48
    47bc:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    47c0:	035487b3          	mul	a5,s1,s5
    47c4:	9795                	srai	a5,a5,0x25
    47c6:	9f95                	subw	a5,a5,a3
    47c8:	06400713          	li	a4,100
    47cc:	02f707bb          	mulw	a5,a4,a5
    47d0:	40f487bb          	subw	a5,s1,a5
    47d4:	03478733          	mul	a4,a5,s4
    47d8:	9709                	srai	a4,a4,0x22
    47da:	41f7d79b          	sraiw	a5,a5,0x1f
    47de:	40f707bb          	subw	a5,a4,a5
    47e2:	0307879b          	addiw	a5,a5,48
    47e6:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    47ea:	03448733          	mul	a4,s1,s4
    47ee:	9709                	srai	a4,a4,0x22
    47f0:	9f15                	subw	a4,a4,a3
    47f2:	0027179b          	slliw	a5,a4,0x2
    47f6:	9fb9                	addw	a5,a5,a4
    47f8:	0017979b          	slliw	a5,a5,0x1
    47fc:	40f487bb          	subw	a5,s1,a5
    4800:	0307879b          	addiw	a5,a5,48
    4804:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    4808:	f4040aa3          	sb	zero,-171(s0)
    printf("writing %s\n", name);
    480c:	85ea                	mv	a1,s10
    480e:	00003517          	auipc	a0,0x3
    4812:	cc250513          	addi	a0,a0,-830 # 74d0 <malloc+0x2096>
    4816:	36d000ef          	jal	5382 <printf>
    int fd = open(name, O_CREATE|O_RDWR);
    481a:	20200593          	li	a1,514
    481e:	856a                	mv	a0,s10
    4820:	71e000ef          	jal	4f3e <open>
    4824:	892a                	mv	s2,a0
    if(fd < 0){
    4826:	0e055b63          	bgez	a0,491c <fsfull+0x1e2>
      printf("open %s failed\n", name);
    482a:	f5040593          	addi	a1,s0,-176
    482e:	00003517          	auipc	a0,0x3
    4832:	cb250513          	addi	a0,a0,-846 # 74e0 <malloc+0x20a6>
    4836:	34d000ef          	jal	5382 <printf>
  while(nfiles >= 0){
    483a:	0a04cc63          	bltz	s1,48f2 <fsfull+0x1b8>
    name[0] = 'f';
    483e:	06600c13          	li	s8,102
    name[1] = '0' + nfiles / 1000;
    4842:	10625a37          	lui	s4,0x10625
    4846:	dd3a0a13          	addi	s4,s4,-557 # 10624dd3 <base+0x1061612b>
    name[2] = '0' + (nfiles % 1000) / 100;
    484a:	3e800b93          	li	s7,1000
    484e:	51eb89b7          	lui	s3,0x51eb8
    4852:	51f98993          	addi	s3,s3,1311 # 51eb851f <base+0x51ea9877>
    name[3] = '0' + (nfiles % 100) / 10;
    4856:	06400b13          	li	s6,100
    485a:	66666937          	lui	s2,0x66666
    485e:	66790913          	addi	s2,s2,1639 # 66666667 <base+0x666579bf>
    unlink(name);
    4862:	f5040a93          	addi	s5,s0,-176
    name[0] = 'f';
    4866:	f5840823          	sb	s8,-176(s0)
    name[1] = '0' + nfiles / 1000;
    486a:	034487b3          	mul	a5,s1,s4
    486e:	9799                	srai	a5,a5,0x26
    4870:	41f4d69b          	sraiw	a3,s1,0x1f
    4874:	9f95                	subw	a5,a5,a3
    4876:	0307871b          	addiw	a4,a5,48
    487a:	f4e408a3          	sb	a4,-175(s0)
    name[2] = '0' + (nfiles % 1000) / 100;
    487e:	02fb87bb          	mulw	a5,s7,a5
    4882:	40f487bb          	subw	a5,s1,a5
    4886:	03378733          	mul	a4,a5,s3
    488a:	9715                	srai	a4,a4,0x25
    488c:	41f7d79b          	sraiw	a5,a5,0x1f
    4890:	40f707bb          	subw	a5,a4,a5
    4894:	0307879b          	addiw	a5,a5,48
    4898:	f4f40923          	sb	a5,-174(s0)
    name[3] = '0' + (nfiles % 100) / 10;
    489c:	033487b3          	mul	a5,s1,s3
    48a0:	9795                	srai	a5,a5,0x25
    48a2:	9f95                	subw	a5,a5,a3
    48a4:	02fb07bb          	mulw	a5,s6,a5
    48a8:	40f487bb          	subw	a5,s1,a5
    48ac:	03278733          	mul	a4,a5,s2
    48b0:	9709                	srai	a4,a4,0x22
    48b2:	41f7d79b          	sraiw	a5,a5,0x1f
    48b6:	40f707bb          	subw	a5,a4,a5
    48ba:	0307879b          	addiw	a5,a5,48
    48be:	f4f409a3          	sb	a5,-173(s0)
    name[4] = '0' + (nfiles % 10);
    48c2:	03248733          	mul	a4,s1,s2
    48c6:	9709                	srai	a4,a4,0x22
    48c8:	9f15                	subw	a4,a4,a3
    48ca:	0027179b          	slliw	a5,a4,0x2
    48ce:	9fb9                	addw	a5,a5,a4
    48d0:	0017979b          	slliw	a5,a5,0x1
    48d4:	40f487bb          	subw	a5,s1,a5
    48d8:	0307879b          	addiw	a5,a5,48
    48dc:	f4f40a23          	sb	a5,-172(s0)
    name[5] = '\0';
    48e0:	f4040aa3          	sb	zero,-171(s0)
    unlink(name);
    48e4:	8556                	mv	a0,s5
    48e6:	668000ef          	jal	4f4e <unlink>
    nfiles--;
    48ea:	34fd                	addiw	s1,s1,-1
  while(nfiles >= 0){
    48ec:	57fd                	li	a5,-1
    48ee:	f6f49ce3          	bne	s1,a5,4866 <fsfull+0x12c>
  printf("fsfull test finished\n");
    48f2:	00003517          	auipc	a0,0x3
    48f6:	c0e50513          	addi	a0,a0,-1010 # 7500 <malloc+0x20c6>
    48fa:	289000ef          	jal	5382 <printf>
}
    48fe:	70aa                	ld	ra,168(sp)
    4900:	740a                	ld	s0,160(sp)
    4902:	64ea                	ld	s1,152(sp)
    4904:	694a                	ld	s2,144(sp)
    4906:	69aa                	ld	s3,136(sp)
    4908:	6a0a                	ld	s4,128(sp)
    490a:	7ae6                	ld	s5,120(sp)
    490c:	7b46                	ld	s6,112(sp)
    490e:	7ba6                	ld	s7,104(sp)
    4910:	7c06                	ld	s8,96(sp)
    4912:	6ce6                	ld	s9,88(sp)
    4914:	6d46                	ld	s10,80(sp)
    4916:	6da6                	ld	s11,72(sp)
    4918:	614d                	addi	sp,sp,176
    491a:	8082                	ret
    int total = 0;
    491c:	4981                	li	s3,0
      int cc = write(fd, buf, BSIZE);
    491e:	40000c13          	li	s8,1024
    4922:	00007b97          	auipc	s7,0x7
    4926:	386b8b93          	addi	s7,s7,902 # bca8 <buf>
      if(cc < BSIZE)
    492a:	3ff00b13          	li	s6,1023
      int cc = write(fd, buf, BSIZE);
    492e:	8662                	mv	a2,s8
    4930:	85de                	mv	a1,s7
    4932:	854a                	mv	a0,s2
    4934:	5ea000ef          	jal	4f1e <write>
      if(cc < BSIZE)
    4938:	00ab5563          	bge	s6,a0,4942 <fsfull+0x208>
      total += cc;
    493c:	00a989bb          	addw	s3,s3,a0
    while(1){
    4940:	b7fd                	j	492e <fsfull+0x1f4>
    printf("wrote %d bytes\n", total);
    4942:	85ce                	mv	a1,s3
    4944:	00003517          	auipc	a0,0x3
    4948:	bac50513          	addi	a0,a0,-1108 # 74f0 <malloc+0x20b6>
    494c:	237000ef          	jal	5382 <printf>
    close(fd);
    4950:	854a                	mv	a0,s2
    4952:	5d4000ef          	jal	4f26 <close>
    if(total == 0)
    4956:	ee0982e3          	beqz	s3,483a <fsfull+0x100>
  for(nfiles = 0; ; nfiles++){
    495a:	2485                	addiw	s1,s1,1
    495c:	b52d                	j	4786 <fsfull+0x4c>

000000000000495e <run>:
//

// run each test in its own process. run returns 1 if child's exit()
// indicates success.
int
run(void f(char *), char *s) {
    495e:	7179                	addi	sp,sp,-48
    4960:	f406                	sd	ra,40(sp)
    4962:	f022                	sd	s0,32(sp)
    4964:	ec26                	sd	s1,24(sp)
    4966:	e84a                	sd	s2,16(sp)
    4968:	1800                	addi	s0,sp,48
    496a:	84aa                	mv	s1,a0
    496c:	892e                	mv	s2,a1
  int pid;
  int xstatus;

  printf("test %s: ", s);
    496e:	00003517          	auipc	a0,0x3
    4972:	baa50513          	addi	a0,a0,-1110 # 7518 <malloc+0x20de>
    4976:	20d000ef          	jal	5382 <printf>
  if((pid = fork()) < 0) {
    497a:	57c000ef          	jal	4ef6 <fork>
    497e:	02054a63          	bltz	a0,49b2 <run+0x54>
    printf("runtest: fork error\n");
    exit(1);
  }
  if(pid == 0) {
    4982:	c129                	beqz	a0,49c4 <run+0x66>
    f(s);
    exit(0);
  } else {
    wait(&xstatus);
    4984:	fdc40513          	addi	a0,s0,-36
    4988:	57e000ef          	jal	4f06 <wait>
    if(xstatus != 0) 
    498c:	fdc42783          	lw	a5,-36(s0)
    4990:	cf9d                	beqz	a5,49ce <run+0x70>
      printf("FAILED\n");
    4992:	00003517          	auipc	a0,0x3
    4996:	bae50513          	addi	a0,a0,-1106 # 7540 <malloc+0x2106>
    499a:	1e9000ef          	jal	5382 <printf>
    else
      printf("OK\n");
    return xstatus == 0;
    499e:	fdc42503          	lw	a0,-36(s0)
  }
}
    49a2:	00153513          	seqz	a0,a0
    49a6:	70a2                	ld	ra,40(sp)
    49a8:	7402                	ld	s0,32(sp)
    49aa:	64e2                	ld	s1,24(sp)
    49ac:	6942                	ld	s2,16(sp)
    49ae:	6145                	addi	sp,sp,48
    49b0:	8082                	ret
    printf("runtest: fork error\n");
    49b2:	00003517          	auipc	a0,0x3
    49b6:	b7650513          	addi	a0,a0,-1162 # 7528 <malloc+0x20ee>
    49ba:	1c9000ef          	jal	5382 <printf>
    exit(1);
    49be:	4505                	li	a0,1
    49c0:	53e000ef          	jal	4efe <exit>
    f(s);
    49c4:	854a                	mv	a0,s2
    49c6:	9482                	jalr	s1
    exit(0);
    49c8:	4501                	li	a0,0
    49ca:	534000ef          	jal	4efe <exit>
      printf("OK\n");
    49ce:	00003517          	auipc	a0,0x3
    49d2:	b7a50513          	addi	a0,a0,-1158 # 7548 <malloc+0x210e>
    49d6:	1ad000ef          	jal	5382 <printf>
    49da:	b7d1                	j	499e <run+0x40>

00000000000049dc <runtests>:

int
runtests(struct test *tests, char *justone, int continuous) {
    49dc:	7179                	addi	sp,sp,-48
    49de:	f406                	sd	ra,40(sp)
    49e0:	f022                	sd	s0,32(sp)
    49e2:	ec26                	sd	s1,24(sp)
    49e4:	e44e                	sd	s3,8(sp)
    49e6:	1800                	addi	s0,sp,48
    49e8:	84aa                	mv	s1,a0
  int ntests = 0;
  for (struct test *t = tests; t->s != 0; t++) {
    49ea:	6508                	ld	a0,8(a0)
    49ec:	cd29                	beqz	a0,4a46 <runtests+0x6a>
    49ee:	e84a                	sd	s2,16(sp)
    49f0:	e052                	sd	s4,0(sp)
    49f2:	892e                	mv	s2,a1
    if((justone == 0) || strcmp(t->s, justone) == 0) {
      ntests++;
      if(!run(t->f, t->s)){
        if(continuous != 2){
    49f4:	1679                	addi	a2,a2,-2 # ffe <bigdir+0x106>
    49f6:	00c03a33          	snez	s4,a2
  int ntests = 0;
    49fa:	4981                	li	s3,0
    49fc:	a029                	j	4a06 <runtests+0x2a>
      ntests++;
    49fe:	2985                	addiw	s3,s3,1
  for (struct test *t = tests; t->s != 0; t++) {
    4a00:	04c1                	addi	s1,s1,16
    4a02:	6488                	ld	a0,8(s1)
    4a04:	c905                	beqz	a0,4a34 <runtests+0x58>
    if((justone == 0) || strcmp(t->s, justone) == 0) {
    4a06:	00090663          	beqz	s2,4a12 <runtests+0x36>
    4a0a:	85ca                	mv	a1,s2
    4a0c:	26c000ef          	jal	4c78 <strcmp>
    4a10:	f965                	bnez	a0,4a00 <runtests+0x24>
      if(!run(t->f, t->s)){
    4a12:	648c                	ld	a1,8(s1)
    4a14:	6088                	ld	a0,0(s1)
    4a16:	f49ff0ef          	jal	495e <run>
        if(continuous != 2){
    4a1a:	f175                	bnez	a0,49fe <runtests+0x22>
    4a1c:	fe0a01e3          	beqz	s4,49fe <runtests+0x22>
          printf("SOME TESTS FAILED\n");
    4a20:	00003517          	auipc	a0,0x3
    4a24:	b3050513          	addi	a0,a0,-1232 # 7550 <malloc+0x2116>
    4a28:	15b000ef          	jal	5382 <printf>
          return -1;
    4a2c:	59fd                	li	s3,-1
    4a2e:	6942                	ld	s2,16(sp)
    4a30:	6a02                	ld	s4,0(sp)
    4a32:	a019                	j	4a38 <runtests+0x5c>
    4a34:	6942                	ld	s2,16(sp)
    4a36:	6a02                	ld	s4,0(sp)
        }
      }
    }
  }
  return ntests;
}
    4a38:	854e                	mv	a0,s3
    4a3a:	70a2                	ld	ra,40(sp)
    4a3c:	7402                	ld	s0,32(sp)
    4a3e:	64e2                	ld	s1,24(sp)
    4a40:	69a2                	ld	s3,8(sp)
    4a42:	6145                	addi	sp,sp,48
    4a44:	8082                	ret
  return ntests;
    4a46:	4981                	li	s3,0
    4a48:	bfc5                	j	4a38 <runtests+0x5c>

0000000000004a4a <countfree>:


// use sbrk() to count how many free physical memory pages there are.
int
countfree()
{
    4a4a:	7179                	addi	sp,sp,-48
    4a4c:	f406                	sd	ra,40(sp)
    4a4e:	f022                	sd	s0,32(sp)
    4a50:	ec26                	sd	s1,24(sp)
    4a52:	e84a                	sd	s2,16(sp)
    4a54:	e44e                	sd	s3,8(sp)
    4a56:	e052                	sd	s4,0(sp)
    4a58:	1800                	addi	s0,sp,48
  int n = 0;
  uint64 sz0 = (uint64)sbrk(0);
    4a5a:	4501                	li	a0,0
    4a5c:	46e000ef          	jal	4eca <sbrk>
    4a60:	8a2a                	mv	s4,a0
  int n = 0;
    4a62:	4481                	li	s1,0
  while(1){
    char *a = sbrk(PGSIZE);
    4a64:	6985                	lui	s3,0x1
    if(a == SBRK_ERROR){
    4a66:	597d                	li	s2,-1
    char *a = sbrk(PGSIZE);
    4a68:	854e                	mv	a0,s3
    4a6a:	460000ef          	jal	4eca <sbrk>
    if(a == SBRK_ERROR){
    4a6e:	01250463          	beq	a0,s2,4a76 <countfree+0x2c>
      break;
    }
    n += 1;
    4a72:	2485                	addiw	s1,s1,1
  while(1){
    4a74:	bfd5                	j	4a68 <countfree+0x1e>
  }
  sbrk(-((uint64)sbrk(0) - sz0));  
    4a76:	4501                	li	a0,0
    4a78:	452000ef          	jal	4eca <sbrk>
    4a7c:	40aa053b          	subw	a0,s4,a0
    4a80:	44a000ef          	jal	4eca <sbrk>
  return n;
}
    4a84:	8526                	mv	a0,s1
    4a86:	70a2                	ld	ra,40(sp)
    4a88:	7402                	ld	s0,32(sp)
    4a8a:	64e2                	ld	s1,24(sp)
    4a8c:	6942                	ld	s2,16(sp)
    4a8e:	69a2                	ld	s3,8(sp)
    4a90:	6a02                	ld	s4,0(sp)
    4a92:	6145                	addi	sp,sp,48
    4a94:	8082                	ret

0000000000004a96 <drivetests>:

int
drivetests(int quick, int continuous, char *justone) {
    4a96:	7159                	addi	sp,sp,-112
    4a98:	f486                	sd	ra,104(sp)
    4a9a:	f0a2                	sd	s0,96(sp)
    4a9c:	eca6                	sd	s1,88(sp)
    4a9e:	e8ca                	sd	s2,80(sp)
    4aa0:	e4ce                	sd	s3,72(sp)
    4aa2:	e0d2                	sd	s4,64(sp)
    4aa4:	fc56                	sd	s5,56(sp)
    4aa6:	f85a                	sd	s6,48(sp)
    4aa8:	f45e                	sd	s7,40(sp)
    4aaa:	f062                	sd	s8,32(sp)
    4aac:	ec66                	sd	s9,24(sp)
    4aae:	e86a                	sd	s10,16(sp)
    4ab0:	e46e                	sd	s11,8(sp)
    4ab2:	1880                	addi	s0,sp,112
    4ab4:	8aaa                	mv	s5,a0
    4ab6:	89ae                	mv	s3,a1
    4ab8:	8a32                	mv	s4,a2
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
      if(continuous != 2) {
        return 1;
      }
    }
    if (justone != 0 && ntests == 0) {
    4aba:	00c03d33          	snez	s10,a2
    printf("usertests starting\n");
    4abe:	00003c17          	auipc	s8,0x3
    4ac2:	aaac0c13          	addi	s8,s8,-1366 # 7568 <malloc+0x212e>
    n = runtests(quicktests, justone, continuous);
    4ac6:	00003b97          	auipc	s7,0x3
    4aca:	54ab8b93          	addi	s7,s7,1354 # 8010 <quicktests>
      if(continuous != 2) {
    4ace:	4b09                	li	s6,2
      n = runtests(slowtests, justone, continuous);
    4ad0:	00004c97          	auipc	s9,0x4
    4ad4:	940c8c93          	addi	s9,s9,-1728 # 8410 <slowtests>
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    4ad8:	00003d97          	auipc	s11,0x3
    4adc:	ac8d8d93          	addi	s11,s11,-1336 # 75a0 <malloc+0x2166>
    4ae0:	a82d                	j	4b1a <drivetests+0x84>
      if(continuous != 2) {
    4ae2:	0b699363          	bne	s3,s6,4b88 <drivetests+0xf2>
    int ntests = 0;
    4ae6:	4481                	li	s1,0
    4ae8:	a0b9                	j	4b36 <drivetests+0xa0>
        printf("usertests slow tests starting\n");
    4aea:	00003517          	auipc	a0,0x3
    4aee:	a9650513          	addi	a0,a0,-1386 # 7580 <malloc+0x2146>
    4af2:	091000ef          	jal	5382 <printf>
    4af6:	a0a1                	j	4b3e <drivetests+0xa8>
        if(continuous != 2) {
    4af8:	05698b63          	beq	s3,s6,4b4e <drivetests+0xb8>
          return 1;
    4afc:	4505                	li	a0,1
    4afe:	a0b5                	j	4b6a <drivetests+0xd4>
      printf("FAILED -- lost some free pages %d (out of %d)\n", free1, free0);
    4b00:	864a                	mv	a2,s2
    4b02:	85aa                	mv	a1,a0
    4b04:	856e                	mv	a0,s11
    4b06:	07d000ef          	jal	5382 <printf>
      if(continuous != 2) {
    4b0a:	09699163          	bne	s3,s6,4b8c <drivetests+0xf6>
    if (justone != 0 && ntests == 0) {
    4b0e:	e491                	bnez	s1,4b1a <drivetests+0x84>
    4b10:	000d0563          	beqz	s10,4b1a <drivetests+0x84>
    4b14:	a0a1                	j	4b5c <drivetests+0xc6>
      printf("NO TESTS EXECUTED\n");
      return 1;
    }
  } while(continuous);
    4b16:	06098d63          	beqz	s3,4b90 <drivetests+0xfa>
    printf("usertests starting\n");
    4b1a:	8562                	mv	a0,s8
    4b1c:	067000ef          	jal	5382 <printf>
    int free0 = countfree();
    4b20:	f2bff0ef          	jal	4a4a <countfree>
    4b24:	892a                	mv	s2,a0
    n = runtests(quicktests, justone, continuous);
    4b26:	864e                	mv	a2,s3
    4b28:	85d2                	mv	a1,s4
    4b2a:	855e                	mv	a0,s7
    4b2c:	eb1ff0ef          	jal	49dc <runtests>
    4b30:	84aa                	mv	s1,a0
    if (n < 0) {
    4b32:	fa0548e3          	bltz	a0,4ae2 <drivetests+0x4c>
    if(!quick) {
    4b36:	000a9c63          	bnez	s5,4b4e <drivetests+0xb8>
      if (justone == 0)
    4b3a:	fa0a08e3          	beqz	s4,4aea <drivetests+0x54>
      n = runtests(slowtests, justone, continuous);
    4b3e:	864e                	mv	a2,s3
    4b40:	85d2                	mv	a1,s4
    4b42:	8566                	mv	a0,s9
    4b44:	e99ff0ef          	jal	49dc <runtests>
      if (n < 0) {
    4b48:	fa0548e3          	bltz	a0,4af8 <drivetests+0x62>
        ntests += n;
    4b4c:	9ca9                	addw	s1,s1,a0
    if((free1 = countfree()) < free0) {
    4b4e:	efdff0ef          	jal	4a4a <countfree>
    4b52:	fb2547e3          	blt	a0,s2,4b00 <drivetests+0x6a>
    if (justone != 0 && ntests == 0) {
    4b56:	f0e1                	bnez	s1,4b16 <drivetests+0x80>
    4b58:	fa0d0fe3          	beqz	s10,4b16 <drivetests+0x80>
      printf("NO TESTS EXECUTED\n");
    4b5c:	00003517          	auipc	a0,0x3
    4b60:	a7450513          	addi	a0,a0,-1420 # 75d0 <malloc+0x2196>
    4b64:	01f000ef          	jal	5382 <printf>
      return 1;
    4b68:	4505                	li	a0,1
  return 0;
}
    4b6a:	70a6                	ld	ra,104(sp)
    4b6c:	7406                	ld	s0,96(sp)
    4b6e:	64e6                	ld	s1,88(sp)
    4b70:	6946                	ld	s2,80(sp)
    4b72:	69a6                	ld	s3,72(sp)
    4b74:	6a06                	ld	s4,64(sp)
    4b76:	7ae2                	ld	s5,56(sp)
    4b78:	7b42                	ld	s6,48(sp)
    4b7a:	7ba2                	ld	s7,40(sp)
    4b7c:	7c02                	ld	s8,32(sp)
    4b7e:	6ce2                	ld	s9,24(sp)
    4b80:	6d42                	ld	s10,16(sp)
    4b82:	6da2                	ld	s11,8(sp)
    4b84:	6165                	addi	sp,sp,112
    4b86:	8082                	ret
        return 1;
    4b88:	4505                	li	a0,1
    4b8a:	b7c5                	j	4b6a <drivetests+0xd4>
        return 1;
    4b8c:	4505                	li	a0,1
    4b8e:	bff1                	j	4b6a <drivetests+0xd4>
  return 0;
    4b90:	854e                	mv	a0,s3
    4b92:	bfe1                	j	4b6a <drivetests+0xd4>

0000000000004b94 <main>:

int
main(int argc, char *argv[])
{
    4b94:	1101                	addi	sp,sp,-32
    4b96:	ec06                	sd	ra,24(sp)
    4b98:	e822                	sd	s0,16(sp)
    4b9a:	e426                	sd	s1,8(sp)
    4b9c:	e04a                	sd	s2,0(sp)
    4b9e:	1000                	addi	s0,sp,32
    4ba0:	84aa                	mv	s1,a0
  int continuous = 0;
  int quick = 0;
  char *justone = 0;

  if(argc == 2 && strcmp(argv[1], "-q") == 0){
    4ba2:	4789                	li	a5,2
    4ba4:	00f50e63          	beq	a0,a5,4bc0 <main+0x2c>
    continuous = 1;
  } else if(argc == 2 && strcmp(argv[1], "-C") == 0){
    continuous = 2;
  } else if(argc == 2 && argv[1][0] != '-'){
    justone = argv[1];
  } else if(argc > 1){
    4ba8:	4785                	li	a5,1
    4baa:	06a7c663          	blt	a5,a0,4c16 <main+0x82>
  char *justone = 0;
    4bae:	4601                	li	a2,0
  int quick = 0;
    4bb0:	4501                	li	a0,0
  int continuous = 0;
    4bb2:	4581                	li	a1,0
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    exit(1);
  }
  if (drivetests(quick, continuous, justone)) {
    4bb4:	ee3ff0ef          	jal	4a96 <drivetests>
    4bb8:	cd35                	beqz	a0,4c34 <main+0xa0>
    exit(1);
    4bba:	4505                	li	a0,1
    4bbc:	342000ef          	jal	4efe <exit>
    4bc0:	892e                	mv	s2,a1
  if(argc == 2 && strcmp(argv[1], "-q") == 0){
    4bc2:	00003597          	auipc	a1,0x3
    4bc6:	a2658593          	addi	a1,a1,-1498 # 75e8 <malloc+0x21ae>
    4bca:	00893503          	ld	a0,8(s2)
    4bce:	0aa000ef          	jal	4c78 <strcmp>
    4bd2:	85aa                	mv	a1,a0
    4bd4:	e501                	bnez	a0,4bdc <main+0x48>
  char *justone = 0;
    4bd6:	4601                	li	a2,0
    quick = 1;
    4bd8:	4505                	li	a0,1
    4bda:	bfe9                	j	4bb4 <main+0x20>
  } else if(argc == 2 && strcmp(argv[1], "-c") == 0){
    4bdc:	00003597          	auipc	a1,0x3
    4be0:	a1458593          	addi	a1,a1,-1516 # 75f0 <malloc+0x21b6>
    4be4:	00893503          	ld	a0,8(s2)
    4be8:	090000ef          	jal	4c78 <strcmp>
    4bec:	cd15                	beqz	a0,4c28 <main+0x94>
  } else if(argc == 2 && strcmp(argv[1], "-C") == 0){
    4bee:	00003597          	auipc	a1,0x3
    4bf2:	a5258593          	addi	a1,a1,-1454 # 7640 <malloc+0x2206>
    4bf6:	00893503          	ld	a0,8(s2)
    4bfa:	07e000ef          	jal	4c78 <strcmp>
    4bfe:	c905                	beqz	a0,4c2e <main+0x9a>
  } else if(argc == 2 && argv[1][0] != '-'){
    4c00:	00893603          	ld	a2,8(s2)
    4c04:	00064703          	lbu	a4,0(a2)
    4c08:	02d00793          	li	a5,45
    4c0c:	00f70563          	beq	a4,a5,4c16 <main+0x82>
  int quick = 0;
    4c10:	4501                	li	a0,0
  int continuous = 0;
    4c12:	4581                	li	a1,0
    4c14:	b745                	j	4bb4 <main+0x20>
    printf("Usage: usertests [-c] [-C] [-q] [testname]\n");
    4c16:	00003517          	auipc	a0,0x3
    4c1a:	9e250513          	addi	a0,a0,-1566 # 75f8 <malloc+0x21be>
    4c1e:	764000ef          	jal	5382 <printf>
    exit(1);
    4c22:	4505                	li	a0,1
    4c24:	2da000ef          	jal	4efe <exit>
  char *justone = 0;
    4c28:	4601                	li	a2,0
    continuous = 1;
    4c2a:	4585                	li	a1,1
    4c2c:	b761                	j	4bb4 <main+0x20>
    continuous = 2;
    4c2e:	85a6                	mv	a1,s1
  char *justone = 0;
    4c30:	4601                	li	a2,0
    4c32:	b749                	j	4bb4 <main+0x20>
  }
  printf("ALL TESTS PASSED\n");
    4c34:	00003517          	auipc	a0,0x3
    4c38:	9f450513          	addi	a0,a0,-1548 # 7628 <malloc+0x21ee>
    4c3c:	746000ef          	jal	5382 <printf>
  exit(0);
    4c40:	4501                	li	a0,0
    4c42:	2bc000ef          	jal	4efe <exit>

0000000000004c46 <start>:
//
// wrapper so that it's OK if main() does not call exit().
//
void
start()
{
    4c46:	1141                	addi	sp,sp,-16
    4c48:	e406                	sd	ra,8(sp)
    4c4a:	e022                	sd	s0,0(sp)
    4c4c:	0800                	addi	s0,sp,16
  extern int main();
  main();
    4c4e:	f47ff0ef          	jal	4b94 <main>
  exit(0);
    4c52:	4501                	li	a0,0
    4c54:	2aa000ef          	jal	4efe <exit>

0000000000004c58 <strcpy>:
}

char*
strcpy(char *s, const char *t)
{
    4c58:	1141                	addi	sp,sp,-16
    4c5a:	e406                	sd	ra,8(sp)
    4c5c:	e022                	sd	s0,0(sp)
    4c5e:	0800                	addi	s0,sp,16
  char *os;

  os = s;
  while((*s++ = *t++) != 0)
    4c60:	87aa                	mv	a5,a0
    4c62:	0585                	addi	a1,a1,1
    4c64:	0785                	addi	a5,a5,1
    4c66:	fff5c703          	lbu	a4,-1(a1)
    4c6a:	fee78fa3          	sb	a4,-1(a5)
    4c6e:	fb75                	bnez	a4,4c62 <strcpy+0xa>
    ;
  return os;
}
    4c70:	60a2                	ld	ra,8(sp)
    4c72:	6402                	ld	s0,0(sp)
    4c74:	0141                	addi	sp,sp,16
    4c76:	8082                	ret

0000000000004c78 <strcmp>:

int
strcmp(const char *p, const char *q)
{
    4c78:	1141                	addi	sp,sp,-16
    4c7a:	e406                	sd	ra,8(sp)
    4c7c:	e022                	sd	s0,0(sp)
    4c7e:	0800                	addi	s0,sp,16
  while(*p && *p == *q)
    4c80:	00054783          	lbu	a5,0(a0)
    4c84:	cb91                	beqz	a5,4c98 <strcmp+0x20>
    4c86:	0005c703          	lbu	a4,0(a1)
    4c8a:	00f71763          	bne	a4,a5,4c98 <strcmp+0x20>
    p++, q++;
    4c8e:	0505                	addi	a0,a0,1
    4c90:	0585                	addi	a1,a1,1
  while(*p && *p == *q)
    4c92:	00054783          	lbu	a5,0(a0)
    4c96:	fbe5                	bnez	a5,4c86 <strcmp+0xe>
  return (uchar)*p - (uchar)*q;
    4c98:	0005c503          	lbu	a0,0(a1)
}
    4c9c:	40a7853b          	subw	a0,a5,a0
    4ca0:	60a2                	ld	ra,8(sp)
    4ca2:	6402                	ld	s0,0(sp)
    4ca4:	0141                	addi	sp,sp,16
    4ca6:	8082                	ret

0000000000004ca8 <strlen>:

uint
strlen(const char *s)
{
    4ca8:	1141                	addi	sp,sp,-16
    4caa:	e406                	sd	ra,8(sp)
    4cac:	e022                	sd	s0,0(sp)
    4cae:	0800                	addi	s0,sp,16
  int n;

  for(n = 0; s[n]; n++)
    4cb0:	00054783          	lbu	a5,0(a0)
    4cb4:	cf91                	beqz	a5,4cd0 <strlen+0x28>
    4cb6:	00150793          	addi	a5,a0,1
    4cba:	86be                	mv	a3,a5
    4cbc:	0785                	addi	a5,a5,1
    4cbe:	fff7c703          	lbu	a4,-1(a5)
    4cc2:	ff65                	bnez	a4,4cba <strlen+0x12>
    4cc4:	40a6853b          	subw	a0,a3,a0
    ;
  return n;
}
    4cc8:	60a2                	ld	ra,8(sp)
    4cca:	6402                	ld	s0,0(sp)
    4ccc:	0141                	addi	sp,sp,16
    4cce:	8082                	ret
  for(n = 0; s[n]; n++)
    4cd0:	4501                	li	a0,0
    4cd2:	bfdd                	j	4cc8 <strlen+0x20>

0000000000004cd4 <memset>:

void*
memset(void *dst, int c, uint n)
{
    4cd4:	1141                	addi	sp,sp,-16
    4cd6:	e406                	sd	ra,8(sp)
    4cd8:	e022                	sd	s0,0(sp)
    4cda:	0800                	addi	s0,sp,16
  char *cdst = (char *) dst;
  int i;
  for(i = 0; i < n; i++){
    4cdc:	ca19                	beqz	a2,4cf2 <memset+0x1e>
    4cde:	87aa                	mv	a5,a0
    4ce0:	1602                	slli	a2,a2,0x20
    4ce2:	9201                	srli	a2,a2,0x20
    4ce4:	00a60733          	add	a4,a2,a0
    cdst[i] = c;
    4ce8:	00b78023          	sb	a1,0(a5)
  for(i = 0; i < n; i++){
    4cec:	0785                	addi	a5,a5,1
    4cee:	fee79de3          	bne	a5,a4,4ce8 <memset+0x14>
  }
  return dst;
}
    4cf2:	60a2                	ld	ra,8(sp)
    4cf4:	6402                	ld	s0,0(sp)
    4cf6:	0141                	addi	sp,sp,16
    4cf8:	8082                	ret

0000000000004cfa <strchr>:

char*
strchr(const char *s, char c)
{
    4cfa:	1141                	addi	sp,sp,-16
    4cfc:	e406                	sd	ra,8(sp)
    4cfe:	e022                	sd	s0,0(sp)
    4d00:	0800                	addi	s0,sp,16
  for(; *s; s++)
    4d02:	00054783          	lbu	a5,0(a0)
    4d06:	cf81                	beqz	a5,4d1e <strchr+0x24>
    if(*s == c)
    4d08:	00f58763          	beq	a1,a5,4d16 <strchr+0x1c>
  for(; *s; s++)
    4d0c:	0505                	addi	a0,a0,1
    4d0e:	00054783          	lbu	a5,0(a0)
    4d12:	fbfd                	bnez	a5,4d08 <strchr+0xe>
      return (char*)s;
  return 0;
    4d14:	4501                	li	a0,0
}
    4d16:	60a2                	ld	ra,8(sp)
    4d18:	6402                	ld	s0,0(sp)
    4d1a:	0141                	addi	sp,sp,16
    4d1c:	8082                	ret
  return 0;
    4d1e:	4501                	li	a0,0
    4d20:	bfdd                	j	4d16 <strchr+0x1c>

0000000000004d22 <gets>:

char*
gets(char *buf, int max)
{
    4d22:	711d                	addi	sp,sp,-96
    4d24:	ec86                	sd	ra,88(sp)
    4d26:	e8a2                	sd	s0,80(sp)
    4d28:	e4a6                	sd	s1,72(sp)
    4d2a:	e0ca                	sd	s2,64(sp)
    4d2c:	fc4e                	sd	s3,56(sp)
    4d2e:	f852                	sd	s4,48(sp)
    4d30:	f456                	sd	s5,40(sp)
    4d32:	f05a                	sd	s6,32(sp)
    4d34:	ec5e                	sd	s7,24(sp)
    4d36:	e862                	sd	s8,16(sp)
    4d38:	1080                	addi	s0,sp,96
    4d3a:	8baa                	mv	s7,a0
    4d3c:	8a2e                	mv	s4,a1
  int i, cc;
  char c;

  for(i=0; i+1 < max; ){
    4d3e:	892a                	mv	s2,a0
    4d40:	4481                	li	s1,0
    cc = read(0, &c, 1);
    4d42:	faf40b13          	addi	s6,s0,-81
    4d46:	4a85                	li	s5,1
  for(i=0; i+1 < max; ){
    4d48:	8c26                	mv	s8,s1
    4d4a:	0014899b          	addiw	s3,s1,1
    4d4e:	84ce                	mv	s1,s3
    4d50:	0349d463          	bge	s3,s4,4d78 <gets+0x56>
    cc = read(0, &c, 1);
    4d54:	8656                	mv	a2,s5
    4d56:	85da                	mv	a1,s6
    4d58:	4501                	li	a0,0
    4d5a:	1bc000ef          	jal	4f16 <read>
    if(cc < 1)
    4d5e:	00a05d63          	blez	a0,4d78 <gets+0x56>
      break;
    buf[i++] = c;
    4d62:	faf44783          	lbu	a5,-81(s0)
    4d66:	00f90023          	sb	a5,0(s2)
    if(c == '\n' || c == '\r')
    4d6a:	0905                	addi	s2,s2,1
    4d6c:	ff678713          	addi	a4,a5,-10
    4d70:	c319                	beqz	a4,4d76 <gets+0x54>
    4d72:	17cd                	addi	a5,a5,-13
    4d74:	fbf1                	bnez	a5,4d48 <gets+0x26>
    buf[i++] = c;
    4d76:	8c4e                	mv	s8,s3
      break;
  }
  buf[i] = '\0';
    4d78:	9c5e                	add	s8,s8,s7
    4d7a:	000c0023          	sb	zero,0(s8)
  return buf;
}
    4d7e:	855e                	mv	a0,s7
    4d80:	60e6                	ld	ra,88(sp)
    4d82:	6446                	ld	s0,80(sp)
    4d84:	64a6                	ld	s1,72(sp)
    4d86:	6906                	ld	s2,64(sp)
    4d88:	79e2                	ld	s3,56(sp)
    4d8a:	7a42                	ld	s4,48(sp)
    4d8c:	7aa2                	ld	s5,40(sp)
    4d8e:	7b02                	ld	s6,32(sp)
    4d90:	6be2                	ld	s7,24(sp)
    4d92:	6c42                	ld	s8,16(sp)
    4d94:	6125                	addi	sp,sp,96
    4d96:	8082                	ret

0000000000004d98 <stat>:

int
stat(const char *n, struct stat *st)
{
    4d98:	1101                	addi	sp,sp,-32
    4d9a:	ec06                	sd	ra,24(sp)
    4d9c:	e822                	sd	s0,16(sp)
    4d9e:	e04a                	sd	s2,0(sp)
    4da0:	1000                	addi	s0,sp,32
    4da2:	892e                	mv	s2,a1
  int fd;
  int r;

  fd = open(n, O_RDONLY);
    4da4:	4581                	li	a1,0
    4da6:	198000ef          	jal	4f3e <open>
  if(fd < 0)
    4daa:	02054263          	bltz	a0,4dce <stat+0x36>
    4dae:	e426                	sd	s1,8(sp)
    4db0:	84aa                	mv	s1,a0
    return -1;
  r = fstat(fd, st);
    4db2:	85ca                	mv	a1,s2
    4db4:	1a2000ef          	jal	4f56 <fstat>
    4db8:	892a                	mv	s2,a0
  close(fd);
    4dba:	8526                	mv	a0,s1
    4dbc:	16a000ef          	jal	4f26 <close>
  return r;
    4dc0:	64a2                	ld	s1,8(sp)
}
    4dc2:	854a                	mv	a0,s2
    4dc4:	60e2                	ld	ra,24(sp)
    4dc6:	6442                	ld	s0,16(sp)
    4dc8:	6902                	ld	s2,0(sp)
    4dca:	6105                	addi	sp,sp,32
    4dcc:	8082                	ret
    return -1;
    4dce:	57fd                	li	a5,-1
    4dd0:	893e                	mv	s2,a5
    4dd2:	bfc5                	j	4dc2 <stat+0x2a>

0000000000004dd4 <atoi>:

int
atoi(const char *s)
{
    4dd4:	1141                	addi	sp,sp,-16
    4dd6:	e406                	sd	ra,8(sp)
    4dd8:	e022                	sd	s0,0(sp)
    4dda:	0800                	addi	s0,sp,16
  int n;

  n = 0;
  while('0' <= *s && *s <= '9')
    4ddc:	00054683          	lbu	a3,0(a0)
    4de0:	fd06879b          	addiw	a5,a3,-48 # 3ffd0 <base+0x31328>
    4de4:	0ff7f793          	zext.b	a5,a5
    4de8:	4625                	li	a2,9
    4dea:	02f66963          	bltu	a2,a5,4e1c <atoi+0x48>
    4dee:	872a                	mv	a4,a0
  n = 0;
    4df0:	4501                	li	a0,0
    n = n*10 + *s++ - '0';
    4df2:	0705                	addi	a4,a4,1 # 1000001 <base+0xff1359>
    4df4:	0025179b          	slliw	a5,a0,0x2
    4df8:	9fa9                	addw	a5,a5,a0
    4dfa:	0017979b          	slliw	a5,a5,0x1
    4dfe:	9fb5                	addw	a5,a5,a3
    4e00:	fd07851b          	addiw	a0,a5,-48
  while('0' <= *s && *s <= '9')
    4e04:	00074683          	lbu	a3,0(a4)
    4e08:	fd06879b          	addiw	a5,a3,-48
    4e0c:	0ff7f793          	zext.b	a5,a5
    4e10:	fef671e3          	bgeu	a2,a5,4df2 <atoi+0x1e>
  return n;
}
    4e14:	60a2                	ld	ra,8(sp)
    4e16:	6402                	ld	s0,0(sp)
    4e18:	0141                	addi	sp,sp,16
    4e1a:	8082                	ret
  n = 0;
    4e1c:	4501                	li	a0,0
    4e1e:	bfdd                	j	4e14 <atoi+0x40>

0000000000004e20 <memmove>:

void*
memmove(void *vdst, const void *vsrc, int n)
{
    4e20:	1141                	addi	sp,sp,-16
    4e22:	e406                	sd	ra,8(sp)
    4e24:	e022                	sd	s0,0(sp)
    4e26:	0800                	addi	s0,sp,16
  char *dst;
  const char *src;

  dst = vdst;
  src = vsrc;
  if (src > dst) {
    4e28:	02b57563          	bgeu	a0,a1,4e52 <memmove+0x32>
    while(n-- > 0)
    4e2c:	00c05f63          	blez	a2,4e4a <memmove+0x2a>
    4e30:	1602                	slli	a2,a2,0x20
    4e32:	9201                	srli	a2,a2,0x20
    4e34:	00c507b3          	add	a5,a0,a2
  dst = vdst;
    4e38:	872a                	mv	a4,a0
      *dst++ = *src++;
    4e3a:	0585                	addi	a1,a1,1
    4e3c:	0705                	addi	a4,a4,1
    4e3e:	fff5c683          	lbu	a3,-1(a1)
    4e42:	fed70fa3          	sb	a3,-1(a4)
    while(n-- > 0)
    4e46:	fee79ae3          	bne	a5,a4,4e3a <memmove+0x1a>
    src += n;
    while(n-- > 0)
      *--dst = *--src;
  }
  return vdst;
}
    4e4a:	60a2                	ld	ra,8(sp)
    4e4c:	6402                	ld	s0,0(sp)
    4e4e:	0141                	addi	sp,sp,16
    4e50:	8082                	ret
    while(n-- > 0)
    4e52:	fec05ce3          	blez	a2,4e4a <memmove+0x2a>
    dst += n;
    4e56:	00c50733          	add	a4,a0,a2
    src += n;
    4e5a:	95b2                	add	a1,a1,a2
    4e5c:	fff6079b          	addiw	a5,a2,-1
    4e60:	1782                	slli	a5,a5,0x20
    4e62:	9381                	srli	a5,a5,0x20
    4e64:	fff7c793          	not	a5,a5
    4e68:	97ba                	add	a5,a5,a4
      *--dst = *--src;
    4e6a:	15fd                	addi	a1,a1,-1
    4e6c:	177d                	addi	a4,a4,-1
    4e6e:	0005c683          	lbu	a3,0(a1)
    4e72:	00d70023          	sb	a3,0(a4)
    while(n-- > 0)
    4e76:	fef71ae3          	bne	a4,a5,4e6a <memmove+0x4a>
    4e7a:	bfc1                	j	4e4a <memmove+0x2a>

0000000000004e7c <memcmp>:

int
memcmp(const void *s1, const void *s2, uint n)
{
    4e7c:	1141                	addi	sp,sp,-16
    4e7e:	e406                	sd	ra,8(sp)
    4e80:	e022                	sd	s0,0(sp)
    4e82:	0800                	addi	s0,sp,16
  const char *p1 = s1, *p2 = s2;
  while (n-- > 0) {
    4e84:	c61d                	beqz	a2,4eb2 <memcmp+0x36>
    4e86:	1602                	slli	a2,a2,0x20
    4e88:	9201                	srli	a2,a2,0x20
    4e8a:	00c506b3          	add	a3,a0,a2
    if (*p1 != *p2) {
    4e8e:	00054783          	lbu	a5,0(a0)
    4e92:	0005c703          	lbu	a4,0(a1)
    4e96:	00e79863          	bne	a5,a4,4ea6 <memcmp+0x2a>
      return *p1 - *p2;
    }
    p1++;
    4e9a:	0505                	addi	a0,a0,1
    p2++;
    4e9c:	0585                	addi	a1,a1,1
  while (n-- > 0) {
    4e9e:	fed518e3          	bne	a0,a3,4e8e <memcmp+0x12>
  }
  return 0;
    4ea2:	4501                	li	a0,0
    4ea4:	a019                	j	4eaa <memcmp+0x2e>
      return *p1 - *p2;
    4ea6:	40e7853b          	subw	a0,a5,a4
}
    4eaa:	60a2                	ld	ra,8(sp)
    4eac:	6402                	ld	s0,0(sp)
    4eae:	0141                	addi	sp,sp,16
    4eb0:	8082                	ret
  return 0;
    4eb2:	4501                	li	a0,0
    4eb4:	bfdd                	j	4eaa <memcmp+0x2e>

0000000000004eb6 <memcpy>:

void *
memcpy(void *dst, const void *src, uint n)
{
    4eb6:	1141                	addi	sp,sp,-16
    4eb8:	e406                	sd	ra,8(sp)
    4eba:	e022                	sd	s0,0(sp)
    4ebc:	0800                	addi	s0,sp,16
  return memmove(dst, src, n);
    4ebe:	f63ff0ef          	jal	4e20 <memmove>
}
    4ec2:	60a2                	ld	ra,8(sp)
    4ec4:	6402                	ld	s0,0(sp)
    4ec6:	0141                	addi	sp,sp,16
    4ec8:	8082                	ret

0000000000004eca <sbrk>:

char *
sbrk(int n) {
    4eca:	1141                	addi	sp,sp,-16
    4ecc:	e406                	sd	ra,8(sp)
    4ece:	e022                	sd	s0,0(sp)
    4ed0:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_EAGER);
    4ed2:	4585                	li	a1,1
    4ed4:	0b2000ef          	jal	4f86 <sys_sbrk>
}
    4ed8:	60a2                	ld	ra,8(sp)
    4eda:	6402                	ld	s0,0(sp)
    4edc:	0141                	addi	sp,sp,16
    4ede:	8082                	ret

0000000000004ee0 <sbrklazy>:

char *
sbrklazy(int n) {
    4ee0:	1141                	addi	sp,sp,-16
    4ee2:	e406                	sd	ra,8(sp)
    4ee4:	e022                	sd	s0,0(sp)
    4ee6:	0800                	addi	s0,sp,16
  return sys_sbrk(n, SBRK_LAZY);
    4ee8:	4589                	li	a1,2
    4eea:	09c000ef          	jal	4f86 <sys_sbrk>
}
    4eee:	60a2                	ld	ra,8(sp)
    4ef0:	6402                	ld	s0,0(sp)
    4ef2:	0141                	addi	sp,sp,16
    4ef4:	8082                	ret

0000000000004ef6 <fork>:
# generated by usys.pl - do not edit
#include "kernel/syscall.h"
.global fork
fork:
 li a7, SYS_fork
    4ef6:	4885                	li	a7,1
 ecall
    4ef8:	00000073          	ecall
 ret
    4efc:	8082                	ret

0000000000004efe <exit>:
.global exit
exit:
 li a7, SYS_exit
    4efe:	4889                	li	a7,2
 ecall
    4f00:	00000073          	ecall
 ret
    4f04:	8082                	ret

0000000000004f06 <wait>:
.global wait
wait:
 li a7, SYS_wait
    4f06:	488d                	li	a7,3
 ecall
    4f08:	00000073          	ecall
 ret
    4f0c:	8082                	ret

0000000000004f0e <pipe>:
.global pipe
pipe:
 li a7, SYS_pipe
    4f0e:	4891                	li	a7,4
 ecall
    4f10:	00000073          	ecall
 ret
    4f14:	8082                	ret

0000000000004f16 <read>:
.global read
read:
 li a7, SYS_read
    4f16:	4895                	li	a7,5
 ecall
    4f18:	00000073          	ecall
 ret
    4f1c:	8082                	ret

0000000000004f1e <write>:
.global write
write:
 li a7, SYS_write
    4f1e:	48c1                	li	a7,16
 ecall
    4f20:	00000073          	ecall
 ret
    4f24:	8082                	ret

0000000000004f26 <close>:
.global close
close:
 li a7, SYS_close
    4f26:	48d5                	li	a7,21
 ecall
    4f28:	00000073          	ecall
 ret
    4f2c:	8082                	ret

0000000000004f2e <kill>:
.global kill
kill:
 li a7, SYS_kill
    4f2e:	4899                	li	a7,6
 ecall
    4f30:	00000073          	ecall
 ret
    4f34:	8082                	ret

0000000000004f36 <exec>:
.global exec
exec:
 li a7, SYS_exec
    4f36:	489d                	li	a7,7
 ecall
    4f38:	00000073          	ecall
 ret
    4f3c:	8082                	ret

0000000000004f3e <open>:
.global open
open:
 li a7, SYS_open
    4f3e:	48bd                	li	a7,15
 ecall
    4f40:	00000073          	ecall
 ret
    4f44:	8082                	ret

0000000000004f46 <mknod>:
.global mknod
mknod:
 li a7, SYS_mknod
    4f46:	48c5                	li	a7,17
 ecall
    4f48:	00000073          	ecall
 ret
    4f4c:	8082                	ret

0000000000004f4e <unlink>:
.global unlink
unlink:
 li a7, SYS_unlink
    4f4e:	48c9                	li	a7,18
 ecall
    4f50:	00000073          	ecall
 ret
    4f54:	8082                	ret

0000000000004f56 <fstat>:
.global fstat
fstat:
 li a7, SYS_fstat
    4f56:	48a1                	li	a7,8
 ecall
    4f58:	00000073          	ecall
 ret
    4f5c:	8082                	ret

0000000000004f5e <link>:
.global link
link:
 li a7, SYS_link
    4f5e:	48cd                	li	a7,19
 ecall
    4f60:	00000073          	ecall
 ret
    4f64:	8082                	ret

0000000000004f66 <mkdir>:
.global mkdir
mkdir:
 li a7, SYS_mkdir
    4f66:	48d1                	li	a7,20
 ecall
    4f68:	00000073          	ecall
 ret
    4f6c:	8082                	ret

0000000000004f6e <chdir>:
.global chdir
chdir:
 li a7, SYS_chdir
    4f6e:	48a5                	li	a7,9
 ecall
    4f70:	00000073          	ecall
 ret
    4f74:	8082                	ret

0000000000004f76 <dup>:
.global dup
dup:
 li a7, SYS_dup
    4f76:	48a9                	li	a7,10
 ecall
    4f78:	00000073          	ecall
 ret
    4f7c:	8082                	ret

0000000000004f7e <getpid>:
.global getpid
getpid:
 li a7, SYS_getpid
    4f7e:	48ad                	li	a7,11
 ecall
    4f80:	00000073          	ecall
 ret
    4f84:	8082                	ret

0000000000004f86 <sys_sbrk>:
.global sys_sbrk
sys_sbrk:
 li a7, SYS_sbrk
    4f86:	48b1                	li	a7,12
 ecall
    4f88:	00000073          	ecall
 ret
    4f8c:	8082                	ret

0000000000004f8e <pause>:
.global pause
pause:
 li a7, SYS_pause
    4f8e:	48b5                	li	a7,13
 ecall
    4f90:	00000073          	ecall
 ret
    4f94:	8082                	ret

0000000000004f96 <uptime>:
.global uptime
uptime:
 li a7, SYS_uptime
    4f96:	48b9                	li	a7,14
 ecall
    4f98:	00000073          	ecall
 ret
    4f9c:	8082                	ret

0000000000004f9e <shm_create>:
.global shm_create
shm_create:
 li a7, SYS_shm_create
    4f9e:	48d9                	li	a7,22
 ecall
    4fa0:	00000073          	ecall
 ret
    4fa4:	8082                	ret

0000000000004fa6 <shm_get>:
.global shm_get
shm_get:
 li a7, SYS_shm_get
    4fa6:	48dd                	li	a7,23
 ecall
    4fa8:	00000073          	ecall
 ret
    4fac:	8082                	ret

0000000000004fae <shm_close>:
.global shm_close
shm_close:
 li a7, SYS_shm_close
    4fae:	48e1                	li	a7,24
 ecall
    4fb0:	00000073          	ecall
 ret
    4fb4:	8082                	ret

0000000000004fb6 <mbox_create>:
.global mbox_create
mbox_create:
 li a7, SYS_mbox_create
    4fb6:	48e5                	li	a7,25
 ecall
    4fb8:	00000073          	ecall
 ret
    4fbc:	8082                	ret

0000000000004fbe <mbox_send>:
.global mbox_send
mbox_send:
 li a7, SYS_mbox_send
    4fbe:	48e9                	li	a7,26
 ecall
    4fc0:	00000073          	ecall
 ret
    4fc4:	8082                	ret

0000000000004fc6 <mbox_recv>:
.global mbox_recv
mbox_recv:
 li a7, SYS_mbox_recv
    4fc6:	48ed                	li	a7,27
 ecall
    4fc8:	00000073          	ecall
 ret
    4fcc:	8082                	ret

0000000000004fce <va2pa>:
.global va2pa
va2pa:
 li a7, SYS_va2pa
    4fce:	48f1                	li	a7,28
 ecall
    4fd0:	00000073          	ecall
 ret
    4fd4:	8082                	ret

0000000000004fd6 <putc>:

static char digits[] = "0123456789ABCDEF";

static void
putc(int fd, char c)
{
    4fd6:	1101                	addi	sp,sp,-32
    4fd8:	ec06                	sd	ra,24(sp)
    4fda:	e822                	sd	s0,16(sp)
    4fdc:	1000                	addi	s0,sp,32
    4fde:	feb407a3          	sb	a1,-17(s0)
  write(fd, &c, 1);
    4fe2:	4605                	li	a2,1
    4fe4:	fef40593          	addi	a1,s0,-17
    4fe8:	f37ff0ef          	jal	4f1e <write>
}
    4fec:	60e2                	ld	ra,24(sp)
    4fee:	6442                	ld	s0,16(sp)
    4ff0:	6105                	addi	sp,sp,32
    4ff2:	8082                	ret

0000000000004ff4 <printint>:

static void
printint(int fd, long long xx, int base, int sgn)
{
    4ff4:	715d                	addi	sp,sp,-80
    4ff6:	e486                	sd	ra,72(sp)
    4ff8:	e0a2                	sd	s0,64(sp)
    4ffa:	f84a                	sd	s2,48(sp)
    4ffc:	f44e                	sd	s3,40(sp)
    4ffe:	0880                	addi	s0,sp,80
    5000:	892a                	mv	s2,a0
  char buf[20];
  int i, neg;
  uint x;

  neg = 0;
  if(sgn && xx < 0){
    5002:	cac1                	beqz	a3,5092 <printint+0x9e>
    5004:	0805d763          	bgez	a1,5092 <printint+0x9e>
    neg = 1;
    x = -xx;
    5008:	40b005bb          	negw	a1,a1
    neg = 1;
    500c:	4305                	li	t1,1
  } else {
    x = xx;
  }

  i = 0;
    500e:	fb840993          	addi	s3,s0,-72
  neg = 0;
    5012:	86ce                	mv	a3,s3
  i = 0;
    5014:	4701                	li	a4,0
  do{
    buf[i++] = digits[x % base];
    5016:	00003817          	auipc	a6,0x3
    501a:	a4a80813          	addi	a6,a6,-1462 # 7a60 <digits>
    501e:	88ba                	mv	a7,a4
    5020:	0017051b          	addiw	a0,a4,1
    5024:	872a                	mv	a4,a0
    5026:	02c5f7bb          	remuw	a5,a1,a2
    502a:	1782                	slli	a5,a5,0x20
    502c:	9381                	srli	a5,a5,0x20
    502e:	97c2                	add	a5,a5,a6
    5030:	0007c783          	lbu	a5,0(a5)
    5034:	00f68023          	sb	a5,0(a3)
  }while((x /= base) != 0);
    5038:	87ae                	mv	a5,a1
    503a:	02c5d5bb          	divuw	a1,a1,a2
    503e:	0685                	addi	a3,a3,1
    5040:	fcc7ffe3          	bgeu	a5,a2,501e <printint+0x2a>
  if(neg)
    5044:	00030c63          	beqz	t1,505c <printint+0x68>
    buf[i++] = '-';
    5048:	fd050793          	addi	a5,a0,-48
    504c:	00878533          	add	a0,a5,s0
    5050:	02d00793          	li	a5,45
    5054:	fef50423          	sb	a5,-24(a0)
    5058:	0028871b          	addiw	a4,a7,2

  while(--i >= 0)
    505c:	02e05563          	blez	a4,5086 <printint+0x92>
    5060:	fc26                	sd	s1,56(sp)
    5062:	377d                	addiw	a4,a4,-1
    5064:	00e984b3          	add	s1,s3,a4
    5068:	19fd                	addi	s3,s3,-1 # fff <bigdir+0x107>
    506a:	99ba                	add	s3,s3,a4
    506c:	1702                	slli	a4,a4,0x20
    506e:	9301                	srli	a4,a4,0x20
    5070:	40e989b3          	sub	s3,s3,a4
    putc(fd, buf[i]);
    5074:	0004c583          	lbu	a1,0(s1)
    5078:	854a                	mv	a0,s2
    507a:	f5dff0ef          	jal	4fd6 <putc>
  while(--i >= 0)
    507e:	14fd                	addi	s1,s1,-1
    5080:	ff349ae3          	bne	s1,s3,5074 <printint+0x80>
    5084:	74e2                	ld	s1,56(sp)
}
    5086:	60a6                	ld	ra,72(sp)
    5088:	6406                	ld	s0,64(sp)
    508a:	7942                	ld	s2,48(sp)
    508c:	79a2                	ld	s3,40(sp)
    508e:	6161                	addi	sp,sp,80
    5090:	8082                	ret
    x = xx;
    5092:	2581                	sext.w	a1,a1
  neg = 0;
    5094:	4301                	li	t1,0
    5096:	bfa5                	j	500e <printint+0x1a>

0000000000005098 <vprintf>:
}

// Print to the given fd. Only understands %d, %x, %p, %c, %s.
void
vprintf(int fd, const char *fmt, va_list ap)
{
    5098:	711d                	addi	sp,sp,-96
    509a:	ec86                	sd	ra,88(sp)
    509c:	e8a2                	sd	s0,80(sp)
    509e:	e4a6                	sd	s1,72(sp)
    50a0:	1080                	addi	s0,sp,96
  char *s;
  int c0, c1, c2, i, state;

  state = 0;
  for(i = 0; fmt[i]; i++){
    50a2:	0005c483          	lbu	s1,0(a1)
    50a6:	22048363          	beqz	s1,52cc <vprintf+0x234>
    50aa:	e0ca                	sd	s2,64(sp)
    50ac:	fc4e                	sd	s3,56(sp)
    50ae:	f852                	sd	s4,48(sp)
    50b0:	f456                	sd	s5,40(sp)
    50b2:	f05a                	sd	s6,32(sp)
    50b4:	ec5e                	sd	s7,24(sp)
    50b6:	e862                	sd	s8,16(sp)
    50b8:	8b2a                	mv	s6,a0
    50ba:	8a2e                	mv	s4,a1
    50bc:	8bb2                	mv	s7,a2
  state = 0;
    50be:	4981                	li	s3,0
  for(i = 0; fmt[i]; i++){
    50c0:	4901                	li	s2,0
    50c2:	4701                	li	a4,0
      if(c0 == '%'){
        state = '%';
      } else {
        putc(fd, c0);
      }
    } else if(state == '%'){
    50c4:	02500a93          	li	s5,37
      c1 = c2 = 0;
      if(c0) c1 = fmt[i+1] & 0xff;
      if(c1) c2 = fmt[i+2] & 0xff;
      if(c0 == 'd'){
    50c8:	06400c13          	li	s8,100
    50cc:	a00d                	j	50ee <vprintf+0x56>
        putc(fd, c0);
    50ce:	85a6                	mv	a1,s1
    50d0:	855a                	mv	a0,s6
    50d2:	f05ff0ef          	jal	4fd6 <putc>
    50d6:	a019                	j	50dc <vprintf+0x44>
    } else if(state == '%'){
    50d8:	03598363          	beq	s3,s5,50fe <vprintf+0x66>
  for(i = 0; fmt[i]; i++){
    50dc:	0019079b          	addiw	a5,s2,1
    50e0:	893e                	mv	s2,a5
    50e2:	873e                	mv	a4,a5
    50e4:	97d2                	add	a5,a5,s4
    50e6:	0007c483          	lbu	s1,0(a5)
    50ea:	1c048a63          	beqz	s1,52be <vprintf+0x226>
    c0 = fmt[i] & 0xff;
    50ee:	0004879b          	sext.w	a5,s1
    if(state == 0){
    50f2:	fe0993e3          	bnez	s3,50d8 <vprintf+0x40>
      if(c0 == '%'){
    50f6:	fd579ce3          	bne	a5,s5,50ce <vprintf+0x36>
        state = '%';
    50fa:	89be                	mv	s3,a5
    50fc:	b7c5                	j	50dc <vprintf+0x44>
      if(c0) c1 = fmt[i+1] & 0xff;
    50fe:	00ea06b3          	add	a3,s4,a4
    5102:	0016c603          	lbu	a2,1(a3)
      if(c1) c2 = fmt[i+2] & 0xff;
    5106:	1c060863          	beqz	a2,52d6 <vprintf+0x23e>
      if(c0 == 'd'){
    510a:	03878763          	beq	a5,s8,5138 <vprintf+0xa0>
        printint(fd, va_arg(ap, int), 10, 1);
      } else if(c0 == 'l' && c1 == 'd'){
    510e:	f9478693          	addi	a3,a5,-108
    5112:	0016b693          	seqz	a3,a3
    5116:	f9c60593          	addi	a1,a2,-100
    511a:	e99d                	bnez	a1,5150 <vprintf+0xb8>
    511c:	ca95                	beqz	a3,5150 <vprintf+0xb8>
        printint(fd, va_arg(ap, uint64), 10, 1);
    511e:	008b8493          	addi	s1,s7,8
    5122:	4685                	li	a3,1
    5124:	4629                	li	a2,10
    5126:	000bb583          	ld	a1,0(s7)
    512a:	855a                	mv	a0,s6
    512c:	ec9ff0ef          	jal	4ff4 <printint>
        i += 1;
    5130:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 1);
    5132:	8ba6                	mv	s7,s1
        // Unknown % sequence.  Print it to draw attention.
        putc(fd, '%');
        putc(fd, c0);
      }

      state = 0;
    5134:	4981                	li	s3,0
    5136:	b75d                	j	50dc <vprintf+0x44>
        printint(fd, va_arg(ap, int), 10, 1);
    5138:	008b8493          	addi	s1,s7,8
    513c:	4685                	li	a3,1
    513e:	4629                	li	a2,10
    5140:	000ba583          	lw	a1,0(s7)
    5144:	855a                	mv	a0,s6
    5146:	eafff0ef          	jal	4ff4 <printint>
    514a:	8ba6                	mv	s7,s1
      state = 0;
    514c:	4981                	li	s3,0
    514e:	b779                	j	50dc <vprintf+0x44>
      if(c1) c2 = fmt[i+2] & 0xff;
    5150:	9752                	add	a4,a4,s4
    5152:	00274583          	lbu	a1,2(a4)
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    5156:	f9460713          	addi	a4,a2,-108
    515a:	00173713          	seqz	a4,a4
    515e:	8f75                	and	a4,a4,a3
    5160:	f9c58513          	addi	a0,a1,-100
    5164:	18051363          	bnez	a0,52ea <vprintf+0x252>
    5168:	18070163          	beqz	a4,52ea <vprintf+0x252>
        printint(fd, va_arg(ap, uint64), 10, 1);
    516c:	008b8493          	addi	s1,s7,8
    5170:	4685                	li	a3,1
    5172:	4629                	li	a2,10
    5174:	000bb583          	ld	a1,0(s7)
    5178:	855a                	mv	a0,s6
    517a:	e7bff0ef          	jal	4ff4 <printint>
        i += 2;
    517e:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 1);
    5180:	8ba6                	mv	s7,s1
      state = 0;
    5182:	4981                	li	s3,0
        i += 2;
    5184:	bfa1                	j	50dc <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 10, 0);
    5186:	008b8493          	addi	s1,s7,8
    518a:	4681                	li	a3,0
    518c:	4629                	li	a2,10
    518e:	000be583          	lwu	a1,0(s7)
    5192:	855a                	mv	a0,s6
    5194:	e61ff0ef          	jal	4ff4 <printint>
    5198:	8ba6                	mv	s7,s1
      state = 0;
    519a:	4981                	li	s3,0
    519c:	b781                	j	50dc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
    519e:	008b8493          	addi	s1,s7,8
    51a2:	4681                	li	a3,0
    51a4:	4629                	li	a2,10
    51a6:	000bb583          	ld	a1,0(s7)
    51aa:	855a                	mv	a0,s6
    51ac:	e49ff0ef          	jal	4ff4 <printint>
        i += 1;
    51b0:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 10, 0);
    51b2:	8ba6                	mv	s7,s1
      state = 0;
    51b4:	4981                	li	s3,0
    51b6:	b71d                	j	50dc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 10, 0);
    51b8:	008b8493          	addi	s1,s7,8
    51bc:	4681                	li	a3,0
    51be:	4629                	li	a2,10
    51c0:	000bb583          	ld	a1,0(s7)
    51c4:	855a                	mv	a0,s6
    51c6:	e2fff0ef          	jal	4ff4 <printint>
        i += 2;
    51ca:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 10, 0);
    51cc:	8ba6                	mv	s7,s1
      state = 0;
    51ce:	4981                	li	s3,0
        i += 2;
    51d0:	b731                	j	50dc <vprintf+0x44>
        printint(fd, va_arg(ap, uint32), 16, 0);
    51d2:	008b8493          	addi	s1,s7,8
    51d6:	4681                	li	a3,0
    51d8:	4641                	li	a2,16
    51da:	000be583          	lwu	a1,0(s7)
    51de:	855a                	mv	a0,s6
    51e0:	e15ff0ef          	jal	4ff4 <printint>
    51e4:	8ba6                	mv	s7,s1
      state = 0;
    51e6:	4981                	li	s3,0
    51e8:	bdd5                	j	50dc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
    51ea:	008b8493          	addi	s1,s7,8
    51ee:	4681                	li	a3,0
    51f0:	4641                	li	a2,16
    51f2:	000bb583          	ld	a1,0(s7)
    51f6:	855a                	mv	a0,s6
    51f8:	dfdff0ef          	jal	4ff4 <printint>
        i += 1;
    51fc:	2905                	addiw	s2,s2,1
        printint(fd, va_arg(ap, uint64), 16, 0);
    51fe:	8ba6                	mv	s7,s1
      state = 0;
    5200:	4981                	li	s3,0
    5202:	bde9                	j	50dc <vprintf+0x44>
        printint(fd, va_arg(ap, uint64), 16, 0);
    5204:	008b8493          	addi	s1,s7,8
    5208:	4681                	li	a3,0
    520a:	4641                	li	a2,16
    520c:	000bb583          	ld	a1,0(s7)
    5210:	855a                	mv	a0,s6
    5212:	de3ff0ef          	jal	4ff4 <printint>
        i += 2;
    5216:	2909                	addiw	s2,s2,2
        printint(fd, va_arg(ap, uint64), 16, 0);
    5218:	8ba6                	mv	s7,s1
      state = 0;
    521a:	4981                	li	s3,0
        i += 2;
    521c:	b5c1                	j	50dc <vprintf+0x44>
    521e:	e466                	sd	s9,8(sp)
        printptr(fd, va_arg(ap, uint64));
    5220:	008b8793          	addi	a5,s7,8
    5224:	8cbe                	mv	s9,a5
    5226:	000bb983          	ld	s3,0(s7)
  putc(fd, '0');
    522a:	03000593          	li	a1,48
    522e:	855a                	mv	a0,s6
    5230:	da7ff0ef          	jal	4fd6 <putc>
  putc(fd, 'x');
    5234:	07800593          	li	a1,120
    5238:	855a                	mv	a0,s6
    523a:	d9dff0ef          	jal	4fd6 <putc>
    523e:	44c1                	li	s1,16
    putc(fd, digits[x >> (sizeof(uint64) * 8 - 4)]);
    5240:	00003b97          	auipc	s7,0x3
    5244:	820b8b93          	addi	s7,s7,-2016 # 7a60 <digits>
    5248:	03c9d793          	srli	a5,s3,0x3c
    524c:	97de                	add	a5,a5,s7
    524e:	0007c583          	lbu	a1,0(a5)
    5252:	855a                	mv	a0,s6
    5254:	d83ff0ef          	jal	4fd6 <putc>
  for (i = 0; i < (sizeof(uint64) * 2); i++, x <<= 4)
    5258:	0992                	slli	s3,s3,0x4
    525a:	34fd                	addiw	s1,s1,-1
    525c:	f4f5                	bnez	s1,5248 <vprintf+0x1b0>
        printptr(fd, va_arg(ap, uint64));
    525e:	8be6                	mv	s7,s9
      state = 0;
    5260:	4981                	li	s3,0
    5262:	6ca2                	ld	s9,8(sp)
    5264:	bda5                	j	50dc <vprintf+0x44>
        putc(fd, va_arg(ap, uint32));
    5266:	008b8493          	addi	s1,s7,8
    526a:	000bc583          	lbu	a1,0(s7)
    526e:	855a                	mv	a0,s6
    5270:	d67ff0ef          	jal	4fd6 <putc>
    5274:	8ba6                	mv	s7,s1
      state = 0;
    5276:	4981                	li	s3,0
    5278:	b595                	j	50dc <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
    527a:	008b8993          	addi	s3,s7,8
    527e:	000bb483          	ld	s1,0(s7)
    5282:	cc91                	beqz	s1,529e <vprintf+0x206>
        for(; *s; s++)
    5284:	0004c583          	lbu	a1,0(s1)
    5288:	c985                	beqz	a1,52b8 <vprintf+0x220>
          putc(fd, *s);
    528a:	855a                	mv	a0,s6
    528c:	d4bff0ef          	jal	4fd6 <putc>
        for(; *s; s++)
    5290:	0485                	addi	s1,s1,1
    5292:	0004c583          	lbu	a1,0(s1)
    5296:	f9f5                	bnez	a1,528a <vprintf+0x1f2>
        if((s = va_arg(ap, char*)) == 0)
    5298:	8bce                	mv	s7,s3
      state = 0;
    529a:	4981                	li	s3,0
    529c:	b581                	j	50dc <vprintf+0x44>
          s = "(null)";
    529e:	00002497          	auipc	s1,0x2
    52a2:	71248493          	addi	s1,s1,1810 # 79b0 <malloc+0x2576>
        for(; *s; s++)
    52a6:	02800593          	li	a1,40
    52aa:	b7c5                	j	528a <vprintf+0x1f2>
        putc(fd, '%');
    52ac:	85be                	mv	a1,a5
    52ae:	855a                	mv	a0,s6
    52b0:	d27ff0ef          	jal	4fd6 <putc>
      state = 0;
    52b4:	4981                	li	s3,0
    52b6:	b51d                	j	50dc <vprintf+0x44>
        if((s = va_arg(ap, char*)) == 0)
    52b8:	8bce                	mv	s7,s3
      state = 0;
    52ba:	4981                	li	s3,0
    52bc:	b505                	j	50dc <vprintf+0x44>
    52be:	6906                	ld	s2,64(sp)
    52c0:	79e2                	ld	s3,56(sp)
    52c2:	7a42                	ld	s4,48(sp)
    52c4:	7aa2                	ld	s5,40(sp)
    52c6:	7b02                	ld	s6,32(sp)
    52c8:	6be2                	ld	s7,24(sp)
    52ca:	6c42                	ld	s8,16(sp)
    }
  }
}
    52cc:	60e6                	ld	ra,88(sp)
    52ce:	6446                	ld	s0,80(sp)
    52d0:	64a6                	ld	s1,72(sp)
    52d2:	6125                	addi	sp,sp,96
    52d4:	8082                	ret
      if(c0 == 'd'){
    52d6:	06400713          	li	a4,100
    52da:	e4e78fe3          	beq	a5,a4,5138 <vprintf+0xa0>
      } else if(c0 == 'l' && c1 == 'd'){
    52de:	f9478693          	addi	a3,a5,-108
    52e2:	0016b693          	seqz	a3,a3
      c1 = c2 = 0;
    52e6:	85b2                	mv	a1,a2
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'd'){
    52e8:	4701                	li	a4,0
      } else if(c0 == 'u'){
    52ea:	07500513          	li	a0,117
    52ee:	e8a78ce3          	beq	a5,a0,5186 <vprintf+0xee>
      } else if(c0 == 'l' && c1 == 'u'){
    52f2:	f8b60513          	addi	a0,a2,-117
    52f6:	e119                	bnez	a0,52fc <vprintf+0x264>
    52f8:	ea0693e3          	bnez	a3,519e <vprintf+0x106>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'u'){
    52fc:	f8b58513          	addi	a0,a1,-117
    5300:	e119                	bnez	a0,5306 <vprintf+0x26e>
    5302:	ea071be3          	bnez	a4,51b8 <vprintf+0x120>
      } else if(c0 == 'x'){
    5306:	07800513          	li	a0,120
    530a:	eca784e3          	beq	a5,a0,51d2 <vprintf+0x13a>
      } else if(c0 == 'l' && c1 == 'x'){
    530e:	f8860613          	addi	a2,a2,-120
    5312:	e219                	bnez	a2,5318 <vprintf+0x280>
    5314:	ec069be3          	bnez	a3,51ea <vprintf+0x152>
      } else if(c0 == 'l' && c1 == 'l' && c2 == 'x'){
    5318:	f8858593          	addi	a1,a1,-120
    531c:	e199                	bnez	a1,5322 <vprintf+0x28a>
    531e:	ee0713e3          	bnez	a4,5204 <vprintf+0x16c>
      } else if(c0 == 'p'){
    5322:	07000713          	li	a4,112
    5326:	eee78ce3          	beq	a5,a4,521e <vprintf+0x186>
      } else if(c0 == 'c'){
    532a:	06300713          	li	a4,99
    532e:	f2e78ce3          	beq	a5,a4,5266 <vprintf+0x1ce>
      } else if(c0 == 's'){
    5332:	07300713          	li	a4,115
    5336:	f4e782e3          	beq	a5,a4,527a <vprintf+0x1e2>
      } else if(c0 == '%'){
    533a:	02500713          	li	a4,37
    533e:	f6e787e3          	beq	a5,a4,52ac <vprintf+0x214>
        putc(fd, '%');
    5342:	02500593          	li	a1,37
    5346:	855a                	mv	a0,s6
    5348:	c8fff0ef          	jal	4fd6 <putc>
        putc(fd, c0);
    534c:	85a6                	mv	a1,s1
    534e:	855a                	mv	a0,s6
    5350:	c87ff0ef          	jal	4fd6 <putc>
      state = 0;
    5354:	4981                	li	s3,0
    5356:	b359                	j	50dc <vprintf+0x44>

0000000000005358 <fprintf>:

void
fprintf(int fd, const char *fmt, ...)
{
    5358:	715d                	addi	sp,sp,-80
    535a:	ec06                	sd	ra,24(sp)
    535c:	e822                	sd	s0,16(sp)
    535e:	1000                	addi	s0,sp,32
    5360:	e010                	sd	a2,0(s0)
    5362:	e414                	sd	a3,8(s0)
    5364:	e818                	sd	a4,16(s0)
    5366:	ec1c                	sd	a5,24(s0)
    5368:	03043023          	sd	a6,32(s0)
    536c:	03143423          	sd	a7,40(s0)
  va_list ap;

  va_start(ap, fmt);
    5370:	8622                	mv	a2,s0
    5372:	fe843423          	sd	s0,-24(s0)
  vprintf(fd, fmt, ap);
    5376:	d23ff0ef          	jal	5098 <vprintf>
}
    537a:	60e2                	ld	ra,24(sp)
    537c:	6442                	ld	s0,16(sp)
    537e:	6161                	addi	sp,sp,80
    5380:	8082                	ret

0000000000005382 <printf>:

void
printf(const char *fmt, ...)
{
    5382:	711d                	addi	sp,sp,-96
    5384:	ec06                	sd	ra,24(sp)
    5386:	e822                	sd	s0,16(sp)
    5388:	1000                	addi	s0,sp,32
    538a:	e40c                	sd	a1,8(s0)
    538c:	e810                	sd	a2,16(s0)
    538e:	ec14                	sd	a3,24(s0)
    5390:	f018                	sd	a4,32(s0)
    5392:	f41c                	sd	a5,40(s0)
    5394:	03043823          	sd	a6,48(s0)
    5398:	03143c23          	sd	a7,56(s0)
  va_list ap;

  va_start(ap, fmt);
    539c:	00840613          	addi	a2,s0,8
    53a0:	fec43423          	sd	a2,-24(s0)
  vprintf(1, fmt, ap);
    53a4:	85aa                	mv	a1,a0
    53a6:	4505                	li	a0,1
    53a8:	cf1ff0ef          	jal	5098 <vprintf>
}
    53ac:	60e2                	ld	ra,24(sp)
    53ae:	6442                	ld	s0,16(sp)
    53b0:	6125                	addi	sp,sp,96
    53b2:	8082                	ret

00000000000053b4 <free>:
static Header base;
static Header *freep;

void
free(void *ap)
{
    53b4:	1141                	addi	sp,sp,-16
    53b6:	e406                	sd	ra,8(sp)
    53b8:	e022                	sd	s0,0(sp)
    53ba:	0800                	addi	s0,sp,16
  Header *bp, *p;

  bp = (Header*)ap - 1;
    53bc:	ff050693          	addi	a3,a0,-16
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    53c0:	00003797          	auipc	a5,0x3
    53c4:	0c07b783          	ld	a5,192(a5) # 8480 <freep>
    53c8:	a039                	j	53d6 <free+0x22>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    53ca:	6398                	ld	a4,0(a5)
    53cc:	00e7e463          	bltu	a5,a4,53d4 <free+0x20>
    53d0:	00e6ea63          	bltu	a3,a4,53e4 <free+0x30>
{
    53d4:	87ba                	mv	a5,a4
  for(p = freep; !(bp > p && bp < p->s.ptr); p = p->s.ptr)
    53d6:	fed7fae3          	bgeu	a5,a3,53ca <free+0x16>
    53da:	6398                	ld	a4,0(a5)
    53dc:	00e6e463          	bltu	a3,a4,53e4 <free+0x30>
    if(p >= p->s.ptr && (bp > p || bp < p->s.ptr))
    53e0:	fee7eae3          	bltu	a5,a4,53d4 <free+0x20>
      break;
  if(bp + bp->s.size == p->s.ptr){
    53e4:	ff852583          	lw	a1,-8(a0)
    53e8:	6390                	ld	a2,0(a5)
    53ea:	02059813          	slli	a6,a1,0x20
    53ee:	01c85713          	srli	a4,a6,0x1c
    53f2:	9736                	add	a4,a4,a3
    53f4:	02e60563          	beq	a2,a4,541e <free+0x6a>
    bp->s.size += p->s.ptr->s.size;
    bp->s.ptr = p->s.ptr->s.ptr;
    53f8:	fec53823          	sd	a2,-16(a0)
  } else
    bp->s.ptr = p->s.ptr;
  if(p + p->s.size == bp){
    53fc:	4790                	lw	a2,8(a5)
    53fe:	02061593          	slli	a1,a2,0x20
    5402:	01c5d713          	srli	a4,a1,0x1c
    5406:	973e                	add	a4,a4,a5
    5408:	02e68263          	beq	a3,a4,542c <free+0x78>
    p->s.size += bp->s.size;
    p->s.ptr = bp->s.ptr;
    540c:	e394                	sd	a3,0(a5)
  } else
    p->s.ptr = bp;
  freep = p;
    540e:	00003717          	auipc	a4,0x3
    5412:	06f73923          	sd	a5,114(a4) # 8480 <freep>
}
    5416:	60a2                	ld	ra,8(sp)
    5418:	6402                	ld	s0,0(sp)
    541a:	0141                	addi	sp,sp,16
    541c:	8082                	ret
    bp->s.size += p->s.ptr->s.size;
    541e:	4618                	lw	a4,8(a2)
    5420:	9f2d                	addw	a4,a4,a1
    5422:	fee52c23          	sw	a4,-8(a0)
    bp->s.ptr = p->s.ptr->s.ptr;
    5426:	6398                	ld	a4,0(a5)
    5428:	6310                	ld	a2,0(a4)
    542a:	b7f9                	j	53f8 <free+0x44>
    p->s.size += bp->s.size;
    542c:	ff852703          	lw	a4,-8(a0)
    5430:	9f31                	addw	a4,a4,a2
    5432:	c798                	sw	a4,8(a5)
    p->s.ptr = bp->s.ptr;
    5434:	ff053683          	ld	a3,-16(a0)
    5438:	bfd1                	j	540c <free+0x58>

000000000000543a <malloc>:
  return freep;
}

void*
malloc(uint nbytes)
{
    543a:	7139                	addi	sp,sp,-64
    543c:	fc06                	sd	ra,56(sp)
    543e:	f822                	sd	s0,48(sp)
    5440:	f04a                	sd	s2,32(sp)
    5442:	ec4e                	sd	s3,24(sp)
    5444:	0080                	addi	s0,sp,64
  Header *p, *prevp;
  uint nunits;

  nunits = (nbytes + sizeof(Header) - 1)/sizeof(Header) + 1;
    5446:	02051993          	slli	s3,a0,0x20
    544a:	0209d993          	srli	s3,s3,0x20
    544e:	09bd                	addi	s3,s3,15
    5450:	0049d993          	srli	s3,s3,0x4
    5454:	2985                	addiw	s3,s3,1
    5456:	894e                	mv	s2,s3
  if((prevp = freep) == 0){
    5458:	00003517          	auipc	a0,0x3
    545c:	02853503          	ld	a0,40(a0) # 8480 <freep>
    5460:	c905                	beqz	a0,5490 <malloc+0x56>
    base.s.ptr = freep = prevp = &base;
    base.s.size = 0;
  }
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    5462:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    5464:	4798                	lw	a4,8(a5)
    5466:	09377663          	bgeu	a4,s3,54f2 <malloc+0xb8>
    546a:	f426                	sd	s1,40(sp)
    546c:	e852                	sd	s4,16(sp)
    546e:	e456                	sd	s5,8(sp)
    5470:	e05a                	sd	s6,0(sp)
  if(nu < 4096)
    5472:	8a4e                	mv	s4,s3
    5474:	6705                	lui	a4,0x1
    5476:	00e9f363          	bgeu	s3,a4,547c <malloc+0x42>
    547a:	6a05                	lui	s4,0x1
    547c:	000a0b1b          	sext.w	s6,s4
  p = sbrk(nu * sizeof(Header));
    5480:	004a1a1b          	slliw	s4,s4,0x4
        p->s.size = nunits;
      }
      freep = prevp;
      return (void*)(p + 1);
    }
    if(p == freep)
    5484:	00003497          	auipc	s1,0x3
    5488:	ffc48493          	addi	s1,s1,-4 # 8480 <freep>
  if(p == SBRK_ERROR)
    548c:	5afd                	li	s5,-1
    548e:	a83d                	j	54cc <malloc+0x92>
    5490:	f426                	sd	s1,40(sp)
    5492:	e852                	sd	s4,16(sp)
    5494:	e456                	sd	s5,8(sp)
    5496:	e05a                	sd	s6,0(sp)
    base.s.ptr = freep = prevp = &base;
    5498:	0000a797          	auipc	a5,0xa
    549c:	81078793          	addi	a5,a5,-2032 # eca8 <base>
    54a0:	00003717          	auipc	a4,0x3
    54a4:	fef73023          	sd	a5,-32(a4) # 8480 <freep>
    54a8:	e39c                	sd	a5,0(a5)
    base.s.size = 0;
    54aa:	0007a423          	sw	zero,8(a5)
    if(p->s.size >= nunits){
    54ae:	b7d1                	j	5472 <malloc+0x38>
        prevp->s.ptr = p->s.ptr;
    54b0:	6398                	ld	a4,0(a5)
    54b2:	e118                	sd	a4,0(a0)
    54b4:	a899                	j	550a <malloc+0xd0>
  hp->s.size = nu;
    54b6:	01652423          	sw	s6,8(a0)
  free((void*)(hp + 1));
    54ba:	0541                	addi	a0,a0,16
    54bc:	ef9ff0ef          	jal	53b4 <free>
  return freep;
    54c0:	6088                	ld	a0,0(s1)
      if((p = morecore(nunits)) == 0)
    54c2:	c125                	beqz	a0,5522 <malloc+0xe8>
  for(p = prevp->s.ptr; ; prevp = p, p = p->s.ptr){
    54c4:	611c                	ld	a5,0(a0)
    if(p->s.size >= nunits){
    54c6:	4798                	lw	a4,8(a5)
    54c8:	03277163          	bgeu	a4,s2,54ea <malloc+0xb0>
    if(p == freep)
    54cc:	6098                	ld	a4,0(s1)
    54ce:	853e                	mv	a0,a5
    54d0:	fef71ae3          	bne	a4,a5,54c4 <malloc+0x8a>
  p = sbrk(nu * sizeof(Header));
    54d4:	8552                	mv	a0,s4
    54d6:	9f5ff0ef          	jal	4eca <sbrk>
  if(p == SBRK_ERROR)
    54da:	fd551ee3          	bne	a0,s5,54b6 <malloc+0x7c>
        return 0;
    54de:	4501                	li	a0,0
    54e0:	74a2                	ld	s1,40(sp)
    54e2:	6a42                	ld	s4,16(sp)
    54e4:	6aa2                	ld	s5,8(sp)
    54e6:	6b02                	ld	s6,0(sp)
    54e8:	a03d                	j	5516 <malloc+0xdc>
    54ea:	74a2                	ld	s1,40(sp)
    54ec:	6a42                	ld	s4,16(sp)
    54ee:	6aa2                	ld	s5,8(sp)
    54f0:	6b02                	ld	s6,0(sp)
      if(p->s.size == nunits)
    54f2:	fae90fe3          	beq	s2,a4,54b0 <malloc+0x76>
        p->s.size -= nunits;
    54f6:	4137073b          	subw	a4,a4,s3
    54fa:	c798                	sw	a4,8(a5)
        p += p->s.size;
    54fc:	02071693          	slli	a3,a4,0x20
    5500:	01c6d713          	srli	a4,a3,0x1c
    5504:	97ba                	add	a5,a5,a4
        p->s.size = nunits;
    5506:	0137a423          	sw	s3,8(a5)
      freep = prevp;
    550a:	00003717          	auipc	a4,0x3
    550e:	f6a73b23          	sd	a0,-138(a4) # 8480 <freep>
      return (void*)(p + 1);
    5512:	01078513          	addi	a0,a5,16
  }
}
    5516:	70e2                	ld	ra,56(sp)
    5518:	7442                	ld	s0,48(sp)
    551a:	7902                	ld	s2,32(sp)
    551c:	69e2                	ld	s3,24(sp)
    551e:	6121                	addi	sp,sp,64
    5520:	8082                	ret
    5522:	74a2                	ld	s1,40(sp)
    5524:	6a42                	ld	s4,16(sp)
    5526:	6aa2                	ld	s5,8(sp)
    5528:	6b02                	ld	s6,0(sp)
    552a:	b7f5                	j	5516 <malloc+0xdc>
